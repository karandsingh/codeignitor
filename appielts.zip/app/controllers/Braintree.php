<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Member controller
* this controller is related to specific user role
*/
class Braintree extends AKAAL_Controller {

    public function __construct() {
        parent::__construct();
 
        $this->load->library('facebook');
        $this->load->model('my_model');

        require_once APPPATH.'third_party/src/Google_Client.php';
        require_once APPPATH.'third_party/src/contrib/Google_Oauth2Service.php';
        
        $this->data['currentAccount'] = 'logger_member';
        $this->data['currentPath'] = 'member';


        $this->config->load('akaal');
        $this->data['number_of_visible_questions'] = $this->config->item('number_of_visible_questions');
        
        // table name of specific user role; which is related to this controller only
        $this->tb_name = $this->tb_member;
        $this->data['rn'] = random_string('nozero',8);
    }

    function braintree_token()
    {
      $braintreeToken = file_get_contents('https://app.ielts24x7.com/braintree_example/index.php');
      echo $braintreeToken; 
    }
    
    function paymentApi()
    {
        $NONCE = $_POST['NONCE'];
        $amount = $_POST['amount'];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"https://app.ielts24x7.com/braintree_example/index.php");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,
        "NONCE=".$NONCE."&amount=".$amount."");
        
        $result = curl_exec($ch);
        curl_close($ch); 
    }
}