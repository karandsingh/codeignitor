<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Member controller
* this controller is related to specific user role
*/
class Teacher extends AKAAL_Controller {

    public function __construct() {
        parent::__construct();
 
        $this->data['currentAccount'] = 'logger_teacher';
        $this->data['currentPath'] = 'teacher';

        $this->config->load('akaal');
        $this->data['number_of_teachers_for_checking'] = $this->config->item('number_of_teachers_for_checking');
        
        // table name of specific user role; which is related to this controller only
        $this->tb_name = 'system_teacher_code';
    }

    function index() {

        $this->login();
    }

    function login() {
        // check website session, if enabled
        if( $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $this->load->model('my_model');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_isValidUser');
            $this->form_validation->set_rules('g-recaptcha-response', 'recaptcha', 'trim|required|xss_clean|callback_checkRecaptcha');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }

        $this->data['title'] = '<a href="'.base_url('/'.$this->data['currentPath'].'/login').'">Teacher Login</a>';

        $this->data['custom_url'] = 'https://ielts24x7.com';

        $window_title = 'Teacher Login - ' . $this->app_name;

        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );
        $this->data['pagetitle'] = 'Teacher Login';

        $this->data['formAction'] = $this->uri->segment(1). '/' . $this->uri->segment(2);
        $this->load->view('shared/login', $this->data);
    }

    function isValidUser($password) {
        //Field validation succeeded.  Validate against database
        $username = $this->input->post('username');
        $result = $this->my_model->getUser($this->tb_name, $username, $password);

        if($result)
        {
            $session_array = array();
            foreach($result as $row)
            {
                $session_array = array(
                    'id' => $row->id,
                    'name' => $row->name,
                );

                $this->session->set_userdata($this->data['currentAccount'], $session_array);
            }
            return true;
        }
        else
        {
            $this->form_validation->set_message('isValidUser', 'Invalid username or password');
            return false;
        }
    }

    function logout() {
        // Make sure you destory website session as well.
        $this->session->unset_userdata($this->data['currentAccount']);
        $this->session->sess_destroy();
        // Finally redirect page to desire location
        redirect('teacher');
    }

    function verifyUser() {

        // check login
        $this->logged = is_user_logged_in(
            $this->data['currentAccount'],
            $this->data['currentPath']
        );

        $this->data['user'] = $this->my_model->getARecord($this->tb_name, $this->logged['id']);
        $this->data['role'] = $this->my_model->getARecord($this->tb_role, $this->data['user']->role_id);

        // checks for valid user get or not
        if( !is_object($this->data['user'])) { return false; }

        $this->data['country'] = $this->my_model->getARecord($this->tb_countries, $this->data['user']->country_id);
    }



    function questionType() {
        $this->verifyUser();

        $this->data['window_title']="Select Question Type";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Question';

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function wtTaskList(){
        $this->verifyUser();
        $this->data['window_title']="Task1 : writing an email";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task1 : writing an email';

        $where = "added_by = '".$this->logged['id']."' AND role = 'teacher' AND status = '0' " ;
        $this->data['wtpart_list'] = $this->my_model->getWhereRecords('system_writing_task1_code', $where);
        
        //echo "<pre>";print_r($this->data['wtpart_list']);die;
        $this->data['total_wtpart'] = count($this->data['wtpart_list']);
        $this->load->view('teacher/writing_task1_listing', $this->data);
    }

    function wtTask2List(){
        $this->verifyUser();
        $this->data['window_title']="Task 2: Responding to Survey Questions";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task 2: Responding to Survey Questions';

        $where = "added_by = '".$this->logged['id']."' AND role = 'teacher' AND status = '0' " ;
        $this->data['wtpart_list'] = $this->my_model->getWhereRecords('system_writing_task2_code', $where);
        
        //echo "<pre>";print_r($this->data['wtpart_list']);die;
        $this->data['total_wtpart'] = count($this->data['wtpart_list']);
        $this->load->view('teacher/writing_task2_listing', $this->data);
    }

    function reviewQuestions($id){
        $this->verifyUser();
        
        if(!is_numeric($id)){ return false; }
           
     
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['test_heading'] = $this->my_model->getARecord("system_PTEsubtype_code",$id); 

        $where = "test_id = '".$id."' AND is_attempt = '1' AND test_check_status = '2' " ;
        $this->data['questions'] = $this->my_model->getWhereRecords('system_testdetails_code', $where);

        //echo "<pre>"; print_r($this->data['questions']);
        
        //echo "<pre>";print_r($this->data['wtpart_list']);die;
        $this->data['total_wtpart'] = count($this->data['wtpart_list']);
        $this->load->view('teacher/review_question_listing', $this->data);
    }

    function reviewedQuestions(){
        $this->verifyUser();
        
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $where = "teacher_id = '".$this->logged['id']."'  " ;
        $this->data['reviewed'] = $this->my_model->getWhereRecords('system_marks_code', $where);
        
        //echo "<pre>";print_r($this->data['wtpart_list']);die;
        $this->data['total_wtpart'] = count($this->data['wtpart_list']);
        $this->load->view('teacher/reviewed_questions', $this->data);
    }

	 function getfile($image_path)
	 {
     require 'aws-s3-bucket/vendor/autoload.php';

  
    $BUCKET_NAME = 'celpipstore-media-files';
    $IAM_KEY = 'AKIA323GRW63FBO3HGTM';
    $IAM_SECRET = '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';
    
    
    $this->load->library('S3'); //load S3 library

    //S3 connection 
    $s3 = new Aws\S3\S3Client(
    array(
    'credentials' => array(
    'key' => $IAM_KEY,
    'secret' => $IAM_SECRET
    ),
    'version' => 'latest',
    'region'  => 'us-west-2'
    )
    );
    $keyPath = 'ielts/uploads/'.$image_path; // file name(can also include the folder name and the file name. eg."member1/IoT-Arduino-Monitor-circuit.png")
    //S3 connection 
    $fileName = $image_path;
    
    $command = $s3->getCommand('GetObject', array(
    'Bucket'      => $BUCKET_NAME,
    'Key'         => $keyPath,
    'ContentType' => 'image/png/mp3/mp4/audio/mpeg',
    'ResponseContentDisposition' => 'attachment; filename="'.$fileName.'"'
    ));
    $signedUrl = $s3->createPresignedRequest($command, "+6 days"); 
    // Create a signed URL from the command object that will last for
    // 6 days from the current time
    $presignedUrl = (string)$signedUrl->getUri();
   // echo file_get_contents($presignedUrl);
       $data['message']   = "sucess";
       $data['imageurl'] = $presignedUrl;
             return $data;

 }

    function answerDetails($id){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $id);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        # coins set for this part
        $coins = $this->my_model->getARecord("system_PTEsubtype_code",$this->data['testdetail']->test_id); 
        $coins_set = $coins->coin_cost;
        //print_r($coins_set);


        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->my_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }
        
       // print_r( $this->data['attempt']);die;
       
       $folder="ielts";

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        
        if($this->data['attempt']->testid==6 and $this->data['attempt']->subtypeid==62){
         $audio1 = $this->data['attempt_data']['response_data'][0][sp_response_file1];
         $audio2 = $this->data['attempt_data']['response_data'][1][sp_response_file2];
         $audio3 = $this->data['attempt_data']['response_data'][2][sp_response_file3];
         $audio4 = $this->data['attempt_data']['response_data'][3][sp_response_file4];
         $audio5 = $this->data['attempt_data']['response_data'][4][sp_response_file5];
         
         
     
         if(!empty($audio1)){
             $fetch= $this->getfile($audio1);        
            $this->data['s3audio1']=$fetch['imageurl'];
             
         }if(!empty($audio2)){
             $fetch= $this->getfile($audio2);        
            $this->data['s3audio2']=$fetch['imageurl'];
             
         }if(!empty($audio3)){
             $fetch= $this->getfile($audio3);        
            $this->data['s3audio3']=$fetch['imageurl'];
             
         }if(!empty($audio4)){
             $fetch= $this->getfile($audio4);        
            $this->data['s3audio4']=$fetch['imageurl'];
             
         }if(!empty($audio5)){
             $fetch= $this->getfile($audio5);        
            $this->data['s3audio5']=$fetch['imageurl'];
             
         }
        }
        
        if($this->data['attempt']->testid==6 and $this->data['attempt']->subtypeid==63){
         $audio1 = $this->data['attempt_data']['response_data'][0][sp_response_file1];
         $audio2 = $this->data['attempt_data']['response_data'][1][sp_response_file2];
         
         
     
         if(!empty($audio1)){
             $fetch= $this->getfile($audio1);        
            $this->data['s3audio1']=$fetch['imageurl'];
             
         }if(!empty($audio2)){
             $fetch= $this->getfile($audio2);        
            $this->data['s3audio2']=$fetch['imageurl'];
         }
        }
        
           if($this->data['attempt']->testid==6 and $this->data['attempt']->subtypeid==64){
         $audio1 = $this->data['attempt_data']['response_data'][0][sp_response_file1];
         $audio2 = $this->data['attempt_data']['response_data'][1][sp_response_file2];
         $audio3 = $this->data['attempt_data']['response_data'][2][sp_response_file3];
         
         
     
         if(!empty($audio1)){
             $fetch= $this->getfile($audio1);        
            $this->data['s3audio1']=$fetch['imageurl'];
             
         }if(!empty($audio2)){
             $fetch= $this->getfile($audio2);        
            $this->data['s3audio2']=$fetch['imageurl'];
             
         }if(!empty($audio3)){
             $fetch= $this->getfile($audio3);        
            $this->data['s3audio3']=$fetch['imageurl'];
         }
        }
        
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;

        # check marks assigned or not 
        $where = "test_part_id = '".$this->data['testdetail']->test_id."' AND member_id = '".$this->data['testdetail']->member_id."'  AND teacher_id = '".$this->logged['id']."' AND testdetail_idmd5 = '".$this->data['testdetail']->id_md5."' ";
        $this->data['marksAssigned'] = $this->my_model->getWhereRecords("system_marks_code",$where);

        //print_r($this->data['marksAssigned']);


        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {    
            $this->form_validation->set_rules('marks', 'Enter Marks', 'trim|required|xss_clean');
            $this->form_validation->set_rules('remarks', 'Remarks', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'testdetail_idmd5'=>$this->data['testdetail']->id_md5,
                    'test_type' => $this->input->post('test_type'),
                    'test_type_id' => $this->input->post('test_type_id'),
                    'test_code' => $this->input->post('test_code'),
                    'test_part_id' => $this->input->post('test_part_id'),
                    'member_id' => $this->input->post('member_id'),
                    'marks'=>$this->input->post('marks'),
                    'remarks'=>$this->input->post('remarks'),
                    'teacher_id'=> $this->logged['id'],
                    'date' => date('Y-m-d H:i:s')
                    
                );

                if(!empty($this->data['marksAssigned'])){

                    if( $this->my_model->updateTable('system_marks_code', $qryData,$this->data['marksAssigned'][0]->id))
                    {          
                        $this->session->set_flashdata('global_msg', 'Marks updated successfully!!');
                        redirect('teacher/answerDetails/'.$id);
                    }

                }else{ 

                    if( $this->my_model->insertDataIntoTable('system_marks_code', $qryData))
                    {    
                        $updateStatus = array(
                        'test_check_status' => '1',
                        );

                        if($this->my_model->updateTable('system_testdetails_code', $updateStatus,$this->data['testdetail']->id)){

                            # assign 1/4th coins to teacher for checking.

                            $coins_teacher_got = $this->data['user']->coins; 
                            if($coins_set > 0 ){
                                $one_fourth_coins = $coins_set/4;
                                $coins_teacher_got = $this->data['user']->coins + $one_fourth_coins;
                            }

                            $updateCoins = array(
                                'coins' => round($coins_teacher_got,1),
                            );

                            if($this->my_model->updateTable('system_teacher_code', $updateCoins,$this->logged['id'])){

                                $number_of_teachers = $this->data['attempt']->checked_by_teachers + 1;
                                $updatedata = array(
                                    'checked_by_teachers' => $number_of_teachers,
                                    );

                                if($this->my_model->updateTable('system_attempt_code',$updatedata,$this->data['attempt']->id)){

                                    $this->session->set_flashdata('global_msg', 'Marks added successfully!!');
                                }
                            }
                        }
                        
                    }
                    redirect('teacher/answerDetails/'.$id);

                }
                
            }
        }

        
        $this->load->view('teacher/answer-Deatils', $this->data);
    }


    function questions() {
        $this->verifyUser();

        $this->data['pagetitle']="Review Questions";
        $this->data['window_title'] = $this->app_name." ->".$this->data['pagetitle'];

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function wtTask(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_writing_task1_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='W1T'. $next_code;
        }else{
            $this->data['test_code']='W1T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('question', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('essayTitle', 'Email title', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'question_title' => $this->input->post('question'),
                    'email_title' => $this->input->post('essayTitle'),
                    'created_date' => date('Y-m-d H:i:s'),
                    'updated_date' => date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_writing_task1_code', $qryData))
                {          
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '47');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '47');
                    }
                    $this->session->set_flashdata('global_msg', 'Writing Task added successfully!!');
                }
                redirect('teacher/wtTaskList');
            }
        }
        
        $this->data['pagetitle'] = 'Task 1: Writing an Email';
        $this->load->view('teacher/writing_task1',$this->data);
        
    }


    function wtTask2(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_writing_task2_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='W2T'. $next_code;
        }else{
            $this->data['test_code']='W2T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('question', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('option_1', 'Option A', 'trim|required|xss_clean');
            $this->form_validation->set_rules('option_2', 'Option B', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'question_title' => $this->input->post('question'),
                    'option_1' => $this->input->post('option_1'),
                    'option_2' => $this->input->post('option_2'),
                    'created_date' => date('Y-m-d H:i:s'),
                    'updated_date' => date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_writing_task2_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '46');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '46');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Writing Task added successfully!!');
                }
                redirect('teacher/wtTask2List');
            }
        }
        
        $this->data['pagetitle'] = 'Task 2: Responding to Survey Questions';
        $this->load->view('teacher/writing_task2',$this->data);
    }


    function wtTask_edit($id){
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('question', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('essayTitle', 'Email title', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'question_title' => $this->input->post('question'),
                    'email_title' => $this->input->post('essayTitle'),
                    'updated_date' => date('Y-m-d H:i:s')
                );

                if( $this->my_model->updateTable('system_writing_task1_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Writing Task update successfully!!');
                }
                redirect('teacher/wtTaskList');
            }
        }
        
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_writing_task1_code', $where);
        $this->data['pagetitle'] = 'Task 1: Writing an Email';
        $this->load->view('teacher/writing_task1_edit',$this->data);
    }


    function wtTask2_edit($id){
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('question', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('option_1', 'Option A', 'trim|required|xss_clean');
            $this->form_validation->set_rules('option_2', 'Option B', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'question_title' => $this->input->post('question'),
                    'option_1' => $this->input->post('option_1'),
                    'option_2' => $this->input->post('option_2'),
                    'updated_date' => date('Y-m-d H:i:s')
                );

                if( $this->my_model->updateTable('system_writing_task2_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Writing Task update successfully!!');
                }
                redirect('teacher/wtTask2List');
            }
        }
        
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_writing_task2_code', $where);
        $this->data['pagetitle'] = 'Task 2: Responding to Survey Questions';
        $this->load->view('teacher/writing_task2_edit',$this->data);
    }



    function spPracticeList(){
        $this->verifyUser();
        $this->data['window_title']="Practice Task";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Practice Task';

        $where = "added_by = ".$this->logged['id']." AND role = 'teacher' ";
        $this->data['sppart_list'] = $this->my_model->getWhereRecords('system_speaking_practice_code', $where);
        $this->data['total_sppart'] = count($this->data['sppart_list']);
        $this->load->view('teacher/spPractice_listing', $this->data);
    }

    function spPractice(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_practice_code WHERE added_by = ".$this->logged['id']." AND role='teacher' ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='S0T'. $next_code;
        }else{
            $this->data['test_code']='S0T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', 'Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_practice_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '59');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '59');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('teacher/spPracticeList');
            }
        }
        
        $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('teacher/spPractice',$this->data);
        
    }

    function spPractice_edit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {   
                //echo "<pre>";print_r($_POST);die;
                $qryData = array(
                    'q1_question' => $this->input->post('q1_question'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_speaking_practice_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Task update successfully!!');
                }
                redirect('teacher/spPracticeList');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_practice_code', $where);
        
        $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('teacher/spPractice_edit',$this->data);
    }


    function spPart1List(){
        $this->verifyUser();
        $this->data['window_title']="Task 1: Giving Advice";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task 1: Giving Advice';

        $where = "added_by = ".$this->logged['id']." AND role = 'teacher' ";
        $this->data['sppart_list'] = $this->my_model->getWhereRecords('system_speaking_part1_code', $where);

        $this->data['total_sppart'] = count($this->data['sppart_list']);
        $this->load->view('teacher/spPart1_listing', $this->data);
    }

    function spPart1_edit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'q1_question' => $this->input->post('q1_question'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_speaking_part1_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Task update successfully!!');
                }
                redirect('teacher/spPart1List');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_part1_code', $where);
        
        $this->data['pagetitle'] = 'Task 1: Giving Advice';
        $this->load->view('teacher/spPart1_edit',$this->data);
    }
    
    function spPart1(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_part1_code WHERE added_by = ".$this->logged['id']." AND role='teacher' ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='S1T'. $next_code;
        }else{
            $this->data['test_code']='S1T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', 'Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_part1_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '58');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '58');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('teacher/spPart1List');
            }
        }
        
        $this->data['pagetitle'] = 'Task 1: Giving Advice';
        $this->load->view('teacher/spPart1',$this->data);
        
    }

    function spPart2_edit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'q1_question' => $this->input->post('q1_question'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_speaking_part2_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Task update successfully!!');
                }
                redirect('teacher/spPart2List');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_part2_code', $where);
        
        $this->data['pagetitle'] = 'Task 2: Talking about a Personal Experience';
        $this->load->view('teacher/spPart2_edit',$this->data);
    }
    
    function spPart2(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_part2_code WHERE added_by = ".$this->logged['id']." AND role='teacher' ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='S2T'. $next_code;
        }else{
            $this->data['test_code']='S2T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', 'Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_part2_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '57');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '57');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('teacher/spPart2List');
            }
        }
        
        $this->data['pagetitle'] = 'Task 2: Talking about a Personal Experience';
        $this->load->view('teacher/spPart2',$this->data);
        
    }
    
    function spPart2List(){
        $this->verifyUser();
        $this->data['window_title']="Task 2: Talking about a Personal Experience";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task 2: Talking about a Personal Experience';

        $where = "added_by = ".$this->logged['id']." AND role = 'teacher' ";
        $this->data['sppart_list'] = $this->my_model->getWhereRecords('system_speaking_part2_code', $where);

        $this->data['total_sppart'] = count($this->data['sppart_list']);
        $this->load->view('teacher/spPart2_listing', $this->data);
    }


    function spPart3List(){
        $this->verifyUser();
        $this->data['window_title']="Task 3: Describing a Scene";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task 3: Describing a Scene';

        $where = "added_by = ".$this->logged['id']." AND role = 'teacher' ";
        $this->data['sppart_list'] = $this->my_model->getWhereRecords('system_speaking_part3_code', $where);

        $this->data['total_sppart'] = count($this->data['sppart_list']);
        $this->load->view('teacher/spPart3_listing', $this->data);
    }


    function spPart3(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_part3_code WHERE added_by = ".$this->logged['id']." AND role='teacher' ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='S3T'. $next_code;
        }else{
            $this->data['test_code']='S3T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', 'Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/speaking_part3';
                $this->load->library('upload', $config);
                $scene_img='';
                
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];
                   }
                }
                
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_image' => $scene_img,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_part3_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '56');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '56');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('teacher/spPart3List');
            }
        }
        
        $this->data['pagetitle'] = 'Task 3: Describing a Scene';
        $this->load->view('teacher/spPart3',$this->data);
    }

    function spPart3_edit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $getl1data = $this->my_model->getARecord('system_speaking_part3_code', $id);
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/speaking_part3';
                $this->load->library('upload', $config);
                $scene_img='';  
                      
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];

                   }
                }else{
                    $scene_img = $getl1data->q1_image;
                }
                
                $qryData = array(
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_image' => $scene_img,
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_speaking_part3_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Task update successfully!!');
                }
                redirect('teacher/spPart3List');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_part3_code', $where);
        
        $this->data['pagetitle'] = 'Task 3: Describing a Scene';
        $this->load->view('teacher/spPart3_edit',$this->data);
    }



    function spPart4_edit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $getl1data = $this->my_model->getARecord('system_speaking_part4_code', $id);
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/speaking_part4';
                $this->load->library('upload', $config);
                $scene_img='';  
                      
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];

                   }
                }else{
                    $scene_img = $getl1data->q1_image;
                }
                
                $qryData = array(
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_image' => $scene_img,
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_speaking_part4_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Task update successfully!!');
                }
                redirect('teacher/spPart4List');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_part4_code', $where);
        
        $this->data['pagetitle'] = 'Task 4: Making Predictions';
        $this->load->view('teacher/spPart4_edit',$this->data);
    }
    
    function spPart4(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_part4_code WHERE added_by = ".$this->logged['id']." AND role='teacher' ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='S4T'. $next_code;
        }else{
            $this->data['test_code']='S4T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', 'Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/speaking_part4';
                $this->load->library('upload', $config);
                $scene_img='';
                
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];
                   }
                }
                
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_image' => $scene_img,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_part4_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '55');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '55');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('teacher/spPart4List');
            }
        }
        
        $this->data['pagetitle'] = 'Task 4: Making Predictions';
        $this->load->view('teacher/spPart4',$this->data);
    }
    
    function spPart4List(){
        $this->verifyUser();
        $this->data['window_title']="Task 4: Making Predictions";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task 4: Making Predictions';

        $where = "added_by = ".$this->logged['id']." AND role = 'teacher' ";
        $this->data['sppart_list'] = $this->my_model->getWhereRecords('system_speaking_part4_code', $where);

        $this->data['total_sppart'] = count($this->data['sppart_list']);
        $this->load->view('teacher/spPart4_listing', $this->data);
    }


    function spPart5_edit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $getl1data = $this->my_model->getARecord('system_speaking_part5_code', $id);
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/speaking_part5';
                $this->load->library('upload', $config);
                $scene_img='';  
                $scene_img2=''; 
                      
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];

                   }
                }else{
                    $scene_img = $getl1data->q1_image;
                }
                
                if($_FILES['scene_img2']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img2')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $scene_img2 = $data['file_name'];
                   }
                }else{
                    $scene_img2 = $getl1data->q1_image2;
                }
                
                $qryData = array(
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_image' => $scene_img,
                    'q1_image2' => $scene_img2,
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_speaking_part5_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Task update successfully!!');
                }
                redirect('teacher/spPart5List');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_part5_code', $where);
        
        $this->data['pagetitle'] = 'Task 5: Comparing and Persuading';
        $this->load->view('teacher/spPart5_edit',$this->data);
    }
    
    function spPart5(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_part5_code WHERE added_by = ".$this->logged['id']." AND role='teacher' ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='S5T'. $next_code;
        }else{
            $this->data['test_code']='S5T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', 'Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/speaking_part5';
                $this->load->library('upload', $config);
                $scene_img='';
                $scene_img2='';
                
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];
                   }
                }
                
                if($_FILES['scene_img2']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img2')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $scene_img2 = $data['file_name'];
                   }
                }
                
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_image' => $scene_img,
                    'q1_image2' => $scene_img2,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_part5_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '54');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '54');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('teacher/spPart5List');
            }
        }
        
        $this->data['pagetitle'] = 'Task 5: Comparing and Persuading';
        $this->load->view('teacher/spPart5',$this->data);
    }
    
    function spPart5List(){
        $this->verifyUser();
        $this->data['window_title']="Task 5: Comparing and Persuading";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task 5: Comparing and Persuading';

        $where = "added_by = ".$this->logged['id']." AND role = 'teacher' ";
        $this->data['sppart_list'] = $this->my_model->getWhereRecords('system_speaking_part5_code', $where);

        $this->data['total_sppart'] = count($this->data['sppart_list']);
        $this->load->view('teacher/spPart5_listing', $this->data);
    }


    function spPart6_edit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'q1_question' => $this->input->post('q1_question'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_speaking_part6_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Task update successfully!!');
                }
                redirect('teacher/spPart6List');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_part6_code', $where);
        
        $this->data['pagetitle'] = 'Task 6: Dealing with a Difficult Situation';
        $this->load->view('teacher/spPart6_edit',$this->data);
    }
    
    function spPart6(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_part6_code WHERE added_by = ".$this->logged['id']." AND role='teacher' ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='S6T'. $next_code;
        }else{
            $this->data['test_code']='S6T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', 'Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_part6_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '53');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '53');
                    }
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('teacher/spPart6List');
            }
        }
        
        $this->data['pagetitle'] = 'Task 6: Dealing with a Difficult Situation';
        $this->load->view('teacher/spPart6',$this->data);
        
    }
    
    function spPart6List(){
        $this->verifyUser();
        $this->data['window_title']="Task 6: Dealing with a Difficult Situation";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task 6: Dealing with a Difficult Situation';

        $where = "added_by = ".$this->logged['id']." AND role = 'teacher' ";
        $this->data['sppart_list'] = $this->my_model->getWhereRecords('system_speaking_part6_code', $where);

        $this->data['total_sppart'] = count($this->data['sppart_list']);
        $this->load->view('teacher/spPart6_listing', $this->data);
    }

    function spPart7_edit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'q1_question' => $this->input->post('q1_question'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_speaking_part7_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Task update successfully!!');
                }
                redirect('teacher/spPart7List');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_part7_code', $where);
        
        $this->data['pagetitle'] = 'Task 7: Expressing Opinions';
        $this->load->view('teacher/spPart7_edit',$this->data);
    }
    
    function spPart7(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_part7_code WHERE added_by = ".$this->logged['id']." AND role='teacher' ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='S7T'. $next_code;
        }else{
            $this->data['test_code']='S7T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', 'Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_part7_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '52');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '52');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('teacher/spPart7List');
            }
        }
        
        $this->data['pagetitle'] = 'Task 7: Expressing Opinions';
        $this->load->view('teacher/spPart7',$this->data);
        
    }
    
    function spPart7List(){
        $this->verifyUser();
        $this->data['window_title']="Task 7: Expressing Opinions";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task 7: Expressing Opinions';

        $where = "added_by = ".$this->logged['id']." AND role = 'teacher' ";
        $this->data['sppart_list'] = $this->my_model->getWhereRecords('system_speaking_part7_code', $where);

        $this->data['total_sppart'] = count($this->data['sppart_list']);
        $this->load->view('teacher/spPart7_listing', $this->data);
    }
    
    function spPart8_edit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $getl1data = $this->my_model->getARecord('system_speaking_part8_code', $id);
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/speaking_part8';
                $this->load->library('upload', $config);
                $scene_img='';  
                      
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];

                   }
                }else{
                    $scene_img = $getl1data->q1_image;
                }
                
                $qryData = array(
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_image' => $scene_img,
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_speaking_part8_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Task update successfully!!');
                }
                redirect('teacher/spPart8List');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_part8_code', $where);
        
        $this->data['pagetitle'] = 'Task 8: Describing an Unusual Situation';
        $this->load->view('teacher/spPart8_edit',$this->data);
    }
    
    function spPart8(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_part8_code WHERE added_by = ".$this->logged['id']." AND role='teacher' ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='S8T'. $next_code;
        }else{
            $this->data['test_code']='S8T1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', 'Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/speaking_part8';
                $this->load->library('upload', $config);
                $scene_img='';
                
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];
                   }
                }
                
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_image' => $scene_img,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                    'added_by'=> $this->logged['id'],
                    'role'=>'teacher'
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_part8_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '51');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '51');
                    }
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('teacher/spPart8List');
            }
        }
        
        $this->data['pagetitle'] = 'Task 8: Describing an Unusual Situation';
        $this->load->view('teacher/spPart8',$this->data);
    }
    
    function spPart8List(){
        $this->verifyUser();
        $this->data['window_title']="Task 8: Describing an Unusual Situation";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Task 8: Describing an Unusual Situation';

        $where = "added_by = ".$this->logged['id']." AND role = 'teacher' ";
        $this->data['sppart_list'] = $this->my_model->getWhereRecords('system_speaking_part8_code', $where);

        $this->data['total_sppart'] = count($this->data['sppart_list']);
        $this->load->view('teacher/spPart8_listing', $this->data);
    }
    




	 function member() {
        $this->verifyUser();

		if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }	
		
		$user_id = $loggedUser['id'];
		$where = "id = '$user_id' ";
		$getData = $this->my_model->getWhereOneRecords('system_business_code', $where);//Get Reference Number
		
        $this->data['window_title']="Students";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Students';
		//echo "<pre>";print_r($getData);die;
		
		if($getData->reference_no!=''){
			$reference_no = $getData->reference_no;
			$where = "id != '0' AND business_reference_no='$reference_no'";
			$this->data['members'] = $this->my_model->getWhereRecords('system_member_code', $where);
		}else{
			$this->data['members'] = array();
		}
		
        $this->data['total_members'] = count($this->data['members']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function deleteMember($id)
    {
        $this->verifyUser();
        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/member'); }
        if( $this->my_model->deleteARecord('system_member_code', $id) )
        {
            redirect($this->data['currentPath'].'/member?trash=1');
        }
        redirect($this->data['currentPath'].'/member');
    }
	
	function addCoins(){
		$this->verifyUser();
		if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }	
		
		$user_id = $loggedUser['id'];
		$where = "id = '$user_id' ";
		$getData = $this->my_model->getWhereOneRecords('system_business_code', $where);
		
		if($getData->coins <= 0){
			$response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
			echo json_encode ($response) ;
			die;
		}
		
		if($getData->coins < $_POST['coins']){
			$response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
			$this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
			echo json_encode ($response) ;
			die;
		}
		
		
		$business_coins = $getData->coins - $_POST['coins'];
		$qryData = array(
			'coins' => $business_coins,
		);

		if( $this->my_model->updateTable('system_business_code', $qryData, $user_id) )
		{
			$description = $_POST['description'];
			$student_id = $_POST['student_id'];
			
			$stuwhere = "id = '$student_id' ";
			$studentData = $this->my_model->getWhereOneRecords('system_member_code', $stuwhere);
			$student_name = $studentData->username;
			
			$business_coin_data = array('user_id'=>$user_id,
				'user_type'=>'business',
				'description'=>"$description Transfer to student $student_name",
				'debit_coin'=>$_POST['coins'],
				'balance_coin'=>$business_coins,
				'created_date'=>date('Y-m-d H:i:s'),
				'updated_at'=>date('Y-m-d H:i:s'),
			);
			$this->my_model->insertDataIntoTable('system_coins_management_code', $business_coin_data);
			
			/* $student_id = $_POST['student_id'];
			$stuwhere = "id = '$student_id' ";
			$studentData = $this->my_model->getWhereOneRecords('system_member_code', $stuwhere); */
		
			$student_coins = $studentData->coins+$_POST['coins'];
			$qryData1 = array(
				'coins' => $student_coins,
			);
			
			$this->my_model->updateTable('system_member_code', $qryData1, $student_id);
			
			$business_name = $getData->username;
			$student_coin_data = array('user_id'=>$student_id,
				'user_type'=>'member',
				'description'=>"$description Transfer by business $business_name",
				'credit_coin'=>$_POST['coins'],
				'balance_coin'=>$student_coins,
				'created_date'=>date('Y-m-d H:i:s'),
				'updated_at'=>date('Y-m-d H:i:s'),
			);
			$this->my_model->insertDataIntoTable('system_coins_management_code', $student_coin_data);
			
			$this->session->set_flashdata('global_msg', 'Coins has been added successfully!!');
			$response = array(
                'result' => 'success',
                'message' => 'Coins Added successfully'
            );
		}else{
			$response = array(
                'result' => 'error',
                'message' => 'Please try again'
            );
			$this->session->set_flashdata('global_msg', 'Please try again.');
		}
		echo json_encode($response);die;
		
	}
	
	function editMember($id)
    {
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                );

                if( $this->my_model->updateTable('system_member_code', $qryData, $id) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Student Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['teacher'] = $this->my_model->getARecord('system_member_code', $id);
        if( !is_object($this->data['teacher'])) { return false; }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function addMember()
    {
        $this->verifyUser();
		
		$business = $this->my_model->getARecord('system_business_code', $this->data['user']->id);
		if( !is_object($business)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {    
			//echo "<pre>";print_r($_POST);die;
			$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_member_code.email]');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_member_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            //$this->form_validation->set_rules('username', 'Username', 'trim');
            //$this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $where = "id != '0' AND student_code!='0'" ;
				$get_last_stu_code = $this->my_model->getWhereLastRecords('system_member_code', $where);
				if(!empty($get_last_stu_code)){
					$student_code = $get_last_stu_code->student_code+1;
				}else{
					$student_code = '101';
				}
				
				$qryData = array(
                    'name' => $this->input->post('name'),
					'student_code'=>$get_last_stu_code->student_code+1,
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'business_reference_no' => $business->reference_no,
					'coins'=>200,
                    'created_time' => time(),
                );

				if( $this->my_model->insertDataIntoTable('system_member_code', $qryData))
                {
					$last_added_id = $this->db->insert_id();
					
					$coin_data = array('user_id'=>$last_added_id,
						'user_type'=>'member',
						'description'=>'By reference Register',
						'credit_coin'=>'200',
						'balance_coin'=>'200',
						'created_date'=>date('Y-m-d H:i:s'),
						'updated_at'=>date('Y-m-d H:i:s'),
					);

					$this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
					
					$this->session->set_flashdata('global_msg', 'Student has been added successfully');
					redirect($this->data['currentPath'].'/member');
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Student Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function account() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Profile';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	public function password() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $this->form_validation->set_rules('old', 'Current password', 'trim|required|xss_clean|min_length[3]|max_length[30]');
            $this->form_validation->set_rules('new', 'New password', 'trim|required|xss_clean|min_length[6]|max_length[30]');
            $this->form_validation->set_rules('confirm', 'Confirm password', 'trim|required|xss_clean|min_length[6]|max_length[30]|callback_checkPassword');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger">','</div>' );
            if($this->form_validation->run() == TRUE) {
                $this->data['success'] = true;
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Change Password';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function checkPassword() {

        $newPassword = $this->input->post('new');
        $confirmPassword = $this->input->post('confirm');

        if($newPassword == $confirmPassword) {

            $result = $this->my_model->changePassword($confirmPassword, $this->data['user']->id, $this->tb_name);
            if(!$result) {

                $this->form_validation->set_message('checkPassword', 'Please enter correct Current Password.');
                return false;
            }
        
        } else {
            $this->form_validation->set_message('checkPassword', 'The New password field does not match the Confirm password field.');
            return false;
        }
        return true;
    }

    function dashboard() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dashboard';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function academicwritingsample($subtypeid){
        
        $this->verifyUser();
        $this->data['window_title']="Writing Samples";
        $this->data['Subtypeid'] = $this->my_model->checkARecord('system_academic_writing_sample_code','Subtypeid',$subtypeid);
        if( !is_object($this->data['Subtypeid'])) {
            exit($this->unauthorized_message);
        }
       
       $test_id = $this->data['Subtypeid']->Subtypeid;
        $where = "Subtypeid = '$test_id'";
       
         $this->data['question_list'] = $this->my_model->getWhereOrderRecords('system_academic_writing_sample_code',$where,id,'asc');
         if(!empty($this->data['question_list'])){
                 $this->load->view('teacher/academic_writing_sample_list', $this->data);
        }
               
    }
    
    function addacademicwritingsample($subtypeid){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_academic_writing_sample_code ORDER BY id desc");
        $result = $query->row();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
             $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('question', 'Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answer', 'Answer', 'trim|required|xss_clean');
           

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
             if($this->form_validation->run() == TRUE)
            {
              
             switch ($subtypeid)
                {
                case "41":
                $qryData = array(   
                      'question_id' =>$this->input->post('questionid'),
                    'Subtypeid'=> $subtypeid,
                     'q1_image' => $this->input->post('q1_image'),
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    
                    'question' => $this->input->post('question'),
                    'json_result' => $this->input->post('answer'),
                     'question_id' =>$this->input->post('questionid'),
                    
                   
                );
                break;
                case "42":
                $qryData = array(   
                   'question_id' =>$this->input->post('questionid'),
                    'Subtypeid'=> $subtypeid,
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    
                    'question' => $this->input->post('question'),
                    'json_result' => $this->input->post('answer'),
                     'question_id' =>$this->input->post('questionid'),
                    
                );
                }
                $this->data['subtype']=$subtypeid;
            
                if( $this->my_model->insertDataIntoTable('system_academic_writing_sample_code', $qryData))
                {          
                
                    $this->data['success'] = true;
                    $last_added_id = $this->db->insert_id();
                    $id_md5 = md5($last_added_id);
                    $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_academic_writing_sample_code', $updateData, $last_added_id);
                }
            }
        }
        if($subtypeid==41){
                $this->data['pagetitle'] = 'Academic Writing Part 1 Sample';}
                else{
                    $this->data['pagetitle'] = 'Academic Writing Part 2 Sample';
                }

        $this->load->view('teacher/add_academic_writing_sample',$this->data);
        
    
    }
    
    
    function editacademicwritingsample($id){
                $this->verifyUser();

       if ( ! is_numeric($id)) { return false; }
        $this->data['Subtypeid'] = $this->my_model->checkARecord('system_academic_writing_sample_code','id',$id);
        
         $test_id = $this->data['Subtypeid']->Subtypeid;
     //    print_r($this->data['Subtypeid']);die;


        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('question', 'Email title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answer', 'Email title', 'trim|required|xss_clean');
         ;


            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            { switch ($test_id)
                {
                case "41":
                $qryData = array(
                   'question_id' =>$this->input->post('questionid'),
                    'Subtypeid'=> $subtypeid,
                    'q1_image' => $this->input->post('q1_image'),
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    
                    'question' => $this->input->post('question'),
                    'json_result' => $this->input->post('answer'),
                    'question_id' =>$this->input->post('questionid'),
                );
                break;
                case "42":
                $qryData = array(
                   'question_id' =>$this->input->post('questionid'),
                    'Subtypeid'=> $subtypeid,
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    
                    'question' => $this->input->post('question'),
                    'json_result' => $this->input->post('answer'),
                     'question_id' =>$this->input->post('questionid'),
                    
                );
                }

                if( $this->my_model->updateTable('system_academic_writing_sample_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Academic Writing Task update successfully!!');
                }
            }
        }
        
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_academic_writing_sample_code', $where);
        $this->data['pagetitle'] = 'Edit academic sample question writing';
        $this->load->view('teacher/academic_writing_sample_edit',$this->data);
    
    }
    
       function generalwritingsample($subtypeid){
        
        $this->verifyUser();
        $this->data['window_title']="Writing Samples";
        $this->data['Subtypeid'] = $this->my_model->checkARecord('system_general_writing_sample_code','Subtypeid',$subtypeid);
        if( !is_object($this->data['Subtypeid'])) {
            exit($this->unauthorized_message);
        }
       
       $test_id = $this->data['Subtypeid']->Subtypeid;
        $where = "Subtypeid = '$test_id'";
       
         $this->data['question_list'] = $this->my_model->getWhereOrderRecords('system_general_writing_sample_code',$where,id,'asc');
         if(!empty($this->data['question_list'])){
                 $this->load->view('teacher/general_writing_sample_list', $this->data);
        }
               
    }
    
    function addgeneralwritingsample($subtypeid){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_general_writing_sample_code ORDER BY id desc");
        $result = $query->row();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
             $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('question', 'Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answer', 'Answer', 'trim|required|xss_clean');
           

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
             if($this->form_validation->run() == TRUE)
            {
              
           
                $qryData = array(   
                   'question_id' =>$this->input->post('questionid'),
                    'Subtypeid'=> $subtypeid,
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    
                    'question' => $this->input->post('question'),
                    'json_result' => $this->input->post('answer'),
                     'question_id' =>$this->input->post('questionid'),
                    
                );

                $this->data['subtype']=$subtypeid;
            
                if( $this->my_model->insertDataIntoTable('system_general_writing_sample_code', $qryData))
                {          
                
                    $this->data['success'] = true;
                    $last_added_id = $this->db->insert_id();
                    $id_md5 = md5($last_added_id);
                    $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_general_writing_sample_code', $updateData, $last_added_id);
                }
            }
        }
        if($subtypeid==51){
                $this->data['pagetitle'] = 'General Writing Part 1 Sample';}
                else{
                    $this->data['pagetitle'] = 'General Writing Part 2 Sample';
                }

        $this->load->view('teacher/add_general_writing_sample',$this->data);
        
    
    }
    
    
    function editgeneralwritingsample($id){
                $this->verifyUser();

       if ( ! is_numeric($id)) { return false; }
        
     //    print_r($this->data['Subtypeid']);die;


        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('question', 'Email title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answer', 'Email title', 'trim|required|xss_clean');
         ;


            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                   'question_id' =>$this->input->post('questionid'),
                    'Subtypeid'=> $subtypeid,
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    
                    'question' => $this->input->post('question'),
                    'json_result' => $this->input->post('answer'),
                     'question_id' =>$this->input->post('questionid'),
                    
                );

                if( $this->my_model->updateTable('system_general_writing_sample_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'General Writing Task update successfully!!');
                }
            }
        }
        
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_general_writing_sample_code', $where);
        $this->data['pagetitle'] = 'Edit general sample question writing';
        $this->load->view('teacher/general_writing_sample_edit',$this->data);
    
    }
    
    
    
       function samplelistening($subtypeid){
        
        $this->verifyUser();
        $this->data['window_title']="Listening Samples";
        $this->data['Subtypeid'] = $this->my_model->checkARecord('system_listening_sample_code','Subtypeid',$subtypeid);

       $test_id = $this->data['Subtypeid']->Subtypeid;
        $where = "Subtypeid = '$test_id'";
       
         $this->data['question_list'] = $this->my_model->getWhereOrderRecords('system_listening_sample_code',$where,id,'asc');
         if(!empty($this->data['question_list'])){
                 $this->load->view('teacher/listening_sample_list', $this->data);
        }
               
    }
    
    
    
    
    function editsamplelistening($id){
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
        $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');

            $this->form_validation->set_rules('youtubelink', 'Email title', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),

                    'video_url' =>  $this->input->post('youtubelink')
                );

                if( $this->my_model->updateTable('system_listening_sample_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Writing Task update successfully!!');
                }
            }
        }
        
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_listening_sample_code', $where);
        $this->data['pagetitle'] = 'Edit Sample Question Listening';
        $this->load->view('teacher/edit_listening_sample',$this->data);
    }
    
    
    
    
    
    function addsamplelistening($subtypeid){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_listening_sample_code ORDER BY id desc");
        $result = $query->row();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('youtubelink', 'Email title', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(   
                    'Subtypeid'=> $subtypeid,
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),

                    'title' => $this->input->post('title'),
                    'video_url' => $this->input->post('youtubelink'),
                );

                if( $this->my_model->insertDataIntoTable('system_listening_sample_code', $qryData))
                {          
                
                    $this->data['success'] = true;
                    $last_added_id = $this->db->insert_id();
                    $id_md5 = md5($last_added_id);
                    $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_listening_sample_code', $updateData, $last_added_id);
                }
            }
        }
                if($subtypeid==11){$this->data['pagetitle'] = 'Listening Part 1: Multiple Choice with one answer';}
                elseif($subtypeid==12){$this->data['pagetitle'] = 'Listening Part 2: Multiple choice with more than one answer';}
                elseif($subtypeid==13){$this->data['pagetitle'] = 'Listening Part 3: Matching';}
                elseif($subtypeid==14){$this->data['pagetitle'] = 'Listening Part 4: Labelling on a Map';}
                elseif($subtypeid==15){$this->data['pagetitle'] = 'Listening Part 5: Fill in the Blanks';}
                elseif($subtypeid==16){$this->data['pagetitle'] = 'Listening Part 6: Fill in the Blanks : Short Answer';}

        $this->load->view('teacher/add_sample_listening',$this->data);
        
    }
    
    
       function generalreadingsample($subtypeid){
        
        $this->verifyUser();
        $this->data['window_title']="General Reading Samples";
        $this->data['Subtypeid'] = $this->my_model->checkARecord('system_general_reading_sample_code','Subtypeid',$subtypeid);

       $test_id = $this->data['Subtypeid']->Subtypeid;
        $where = "Subtypeid = '$test_id'";
       
         $this->data['question_list'] = $this->my_model->getWhereOrderRecords('system_general_reading_sample_code',$where,id,'asc');
         if(!empty($this->data['question_list'])){
                 $this->load->view('teacher/general_reading_sample_list', $this->data);
        }
               
    }
    
    
    function editgeneralreadingsample($id){
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');

            $this->form_validation->set_rules('youtubelink', 'Email title', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    'video_url' =>  $this->input->post('youtubelink')
                );

                if( $this->my_model->updateTable('system_general_reading_sample_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'General Reading Task update successfully!!');
                }
            }
        }
        
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_general_reading_sample_code', $where);
        $this->data['pagetitle'] = 'Edit Sample Question General Reading';
        $this->load->view('teacher/edit_general_reading_sample',$this->data);
    }
    
    
    
        function addgeneralreadingsample($subtypeid){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_general_reading_sample_code ORDER BY id desc");
        $result = $query->row();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('youtubelink', 'Email title', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(   
                    'Subtypeid'=> $subtypeid,
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    'video_url' => $this->input->post('youtubelink'),
                );

                if( $this->my_model->insertDataIntoTable('system_general_reading_sample_code', $qryData))
                {          
                
                    $this->data['success'] = true;
                    $last_added_id = $this->db->insert_id();
                    $id_md5 = md5($last_added_id);
                    $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_general_reading_sample_code', $updateData, $last_added_id);
                }
            }
        }
                if($subtypeid==31){$this->data['pagetitle'] = 'Sample General Reading Part 1: Matching Information';}
                    elseif($subtypeid==32){$this->data['pagetitle'] = 'Sample General Reading Part 2: True/False/Not Given';}
                    elseif($subtypeid==33){$this->data['pagetitle'] = 'Sample General Reading Part 3: Note Completion';}
                    elseif($subtypeid==34){$this->data['pagetitle'] = 'Sample General Reading Part 4: Sentence Completion';} 
                    elseif($subtypeid==35){$this->data['pagetitle'] = 'Sample General Reading Part 5: Matching Features';} 
                    elseif($subtypeid==36){$this->data['pagetitle'] = 'Sample General Reading Part 6: Multiple Choice';} 
                    elseif($subtypeid==37){$this->data['pagetitle'] = 'Sample General Reading Part 7: Summary Completion';}

        $this->load->view('teacher/add_general_sample_reading',$this->data);
        
    }



  
       function academicreadingsample($subtypeid){
        
        $this->verifyUser();
        $this->data['window_title']="Academic Reading Samples";
        $this->data['Subtypeid'] = $this->my_model->checkARecord('system_academic_reading_sample_code','Subtypeid',$subtypeid);

       $test_id = $this->data['Subtypeid']->Subtypeid;
        $where = "Subtypeid = '$test_id'";
       
         $this->data['question_list'] = $this->my_model->getWhereOrderRecords('system_academic_reading_sample_code',$where,id,'asc');
         if(!empty($this->data['question_list'])){
                 $this->load->view('teacher/academic_reading_sample_list', $this->data);
        }
               
    }
    
    
    function editacademicreadingsample($id){
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');

            $this->form_validation->set_rules('youtubelink', 'Email title', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    'video_url' =>  $this->input->post('youtubelink')
                );

                if( $this->my_model->updateTable('system_academic_reading_sample_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Academic Reading Task update successfully!!');
                }
            }
        }
        
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_academic_reading_sample_code', $where);
        $this->data['pagetitle'] = 'Edit Sample Question Academic Reading';
        $this->load->view('teacher/academic_reading_sample_edit',$this->data);
    }
    
    
    
        function addacademicreadingsample($subtypeid){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_academic_reading_sample_code ORDER BY id desc");
        $result = $query->row();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('youtubelink', 'Email title', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(   
                    'Subtypeid'=> $subtypeid,
                    'title' => $this->input->post('title'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                    'video_url' => $this->input->post('youtubelink'),
                );

                if( $this->my_model->insertDataIntoTable('system_academic_reading_sample_code', $qryData))
                {          
                
                    $this->data['success'] = true;
                    $last_added_id = $this->db->insert_id();
                    $id_md5 = md5($last_added_id);
                    $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_academic_reading_sample_code', $updateData, $last_added_id);
                }
            }
        }
               if($test->Subtypeid==21){$this->data['pagetitle'] = 'Sample Academic Reading Part 1: Multiple Choice with one answer';}
                    elseif($subtypeid==22){$this->data['pagetitle'] = 'Sample Academic Reading Part 2: Multiple Choice with more than one answer';}
                    elseif($subtypeid==23){$this->data['pagetitle'] = 'Sample Academic Reading Part 3: Identify Information : True/False/Not Given';}
                    elseif($subtypeid==24){$this->data['pagetitle'] = 'Sample Academic Reading Part 4: Note Completion';} 
                    elseif($subtypeid==25){$this->data['pagetitle'] = 'Sample Academic Reading Part 5: Matching Headings';} 
                    elseif($subtypeid==26){$this->data['pagetitle'] = 'Sample Academic Reading Part 6: Summary Completion (Selecting Word from a text)';} 
                    elseif($subtypeid==27){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Summary Completion (Selecting from a list of words or phase)';}
                    elseif($subtypeid==28){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Flow -Chart Completion';}
                    elseif($subtypeid==29){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Sentence Completion';}
                    elseif($subtypeid==30){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Matching Sentence endings';}

        $this->load->view('teacher/add_academic_reading_sample',$this->data);
        
    }
    
    
    
function Samplespeaking($subtypeid){
        
        $this->verifyUser();
        $this->data['window_title']="Speaking Samples";
        $this->data['Subtypeid'] = $this->my_model->checkARecord('system_speaking_sample_code','Subtypeid',$subtypeid);

       $test_id = $this->data['Subtypeid']->Subtypeid;
        $where = "Subtypeid = '$test_id'";
       
         $this->data['question_list'] = $this->my_model->getWhereOrderRecords('system_speaking_sample_code',$where,id,'asc');
         if(!empty($this->data['question_list'])){
                 $this->load->view('teacher/speaking_sample_list', $this->data);
        }
               
    }
    
         function editsamplespeaking($id){
         
         
        if ( ! is_numeric($id)) { return false; }
        $this->data['Subtypeid'] = $this->my_model->checkARecord('system_speaking_sample_code','id',$id);
        
         $test_id = $this->data['Subtypeid']->Subtypeid;

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('title', 'Question title', 'trim|required|xss_clean');
               $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');

            $this->form_validation->set_rules('audio', 'Audio', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'question_id' =>$this->input->post('questionid'),
                    'title' => $this->input->post('title'),
                    'json_result' => $this->input->post('audio'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                );
              
                

                if( $this->my_model->updateTable('system_speaking_sample_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking Sample update successfully!!');
                }
            }
        }
        
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_speaking_sample_code', $where);
        $this->data['pagetitle'] = 'Edit Sample Question Speaking';
        $this->load->view('teacher/speaking_sample_edit',$this->data);
    }

     function addsamplespeaking($subtypeid){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_speaking_sample_code ORDER BY id desc");
        $result = $query->row();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            
            $this->form_validation->set_rules('audio', 'Audio', 'trim|required|xss_clean');
               $this->form_validation->set_rules('seo_title', 'Seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'Seo Discription title', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
           
                 if($this->form_validation->run() == TRUE)
            {
                 $qryData = array(   
                    'question_id' =>$this->input->post('questionid'),
                    'Subtypeid'=> $subtypeid,
                    'title' => $this->input->post('title'),
                    'json_result' => $this->input->post('audio'),
                    'seo_title' => $this->input->post('seo_title'),
                    'seo_discription' => $this->input->post('seo_discription'),
                );

                if( $this->my_model->insertDataIntoTable('system_speaking_sample_code', $qryData))
                {          
                
                    $this->data['success'] = true;
                    $last_added_id = $this->db->insert_id();
                    $id_md5 = md5($last_added_id);
                    $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_speaking_sample_code', $updateData, $last_added_id);
                }
            }
        }
                if($subtypeid==61){$this->data['pagetitle'] = 'Sample Speaking Task 1: Talking about a personal experience';}
                


        $this->load->view('teacher/add_sample_speaking',$this->data);
        
    }




}