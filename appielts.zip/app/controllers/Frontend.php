<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Anybody can access this controller
*/
class Frontend extends AKAAL_Controller {

    public function __construct() {
        parent::__construct();
 
        $this->data['currentAccount'] = 'logger_frontend';
        $this->data['currentPath'] = 'frontend';
    }

    function index() {
        $this->home();
    }

    /*
    * HOME Page
    */
    function home() {

        $window_title = $this->app_name;

        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );

        $this->data['pagetitle'] = 'Home';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    /*
    * Check Google Recaptcha
    */
    function checkRecaptcha($recaptcha_response) {

        if($this->verifyRecaptcha($recaptcha_response)) {
            return true;
        } else {
            $this->form_validation->set_message(__FUNCTION__, 'The reCaptcha verification was not verified, please try again.');
            return false;
        }
    }

    /*
    * Registration Page
    */
    function registration() {

        // Submit form
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

			$this->form_validation->set_rules('email', 'Email Address', 'trim|required|max_length[80]|valid_email|is_unique['.$this->tb_member.'.email]');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|max_length[50]|is_unique['.$this->tb_member.'.username]|alpha_numeric');
			$this->form_validation->set_rules('g-recaptcha-response', 'recaptcha', 'trim|required|xss_clean|callback_checkRecaptcha');
		
            /* $this->form_validation->set_rules('name', 'Full Name', 'trim|required|max_length[80]|alpha_numeric_spaces');
            $this->form_validation->set_rules('email', 'Email Address', 'trim|required|max_length[80]|valid_email|is_unique['.$this->tb_member.'.email]');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|max_length[50]|is_unique['.$this->tb_member.'.username]|alpha_numeric');
            $this->form_validation->set_rules('mobile', 'Mobile', 'trim|required');
            $this->form_validation->set_rules('street_address', 'Address', 'trim|required');
            $this->form_validation->set_rules('reference_no', 'Reference Number', 'trim|required');
            $this->form_validation->set_rules('city_region', 'City or Region', 'trim|required');
            $this->form_validation->set_rules('country_id', 'Country', 'trim|required');
            $this->form_validation->set_rules('postal_code', 'Postal Code', 'trim|required'); */
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE) {
				$student_reference_no = '';
				$tycoon_reference_no = '';
				$get_coins = '100';
				$description = 'By Register';
				
				$where = 'id != 0';
				$get_last_stu_code = $this->my_model->getWhereLastRecords('system_member_code', $where);
				
                $reference_no = $this->input->post('reference_no');
				if(!empty($reference_no)){
					$firstCharacter = substr($reference_no, 0, 1);
					if($firstCharacter=='T'){
						$check_reseller = $this->my_model->checkARecord('system_reseller_code', 'reference_no',$reference_no );
						if(!empty($check_reseller)){
							$tycoon_reference_no = $check_reseller->reference_no;
							$get_coins = '200';
							$description = 'By Tycoon reference Register';
						}
					}else{
						$check_student_ref = $this->my_model->checkARecord('system_member_code', 'student_code',$reference_no);
						if(!empty($check_student_ref)){
							$student_reference_no = $check_student_ref->student_code;
							$tycoon_reference_no = $check_student_ref->reference_no;
							$get_coins = '200';
							$description = 'By Student reference Register';
							
							$earned_coin = $check_student_ref->coins + 100;
							$stu_earn_coin_data = array('user_id'=>$check_student_ref->id,
								'user_type'=>'member',
								'description'=>'Join Student By Coupon Code',
								'credit_coin'=>'100',
								'balance_coin'=>$earned_coin,
								'created_date'=>date('Y-m-d H:i:s'),
								'updated_at'=>date('Y-m-d H:i:s'),
							);
							$this->my_model->insertDataIntoTable('system_coins_management_code', $stu_earn_coin_data);
							
							$earn_qryData = array(
								'coins' => $earned_coin
							);
							$this->my_model->updateTable('system_member_code', $earn_qryData, $check_student_ref->id);
						}
					}
				}
				
				$urlkey = url_title($this->input->post('name'), '-', true);
                $password = random_string('alnum', 8);

                // Default : confirm = yes , role_id = 2 (member)
                $qryData = array(
					'student_code'=>$get_last_stu_code->student_code+1,
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('username'),
                    'password' => md5($password),
                    'notMD5password' => $password,
                    'confirm' => 'yes', // we are going to Active new user , bcoz we are sending password by email.
                    'md5Email' => md5($this->input->post('email')),
                    'created_time' => time(),
                    //'name' => $this->input->post('name'),
                    'student_reference_no' => $student_reference_no,
                    'reference_no' => $tycoon_reference_no,
					'coins'=>$get_coins
                    //'mobile' => $this->input->post('mobile'),
                    //'street_address' => $this->input->post('street_address'),
                    //'city_region' => $this->input->post('city_region'),
                    //'country_id' => $this->input->post('country_id'),
                    //'postal_code' => $this->input->post('postal_code'),
                );

                if( $this->my_model->insertDataIntoTable($this->tb_member, $qryData) ) {
                    $this->data['success'] = true;
                    $last_added_id = $this->db->insert_id();
					
					$coin_data = array('user_id'=>$last_added_id,
						'user_type'=>'member',
						'description'=>$description,
						'credit_coin'=>$get_coins,
						'balance_coin'=>$get_coins,
						'created_date'=>date('Y-m-d H:i:s'),
						'updated_at'=>date('Y-m-d H:i:s'),
					);
					$this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
					
                    $url_key = $urlkey.'-'.$last_added_id;
                    // added other information related to member
                    $memberDetail = array(
                        'id' => $last_added_id, // same as member ID
                        'created_time' => time(),
                        'urlkey' => $url_key,
                    );
                    $this->my_model->insertDataIntoTable($this->tb_member_extras, $memberDetail);
                    
                    /* Send account detail email */
                        $this->load->library('email');
                        $config = array (
                            'mailtype' => 'text',
                            'charset'  => 'utf-8',
                            'wordwrap' => TRUE,
                            'priority' => '1'
                        );
                        $this->email->initialize($config);
                        $this->email->from($this->app_email, $this->app_name);
                        $this->email->to($this->input->post('email'));
                        #$this->email->cc($this->app_contactemail); // send copy at website contact email address
                        $this->email->subject('Welcome to '.$this->app_name);

// send text email
$this->email->message('Thanks for signing up!

Your account has been created, you can login with the following credentials to manage your account. After login you can access IELTS material on our website.

Login URL : '.base_url('/login').'
Username : '.$this->input->post('username').'
Password : '.$password.'

Best Wishes,
'.$this->app_name.' Team
');
                        
                        //echo '<pre>'; print_r($data); echo '</pre>';
                        $this->email->send();
                        //echo $this->email->print_debugger();
                    // @end email

                    $this->data['success'] = true;

                }
            }
        }

        # Get countries
        $where = "active = 'Yes' ";
        $this->data['countries'] = $this->my_model->getWhereRecords($this->tb_countries, $where);
        $this->data['countries'] = $this->my_model->getWhereOrderRecords($this->tb_countries, $where, 'name', 'ASC');
        
        $this->data['custom_url'] = 'http://ielts24x7.com/NEW';

        $window_title = 'Register - ' . $this->app_name;
        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );
        $this->data['pagetitle'] = 'Sign Up';
        //$this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
        $this->load->view($this->data['currentPath'].'/registration', $this->data);
    }


    /*
    * Login Page
    */
    function login() {

        $window_title = 'Login - ' . $this->app_name;
        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );
        $this->data['pagetitle'] = 'Login';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function privacy() {
		$this->data['pagetitle'] = 'Privacy policy';
        $this->load->view('web/privacy', $this->data);
	}
	
	function terms() {
		$this->data['pagetitle'] = 'Terms & conditions';
        $this->load->view('web/terms-and-conditions', $this->data);
	}

	function disclaimer() {
		$this->data['pagetitle'] = 'Disclaimer';
        $this->load->view('web/disclaimer', $this->data);
	}

function faqs() {
		$this->data['title'] = 'Faqs';
        $this->load->view('web/faqs', $this->data);
	}
function samples() {
		$this->data['pagetitle'] = 'Free Celpip test sample tests material';
        $this->load->view('web/samples', $this->data);
	}
function testformat() {
		$this->data['pagetitle'] = 'Celpip test format';
        $this->load->view('web/testformat', $this->data);
	}


















    /*
    * Static Pages
    
    function staticpage($id) {

        $this->data['objPage'] = $this->my_model->getARecord($this->tb_spage, $id);
        if( !is_object($this->data['objPage'])) { return false; }

        $window_title = $this->data['objPage']->heading . ' - ' . $this->app_name;

        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    */





}