<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Super Admin controller
* this controller is related to specific user role
*/
class Superadmin extends AKAAL_Controller {

    public function __construct() {
        parent::__construct();
 
        $this->data['currentAccount'] = 'logger_superadmin';
        $this->data['currentPath'] = 'superadmin';
        $this->data['pagetitle']='';

        $this->load->model('my_model');
        
        // table name of specific user role; which is related to this controller only
        $this->tb_name = $this->tb_superadmin;
    }

    function index() {

        $this->login();
    }

    function login() {
        // check website session, if enabled
        if( $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            if($loggedUser['user_role']=='superadmin'){
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $this->load->model('my_model');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_isValidUser');
            $this->form_validation->set_rules('g-recaptcha-response', 'recaptcha', 'trim|required|xss_clean|callback_checkRecaptcha');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }

        }

        $this->data['title'] = '<a href="'.base_url('/'.$this->data['currentPath'].'/login').'">Super Admin Login</a>';

        //$this->data['custom_url'] = 'http://ielts24x7.com/NEW';
        //$this->data['custom_url'] = 'http://ielts24x7.com';
        $this->data['custom_url'] = 'https://ielts24x7.com';

        $window_title = 'SuperAdmin Login - ' . $this->app_name;

        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );
        
        $this->data['pagetitle'] = 'Super Admin Login';

        $this->data['formAction'] = $this->uri->segment(1). '/' . $this->uri->segment(2);
        $this->load->view('shared/login', $this->data);
    }

    function isValidUser($password) {
        //Field validation succeeded.  Validate against database
        $username = $this->input->post('username');
        $result = $this->my_model->getUser($this->tb_name, $username, $password);

        if($result)
        {
            $session_array = array();
            foreach($result as $row)
            {
                $session_array = array(
                    'id' => $row->id,
                    'name' => $row->name,
                    'user_role'=>'superadmin'
                );

                $this->session->set_userdata($this->data['currentAccount'], $session_array);
            }
            return true;
        }
        else
        {
            $this->form_validation->set_message('isValidUser', 'Invalid username or password');
            return false;
        }
    }

    function logout() {
        // Make sure you destory website session as well.
        $this->session->unset_userdata($this->data['currentAccount']);
        $this->session->sess_destroy();
        // Finally redirect page to desire location
        redirect($this->data['currentPath']);
    }

    function verifyUser() {

        // check login
        $this->logged = is_user_logged_in(
            $this->data['currentAccount'],
            $this->data['currentPath']
        );

        $this->data['user'] = $this->my_model->getARecord($this->tb_name, $this->logged['id']);
        $this->data['role'] = $this->my_model->getARecord($this->tb_role, $this->data['user']->role_id);

        // checks for valid user get or not
        if( !is_object($this->data['user'])) { return false; }
    }

    function account() {
        $this->verifyUser();
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    public function password() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $this->form_validation->set_rules('old', 'Current password', 'trim|required|xss_clean|min_length[3]|max_length[30]');
            $this->form_validation->set_rules('new', 'New password', 'trim|required|xss_clean|min_length[6]|max_length[30]');
            $this->form_validation->set_rules('confirm', 'Confirm password', 'trim|required|xss_clean|min_length[6]|max_length[30]|callback_checkPassword');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            if($this->form_validation->run() == TRUE) {
                $this->data['success'] = true;
            }
        }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function checkPassword() {

        $newPassword = $this->input->post('new');
        $confirmPassword = $this->input->post('confirm');

        if($newPassword == $confirmPassword) {

            $result = $this->my_model->changePassword($confirmPassword, $this->data['user']->id, $this->tb_name);
            if(!$result)
            {
                $this->form_validation->set_message('checkPassword', 'Please enter correct Current Password.');
                return false;
            }
        
        } else {
            $this->form_validation->set_message('checkPassword', 'The New password field does not match the Confirm password field.');
            return false;
        }

        return true;
    }

    function dashboard() {
        $this->verifyUser();

        $this->data['transaction'] = $this->my_model->getAllRecords('system_transaction_code');
        
        $this->data['tests'] = $this->my_model->getAllRecords($this->tb_test);
        $this->data['students'] = $this->my_model->getAllRecords($this->tb_member);
        $this->data['teachers'] = $this->my_model->getAllRecords($this->tb_teacher);
        $this->data['tickets'] = $this->my_model->getAllRecords($this->tb_support);
        
        $this->data['pagetitle'] = '';
        $this->data['window_title']="Dashboard";
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function vocabularytests() {
        $this->verifyUser();

        # Show all test
        $where = "active = 'Yes' ";
        $this->data['levels'] = $this->my_model->getWhereOrderRecords($this->tb_vlevel, $where, 'id', 'asc');
        $this->data['total'] = count($this->data['levels']);


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Vocabulary Tests';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function vquestions($level_id) {
        $this->verifyUser();

        $this->data['objLevel'] = $this->my_model->getARecord($this->tb_vlevel, $level_id);
        if( !is_object($this->data['objLevel'])) { 
            exit($this->unauthorized_message);
        }

        # Show all questions of Objective type
        $where = "level_id = '".$this->data['objLevel']->id."' AND type = 'Objective' ";
        $this->data['questions'] = $this->my_model->getWhereOrderRecords($this->tb_vquestion, $where, 'id', 'asc');
        $this->data['total'] = count($this->data['questions']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Vocabulary Tests - Questions ('.$this->data['objLevel']->name.')';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function vaddquestion($level_id) {
        $this->verifyUser();

        $objLevel = $this->my_model->getARecord($this->tb_vlevel, $level_id);
        if( !is_object($objLevel)) { 
            exit($this->unauthorized_message);
        }

        $qryData = array(
            'added_rid' => $this->data['user']->role_id,
            'added_uid' => $this->data['user']->id,
            'time' => time(),
            'title' => '',
            'level_id' => $level_id,
            'type' => 'Objective'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_vquestion, $qryData) ) {

            $last_added_id = $this->db->insert_id();

            $dataOptionA = array(
                'added_rid' => $this->data['user']->role_id,
                'added_uid' => $this->data['user']->id,
                'time' => time(),
                'title' => '',
                'question_id' => $last_added_id,
                'is_correct' => '0'
            );
            $dataOptionB = array(
                'added_rid' => $this->data['user']->role_id,
                'added_uid' => $this->data['user']->id,
                'time' => time(),
                'title' => '',
                'question_id' => $last_added_id,
                'is_correct' => '1'
            );

            // Add question options
            $this->my_model->insertDataIntoTable($this->tb_voption, $dataOptionA);
            $this->my_model->insertDataIntoTable($this->tb_voption, $dataOptionB);

            // Update total question in level
            $total_questions = $objLevel->total_questions + 1;
            $levelData = array(
                'total_questions' => $total_questions
            );
            $this->my_model->updateTable($this->tb_vlevel, $levelData, $objLevel->id);

            // Redirect to edit question page
            redirect($this->data['currentPath'].'/vquestionedit/'.$last_added_id.'?new=1');
            // Question has been added successfully.
            // You just need to update question information according your requirements.
        }
    }

    function vquestionedit($q_id) {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $this->form_validation->set_rules('title', 'Question', 'trim|required');
            $this->form_validation->set_rules('quizquestion_iscorrect', 'Right Answer', 'trim|required');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger">','</div>' );
            if($this->form_validation->run() == TRUE) {
                
                
                
                if(!empty($_FILES["question_img"]["name"])){
                    $question_image = strtotime(date("Y-m-d h:i:s A")).'_'.$_FILES["question_img"]["name"];
                    
                    $config['file_name']   = $question_image;
                    $config['upload_path'] = './uploads/question_images';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $this->load->library('upload', $config);

                    if ( ! $this->upload->do_upload('question_img')) {
                       $this->session->set_flashdata('global_msg',strip_tags($this->upload->display_errors()));
                    }
                }
                
                if(!empty($question_image)){
                    $question_image=$question_image;
                }else{
                    $getQuestiondata = $this->my_model->getARecord($this->tb_vquestion, $q_id);
                    $question_image = $getQuestiondata->question_image;
                }
                
                $getQuestiondata = $this->my_model->getARecord($this->tb_vquestion, $q_id);
                

                $arrOptionTitle = $this->input->post('quiz_opt_title'); //$this->request->data['quiz_opt_title'];
                $haveOptions = count($arrOptionTitle);

                // update question
                $questionData = array(
                    'time' => time(),
                    'title' => $this->input->post('title'),
                    'question_image' => $question_image,
                );
                if( $this->my_model->updateTable($this->tb_vquestion, $questionData, $q_id) ) {

                    $is_correct = $this->input->post('quizquestion_iscorrect');
                    // update options
                    if($haveOptions) {
                        foreach ($arrOptionTitle as $optId => $optTitle) {

                            $columnCorrect = '0';
                            if($optId == $is_correct) {
                                $columnCorrect = '1';
                            }

                            $optionData = array(
                                'time' => time(),
                                'title' => $optTitle,
                                'is_correct' => $columnCorrect
                            );
                            $this->my_model->updateTable($this->tb_voption, $optionData, $optId);
                        }
                    }

                    $this->data['success'] = true;
                }
            }
        }

        $this->data['objQuestion'] = $this->my_model->getARecord($this->tb_vquestion, $q_id);
        if( !is_object($this->data['objQuestion'])) { 
            exit($this->unauthorized_message);
        }

        $this->data['objLevel'] = $this->my_model->getARecord($this->tb_vlevel, $this->data['objQuestion']->level_id);
        if( !is_object($this->data['objLevel'])) { 
            exit($this->unauthorized_message);
        }



        # Show all options of question
        $where = "question_id = '".$this->data['objQuestion']->id."' ";
        $this->data['options'] = $this->my_model->getWhereOrderRecords($this->tb_voption, $where, 'id', 'asc');

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Vocabulary Tests - Edit Question ('.$this->data['objLevel']->name.')';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function vdeletequestion($q_id, $level_id) {
        $this->verifyUser();

        $objQuestion = $this->my_model->getARecord($this->tb_vquestion, $q_id);
        if( !is_object($objQuestion)) { 
            exit($this->unauthorized_message);
        }

        $objLevel = $this->my_model->getARecord($this->tb_vlevel, $level_id);
        if( !is_object($objLevel)) { 
            exit($this->unauthorized_message);
        }

        // Check if entry is in database, then user can delete entry
        if( is_object($objQuestion)) {

            if( $this->my_model->deleteARecord($this->tb_vquestion, $objQuestion->id) ) {

                // Update total question in level
                $total_questions = $objLevel->total_questions - 1;
                $levelData = array(
                    'total_questions' => $total_questions
                );
                $this->my_model->updateTable($this->tb_vlevel, $levelData, $objLevel->id);

                redirect($this->data['currentPath'].'/vquestions/'.$objLevel->id.'?deleteq=1');
            }
        }
        exit($this->unauthorized_message);
    }

    function vaddquestionoption($q_id) {
        $this->verifyUser();

        $objQuestion = $this->my_model->getARecord($this->tb_vquestion, $q_id);
        if( !is_object($objQuestion)) { 
            exit($this->unauthorized_message);
        }

        $qryData = array(
            'added_rid' => $this->data['user']->role_id,
            'added_uid' => $this->data['user']->id,
            'time' => time(),
            'title' => 'Option',
            'question_id' => $objQuestion->id,
            'is_correct' => '0'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_voption, $qryData) ) {

            //$last_added_id = $this->db->insert_id();

            // Redirect to edit question page
            redirect($this->data['currentPath'].'/vquestionedit/'.$objQuestion->id.'?newoption=1');
            // New option has been added successfully
        }
    }

    function vdeletequestionoption($option_id) {
        $this->verifyUser();

        $objOption = $this->my_model->getARecord($this->tb_voption, $option_id);
        if( !is_object($objOption)) { 
            exit($this->unauthorized_message);
        }

        // Check if entry is in database, then user can delete entry
        if( is_object($objOption)) {
            if( $this->my_model->deleteARecord($this->tb_voption, $option_id) ) {
                redirect($this->data['currentPath'].'/vquestionedit/'.$objOption->question_id.'?deleteoption=1');
            }
        }
        exit($this->unauthorized_message);
    }

    function member() {
        $this->verifyUser();

        $this->data['window_title']="Students";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Students';

        $where = "id != '0' ";
        $this->data['members'] = $this->my_model->getWhereOrderRecords('system_member_code', $where,'id','asc');
        //print_r($this->data['members']);
        

        $this->data['total_members'] = count($this->data['members']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function teacher() {
        $this->verifyUser();

        $this->data['window_title']="Teachers";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Teachers';

        $where = "id != '0' ";

        $this->data['teachers'] = $this->my_model->getWhereRecords('system_teacher_code', $where);
        $this->data['total_teacher'] = count($this->data['teachers']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function tests() {
        $this->verifyUser();

        $this->data['window_title']="Tests";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Tests';

        $where = "id != '0' ";

        $this->data['tests'] = $this->my_model->getWhereRecords($this->tb_test, $where);
        $this->data['total_test'] = count($this->data['tests']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function ticket($id) {
        $this->verifyUser();


        $this->data['support'] = $this->my_model->getARecord($this->tb_support, $id);

        $where = "support_id =".$id; 

        $this->data['tickets'] = $this->my_model->getWhereOrderRecords($this->tb_ticket, $where ,'id','asc');
        $this->data['total_tickets'] = count($this->data['tickets']);



        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Ticket';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function support() {
        $this->verifyUser();



        $where = "id != ''";

        $this->data['supports'] = $this->my_model->getWhereRecords($this->tb_support, $where);
        $this->data['total_support'] = count($this->data['supports']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Support';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }  

    function closeTicket($id)
    {
        $this->verifyUser();

        $qryData = array(
            'status' => "resoloved",
        );

        if( $this->my_model->updateTable($this->tb_support, $qryData, $id) )
        {
            redirect($this->data['currentPath'].'/support?close=1');
        }
    }
  
    function replyTicket($id)
    {
        $this->verifyUser();

        $qryData = array(
            'support_id' => $id,
            'details' => $this->input->post('details'),
            'time' => time(),
        );

        if( $this->my_model->insertDataIntoTable($this->tb_ticket, $qryData) )
        {
            redirect($this->data['currentPath'].'/ticket/'.$id);
        }
    }

    function questions() {
        $this->verifyUser();

        $this->data['pagetitle']="Questions";
        $this->data['window_title'] = $this->app_name." ->".$this->data['pagetitle'];

        $where = "id != '0' ";
        $this->data['questions'] = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');
        $this->data['question'] = count($this->data['questions']);

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function questionType() {
        $this->verifyUser();

        $this->data['window_title']="Select Question Type";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Question';

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function ComingSoon() {
        $this->verifyUser();

        $this->data['window_title']="Select Question Type";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Question';

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function addQuestion($id) {
        $this->verifyUser();

        // Get type and subtype
        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord($this->tb_type, $this->data['subtype']->PTEtypeid);

        $role_id = 1; // Super admin role : equal to 1 in role table
        $Qtable =  $this->data['subtype']->tbname;
        $error = '';

        // Upload settings
        $config['upload_path'] = './uploads/dir/'.$this->data['type']->PTEtype;
        $config['max_size'] = $this->filemaxsize;
        $config['max_width'] = 5024;
        $config['max_height'] = 3868;

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
          
            // $this->form_validation->set_rules('testid', 'Select Test', 'trim|required');
            $this->form_validation->set_rules('question', 'Question Title', 'trim|required');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                # Main question table
                $qryData = array(
                    'testid' => $this->input->post('testid'),
                    'question' => $this->input->post('question'),
                    'PTEtypeid' => $this->data['type']->id,
                    'PTEsubtypeid' => $this->data['subtype']->id,
                    'Qtable' => $Qtable,
                    'time' => time(),
                );
                $this->my_model->insertDataIntoTable($this->tb_question, $qryData);
                $last_added_id = $this->db->insert_id();
                $extra_question_table = $this->tb_prefix.$Qtable.$this->tb_suffix;


                if($id=="15") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'paragraph' => $this->input->post('paragraph'),
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'words' => $this->input->post('words'),                            
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }


                if($id=="16") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'paragraph' => $this->input->post('paragraph'),
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'words' => $this->input->post('words'),                            
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                if($id=="17") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'paragraph' => $this->input->post('paragraph'),
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'words' => $this->input->post('words'),                            
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                if($id=="18") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'answer' => $this->input->post('answer'),
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                if($id=="19") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'answer' => $this->input->post('answer'),
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                if($id=="20") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'answer' => $this->input->post('answer'),
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }







                # Multiple Fill in the blanks = 36 (Reading:2)
                if($id=="36") {

                   
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'paragraph' => $this->input->post('paragraph'),
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'words' => $this->input->post('words'),
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                   
                } 

                # Fill in the blanks = 37 (Reading:2)
                if($id=="37") {

                   
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'paragraph' => $this->input->post('paragraph'),
                            'optionwords' => $this->input->post('optionwords'),
                            'words' => $this->input->post('words'),
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                   
                } 


                # 38 (Reading:2)
                if($id=="38") {

                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $this->load->library('upload', $config);
                    $attachment = 'diagram';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'paragraph' => $this->input->post('paragraph'),
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'words' => $this->input->post('words'),
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }


                # 39 (Reading:2)
                if($id=="39") {

                        $qryData = array(
                            'questionid' => $last_added_id,
                            'paragraph' => $this->input->post('paragraph'),
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'words' => $this->input->post('words'),
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                   
                } 











                # Multiple-choice: Single = 40 (Reading:2)
                if($id=="40") {

                   
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'optiontitle' => $this->input->post('optiontitle'),
                            'paragraph' => $this->input->post('paragraph'),
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'answer' => $this->input->post('answer'),
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                   
                }               

                # Multiple-choice: Single = 29 (Listening:3)
                if($id=="29") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'answer' => $this->input->post('answer'),
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }                

                # Multiple-choice: Multiple = 30 (Listening:3)
                if($id=="30") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    //create string of multiple answers 
                    $multians= implode(',',$this->input->post('answer'));
                 
                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'answer' => $multians,
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Fill in the blanks = 31 (Listening:3)
                if($id=="31") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'transcription' => $this->input->post('transcription'),
                            'words' => $this->input->post('words'),
                           
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Select missing word = 33 (Listening:3)
                if($id=="33") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'answer' => $this->input->post('answer'),
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Highlight correct summary = 32 (Listening:3)
                if($id=="32") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'option1' => $this->input->post('option1'),
                            'option2' => $this->input->post('option2'),
                            'option3' => $this->input->post('option3'),
                            'option4' => $this->input->post('option4'),
                            'answer' => $this->input->post('answer'),
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Highlight incorrect words = 34 (Listening:3)
                if($id=="34") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            'transcription' => $this->input->post('transcription'),
                             'words' => $this->input->post('words'),

                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Summarize spoken text = 28 (Listening:3)
                if($id=="28") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Write from dictation = 35 (Listening:3)
                if($id=="35") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Read Aloud = 41 (Speaking:1)
                if($id == '41') {
                    $qryData = array(
                        'questionid' => $last_added_id,
                        'paragraph' => $this->input->post('paragraph'),
                    );
                    if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                        $this->data['success'] = true;
                    }
                }

                # Repeat Sentence = 42 (Speaking:1)
                if($id=="42") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Describe Image = 43 (Speaking:1)
                if($id=="43") {

                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $this->load->library('upload', $config);
                    $attachment = 'SDimage';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Re-Tell Lecture = 44 (Speaking:1)
                if($id=="44") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                    $this->load->library('upload', $config);
                    $attachment = 'imageURL';
                    $attachment2 = 'mp3URL';

                    // print_r(($_FILES[$attachment]['name']));

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $file1 = $data['file_name'];
                    }

                    if ( ! $this->upload->do_upload($attachment2)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $file2 = $data['file_name'];
                    }

                    $qryData = array(
                        'questionid' => $last_added_id,
                        $attachment => $file1,
                        $attachment2 => $file2,
                    );

                    // print_r($qryData);
                    if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                        $this->data['success'] = true;
                    }
                }

                # Answer short question = 45 (Speaking:1)
                if($id=="45") {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if ( ! $this->upload->do_upload($attachment)) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $qryData = array(
                            'questionid' => $last_added_id,
                            $attachment => $data['file_name'],
                        );
                        if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                            $this->data['success'] = true;
                        }
                    }
                }

                # Summarize written text = 46 (Writing:4)
                if($id == '46') {
                    $qryData = array(
                        'questionid' => $last_added_id,
                        'essay' => $this->input->post('essay'),
                    );
                    if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                        $this->data['success'] = true;
                    }
                }

                # Write Essey = 47 (Writing:4)
                if($id == '47') {
                    $qryData = array(
                        'questionid' => $last_added_id,
                        'essayTitle' => $this->input->post('essayTitle'),
                    );
                    if( $this->my_model->insertDataIntoTable($extra_question_table, $qryData) ) {
                        $this->data['success'] = true;
                    }
                }

            }
        }



        $where = "id != '' ";
        $this->data['tests'] = $this->my_model->getWhereOrderRecords($this->tb_test, $where, 'test_name', 'asc');
        
        $this->data['errors'] = $error;
        
        $this->data['window_title'] = 'Add Question -'. $this->app_name;
        $this->data['pagetitle'] = 'Add Question';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function editQuestion($id) {

        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        $this->data['objQuestion'] = $this->my_model->getARecord($this->tb_question, $id);
        if( !is_object($this->data['objQuestion'])) {
            exit($this->unauthorized_message);
        }

        // Get type and subtype
        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $this->data['objQuestion']->PTEsubtypeid);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord($this->tb_type, $this->data['subtype']->PTEtypeid);

        // Get extra detail of question
        $Qtable =  $this->data['subtype']->tbname;
        $extra_question_table = $this->tb_prefix.$Qtable.$this->tb_suffix;
        $this->data['objExtra'] = $this->my_model->checkARecord($extra_question_table, 'questionid', $id);
        if( !is_object($this->data['objExtra'])) {
            exit($this->unauthorized_message);
        }

        $error = '';

        // Upload settings
        $config['upload_path'] = './uploads/dir/'.$this->data['type']->PTEtype;
        $config['max_size'] = $this->filemaxsize;
        $config['max_width'] = 5024;
        $config['max_height'] = 3868;

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
          
            $this->form_validation->set_rules('question', 'Question Title', 'trim|required');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>');

            if($this->form_validation->run() == TRUE)
            {
                # Main question table
                $qryData = array(
                    'question' => $this->input->post('question'),
                    'time' => time(),
                );
                $this->my_model->updateTable($this->tb_question, $qryData, $id);


                if($this->data['subtype']->id == '15') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'paragraph' => $this->input->post('paragraph'),
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'words' => $this->input->post('words'),
                    );

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData[$attachment] = $data['file_name'];
                            
                        }
                    }
   
                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }


                if($this->data['subtype']->id == '16') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'paragraph' => $this->input->post('paragraph'),
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'words' => $this->input->post('words'),
                    );

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData[$attachment] = $data['file_name'];
                            
                        }
                    }
   
                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }

                if($this->data['subtype']->id == '17') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'paragraph' => $this->input->post('paragraph'),
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'words' => $this->input->post('words'),
                    );

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData[$attachment] = $data['file_name'];
                            
                        }
                    }
   
                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }

                if($this->data['subtype']->id == '18') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'answer' => $this->input->post('answer'),
                    );   

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData[$attachment] = $data['file_name'];
                            
                        }
                    }
   
                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }

                if($this->data['subtype']->id == '19') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'answer' => $this->input->post('answer'),
                    );   

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData[$attachment] = $data['file_name'];
                            
                        }
                    }
   
                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }

                if($this->data['subtype']->id == '20') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'answer' => $this->input->post('answer'),
                    );   

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData[$attachment] = $data['file_name'];
                            
                        }
                    }
   
                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }













                #  Multiple-choice: Single  = 29 (Listening:3)
                if($this->data['subtype']->id == '29') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'answer' => $this->input->post('answer'),
                    );   



                        if($_FILES[$attachment]['tmp_name'] != "") {

                            if ( ! $this->upload->do_upload($attachment)) {
                                $error = array('error' => $this->upload->display_errors());
                                //return false;
                            } else {
                                $data =  $this->upload->data();
                                $qryData[$attachment] = $data['file_name'];
                                
                            }
                        }
       
                        if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                        {
                            $this->data['success'] = true;
                        }
                

                }   



                #  Multiple Fill in the blanks  = 36 (Reading:2)
                if($this->data['subtype']->id == '36') {

                    $qryData = array(
                        'paragraph' => $this->input->post('paragraph'),
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'words' => $this->input->post('words'),
                    );   

                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }


                #  Fill in the blanks  = 37 (Reading:2)
                if($this->data['subtype']->id == '37') {

                    $qryData = array(
                        'paragraph' => $this->input->post('paragraph'),
                        'optionwords' => $this->input->post('optionwords'),
                        'words' => $this->input->post('words'),             
                    );   

                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }  


                #  38 (Reading:2)
                if($this->data['subtype']->id == '38') {

                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $this->load->library('upload', $config);
                    $attachment = 'diagram';

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData = array(
                                'paragraph' => $this->input->post('paragraph'),
                                'option1' => $this->input->post('option1'),
                                'option2' => $this->input->post('option2'),
                                'option3' => $this->input->post('option3'),
                                'option4' => $this->input->post('option4'),
                                'words' => $this->input->post('words'),
                                $attachment => $data['file_name'],
                            );
                            if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                            {
                                $this->data['success'] = true;
                            }
                        }
                    }
                }


                #  39 (Reading:2)
                if($this->data['subtype']->id == '39') {

                    $qryData = array(
                        'paragraph' => $this->input->post('paragraph'),
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'words' => $this->input->post('words'),
                    );

                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }   



                #  Multiple-choice: Single  = 40 (Reading:2)
                if($this->data['subtype']->id == '40') {

                    $qryData = array(
                        'paragraph' => $this->input->post('paragraph'),
                        'optiontitle' => $this->input->post('optiontitle'),
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'answer' => $this->input->post('answer'),
                    );   

                        if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                        {
                            $this->data['success'] = true;
                        }
                

                }     






                #  Multiple-choice: Multiple  = 30 (Listening:3)
                if($this->data['subtype']->id == '30') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                    $multians= implode(',',$this->input->post('answer'));

                    $qryData = array(
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'answer' =>  $multians,
                    );   



                        if($_FILES[$attachment]['tmp_name'] != "") {

                            if ( ! $this->upload->do_upload($attachment)) {
                                $error = array('error' => $this->upload->display_errors());
                                //return false;
                            } else {
                                $data =  $this->upload->data();
                                $qryData[$attachment] = $data['file_name'];
                                
                            }
                        }
       
                        if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                        {
                            $this->data['success'] = true;
                        }
                

                }

                #  Select missing word  = 33 (Listening:3)
                if($this->data['subtype']->id == '33') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'answer' => $this->input->post('answer'),
                    );   



                        if($_FILES[$attachment]['tmp_name'] != "") {

                            if ( ! $this->upload->do_upload($attachment)) {
                                $error = array('error' => $this->upload->display_errors());
                                //return false;
                            } else {
                                $data =  $this->upload->data();
                                $qryData[$attachment] = $data['file_name'];
                                
                            }
                        }
       
                        if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                        {
                            $this->data['success'] = true;
                        }
                

                }

                #  Highlight correct summary  = 32 (Listening:3)
                if($this->data['subtype']->id == '32') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'option4' => $this->input->post('option4'),
                        'answer' => $this->input->post('answer'),
                    );   



                        if($_FILES[$attachment]['tmp_name'] != "") {

                            if ( ! $this->upload->do_upload($attachment)) {
                                $error = array('error' => $this->upload->display_errors());
                                //return false;
                            } else {
                                $data =  $this->upload->data();
                                $qryData[$attachment] = $data['file_name'];
                                
                            }
                        }
       
                        if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                        {
                            $this->data['success'] = true;
                        }
                

                }

                #  Highlight incorrect words  = 34 (Listening:3)
                if($this->data['subtype']->id == '34') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'transcription' => $this->input->post('transcription'),
                        'words' => $this->input->post('words'),
                    );   



                        if($_FILES[$attachment]['tmp_name'] != "") {

                            if ( ! $this->upload->do_upload($attachment)) {
                                $error = array('error' => $this->upload->display_errors());
                                //return false;
                            } else {
                                $data =  $this->upload->data();
                                $qryData[$attachment] = $data['file_name'];
                                
                            }
                        }
       
                        if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                        {
                            $this->data['success'] = true;
                        }
                

                }


                #  Fill in the blanks  = 31 (Listening:3)
                if($this->data['subtype']->id == '31') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';
                   
                    $qryData = array(
                        'transcription' => $this->input->post('transcription'),
                        'words' => $this->input->post('words'),
                    );   



                        if($_FILES[$attachment]['tmp_name'] != "") {

                            if ( ! $this->upload->do_upload($attachment)) {
                                $error = array('error' => $this->upload->display_errors());
                                //return false;
                            } else {
                                $data =  $this->upload->data();
                                $qryData[$attachment] = $data['file_name'];
                                
                            }
                        }
       
                        if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                        {
                            $this->data['success'] = true;
                        }
                

                }


                # Summarize spoken text = 28 (Listening:3)
                if($this->data['subtype']->id == '28') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData = array(
                                $attachment => $data['file_name'],
                            );
                            if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                            {
                                $this->data['success'] = true;
                            }
                        }
                    }
                }

                # Write from dictation = 35 (Listening:3)
                if($this->data['subtype']->id == '35') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData = array(
                                $attachment => $data['file_name'],
                            );
                            if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                            {
                                $this->data['success'] = true;
                            }
                        }
                    }
                }



                # Read Aloud = 41 (Speaking:1)
                if($this->data['subtype']->id == '41') {
                    $qryData = array(
                        'paragraph' => $this->input->post('paragraph'),
                    );
                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }

                # Repeat Sentence = 42 (Speaking:1)
                if($this->data['subtype']->id == '42') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData = array(
                                $attachment => $data['file_name'],
                            );
                            if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                            {
                                $this->data['success'] = true;
                            }
                        }
                    }
                }

                # Describe Image = 43 (Speaking:1)
                if($this->data['subtype']->id == '43') {

                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $this->load->library('upload', $config);
                    $attachment = 'SDimage';

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData = array(
                                $attachment => $data['file_name'],
                            );
                            if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                            {
                                $this->data['success'] = true;
                            }
                        }
                    }
                }

                # Re-Tell Lecture = 44 (Speaking:1)
                if($this->data['subtype']->id == '44') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                    $this->load->library('upload', $config);
                    $attachment = 'imageURL';
                    $attachment2 = 'mp3URL';
                    $file1=NULL;
                    $file2=NULL;

                    // print_r(($_FILES[$attachment]['name']));
                    
                   if($_FILES[$attachment]['name']!="")
                    {   
                            if ( ! $this->upload->do_upload($attachment)) {
                                $error = array('error' => $this->upload->display_errors());
                                //return false;
                            } else {
                                
                                 $data =  $this->upload->data();
                                 $file1 = $data['file_name'];

                                 $qryData = array(
                                         $attachment => $file1,
                                    
                                );

                            }
                    }

                  
                   if($_FILES[$attachment2]['name']!="")
                    {   
                        if ( ! $this->upload->do_upload($attachment2)) {
                            $error = array('error' => $this->upload->display_errors());
                            //return false;
                        } else {
                            $data =  $this->upload->data();
                             $file2 = $data['file_name'];

                                     $qryData = array(
                                     $attachment2 => $file2,
                                
                            );

                       }
                     }   

                           if($file1 && $file2)
                           {
                                 $qryData = array(
                                 $attachment => $file1,
                                 $attachment2 => $file2,
                            
                                  );
                           }

                     if($file1 || $file2 )
                     {
                        if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                            {
                                $this->data['success'] = true;
                            }
                     }
                       

                }

                # Answer short question = 45 (Speaking:1)
                if($this->data['subtype']->id == '45') {

                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);
                    $attachment = 'mp3URL';

                    if($_FILES[$attachment]['tmp_name'] != "") {

                        if ( ! $this->upload->do_upload($attachment)) {
                            $error = array('error' => $this->upload->display_errors());
                            return false;
                        } else {
                            $data =  $this->upload->data();
                            $qryData = array(
                                $attachment => $data['file_name'],
                            );
                            if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                            {
                                $this->data['success'] = true;
                            }
                        }
                    }
                }

                # Summarize written text = 46 (Writing:4)
                if($this->data['subtype']->id == '46') {
                    $qryData = array(
                        'essay' => $this->input->post('essay'),
                    );
                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }

                # Write Essey = 47 (Writing:4)
                if($this->data['subtype']->id == '47') {
                    $qryData = array(
                        'essayTitle' => $this->input->post('essayTitle'),
                    );
                    if($this->my_model->updateTable($extra_question_table, $qryData, $this->data['objExtra']->id))
                    {
                        $this->data['success'] = true;
                    }
                }
            }
        }

        // Get Test
        $this->data['objTest'] = $this->my_model->getARecord($this->tb_test, $this->data['objQuestion']->testid);
        if( !is_object($this->data['objTest'])) {
            exit($this->unauthorized_message);
        }

        $this->data['errors'] = $error;

        $this->data['window_title'] = 'Update Question -'. $this->app_name;
        $this->data['pagetitle'] = 'Update Question';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }




    function addTeacher() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {

            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                );

                if( $this->my_model->insertDataIntoTable('system_teacher_code', $qryData) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add New Teacher';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function editTeacher($id)
    {
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                );

                if( $this->my_model->updateTable('system_teacher_code', $qryData, $id) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Teacher Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['teacher'] = $this->my_model->getARecord('system_teacher_code', $id);
        if( !is_object($this->data['teacher'])) { return false; }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function deleteTeacher($id)
    {
        $this->verifyUser();
        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/writers'); }
        if( $this->my_model->deleteARecord('system_teacher_code', $id) )
        {
            redirect($this->data['currentPath'].'/teacher?trash=1');
        }
        redirect($this->data['currentPath'].'/teacher');
    }

    function deleteTicket($id)
    {
        $this->verifyUser();
        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/writers'); }
        if( $this->my_model->deleteARecord($this->tb_support, $id) )
        {
            redirect($this->data['currentPath'].'/support?trash=1');
        }
        redirect($this->data['currentPath'].'/support');
    }


    function editMember($id)
    {
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'student_reference_no'=>$this->input->post('student_reference_no'),
                    'business_reference_no'=>$this->input->post('business_reference_no'),
                    'reference_no'=>$this->input->post('reference_no'),
                    'created_time' => time(),
                    'status' => $this->input->post('status')
                );

                if( $this->my_model->updateTable('system_member_code', $qryData, $id) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Student Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['member'] = $this->my_model->getARecord('system_member_code', $id);
        if( !is_object($this->data['member'])) { return false; }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function deleteMember($id)
    {
        $this->verifyUser();
        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/member'); }
        if( $this->my_model->deleteARecord('system_member_code', $id) )
        {
            redirect($this->data['currentPath'].'/member?trash=1');
        }
        redirect($this->data['currentPath'].'/member');
    }

 

 function addTest() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {

            $this->form_validation->set_rules('testType', 'Test type', 'trim');
            $this->form_validation->set_rules('test_name', 'Test_name', 'trim');
            $this->form_validation->set_rules('total_time', 'Total_time', 'trim');
            $this->form_validation->set_rules('price', 'price', 'trim');


            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'testType' => $this->input->post('testType'),
                    'test_name' => $this->input->post('test_name'),
                    'total_time' => $this->input->post('total_time'),
                    'price' => $this->input->post('price'),
                    'time' => time(),
                );

                if( $this->my_model->insertDataIntoTable($this->tb_test, $qryData) )
                {
                    $this->data['success'] = true;
                    $last_added_id = $this->db->insert_id();

                    $updateData = array(
                        'id_md5' => md5($last_added_id),
                    );
                    $this->my_model->updateTable($this->tb_test, $updateData, $last_added_id);

                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add New Test';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function editTest($id)
    {
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');

            $this->form_validation->set_rules('testType', 'Test type', 'trim');

            $this->form_validation->set_rules('test_name', 'Test_name', 'trim');
            $this->form_validation->set_rules('total_time', 'Total_time', 'trim');
            $this->form_validation->set_rules('price', 'Price', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'testType' => $this->input->post('testType'),
                    'test_name' => $this->input->post('test_name'),
                    'total_time' => $this->input->post('total_time'),
                    'price' => $this->input->post('price'),
                );

                if( $this->my_model->updateTable($this->tb_test, $qryData, $id) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Test Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['test'] = $this->my_model->getARecord($this->tb_test, $id);
        if( !is_object($this->data['test'])) { return false; }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }



    function deleteTest($id)
    {
        $this->verifyUser();
        
        if($id != '7') { // sample test cannot be delete

            if (!is_numeric($id)){ redirect($this->data['currentPath'].'/tests'); }
 
            if( $this->my_model->deleteARecord($this->tb_test, $id) ) {
                redirect($this->data['currentPath'].'/tests?trash=1');

            }
        }

        redirect($this->data['currentPath'].'/tests');
    }


    function deleteQuestion($id,$table)
    {
        $this->verifyUser();

        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/tests'); }

        if( $this->my_model->deleteARecord('system_question_code', $id) )
        {
            $this->my_model->deleteWhereRecord('system_'.$table.'_code', 'questionid' , $id);

            redirect($this->data['currentPath'].'/questions?trash=1');
        }
        redirect($this->data['currentPath'].'/questions');
    }
    
    function editvlevel($id){
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {

            $this->form_validation->set_rules('level_name', 'Level_name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('coin_cost', 'Coin Cost', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('level_name'),
                    'coin_cost' => $this->input->post('coin_cost'),
                );

                if( $this->my_model->updateTable($this->tb_vlevel, $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Edit Category succeeded!!');
                }
                redirect('superadmin/vocabularytests');
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Lavel Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['level'] = $this->my_model->getARecord($this->tb_vlevel, $id);
        //echo "<pre>";print_r($this->data['level']);die;
        if( !is_object($this->data['level'])) { return false; }
        //$this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
        $this->load->view('superadmin/vocabulary_edit_level_view', $this->data);
        
    }
    
    function vaddlevel(){
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('level_name', 'Category Name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('coin_cost', 'Coin Cost', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('level_name'),
                    'coin_cost' => $this->input->post('coin_cost'),
                    'active' => 'Yes'
                );

                if( $this->my_model->insertDataIntoTable($this->tb_vlevel, $qryData) )
                {
                    $last_added_id = $this->db->insert_id();
                    $this->session->set_flashdata('global_msg', 'Add succeeded!!');
                }
                redirect('superadmin/vocabularytests');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add New Test';
        $this->load->view('superadmin/vocabulary_add_level_view', $this->data); 
    }
    
    
    function reseller() {
        $this->verifyUser();

        $this->data['window_title']="Reseller";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Reseller';

        $where = "id != '0' ";

        $this->data['resellers'] = $this->my_model->getWhereRecords('system_reseller_code', $where);
        $this->data['total_resellers'] = count($this->data['resellers']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    
    function editReseller($id)
    {
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'reference_no' => $this->input->post('reference_no'),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                );

                if( $this->my_model->updateTable('system_reseller_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Reseller update successfully!!');
                }
                redirect('superadmin/reseller');
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Reseller Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['reseller'] = $this->my_model->getARecord('system_reseller_code', $id);
        if( !is_object($this->data['reseller'])) { return false; }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function deleteReseller($id)
    {
        $this->verifyUser();
        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/reseller'); }
        if( $this->my_model->deleteARecord('system_reseller_code', $id) )
        {
             $this->session->set_flashdata('global_msg', 'Reseller has been deleted successfully!!');
        }
        redirect('superadmin/reseller');
    }
    
    function addReseller()
    {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_POST);die;
            $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_reseller_code.email]');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_reseller_code.username]');
            $this->form_validation->set_rules('reference_no', 'Reference Number', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'reference_no' => $this->input->post('reference_no'),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                );

                
                if( $this->my_model->insertDataIntoTable('system_reseller_code', $qryData) )
                {
                    $this->session->set_flashdata('global_msg', 'Reseller added successfully!!');
                }
                redirect('superadmin/reseller');
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Reseller Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    

      function s3_bucket_upload($temppath, $image_path, $folder)
    {
        require 'aws-s3-bucket/vendor/autoload.php';
        $bucket = "celpipstore-media-files";
        //$bucket = "com.homepie.staging.images";
       // print_r($image_path);die;




        $data = array();
        $data['message'] = "false";

        try {
            //staging homepie
            /* $s3Client = new Aws\S3\S3Client([
                'version'     => 'latest',
                'region'      => 'us-west-2',
                'credentials' => [
                    'key'    => 'AKIAQ5TUPBP67S6PCJ6U',
                    'secret' => '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',
                ],
            ]); */

            //celpip bucket
            $s3Client = new Aws\S3\S3Client([
                'version'     => 'latest',
                'region'      => 'us-west-2',
                'credentials' => [
                    'key'    => 'AKIA323GRW63FBO3HGTM',
                    'secret' => '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',
                ],
            ]);

            // For website only
            $result = $s3Client->putObject([
                'Bucket'     => $bucket,
                'Key'        => 'ielts/'.$folder.'/'.$image_path,
                'SourceFile' => $temppath,
                //'body'=> $file_Path,
                //'ACL'        => 'public-read',
                //'StorageClass' => 'REDUCED_REDUNDANCY',
            ]);
            $data['message']   = "sucess";
            $data['imagename'] = $image_path;
            $data['imagepath'] = $result['ObjectURL'];

            //Get a command to GetObject
       

        } catch (Exception $e) {
            $data['message'] = "false";
            echo $e->getMessage() . "\n";
        }

        return $data;
    }
    
    
    
    function part11list(){
        $this->verifyUser();
        $this->data['window_title']="Part 1: Multiple choice with one answer";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 1: Multiple choice with one answer';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part1_MCOA_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part1_1listing', $this->data);
    }
    
    function add_part1_1()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part1_MCOA_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART1_MCOA'. $next_code;
        }else{
            $this->data['test_code']='PART1_MCOA1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
            
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer','1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_MCOA';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
               // print_r(($_FILES[$attachment]['name']));
                        
              

        if($_FILES['conversation_1_audio']['name']!="")
                {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }
                    $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'l1_conversation_1_audio' => $conversation_1_audio,
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_option1' => $this->input->post('q1_option1'),
                        'q1_option2' => $this->input->post('q1_option2'),
                        'q1_option3' => $this->input->post('q1_option3'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_option1' => $this->input->post('q2_option1'),
                        'q2_option2' => $this->input->post('q2_option2'),
                        'q2_option3' => $this->input->post('q2_option3'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_option1' => $this->input->post('q3_option1'),
                        'q3_option2' => $this->input->post('q3_option2'),
                        'q3_option3' => $this->input->post('q3_option3'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'created_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part1_MCOA_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '11');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '11');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part11list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part1_1',$this->data);
    }
    
        function edit_part1_1($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

                $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer', '1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
           
            
            
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                
                $getl1data = $this->my_model->getARecord('system_part1_MCOA_code', $id);
                
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_MCOA';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
                  
                  
                   if($_FILES['conversation_1_audio']['name']!="")
                        {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }else{
                    $conversation_1_audio = $getl1data->l1_conversation_1_audio;
                }
                
                    $qryData = array(
                        'l1_conversation_1_audio' => $conversation_1_audio,
                        
                            'q1_question' => $this->input->post('q1_question'),
                    'q1_option1' => $this->input->post('q1_option1'),
                    'q1_option2' => $this->input->post('q1_option2'),
                    'q1_option3' => $this->input->post('q1_option3'),
                    'q1_answer' => $this->input->post('q1_answer'),
                    
                    
                    'q2_question' => $this->input->post('q2_question'),
                    'q2_option1' => $this->input->post('q2_option1'),
                    'q2_option2' => $this->input->post('q2_option2'),
                    'q2_option3' => $this->input->post('q2_option3'),
                    'q2_answer' => $this->input->post('q2_answer'),
                    
                    
                    'q3_question' => $this->input->post('q3_question'),
                    'q3_option1' => $this->input->post('q3_option1'),
                    'q3_option2' => $this->input->post('q3_option2'),
                    'q3_option3' => $this->input->post('q3_option3'),
                    'q3_answer' => $this->input->post('q3_answer'),
                    
                    'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part1_MCOA_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part11list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part1_MCOA_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Short listening';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part1_MCOA_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 1: Multiple choice with one answer';
        $this->load->view('superadmin/edit_part1_1', $this->data);
    }
        function part12list(){
        $this->verifyUser();
        $this->data['window_title']="Part 1: Multiple choice with more than one answer";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 2: Multiple choice with more than one answer';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part1_MCMTOA_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part1_2listing', $this->data);
    }
    
    function add_part1_2()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part1_MCMTOA_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART1_MCMTOA'. $next_code;
        }else{
            $this->data['test_code']='PART1_MCMTOA1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
            
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '3rd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '4th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option5', '5th Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option6', '6th Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option7', '7th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option8', '8th Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer1','1st answer 1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer2','1st answer 2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer3','1st answer 3', 'trim|required|xss_clean');
        
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_MCMTOA';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
               // print_r(($_FILES[$attachment]['name']));
                        
              

        if($_FILES['conversation_1_audio']['name']!="")
                {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'l1_conversation_1_audio' => $conversation_1_audio,
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_option1' => $this->input->post('q1_option1'),
                        'q1_option2' => $this->input->post('q1_option2'),
                        'q1_option3' => $this->input->post('q1_option3'),
                        'q1_option4' => $this->input->post('q1_option4'),
                        'q1_option5' => $this->input->post('q1_option5'),
                        'q1_option6' => $this->input->post('q1_option6'),
                        'q1_option7' => $this->input->post('q1_option7'),
                        'q1_option8' => $this->input->post('q1_option8'),
                        'q1_answer1' => $this->input->post('q1_answer1'),
                        'q1_answer2' => $this->input->post('q1_answer2'),
                        'q1_answer3' => $this->input->post('q1_answer3'),
                        
                
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part1_MCMTOA_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '12');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '12');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part12list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part1_2',$this->data);
    }
            function edit_part1_2($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

                $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '3rd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '4th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option5', '5th Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option6', '6th Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option7', '7th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option8', '8th Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer1','1st answer 1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer2','1st answer 2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer3','1st answer 3', 'trim|required|xss_clean');
        
            
            
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                
                $getl1data = $this->my_model->getARecord('system_part1_MCMTOA_code', $id);
                
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_MCMTOA';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
                  
                  
                   if($_FILES['conversation_1_audio']['name']!="")
                        {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }else{
                    $conversation_1_audio = $getl1data->l1_conversation_1_audio;
                }
                
                    $qryData = array(
                       'l1_conversation_1_audio' => $conversation_1_audio,
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_option1' => $this->input->post('q1_option1'),
                        'q1_option2' => $this->input->post('q1_option2'),
                        'q1_option3' => $this->input->post('q1_option3'),
                        'q1_option4' => $this->input->post('q1_option4'),
                        'q1_option5' => $this->input->post('q1_option5'),
                        'q1_option6' => $this->input->post('q1_option6'),
                        'q1_option7' => $this->input->post('q1_option7'),
                        'q1_option8' => $this->input->post('q1_option8'),
                        'q1_answer1' => $this->input->post('q1_answer1'),
                        'q1_answer2' => $this->input->post('q1_answer2'),
                        'q1_answer3' => $this->input->post('q1_answer3'),
                
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part1_MCMTOA_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part12list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part1_MCMTOA_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update  listening';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part1_MCMTOA_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 1: Multiple choice with more than one answer';
        $this->load->view('superadmin/edit_part1_2', $this->data);
    }
        function part13list(){
        $this->verifyUser();
        $this->data['window_title']="Part 3: Matching";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 3: Matching';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part1_MH_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part1_3listing', $this->data);
    }
        function add_part1_3()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part1_MH_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART1_MH'. $next_code;
        }else{
            $this->data['test_code']='PART1_MH';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
            
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('heading1', 'Heading 1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h1_answer', 'Heading 1 Answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('heading2', 'Heading 2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h2_answer', 'Heading 2 Answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('heading3', 'Heading 3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h3_answer', 'Heading 3 Answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('heading4', 'Heading 4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h4_answer', 'Heading 4 Answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('heading5', 'Heading 5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h5_answer', 'Heading 5 Answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('option1', 'Option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('option2', 'Option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('option3', 'Option3', 'trim|required|xss_clean');
        
        
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_MH';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
               // print_r(($_FILES[$attachment]['name']));
                        
              

        if($_FILES['conversation_1_audio']['name']!="")
                {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'l1_conversation_1_audio' => $conversation_1_audio,
                    
                'q1_question' => $this->input->post('q1_question'),
                
                        'heading1' => $this->input->post('heading1'),
                        'h1_answer' => $this->input->post('h1_answer'),
                
                        'heading2' => $this->input->post('heading2'),
                        'h2_answer' => $this->input->post('h2_answer'),
                
                        'heading3' => $this->input->post('heading3'),
                        'h3_answer' => $this->input->post('h3_answer'),
                
                        'heading4' => $this->input->post('heading4'),
                        'h4_answer' => $this->input->post('h4_answer'),
                
                        'heading5' => $this->input->post('heading5'),
                        'h5_answer' => $this->input->post('h5_answer'),
                
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        
                
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part1_MH_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '13');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '13');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part13list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part1_3',$this->data);
    }
    
    function edit_part1_3($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

                $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('heading1', 'Heading 1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h1_answer', 'Heading 1 Answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('heading2', 'Heading 2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h2_answer', 'Heading 2 Answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('heading3', 'Heading 3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h3_answer', 'Heading 3 Answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('heading4', 'Heading 4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h4_answer', 'Heading 4 Answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('heading5', 'Heading 5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('h5_answer', 'Heading 5 Answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('option1', 'Option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('option2', 'Option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('option3', 'Option3', 'trim|required|xss_clean');
        
        
            
            
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                
                $getl1data = $this->my_model->getARecord('system_part1_MCMTOA_code', $id);
                
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_MH';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
                  
                  
                   if($_FILES['conversation_1_audio']['name']!="")
                        {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }else{
                    $conversation_1_audio = $getl1data->l1_conversation_1_audio;
                }
                
                    $qryData = array(
                            'l1_conversation_1_audio' => $conversation_1_audio,
                    
                'q1_question' => $this->input->post('q1_question'),
                
                        'heading1' => $this->input->post('heading1'),
                        'h1_answer' => $this->input->post('h1_answer'),
                
                        'heading2' => $this->input->post('heading2'),
                        'h2_answer' => $this->input->post('h2_answer'),
                
                        'heading3' => $this->input->post('heading3'),
                        'h3_answer' => $this->input->post('h3_answer'),
                
                        'heading4' => $this->input->post('heading4'),
                        'h4_answer' => $this->input->post('h4_answer'),
                
                        'heading5' => $this->input->post('heading5'),
                        'h5_answer' => $this->input->post('h5_answer'),
                
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        
                
                        
                
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part1_MH_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part13list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part1_MH_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update  listening';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part1_MH_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 3: Matching';
        $this->load->view('superadmin/edit_part1_3', $this->data);
    }
    function part14list(){
        $this->verifyUser();
        $this->data['window_title']="Part 4: Marking on a map";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 4: Marking on a map';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part1_LOM_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part1_4listing', $this->data);
    }
        function add_part1_4(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part1_LOM_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='Part1_LOM'. $next_code;
        }else{
            $this->data['test_code']='Part1_LOM1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');        
            
            $this->form_validation->set_rules('q1_answer','1st answer', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q3_question','3rd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
                    
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                     
                     
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/part1_LOM';
                $this->load->library('upload', $config);
                $scene_img='';
                $conversation_1_audio='';
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];
                   }
                }
                if($_FILES['conversation_1_audio']['name']!="")
                {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }
                
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'l1_conversation_1_audio' => $conversation_1_audio,
                    'q1_image' => $scene_img,
                    'q1_question' => $this->input->post('q1_question'),  
                    'q1_answer' => $this->input->post('q1_answer'),
                    'q2_question' => $this->input->post('q2_question'),
                    'q2_answer' => $this->input->post('q2_answer'),
                    'q3_question' => $this->input->post('q3_question'),
                    'q3_answer' => $this->input->post('q3_answer'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->insertDataIntoTable('system_part1_LOM_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '14');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '14');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Speaking Task added successfully!!');
                }
                redirect('superadmin/part14list');
            }
        }
        
        $this->data['pagetitle'] = 'Part 4: Labelling on a map';
        $this->load->view('superadmin/add_part1_4',$this->data);
    }
    
    function edit_part1_4($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer', '1st answer', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');
        
            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
             $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
        
            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
            
            

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $getl1data = $this->my_model->getARecord('system_part1_LOM_code', $id);
                $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/part1_LOM';
                $this->load->library('upload', $config);
                $scene_img='';  
                $conversation_1_audio='';
 
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];

                   }
                }else{
                    $scene_img = $getl1data->q1_image;
                }
                if($_FILES['conversation_1_audio']['name']!="")
                        {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }else{
                    $conversation_1_audio = $getl1data->l1_conversation_1_audio;
                }
                
                    $qryData = array(
                        'l1_conversation_1_audio' => $conversation_1_audio,
                        'q1_image' => $scene_img,
                        'q1_question' => $this->input->post('q1_question'), 
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;


                if( $this->my_model->updateTable('system_part1_LOM_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part14list');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part1_LOM_code', $where);
    
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update listening';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part1_LOM_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 4: Labelling on a Map';
        $this->load->view('superadmin/edit_part1_4', $this->data);
    }
    function part15list(){
        $this->verifyUser();
        $this->data['window_title']="Part 5: Fill in the gaps";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 5: Fill in the gaps';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part1_FIG_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part1_5listing', $this->data);
    }
    
        function add_part1_5(){
            $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part1_FIG_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='part1_FIB'. $next_code;
        }else{
            $this->data['test_code']='part1_FIB1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_FIG';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
               // print_r(($_FILES[$attachment]['name']));
                        
              

        if($_FILES['conversation_1_audio']['name']!="")
                {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'l1_conversation_1_audio' => $conversation_1_audio,
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_heading' => $this->input->post('q1_heading'),
                        'q1_words' => $this->input->post('q1_words'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_heading' => $this->input->post('q2_heading'),
                        'q2_words' => $this->input->post('q2_words'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_heading' => $this->input->post('q3_heading'),
                        'q3_words' => $this->input->post('q3_words'),
                        'created_date' => date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part1_FIG_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '15');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '15');
                        }
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                redirect('superadmin/part15list');
            }
        }
        
        $this->load->view('superadmin/add_part1_5',$this->data);
        
    }
    
    
    
    
    function edit_part1_5($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                
            
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_FIG';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
               // print_r(($_FILES[$attachment]['name']));
                        
              

        if($_FILES['conversation_1_audio']['name']!="")
                {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }
                  $qryData = array(
                        
                        
                        'l1_conversation_1_audio' => $conversation_1_audio,
                      'q1_question' => $this->input->post('q1_question'),
             
                        'q1_heading' => $this->input->post('q1_heading'),
                        'q1_words' => $this->input->post('q1_words'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_heading' => $this->input->post('q2_heading'),
                        'q2_words' => $this->input->post('q2_words'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_heading' => $this->input->post('q3_heading'),
                        'q3_words' => $this->input->post('q3_words'),           'updated_date' => date('Y-m-d H:i:s'),
                );
                
        //      echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part1_FIG_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'update successfully!!');
                }
                
                redirect('superadmin/part15list');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update listening Part 5 Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['l2data'] = $this->my_model->getARecord('system_part1_FIG_code', $id);
        if( !is_object($this->data['l2data'])) { return false; }
        $this->load->view('superadmin/edit_part1_5', $this->data);
        
    }
    
    
    
    function part16list(){
        $this->verifyUser();
        $this->data['window_title']="Part 6: Fill in the gaps: short answers";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 6: Fill in the gaps: short answers';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part1_FGOWA_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part1_6listing', $this->data);
    }
    
        function add_part1_6()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part1_FGOWA_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART1_FGOWA'. $next_code;
        }else{
            $this->data['test_code']='PART1_FGOWA1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
            
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('answer1', 'Answer1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answer2', 'Answer2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answer3', '1st Question option3', 'trim|required|xss_clean');
        
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_FGOWA';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
               // print_r(($_FILES[$attachment]['name']));
                        
              

        if($_FILES['conversation_1_audio']['name']!="")
                {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'l1_conversation_1_audio' => $conversation_1_audio,
                        'q1_question' => $this->input->post('q1_question'),
                        'answer1' => $this->input->post('answer1'),
                        'answer2' => $this->input->post('answer2'),
                        'answer3' => $this->input->post('answer3'),
                        
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part1_FGOWA_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '16');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '16');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part16list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part1_6',$this->data);
    }
    
        
    function edit_part1_6($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
                
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('answer1', 'Answer1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answer2', 'Answer2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answer3', 'Answer3', 'trim|required|xss_clean');
            
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mp3|mp4';
                $config['upload_path'] = './uploads/part1_FGOWA';
                $this->load->library('upload', $config);
                $conversation_1_audio='';
               // print_r(($_FILES[$attachment]['name']));
                        
              

        if($_FILES['conversation_1_audio']['name']!="")
                {
                    if ( ! $this->upload->do_upload('conversation_1_audio')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                        $data =  $this->upload->data();
                        $conversation_1_audio = $data['file_name'];

                   }
                }
                  $qryData = array(
                        
                        
                        'l1_conversation_1_audio' => $conversation_1_audio,
                        'q1_question' => $this->input->post('q1_question'),
                        'answer1' => $this->input->post('answer1'),
                        'answer2' => $this->input->post('answer2'),
                        'answer3' => $this->input->post('answer3'),
                        
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;


                if( $this->my_model->updateTable('system_part1_FGOWA_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part16list');
            }
                 
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part1_FGOWA_code', $where);
    
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update listening';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part1_FGOWA_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 6: Fill in the gaps: short answers';
        $this->load->view('superadmin/edit_part1_6', $this->data);
    }
    
    
    function part21list(){
        $this->verifyUser();
        $this->data['window_title']="Part 1: Multiple choice with one answer";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 1: Multiple choice with one answer';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_MCOA_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part2_1listing', $this->data);
    }
    
    function add_part2_1()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_MCOA_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART2_MCOA'. $next_code;
        }else{
            $this->data['test_code']='PART2_MCOA1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
                $this->form_validation->set_rules('passage','Passage', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer','1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option4', '2nd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option4', '3rd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('q4_question', '4th Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option1', '4th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option2', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option3', '4th Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option4', '4th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answer', '4th answer', 'trim|required|xss_clean');
            
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'passage' => $this->input->post('passage'),
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_option1' => $this->input->post('q1_option1'),
                        'q1_option2' => $this->input->post('q1_option2'),
                        'q1_option3' => $this->input->post('q1_option3'),
                        'q1_option4' => $this->input->post('q1_option4'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_option1' => $this->input->post('q2_option1'),
                        'q2_option2' => $this->input->post('q2_option2'),
                        'q2_option3' => $this->input->post('q2_option3'),
                        'q2_option4' => $this->input->post('q2_option4'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_option1' => $this->input->post('q3_option1'),
                        'q3_option2' => $this->input->post('q3_option2'),
                        'q3_option3' => $this->input->post('q3_option3'),
                        'q3_option4' => $this->input->post('q3_option4'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_option1' => $this->input->post('q4_option1'),
                        'q4_option2' => $this->input->post('q4_option2'),
                        'q4_option3' => $this->input->post('q4_option3'),
                        'q4_option4' => $this->input->post('q4_option4'),
                        'q4_answer' => $this->input->post('q4_answer'),
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_MCOA_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '21');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '21');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part21list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part2_1',$this->data);
    }
    
    function edit_part2_1($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

                $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option4', 'trim|required|xss_clean'); 
            $this->form_validation->set_rules('q1_answer', '1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option4', '2nd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option4', '3rd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
           
                $this->form_validation->set_rules('q4_question', '4th Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option1', '4th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option2', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option3', '4th Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option4', '4th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answer', '4th answer', 'trim|required|xss_clean');
            
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        
                            'passage' => $this->input->post('passage'),
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_option1' => $this->input->post('q1_option1'),
                        'q1_option2' => $this->input->post('q1_option2'),
                        'q1_option3' => $this->input->post('q1_option3'),
                        'q1_option4' => $this->input->post('q1_option4'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_option1' => $this->input->post('q2_option1'),
                        'q2_option2' => $this->input->post('q2_option2'),
                        'q2_option3' => $this->input->post('q2_option3'),
                        'q2_option4' => $this->input->post('q2_option4'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_option1' => $this->input->post('q3_option1'),
                        'q3_option2' => $this->input->post('q3_option2'),
                        'q3_option3' => $this->input->post('q3_option3'),
                        'q3_option4' => $this->input->post('q3_option4'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_option1' => $this->input->post('q4_option1'),
                        'q4_option2' => $this->input->post('q4_option2'),
                        'q4_option3' => $this->input->post('q4_option3'),
                        'q4_option4' => $this->input->post('q4_option4'),
                        'q4_answer' => $this->input->post('q4_answer'),
                    
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_MCOA_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part21list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part2_MCOA_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Short listening';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part2_MCOA_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 1: Multiple choice with one answer';
        $this->load->view('superadmin/edit_part2_1', $this->data);
    }
        function part22list(){
        $this->verifyUser();
        $this->data['window_title']="Part 1: Multiple choice with more than one answer";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 2: Multiple choice with more than one answer';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_MCMTOA_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part2_2listing', $this->data);
    }
    
        function add_part2_2(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_MCMTOA_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART2_MCMTOA'. $next_code;
        }else{
            $this->data['test_code']='PART2_MCMTOA1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
                $this->form_validation->set_rules('passage','Passage', 'trim|required|xss_clean');
                
                
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '3rd Question option3', 'trim|required|xss_clean');

            
            $this->form_validation->set_rules('q1_option4', '1st Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option5', '1st Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option6', '1st Question option6', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option7', '1st Question option7', 'trim|required|xss_clean');
        
            
            
            
            $this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option4', '2nd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option5', '2nd Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option6', '2nd Question option6', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option7', '2nd Question option7', 'trim|required|xss_clean');
        
            
            
        
            
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'passage' => $this->input->post('passage'),
                        
                        
                        
                        
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_option1' => $this->input->post('q1_option1'),
                        'q1_option2' => $this->input->post('q1_option2'),
                        'q1_option3' => $this->input->post('q1_option3'),
                        'q1_option4' => $this->input->post('q1_option4'),
                        'q1_option5' => $this->input->post('q1_option5'),
                        'q1_option6' => $this->input->post('q1_option6'),
                        'q1_option7' => $this->input->post('q1_option7'),
                        'q1_answer1' => $this->input->post('q1_answer1'),
                        'q1_answer2' => $this->input->post('q1_answer2'),

                    
                    
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_option1' => $this->input->post('q2_option1'),
                        'q2_option2' => $this->input->post('q2_option2'),
                        'q2_option3' => $this->input->post('q2_option3'),
                        'q2_option4' => $this->input->post('q2_option4'),
                        'q2_option5' => $this->input->post('q2_option5'),
                        'q2_option6' => $this->input->post('q2_option6'),
                        'q2_option7' => $this->input->post('q2_option7'),
                        'q2_answer1' => $this->input->post('q2_answer1'),
                        'q2_answer2' => $this->input->post('q2_answer2'),
                        
                            'created_date'=>date('Y-m-d H:i:s'),
                    );
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_MCMTOA_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '22');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '22');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part22list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part2_2',$this->data);
    }
    
        function edit_part2_2($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

            $this->form_validation->set_rules('passage','Passage', 'trim|required|xss_clean');
                
                
                
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '3rd Question option3', 'trim|required|xss_clean');

            
            $this->form_validation->set_rules('q1_option4', '1st Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option5', '1st Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option6', '1st Question option6', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option7', '1st Question option7', 'trim|required|xss_clean');
        
            
            
            
            $this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option4', '2nd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option5', '2nd Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option6', '2nd Question option6', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option7', '2nd Question option7', 'trim|required|xss_clean');
        
        
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        
                            'passage' => $this->input->post('passage'),
                        
                                            'q1_question' => $this->input->post('q1_question'),
                        'q1_option1' => $this->input->post('q1_option1'),
                        'q1_option2' => $this->input->post('q1_option2'),
                        'q1_option3' => $this->input->post('q1_option3'),
                        'q1_option4' => $this->input->post('q1_option4'),
                        'q1_option5' => $this->input->post('q1_option5'),
                        'q1_option6' => $this->input->post('q1_option6'),
                        'q1_option7' => $this->input->post('q1_option7'),
                        'q1_answer1' => $this->input->post('q1_answer1'),
                        'q1_answer2' => $this->input->post('q1_answer2'),

                    
                    
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_option1' => $this->input->post('q2_option1'),
                        'q2_option2' => $this->input->post('q2_option2'),
                        'q2_option3' => $this->input->post('q2_option3'),
                        'q2_option4' => $this->input->post('q2_option4'),
                        'q2_option5' => $this->input->post('q2_option5'),
                        'q2_option6' => $this->input->post('q2_option6'),
                        'q2_option7' => $this->input->post('q2_option7'),
                        'q2_answer1' => $this->input->post('q2_answer1'),
                        'q2_answer2' => $this->input->post('q2_answer2'),
                        
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_MCMTOA_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part22list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part2_MCMTOA_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Academic Reaing';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part2_MCMTOA_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 2: Multiple choice with more than one answer';
        $this->load->view('superadmin/edit_part2_2', $this->data);
    }
        function part23list(){
        $this->verifyUser();
        $this->data['window_title']="Part 3: Identifying Information (True/False/Not Given)";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 3: Identifying Information (True/False/Not Given)';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_II_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part2_3listing', $this->data);
    }
    
    
    
    function add_part2_3()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_II_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART2_II'. $next_code;
        }else{
            $this->data['test_code']='PART2_II1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
                $this->form_validation->set_rules('passage','Passage', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                
            $this->form_validation->set_rules('q1_answer','1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
        
            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'passage' => $this->input->post('passage'),
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                    
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                    
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_II_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '23');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '23');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part23list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part2_3',$this->data);
    }
    
    
    function edit_part2_3($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

                $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer', '1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
            
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        
                            'passage' => $this->input->post('passage'),
                        'q1_question' => $this->input->post('q1_question'),
                
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                    
                        'q3_answer' => $this->input->post('q3_answer'),
                        
                    
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_II_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part23list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part2_II_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Reading';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part2_II_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 3: Identifying Information (True/False/Not Given)';
        $this->load->view('superadmin/edit_part2_3', $this->data);
    }
    
        function part24list(){
        $this->verifyUser();
        $this->data['window_title']="Part 4: Note Completion";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 4: Note Completion';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_NC_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part2_4listing', $this->data);
    }
        
        function add_part2_4(){
            $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_NC_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='part2_NC'. $next_code;
        }else{
            $this->data['test_code']='part2_NC1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'passage' => $this->input->post('passage'),
                        'q1_title' => $this->input->post('q1_title'), 
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                        'q5_question' => $this->input->post('q5_question'),
                        'q5_answer' => $this->input->post('q5_answer'),
                        'q6_question' => $this->input->post('q6_question'),
                        'q6_answer' => $this->input->post('q6_answer'), 
                        
                        
                        'created_date' => date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_NC_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '24');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '24');
                        }
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                redirect('superadmin/part24list');
            }
        }
        
        $this->load->view('superadmin/add_part2_4',$this->data);
    }
    
    function edit_part2_4($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'passage' => $this->input->post('passage'),
                        'q1_title' =>$this->input->post('q1_title'),

                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                        'q5_question' => $this->input->post('q5_question'),
                        'q5_answer' => $this->input->post('q5_answer'),
                        'q6_question' => $this->input->post('q6_question'),
                        'q6_answer' => $this->input->post('q6_answer'), 
                                  'updated_date' => date('Y-m-d H:i:s'),
                );
                
        //      echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_NC_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'update successfully!!');
                }
                
                redirect('superadmin/part24list');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Academic Reading Part 4 Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['l2data'] = $this->my_model->getARecord('system_part2_NC_code', $id);
        if( !is_object($this->data['l2data'])) { return false; }
        $this->load->view('superadmin/edit_part2_4', $this->data);
        
    }
    
    
        function part25list(){
        $this->verifyUser();
        $this->data['window_title']="Part 5: Matching Headings";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 5: Matching Headings';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_MH_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part2_5listing', $this->data);
    }
        function add_part2_5()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_MH_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART2_MH'. $next_code;
        }else{
            $this->data['test_code']='PART2_MH1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
                $this->form_validation->set_rules('passage_heading1','Passage Heading', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('passage1','1st Passage', 'trim|required|xss_clean');
                $this->form_validation->set_rules('p1_answer', '1st Passagr answer', 'trim|required|xss_clean');
            $this->form_validation->set_rules('passage2', '2nd Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p2_answer', '2nd Passage Answer option3', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('passage3', '3rd Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p3_answer', '3rd Passage Answer', 'trim|required|xss_clean');

            
                $this->form_validation->set_rules('passage4', '4th Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p4_answer', '4th Passage Answer', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading1', 'Heading1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading2', 'Heading2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading3', 'Heading3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading4', 'Heading4', 'trim|required|xss_clean');
            
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'passage_heading1' => $this->input->post('passage_heading1'),
                        'passage1' => $this->input->post('passage1'),
                        'p1_answer' => $this->input->post('p1_answer'),
                        'passage_heading2' => $this->input->post('passage_heading2'),
                        'passage2' => $this->input->post('passage2'),
                        'p2_answer' => $this->input->post('p2_answer'),
                        'passage3' => $this->input->post('passage3'),
                        'p3_answer' => $this->input->post('p3_answer'),
                        'passage4' => $this->input->post('passage4'),
                        'p4_answer' => $this->input->post('p4_answer'),
                        'passage5' => $this->input->post('passage5'),
                        'heading1' => $this->input->post('heading1'),
                        'heading2' => $this->input->post('heading2'),
                        'heading3' => $this->input->post('heading3'),

                        
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_MH_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '25');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '25');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part25list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part2_5',$this->data);
    }
    
        function edit_part2_5($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

                $this->form_validation->set_rules('passage_heading1','Passage Heading', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('passage1','1st Passage', 'trim|required|xss_clean');
                $this->form_validation->set_rules('p1_answer', '1st Passagr answer', 'trim|required|xss_clean');
            $this->form_validation->set_rules('passage2', '2nd Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p2_answer', '2nd Passage Answer option3', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('passage3', '3rd Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p3_answer', '3rd Passage Answer', 'trim|required|xss_clean');

            
                $this->form_validation->set_rules('passage4', '4th Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p4_answer', '4th Passage Answer', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading1', 'Heading1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading2', 'Heading2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading3', 'Heading3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading4', 'Heading4', 'trim|required|xss_clean');
            
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        
                        'passage_heading1' => $this->input->post('passage_heading1'),
                        'passage1' => $this->input->post('passage1'),
                        'p1_answer' => $this->input->post('p1_answer'),
                        'passage_heading2' => $this->input->post('passage_heading2'),
                        'passage2' => $this->input->post('passage2'),
                        'p2_answer' => $this->input->post('p2_answer'),
                        'passage3' => $this->input->post('passage3'),
                        'p3_answer' => $this->input->post('p3_answer'),
                        'passage4' => $this->input->post('passage4'),
                        'p4_answer' => $this->input->post('p4_answer'),
                        'passage5' => $this->input->post('passage5'),
                        'heading1' => $this->input->post('heading1'),
                        'heading2' => $this->input->post('heading2'),
                        'heading3' => $this->input->post('heading3'),
                        
                    
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_MH_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part25list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part2_MH_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Reading';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part2_MH_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 5: Matching Headings';
        $this->load->view('superadmin/edit_part2_5', $this->data);
    }
            function part26list(){
        $this->verifyUser();
        $this->data['window_title']="Part 6: Summary Completion (selecting words from the text)";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 6: Summary Completion (selecting words from the text)';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_SC_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part2_6listing', $this->data);
    }   
    
    function add_part2_6(){
        
                $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_SC_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='part2_SC'. $next_code;
        }else{
            $this->data['test_code']='part2_SC1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
                
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'passage' => $this->input->post('passage'),

                        'q1_question' => $this->input->post('q1_question'),
                    
                        'q1_words' => $this->input->post('q1_words'),
                    
                        'created_date' => date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_SC_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '26');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '26');
                        }
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                redirect('superadmin/part26list');
            }
        }
        
        $this->load->view('superadmin/add_part2_6',$this->data);
        
    }
    
    
    
    
    function edit_part2_6($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        
                        
                    'passage' => $this->input->post('passage'),

                        'q1_question' => $this->input->post('q1_question'),
                    
                        'q1_words' => $this->input->post('q1_words'),     'updated_date' => date('Y-m-d H:i:s'),
                );
                
        //      echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_SC_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'update successfully!!');
                }
                
                redirect('superadmin/part26list');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Academic Reading Part 6 Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['l2data'] = $this->my_model->getARecord('system_part2_SC_code', $id);
        if( !is_object($this->data['l2data'])) { return false; }
        $this->load->view('superadmin/edit_part2_6', $this->data);
        
    }
    
    
            function part27list(){
        $this->verifyUser();
        $this->data['window_title']="Part 7: Summary Completion (selecting from a list of words or phrases) ";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 7: Summary Completion (selecting from a list of words or phrases) ';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_SCA_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part2_7listing', $this->data);
    }   
    
    
        function add_part2_7(){
        
                $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_SCA_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='part2_SCA'. $next_code;
        }else{
            $this->data['test_code']='part2_SCA1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
                
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'h1_heading' => $this->input->post('h1_heading'),
                        'passage' => $this->input->post('passage'),

                        'h2_heading' => $this->input->post('h2_heading'),

                        'q1_question' => $this->input->post('q1_question'),
                    
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                    
                        'q4_answer' => $this->input->post('q4_answer'),                 'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
        
                    
                        'created_date' => date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_SCA_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '27');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '27');
                        }
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                redirect('superadmin/part27list');
            }
        }
        
        $this->load->view('superadmin/add_part2_7',$this->data);
        
    }
    
    
    
    
    function edit_part2_7($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        
                        
                'h1_heading' => $this->input->post('h1_heading'),
                        'passage' => $this->input->post('passage'),

                        'h2_heading' => $this->input->post('h2_heading'),

                        'q1_question' => $this->input->post('q1_question'),
                    
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                    
                        'q4_answer' => $this->input->post('q4_answer'),                     
                        'option1' => $this->input->post('option1'),
                        'option2' => $this->input->post('option2'),
                        'option3' => $this->input->post('option3'),
                        'updated_date'=>date('Y-m-d H:i:s'),

                );
                
        //      echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_SCA_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'update successfully!!');
                }
                
                redirect('superadmin/part27list');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Academic Reading Part 7 Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['l2data'] = $this->my_model->getARecord('system_part2_SCA_code', $id);
        if( !is_object($this->data['l2data'])) { return false; }
        $this->load->view('superadmin/edit_part2_7', $this->data);
        
    }

            function part28list(){
        $this->verifyUser();
        $this->data['window_title']="Part 8: Flow-chart Completion (selecting words from the text)";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 8: Flow-chart Completion (selecting words from the text)';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_FCC_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part2_8listing', $this->data);
    }   
    
    function add_part2_8(){
        
            $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_FCC_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='part2_FCC'. $next_code;
        }else{
            $this->data['test_code']='part2_FCC1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'passage' => $this->input->post('passage'),
                        'q1_title' => $this->input->post('q1_title'), 
                        'q2_title' => $this->input->post('q2_title'), 
                        'l1_line' => $this->input->post('l1_line'), 
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'l2_line' => $this->input->post('l2_line'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                    
                        
                        'created_date' => date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_FCC_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '28');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '28');
                        }
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                redirect('superadmin/part28list');
            }
        }
        
        $this->load->view('superadmin/add_part2_8',$this->data);
    }
    
        function edit_part2_8($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'passage' => $this->input->post('passage'),
                        'q1_title' => $this->input->post('q1_title'), 
                        'q2_title' => $this->input->post('q2_title'), 
                        'l1_line' => $this->input->post('l1_line'), 
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'l2_line' => $this->input->post('l2_line'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                    
                                  'updated_date' => date('Y-m-d H:i:s'),
                );
                
        //      echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_FCC_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'update successfully!!');
                }
                
                redirect('superadmin/part28list');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Academic Reading Part 8 Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['l2data'] = $this->my_model->getARecord('system_part2_FCC_code', $id);
        if( !is_object($this->data['l2data'])) { return false; }
        $this->load->view('superadmin/edit_part2_8', $this->data);
        
    }
    
    
    
    function part29list(){
        $this->verifyUser();
        $this->data['window_title']="Part 9: Sentence Completion ";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 9: Sentence Completion';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_SCB_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part2_9listing', $this->data);
    }   
    
            function add_part2_9(){
            $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_SCB_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='part2_SCB'. $next_code;
        }else{
            $this->data['test_code']='part2_SCB1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'passage' => $this->input->post('passage'),
                        'q1_title' => $this->input->post('q1_title'), 
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                        'q5_question' => $this->input->post('q5_question'),
                        'q5_answer' => $this->input->post('q5_answer'),
                        
                        'created_date' => date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_SCB_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '29');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '29');
                        }
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                redirect('superadmin/part29list');
            }
        }
        
        $this->load->view('superadmin/add_part2_9',$this->data);
    }
    
    function edit_part2_9($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'passage' => $this->input->post('passage'),
                        'q1_title' =>$this->input->post('q1_title'),

                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                        'q5_question' => $this->input->post('q5_question'),
                        'q5_answer' => $this->input->post('q5_answer'),
                                  'updated_date' => date('Y-m-d H:i:s'),
                );
                
        //      echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_SCB_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'update successfully!!');
                }
                
                redirect('superadmin/part29list');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Academic Reading Part 9 Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['l2data'] = $this->my_model->getARecord('system_part2_SCB_code', $id);
        if( !is_object($this->data['l2data'])) { return false; }
        $this->load->view('superadmin/edit_part2_9', $this->data);
        
    }
    
    
    
            function part30list(){
        $this->verifyUser();
        $this->data['window_title']="Part 10: Matching Sentence Endings";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 10: Matching Sentence Endings';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part2_MSE_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part3_0listing', $this->data);
    }
    
        function add_part3_0()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part2_MSE_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART2_MSE'. $next_code;
        }else{
            $this->data['test_code']='PART2_MSE1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
                $this->form_validation->set_rules('passage_heading','Passage Heading', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('passage1','1st Passage', 'trim|required|xss_clean');
                $this->form_validation->set_rules('p1_answer', '1st Passagr answer', 'trim|required|xss_clean');
            $this->form_validation->set_rules('passage2', '2nd Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p2_answer', '2nd Passage Answer option3', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('passage3', '3rd Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p3_answer', '3rd Passage Answer', 'trim|required|xss_clean');

        
            $this->form_validation->set_rules('heading1', 'Heading1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading2', 'Heading2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading3', 'Heading3', 'trim|required|xss_clean');
            
            
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'passage' => $this->input->post('passage'), 
                        'passage_heading' => $this->input->post('passage_heading'),
                        'passage1' => $this->input->post('passage1'),
                        'p1_answer' => $this->input->post('p1_answer'),
                        'passage2' => $this->input->post('passage2'),
                        'p2_answer' => $this->input->post('p2_answer'),
                        'passage3' => $this->input->post('passage3'),
                        'p3_answer' => $this->input->post('p3_answer'),
                        'heading1' => $this->input->post('heading1'),
                        'heading2' => $this->input->post('heading2'),
                        'heading3' => $this->input->post('heading3'),

                        
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part2_MSE_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '30');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '30');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part30list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part3_0',$this->data);
    }
    
        function edit_part3_0($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

                $this->form_validation->set_rules('passage_heading','Passage Heading', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('passage1','1st Passage', 'trim|required|xss_clean');
                $this->form_validation->set_rules('p1_answer', '1st Passagr answer', 'trim|required|xss_clean');
            $this->form_validation->set_rules('passage2', '2nd Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p2_answer', '2nd Passage Answer option3', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('passage3', '3rd Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('p3_answer', '3rd Passage Answer', 'trim|required|xss_clean');

            
    
            $this->form_validation->set_rules('heading1', 'Heading1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading2', 'Heading2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('heading3', 'Heading3', 'trim|required|xss_clean');

                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        
                        'passage_heading' => $this->input->post('passage_heading'),
                        'passage' => $this->input->post('passage'),
                        'passage1' => $this->input->post('passage1'),

                        'p1_answer' => $this->input->post('p1_answer'),
                        'passage2' => $this->input->post('passage2'),
                        'p2_answer' => $this->input->post('p2_answer'),
                        'passage3' => $this->input->post('passage3'),
                        'p3_answer' => $this->input->post('p3_answer'),
                        'heading1' => $this->input->post('heading1'),
                        'heading2' => $this->input->post('heading2'),
                        'heading3' => $this->input->post('heading3'),
                        
                    
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part2_MSE_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part30list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part2_MSE_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Reading';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part2_MSE_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 10 : Matching Sentence Endings';
        $this->load->view('superadmin/edit_part3_0', $this->data);
    }
    
    
    
    
        function part31list(){
        $this->verifyUser();
        $this->data['window_title']="Part 1: Matching Information";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 1: Matching Information';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part3_MI_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part3_1listing', $this->data);
    }
        function add_part3_1()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part3_MI_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART3_MI'. $next_code;
        }else{
            $this->data['test_code']='PART3_MI1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
            $this->form_validation->set_rules('passage1','1st Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('passage2', '2nd Passage', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('passage3', '3rd Passage', 'trim|required|xss_clean');

            
                $this->form_validation->set_rules('passage4', '4th Passage', 'trim|required|xss_clean');
                $this->form_validation->set_rules('passage5', '4th Passage', 'trim|required|xss_clean');
                $this->form_validation->set_rules('passage6', '4th Passage', 'trim|required|xss_clean');
           
            
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'passage1' => $this->input->post('passage1'),
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                            'passage2' => $this->input->post('passage2'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                            'passage3' => $this->input->post('passage3'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                            'passage4' => $this->input->post('passage4'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                            'passage5' => $this->input->post('passage5'),
                        'q5_question' => $this->input->post('q5_question'),
                        'q5_answer' => $this->input->post('q5_answer'),
                            'passage6' => $this->input->post('passage6'),
                        'q6_question' => $this->input->post('q6_question'),
                        'q6_answer' => $this->input->post('q6_answer'),
                        'created_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part3_MI_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '31');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '25');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part31list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part3_1',$this->data);
    }
    
    
    
    
        function edit_part3_1($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

            
            $this->form_validation->set_rules('passage1','1st Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('passage2', '2nd Passage', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('passage3', '3rd Passage', 'trim|required|xss_clean');

            
                $this->form_validation->set_rules('passage4', '4th Passage', 'trim|required|xss_clean');
                $this->form_validation->set_rules('passage5', '4th Passage', 'trim|required|xss_clean');
                $this->form_validation->set_rules('passage6', '4th Passage', 'trim|required|xss_clean');
           
            
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        
                        'passage1' => $this->input->post('passage1'),
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                            'passage2' => $this->input->post('passage2'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                            'passage3' => $this->input->post('passage3'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                            'passage4' => $this->input->post('passage4'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                            'passage5' => $this->input->post('passage5'),
                        'q5_question' => $this->input->post('q5_question'),
                        'q5_answer' => $this->input->post('q5_answer'),
                            'passage6' => $this->input->post('passage6'),
                        'q6_question' => $this->input->post('q6_question'),
                        'q6_answer' => $this->input->post('q6_answer'),
                    
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part3_MI_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part31list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part3_MI_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Reading';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part3_MI_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 1: Matching Information';
        $this->load->view('superadmin/edit_part3_1', $this->data);
    }
    
    function part32list(){
        $this->verifyUser();
        $this->data['window_title']="Part 2: True/False/Not Given";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 2: True/False/Not Given';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part3_TFN_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part3_2listing', $this->data);
    }
    
    
    function add_part3_2()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part3_TFN_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART3_TFN'. $next_code;
        }else{
            $this->data['test_code']='PART3_TFN1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
            
                $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer', '1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q4_question', '4th Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q4_answer', '4th answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q5_question', '5th Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q5_answer', '5th answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q6_question', '6th Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q6_answer', '6th answer', 'trim|required|xss_clean');
            
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],

                            'passage' => $this->input->post('passage'),
                        'q1_question' => $this->input->post('q1_question'),
                
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                    
                        'q3_answer' => $this->input->post('q3_answer'),
                        
                        'q4_question' => $this->input->post('q4_question'),
                    
                        'q4_answer' => $this->input->post('q4_answer'),
                        'q5_question' => $this->input->post('q5_question'),
                    
                        'q5_answer' => $this->input->post('q5_answer'),
                        'q6_question' => $this->input->post('q6_question'),
                    
                        'q6_answer' => $this->input->post('q6_answer'),
                        
                        'created_date'=>date('Y-m-d H:i:s'),
                            );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part3_TFN_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '32');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '32');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part32list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part3_2',$this->data);
    }
    
    
    function edit_part3_2($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

                $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer', '1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q4_question', '4th Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q4_answer', '4th answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q5_question', '5th Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q5_answer', '5th answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q6_question', '6th Question', 'trim|required|xss_clean');

            $this->form_validation->set_rules('q6_answer', '6th answer', 'trim|required|xss_clean');
            
            
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        
                            'passage' => $this->input->post('passage'),
                        'q1_question' => $this->input->post('q1_question'),
                
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                    
                        'q3_answer' => $this->input->post('q3_answer'),
                        
                        'q4_question' => $this->input->post('q4_question'),
                    
                        'q4_answer' => $this->input->post('q4_answer'),
                        'q5_question' => $this->input->post('q5_question'),
                    
                        'q5_answer' => $this->input->post('q5_answer'),
                        'q6_question' => $this->input->post('q6_question'),
                    
                        'q6_answer' => $this->input->post('q6_answer'),
                        
                    
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part3_TFN_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part32list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part3_TFN_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Reading';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part3_TFN_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 2: True/False/Not Given';
        $this->load->view('superadmin/edit_part3_2', $this->data);
    }
    
        function part33list(){
        $this->verifyUser();
        $this->data['window_title']="Part 3: Note Completion ";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 3: Note Completion';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part3_NC_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part3_3listing', $this->data);
    }   
    
            function add_part3_3(){
            $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part3_NC_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='part3_NC'. $next_code;
        }else{
            $this->data['test_code']='part3_NC1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'passage' => $this->input->post('passage'),
                        'q1_title' => $this->input->post('q1_title'), 
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                        'q5_question' => $this->input->post('q5_question'),
                        'q5_answer' => $this->input->post('q5_answer'),
                        
                        'created_date' => date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part3_NC_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '33');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '33');
                        }
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                redirect('superadmin/part33list');
            }
        }
        
        $this->load->view('superadmin/add_part3_3',$this->data);
    }
    
    function edit_part3_3($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'passage' => $this->input->post('passage'),
                        'q1_title' =>$this->input->post('q1_title'),

                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                        'q5_question' => $this->input->post('q5_question'),
                        'q5_answer' => $this->input->post('q5_answer'),
                                  'updated_date' => date('Y-m-d H:i:s'),
                );
                
        //      echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part3_NC_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'update successfully!!');
                }
                
                redirect('superadmin/part33list');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update General Reading Part 3 Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['l2data'] = $this->my_model->getARecord('system_part3_NC_code', $id);
        if( !is_object($this->data['l2data'])) { return false; }
        $this->load->view('superadmin/edit_part3_3', $this->data);
        
    }
    
    
        function part34list(){
        $this->verifyUser();
        $this->data['window_title']="Part 4: Summary Completion ";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 4: Summary Completion';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part3_SC_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part3_4listing', $this->data);
    }   
    
            function add_part3_4(){
            $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part3_SC_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='part3_SC'. $next_code;
        }else{
            $this->data['test_code']='part3_SC1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'passage' => $this->input->post('passage'),
                        'q1_title' => $this->input->post('q1_title'), 
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                        
                        'created_date' => date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part3_SC_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '34');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '34');
                        }
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                redirect('superadmin/part34list');
            }
        }
        
        $this->load->view('superadmin/add_part3_4',$this->data);
    }
    
    function edit_part3_4($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                  $qryData = array(
                        'passage' => $this->input->post('passage'),
                        'q1_title' =>$this->input->post('q1_title'),

                        'q1_question' => $this->input->post('q1_question'),
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                                  'updated_date' => date('Y-m-d H:i:s'),
                );
                
        //      echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part3_SC_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'update successfully!!');
                }
                
                redirect('superadmin/part34list');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update General Reading Part 4 Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['l2data'] = $this->my_model->getARecord('system_part3_SC_code', $id);
        if( !is_object($this->data['l2data'])) { return false; }
        $this->load->view('superadmin/edit_part3_4', $this->data);
        
    }
    
    
        
    function part35list(){
        $this->verifyUser();
        $this->data['window_title']="Part 5: Matching Features";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 5: Matching Features';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part3_MFC_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part3_5listing', $this->data);
    }
    
    function add_part3_5()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part3_MFC_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART3_MFC'. $next_code;
        }else{
            $this->data['test_code']='PART3_MFC1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
                $this->form_validation->set_rules('passage','Passage', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q_option1', ' option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q_option2', ' option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q_option3', ' option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer','1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('q4_question', '4th Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answer', '4th answer', 'trim|required|xss_clean');
            
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'heading' => $this->input->post('heading'),

                        'passage' => $this->input->post('passage'),
                        'optionheading' => $this->input->post('optionheading'),
                        'q_option1' => $this->input->post('q_option1'),
                        'q_option2' => $this->input->post('q_option2'),
                        'q_option3' => $this->input->post('q_option3'),
                        
                        'q1_question' => $this->input->post('q1_question'),
                    
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part3_MFC_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '35');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '35');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part35list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part3_5',$this->data);
    }
    
    function edit_part3_5($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

        
                $this->form_validation->set_rules('passage','Passage', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q_option1', ' option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q_option2', ' option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q_option3', ' option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer','1st answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answer', '2nd answer', 'trim|required|xss_clean');
            
            
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answer', '3rd answer', 'trim|required|xss_clean');
            
            
                $this->form_validation->set_rules('q4_question', '4th Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answer', '4th answer', 'trim|required|xss_clean');
            
                      $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        'heading' => $this->input->post('heading'),

                        'passage' => $this->input->post('passage'),
                        'optionheading' => $this->input->post('optionheading'),
                        'q_option1' => $this->input->post('q_option1'),
                        'q_option2' => $this->input->post('q_option2'),
                        'q_option3' => $this->input->post('q_option3'),
                        
                        'q1_question' => $this->input->post('q1_question'),
                    
                        'q1_answer' => $this->input->post('q1_answer'),
                        'q2_question' => $this->input->post('q2_question'),
                        'q2_answer' => $this->input->post('q2_answer'),
                        'q3_question' => $this->input->post('q3_question'),
                        'q3_answer' => $this->input->post('q3_answer'),
                        'q4_question' => $this->input->post('q4_question'),
                        'q4_answer' => $this->input->post('q4_answer'),
                    
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part3_MFC_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part35list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part3_MFC_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update General Reading';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part3_MFC_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 5: Matching Features';
        $this->load->view('superadmin/edit_part3_5', $this->data);
    }
    
        function part36list(){
        $this->verifyUser();
        $this->data['window_title']="Part 6: Multiple Choice";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 6: Multiple Choice';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part3_MC_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part3_6listing', $this->data);
    }
    
        function add_part3_6(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part3_MC_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART3_MC'. $next_code;
        }else{
            $this->data['test_code']='PART3_MC1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
                $this->form_validation->set_rules('passage','Passage', 'trim|required|xss_clean');
                
                
            
            $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '3rd Question option3', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q1_option4', '4th Question option4', 'trim|required|xss_clean');
                    $this->form_validation->set_rules('q1_option5', '5th Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer1','1st answer 1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer2','1st answer 2', 'trim|required|xss_clean');
        
            
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'passage' => $this->input->post('passage'),
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_option1' => $this->input->post('q1_option1'),
                        'q1_option2' => $this->input->post('q1_option2'),
                        'q1_option3' => $this->input->post('q1_option3'),
                        'q1_option4' => $this->input->post('q1_option4'),
                        'q1_option5' => $this->input->post('q1_option5'),
                        'q1_answer1' => $this->input->post('q1_answer1'),
                        'q1_answer2' => $this->input->post('q1_answer2'),
                            'created_date'=>date('Y-m-d H:i:s'),
                    );
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part3_MC_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '36');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '36');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part36list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part3_6',$this->data);
    }
    
        function edit_part3_6($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

            $this->form_validation->set_rules('passage','Passage', 'trim|required|xss_clean');
                
                
        $this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '3rd Question option3', 'trim|required|xss_clean');
                $this->form_validation->set_rules('q1_option4', '4th Question option4', 'trim|required|xss_clean');
                    $this->form_validation->set_rules('q1_option5', '5th Question option5', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer1','1st answer 1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_answer2','1st answer 2', 'trim|required|xss_clean');
        
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        
                            'passage' => $this->input->post('passage'),
                        
                        
                        'passage' => $this->input->post('passage'),
                        'q1_question' => $this->input->post('q1_question'),
                        'q1_option1' => $this->input->post('q1_option1'),
                        'q1_option2' => $this->input->post('q1_option2'),
                        'q1_option3' => $this->input->post('q1_option3'),
                        'q1_option4' => $this->input->post('q1_option4'),
                        'q1_option5' => $this->input->post('q1_option5'),
                        'q1_answer1' => $this->input->post('q1_answer1'),
                        'q1_answer2' => $this->input->post('q1_answer2'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part3_MC_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part36list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part3_MC_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update General Reaing';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part3_MC_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 6: Multiple choice';
        $this->load->view('superadmin/edit_part3_6', $this->data);
    }
    
    
        function part37list(){
        $this->verifyUser();
        $this->data['window_title']="Part 7: Summary Completion";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 7: Summary Completion';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part3_SMC_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part3_7listing', $this->data);
    }   
    
    function add_part3_7(){
        
                $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part3_SMC_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='part3_SMC'. $next_code;
        }else{
            $this->data['test_code']='part3_SMC1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
                
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        'passage' => $this->input->post('passage'),
                        'q1_title' => $this->input->post('q1_title'),
                    'q2_title' => $this->input->post('q2_title'),

                        'q1_question' => $this->input->post('q1_question'),
                    
                        'q1_words' => $this->input->post('q1_words'),
                    
                        'created_date' => date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part3_SMC_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '37');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '37');
                        }
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                redirect('superadmin/part37list');
            }
        }
        
        $this->load->view('superadmin/add_part3_7',$this->data);
        
    }
    
    
    
    
    function edit_part3_7($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        
                        
                    'passage' => $this->input->post('passage'),
                    'q1_title' => $this->input->post('q1_title'),
                    'q2_title' => $this->input->post('q2_title'),

                        'q1_question' => $this->input->post('q1_question'),
                    
                        'q1_words' => $this->input->post('q1_words'),     'updated_date' => date('Y-m-d H:i:s'),
                );
                
        //      echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part3_SMC_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'update successfully!!');
                }
                
                redirect('superadmin/part37list');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update General Reading Part 7 Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['l2data'] = $this->my_model->getARecord('system_part3_SMC_code', $id);
        if( !is_object($this->data['l2data'])) { return false; }
        $this->load->view('superadmin/edit_part3_7', $this->data);
        
    }
    
    
    
        function part41list(){
        $this->verifyUser();
        $this->data['window_title']="Sample Academic Writing Part 1";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Sample Academic Writing Part 1';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part4_SAWPA_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part4_1listing', $this->data);
    }
    
        function add_part4_1(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part4_SAWPA_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='Part4_SAWPA'. $next_code;
        }else{
            $this->data['test_code']='Part4_SAWPA1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');        
            
            
                    
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                     
                     
            if($this->form_validation->run() == TRUE)
            { $path = $_FILES['scene_img']['tmp_name'];

        $image_name = preg_replace("/[^a-z0-9\._]+/", "-", strtolower(uniqid() . $_FILES['scene_img']['name']));

        $data['message'] = "sucess";

        $s3_bucket = $this->s3_bucket_upload($path, $image_name);
        echo "<pre>hiii";print_r($s3_bucket);die;
        if ($s3_bucket['message'] == "sucess") {
            $data['imagename'] = $s3_bucket['imagepath'];
            $data['imagepath'] = $s3_bucket['imagename'];
        }
            
                
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'q1_question' => $this->input->post('q1_question'),  
                    'q1_image' => $scene_img,

                    'created_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->insertDataIntoTable('system_part4_SAWPA_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '41');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '41');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Writing Task added successfully!!');
                }
                redirect('superadmin/part41list');
            }
        }
        
        $this->data['pagetitle'] = 'Sample Academic Writing Part 1
';
        $this->load->view('superadmin/add_part4_1',$this->data);
    }
    
    function edit_part4_1($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
        
            

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $getl1data = $this->my_model->getARecord('system_part1_SAWPA_code', $id);
                $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                $config['upload_path'] = './uploads/part4_SAWPA';
                $this->load->library('upload', $config);
                $scene_img='';  
                $conversation_1_audio='';
 
                if($_FILES['scene_img']['name']!="")
                {
                    if ( ! $this->upload->do_upload('scene_img')) {
                        $error = array('error' => $this->upload->display_errors());
                    } else {
                        $data =  $this->upload->data();
                        $scene_img = $data['file_name'];

                   }
                }else{
                    $scene_img = $getl1data->q1_image;
                }
            
                
                    $qryData = array(
                        'q1_image' =>$scene_img,
                        'q1_question' => $this->input->post('q1_question'), 
                        
                        'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;


                if( $this->my_model->updateTable('system_part4_SAWPA_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part41list');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part4_SAWPA_code', $where);
    
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Writing';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part4_SAWPA_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Sample Academic Writing Part 1
';
        $this->load->view('superadmin/edit_part4_1', $this->data);
    }
    
        function part42list(){
        $this->verifyUser();
        $this->data['window_title']="Sample Academic Writing Part 2";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Sample Academic Writing Part 1';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part4_SAWPB_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part4_2listing', $this->data);
    }
    
        function add_part4_2(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part4_SAWPB_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='Part4_SAWPB'. $next_code;
        }else{
            $this->data['test_code']='Part4_SAWPB1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');        
            
            
                    
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
                     
                     
            if($this->form_validation->run() == TRUE)
            {
                    
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'passage' => $this->input->post('passage'),  
                    'q1_question' => $this->input->post('q1_question'),  
                    

                    'created_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->insertDataIntoTable('system_part4_SAWPB_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '42');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '42');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Writing Task added successfully!!');
                }
                redirect('superadmin/part42list');
            }
        }
        
        $this->data['pagetitle'] = 'Sample Academic Writing Part 2
';
        $this->load->view('superadmin/add_part4_2',$this->data);
    }
    
    function edit_part4_2($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
        
            

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
            
                
                    $qryData = array(
                        'passage' =>$this->input->post('passage'),
                        'q1_question' => $this->input->post('q1_question'), 
                        
                        'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;


                if( $this->my_model->updateTable('system_part4_SAWPB_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part42list');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part4_SAWPB_code', $where);
    
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Writing';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part4_SAWPB_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Sample Academic Writing Part 2
';
        $this->load->view('superadmin/edit_part4_2', $this->data);
    }
    
        function part51list(){
        $this->verifyUser();
        $this->data['window_title']="Sample General Writing Part 1";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Sample General Writing Part 1';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part5_SGWPA_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part5_1listing', $this->data);
    }
    function add_part5_1(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part5_SGWPA_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='Part5_SGWPA'. $next_code;
        }else{
            $this->data['test_code']='Part5_SGWPA1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');        
            
            
                    
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                     
                     
            if($this->form_validation->run() == TRUE)
            {
            
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'passage' => $this->input->post('passage'),  
                    'q1_question' => $this->input->post('q1_question'),  
                    'instruction' => $this->input->post('instruction'),  

                    'created_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->insertDataIntoTable('system_part5_SGWPA_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '51');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '51');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Writing Task added successfully!!');
                }
                redirect('superadmin/part51list');
            }
        }
        
        $this->data['pagetitle'] = 'Sample General Writing Part 1
';
        $this->load->view('superadmin/add_part5_1',$this->data);
    }
    
    function edit_part5_1($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
        
            

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                    $qryData = array(
            'passage' => $this->input->post('passage'),  
                    'q1_question' => $this->input->post('q1_question'),  
                    'instruction' => $this->input->post('instruction'),  
            
                        'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;


                if( $this->my_model->updateTable('system_part5_SGWPA_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part51list');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part5_SGWPA_code', $where);
    
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Writing';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part5_SGWPA_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Sample General Writing Part 1
';
        $this->load->view('superadmin/edit_part5_1', $this->data);
    }
    
    
        function part52list(){
        $this->verifyUser();
        $this->data['window_title']="Sample General Writing Part 2";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Sample General Writing Part 2';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part5_SGWPB_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part5_2listing', $this->data);
    }
    function add_part5_2(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part5_SGWPB_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='Part5_SGWPB'. $next_code;
        }else{
            $this->data['test_code']='Part5_SGWPB1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');        
            
            
                    
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                     
                     
            if($this->form_validation->run() == TRUE)
            {
            
                $qryData = array(
                    'test_code' => $this->data['test_code'],
                    'passage' => $this->input->post('passage'),  
                    'q1_question' => $this->input->post('q1_question'),  

                    'created_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->insertDataIntoTable('system_part5_SGWPB_code', $qryData))
                {
                    $getData = $this->my_model->getARecord('system_PTEsubtype_code', '52');
                    if($getData){
                        // Update total test
                        $total_test = $getData->total_test + 1;
                        $qtdata = array(
                            'total_test' => $total_test
                        );
                        $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '52');
                    }
                    
                    $this->session->set_flashdata('global_msg', 'Writing Task added successfully!!');
                }
                redirect('superadmin/part51list');
            }
        }
        
        $this->data['pagetitle'] = 'Sample General Writing Part 2
';
        $this->load->view('superadmin/add_part5_2',$this->data);
    }
    
    function edit_part5_2($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {               
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
        
            

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                    $qryData = array(
            'passage' => $this->input->post('passage'),  
                    'q1_question' => $this->input->post('q1_question'),  

                        'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;


                if( $this->my_model->updateTable('system_part5_SGWPB_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part52list');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part5_SGWPB_code', $where);
    
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Writing';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part5_SGWPB_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Sample General Writing Part 2
';
        $this->load->view('superadmin/edit_part5_2', $this->data);
    }
    
    
    
    
    
        function part61list(){
        $this->verifyUser();
        $this->data['window_title']="Part 1:Talking about a personal experience";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 1: Talking about a personal experience';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part6_TAPE_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part6_1listing', $this->data);
    }
        function add_part6_1()
    {
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_part6_TAPE_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
        if(!empty($result)){
            $next_code = $result->id+1;
            $this->data['test_code']='PART6_TAPE'. $next_code;
        }else{
            $this->data['test_code']='PART6_TAPE1';
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        
       {
                $this->form_validation->set_rules('passage','Passage', 'trim|required|xss_clean');
            
        
            
             $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
                
            if($this->form_validation->run() == TRUE)
            {
                  $qryData = array(
                        'test_code' => $this->data['test_code'],
                        
                        'passage' => $this->input->post('passage'),
                
                        'created_date'=>date('Y-m-d H:i:s'),
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_part6_TAPE_code', $qryData) )
                    {
                        $getData = $this->my_model->getARecord('system_PTEsubtype_code', '61');
                        if($getData){
                            // Update total test
                            $total_test = $getData->total_test + 1;
                            $qtdata = array(
                                'total_test' => $total_test
                            );
                            $this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '61');
                        }
                        
                        $this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
                    }
                    
                    redirect('superadmin/part61list');
            }
       }
            $this->data['pagetitle'] = 'Practice Task';
        $this->load->view('superadmin/add_part6_1',$this->data);
    }
    
    function edit_part6_1($id){
            
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;

                $this->form_validation->set_rules('passage', 'Passage', 'trim|required|xss_clean');
        
            
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
            
                    $qryData = array(
                        
                            'passage' => $this->input->post('passage'),
                    
                            'updated_date'=>date('Y-m-d H:i:s'),
                    );
                //echo "<pre>";print_r($qryData);die;

    //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part6_TAPE_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/part61list');
            }
        }
                $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_part6_TAPE_code', $where);
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update speaking';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part6_TAPE_code', $id);
        if( !is_object($this->data['l1data'])) { return false; }
        $this->data['pagetitle'] = 'Part 1: Talking about a personal experience';
        $this->load->view('superadmin/edit_part6_1', $this->data);
    }
    function part62list(){
     	$this->verifyUser();
        $this->data['window_title']="Part 1: Introduction & Interview";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 1: Introduction & Interview';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part6_II_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part6_2listing', $this->data);
	}
	
	function add_part6_2()
	{
		$this->verifyUser();
		
		$query = $this->db->query("SELECT * FROM system_part6_II_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
		if(!empty($result)){
			$next_code = $result->id+1;
			$this->data['test_code']='PART6_II'. $next_code;
		}else{
			$this->data['test_code']='PART1_II1';
		}
		
		if ($_SERVER["REQUEST_METHOD"] == "POST")
		
       {
			
			
			$this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
			$this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
			
			
			$this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
			$this->form_validation->set_rules('q4_question', '4rd Question', 'trim|required|xss_clean');
		    
		    $this->form_validation->set_rules('q5_question', '5rd Question', 'trim|required|xss_clean');
		    
		     $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
			
			if($this->form_validation->run() == TRUE)
            {
               // print_r(($_FILES[$attachment]['name']));
			
                    $qryData = array(
                        'test_code' => $this->data['test_code'],
            			'q1_question' => $this->input->post('q1_question'),
						'q2_question' => $this->input->post('q2_question'),
						'q3_question' => $this->input->post('q3_question'),
						'q4_question' => $this->input->post('q4_question'),
						'q5_question' => $this->input->post('q5_question'),
						'created_date'=>date('Y-m-d H:i:s'),
					);
					
					//echo "<pre>";print_r($qryData);die;

					if( $this->my_model->insertDataIntoTable('system_part6_II_code', $qryData) )
					{
						$getData = $this->my_model->getARecord('system_PTEsubtype_code', '62');
						if($getData){
							// Update total test
							$total_test = $getData->total_test + 1;
							$qtdata = array(
								'total_test' => $total_test
							);
							$this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '62');
						}
						
						$this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
					}
					
					redirect('superadmin/part62list');
			}
       }
       		$this->data['pagetitle'] = 'Practice Task';
		$this->load->view('superadmin/add_part6_2',$this->data);
	}
	
		function edit_part6_2($id){
		    
		$this->verifyUser();
		
		if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
			//echo "<pre>";print_r($_REQUEST);die;

				$this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
			$this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');
			
			
			$this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
		   
			$this->form_validation->set_rules('q4_question', '4th Question', 'trim|required|xss_clean');
			$this->form_validation->set_rules('q4_question', '5th Question', 'trim|required|xss_clean');
			
			
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
			
			if($this->form_validation->run() == TRUE)
            {
				
				$getl1data = $this->my_model->getARecord('system_part6_II_code', $id);
				
			
                  
                    $qryData = array(
                	'q1_question' => $this->input->post('q1_question'),
					'q2_question' => $this->input->post('q2_question'),
					
					'q3_question' => $this->input->post('q3_question'),
					'q4_question' => $this->input->post('q4_question'),
					'q5_question' => $this->input->post('q5_question'),
					
					'updated_date'=>date('Y-m-d H:i:s'),
					);
				//echo "<pre>";print_r($qryData);die;

	//echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part6_II_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
				
				redirect('superadmin/part62list');
			}
		}
				$where = "id = '$id' ";
		$this->data['test'] = $this->my_model->getWhereOneRecords('system_part6_II_code', $where);
		$this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Speaking Introduction & Interview';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part6_II_code', $id);
        
        $this->load->view('superadmin/edit_part6_2', $this->data);
	}
		function part63list(){
     	$this->verifyUser();
        $this->data['window_title']="Part 3: Individual Long Turn (Cue-Card)";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 3: Individual Long Turn (Cue-Card)';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part6_ILT_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part6_3listing', $this->data);
	}
	
	function add_part6_3()
	{
		$this->verifyUser();
		
		$query = $this->db->query("SELECT * FROM system_part6_ILT_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
		if(!empty($result)){
			$next_code = $result->id+1;
			$this->data['test_code']='PART6_ILT'. $next_code;
		}else{
			$this->data['test_code']='PART1_ILT1';
		}
		
		if ($_SERVER["REQUEST_METHOD"] == "POST")
		
       {
				$this->form_validation->set_rules('heading','1st Question', 'trim|required|xss_clean');
		
			
			$this->form_validation->set_rules('q1_question','Clu Question', 'trim|required|xss_clean');
			$this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
			
			
		    
		     $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
			
			if($this->form_validation->run() == TRUE)
            {
               // print_r(($_FILES[$attachment]['name']));
			
                    $qryData = array(
                        'test_code' => $this->data['test_code'],
            			'q1_question' => $this->input->post('q1_question'),
						'q2_question' => $this->input->post('q2_question'),
						'heading' => $this->input->post('heading'),
						'created_date'=>date('Y-m-d H:i:s'),
					);
					
					//echo "<pre>";print_r($qryData);die;

					if( $this->my_model->insertDataIntoTable('system_part6_ILT_code', $qryData) )
					{
						$getData = $this->my_model->getARecord('system_PTEsubtype_code', '63');
						if($getData){
							// Update total test
							$total_test = $getData->total_test + 1;
							$qtdata = array(
								'total_test' => $total_test
							);
							$this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '63');
						}
						
						$this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
					}
					
					redirect('superadmin/part63list');
			}
       }
       		$this->data['pagetitle'] = 'Individual Long Turn';
		$this->load->view('superadmin/add_part6_3',$this->data);
	}
	
		function edit_part6_3($id){
		    
		$this->verifyUser();
		
		if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
			//echo "<pre>";print_r($_REQUEST);die;

				$this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
			$this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');
			
			
			$this->form_validation->set_rules('heading', 'heading Question', 'trim|required|xss_clean');
			
			
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
			
			if($this->form_validation->run() == TRUE)
            {
				
				$getl1data = $this->my_model->getARecord('system_part6_ILT_code', $id);
				
			
                  
                    $qryData = array(
                	'q1_question' => $this->input->post('q1_question'),
					'q2_question' => $this->input->post('q2_question'),
					
					'heading' => $this->input->post('heading'),
					
					'updated_date'=>date('Y-m-d H:i:s'),
					);
				//echo "<pre>";print_r($qryData);die;

	//echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part6_ILT_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
				
				redirect('superadmin/part63list');
			}
		}
				$where = "id = '$id' ";
		$this->data['test'] = $this->my_model->getWhereOneRecords('system_part6_ILT_code', $where);
		$this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Speaking Individual Long Turn';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part6_ILT_code', $id);
        
        $this->load->view('superadmin/edit_part6_3', $this->data);
	}
		
	function part64list(){
     	$this->verifyUser();
        $this->data['window_title']="Part 4: Discussion";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Part 4: Discussion';

        $where = "id != '0' ";

        $this->data['lspart_list'] = $this->my_model->getWhereRecords('system_part6_D_code', $where);
        $this->data['total_lspart'] = count($this->data['lspart_list']);
        $this->load->view('superadmin/part6_4listing', $this->data);
	}
	
	function add_part6_4()
	{
		$this->verifyUser();
		
		$query = $this->db->query("SELECT * FROM system_part6_D_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();
		if(!empty($result)){
			$next_code = $result->id+1;
			$this->data['test_code']='PART6_D'. $next_code;
		}else{
			$this->data['test_code']='PART1_D1';
		}
		
		if ($_SERVER["REQUEST_METHOD"] == "POST")
		
       {
			
			
			$this->form_validation->set_rules('q1_question','1st Question', 'trim|required|xss_clean');
			$this->form_validation->set_rules('q2_question','2nd Question', 'trim|required|xss_clean');
			
			
			$this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
		    
		    $this->form_validation->set_rules('heading', 'heading Question', 'trim|required|xss_clean');
		    
		     $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
			
			if($this->form_validation->run() == TRUE)
            {
               // print_r(($_FILES[$attachment]['name']));
			
                    $qryData = array(
                        'test_code' => $this->data['test_code'],
            			'q1_question' => $this->input->post('q1_question'),
						'q2_question' => $this->input->post('q2_question'),
						'q3_question' => $this->input->post('q3_question'),
						'heading' => $this->input->post('heading'),
						'created_date'=>date('Y-m-d H:i:s'),
					);
					
					//echo "<pre>";print_r($qryData);die;

					if( $this->my_model->insertDataIntoTable('system_part6_D_code', $qryData) )
					{
						$getData = $this->my_model->getARecord('system_PTEsubtype_code', '64');
						if($getData){
							// Update total test
							$total_test = $getData->total_test + 1;
							$qtdata = array(
								'total_test' => $total_test
							);
							$this->my_model->updateTable('system_PTEsubtype_code', $qtdata, '64');
						}
						
						$this->session->set_flashdata('global_msg', 'Question set has been added successfully!!');
					}
					
					redirect('superadmin/part64list');
			}
       }
       		$this->data['pagetitle'] = 'Discussion';
		$this->load->view('superadmin/add_part6_4',$this->data);
	}
	
		function edit_part6_4($id){
		    
		$this->verifyUser();
		
		if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
			//echo "<pre>";print_r($_REQUEST);die;

				$this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
			$this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');
			
			
			$this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
		   
			$this->form_validation->set_rules('heading', 'heading Question', 'trim|required|xss_clean');
			
                  $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
			
			if($this->form_validation->run() == TRUE)
            {
				
				$getl1data = $this->my_model->getARecord('system_part6_D_code', $id);
				
			
                  
                    $qryData = array(
                	'q1_question' => $this->input->post('q1_question'),
					'q2_question' => $this->input->post('q2_question'),
					
					'q3_question' => $this->input->post('q3_question'),
					'heading' => $this->input->post('heading'),
					
					'updated_date'=>date('Y-m-d H:i:s'),
					);
				//echo "<pre>";print_r($qryData);die;

	//echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_part6_D_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
				
				redirect('superadmin/part64list');
			}
		}
				$where = "id = '$id' ";
		$this->data['test'] = $this->my_model->getWhereOneRecords('system_part6_D_code', $where);
		$this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Speaking Discussion';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
           
        $this->data['l1data'] = $this->my_model->getARecord('system_part6_D_code', $id);
        
        $this->load->view('superadmin/edit_part6_4', $this->data);
	}
	

    function addStudentCoins(){ 
        $this->verifyUser();
        if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }   
        
        $description = $_REQUEST['description'];
        $student_id = $_REQUEST['student_id'];
        $where = "id = '$student_id' ";
        $studentData = $this->my_model->getWhereOneRecords('system_member_code', $where);
    
        $student_coins = $studentData->coins+$_REQUEST['coins'];
        $qryData = array(
            'coins' => $student_coins,
        );

        if( $this->my_model->updateTable('system_member_code', $qryData, $student_id) )
        {
            $this->session->set_flashdata('global_msg', 'Coins has been added successfully!!');
            $response = array(
                'result' => 'success',
                'message' => 'Coins Added successfully'
            );
            
            $coin_data = array('user_id'=>$student_id,
                'user_type'=>'member',
                'description'=>"By Superadmin $description",
                'credit_coin'=>$_REQUEST['coins'],
                'balance_coin'=>$student_coins,
                'created_date'=>date('Y-m-d H:i:s'),
                'updated_at'=>date('Y-m-d H:i:s'),
            );
            $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
        }else{
            $response = array(
                'result' => 'error',
                'message' => 'Please try again'
            );
            $this->session->set_flashdata('global_msg', 'Please try again.');
        }
        echo json_encode($response);die;
        
    }
    
    
    function addResellerCoins(){ 
    
        //echo "<pre>";print_r($_REQUEST);die; 
        $this->verifyUser();
        if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }   
        
        $reseller_id = $_REQUEST['reseller_id'];
        $description = $_REQUEST['description'];
        $where = "id = '$reseller_id' ";
        $studentData = $this->my_model->getWhereOneRecords('system_reseller_code', $where);
    
        $reseller_coins = $studentData->coins+$_REQUEST['coins'];
        $qryData = array(
            'coins' => $reseller_coins,
        );

        if( $this->my_model->updateTable('system_reseller_code', $qryData, $reseller_id) )
        {
            $this->session->set_flashdata('global_msg', 'Coins has been added successfully!!');
            $response = array(
                'result' => 'success',
                'message' => 'Coins Added successfully'
            );
            
            $coin_data = array('user_id'=>$reseller_id,
                'user_type'=>'reseller',
                'description'=>"By Celpip Store $description",
                'credit_coin'=>$_REQUEST['coins'],
                'balance_coin'=>$reseller_coins,
                'created_date'=>date('Y-m-d H:i:s'),
                'updated_at'=>date('Y-m-d H:i:s'),
            );
            $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
            
        }else{
            $response = array(
                'result' => 'error',
                'message' => 'Please try again'
            );
            $this->session->set_flashdata('global_msg', 'Please try again.');
        }
        echo json_encode($response);die;
        
    }
    

    function editDictationLevel($id){
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {

            $this->form_validation->set_rules('level_name', 'Level_name', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('level_name'),
                );

                if( $this->my_model->updateTable('system_dictation_level_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Edit Category succeeded!!');
                }
                redirect('superadmin/dictationLevelList');
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Lavel Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['level'] = $this->my_model->getARecord('system_dictation_level_code', $id);
        //echo "<pre>";print_r($this->data['level']);die;
        if( !is_object($this->data['level'])) { return false; }
        $this->load->view('superadmin/dictation_edit_level_view', $this->data);
        
    }
    
    function dictationAddlevel(){
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('level_name', 'Category Name', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('level_name'),
                    'active' => 'Yes'
                );

                if( $this->my_model->insertDataIntoTable('system_dictation_level_code', $qryData) )
                {
                    $last_added_id = $this->db->insert_id();
                    $this->session->set_flashdata('global_msg', 'Add succeeded!!');
                }
                redirect('superadmin/dictationLevelList');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add New Level';
        $this->load->view('superadmin/dictation_add_level_view', $this->data);  
    }
    
    function dictationLevelList() {
        $this->verifyUser();

        # Show all test
        $where = "active = 'Yes' ";
        $this->data['levels'] = $this->my_model->getWhereOrderRecords('system_dictation_level_code', $where, 'id', 'asc');
        $this->data['total'] = count($this->data['levels']);


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dictation Level List';
        //$this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
        
        $this->load->view('superadmin/dictationLevel_listing', $this->data);
    }
    
    function dictationLevelquestions($level_id) {
        $this->verifyUser();

        $this->data['objLevel'] = $this->my_model->getARecord('system_dictation_level_code', $level_id);
        if( !is_object($this->data['objLevel'])) { 
            exit($this->unauthorized_message);
        }

        # Show all questions of Objective type
        $where = "level_id = '".$this->data['objLevel']->id ."'";
        $this->data['questions'] = $this->my_model->getWhereOrderRecords('system_dictation_question_code', $where, 'id', 'asc');
        $this->data['total'] = count($this->data['questions']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dictation Tests - Questions ('.$this->data['objLevel']->name.')';
        $this->load->view('superadmin/dictationLevel_questions', $this->data);
    }
    
    function dictationAddquestion($level_id) {
        $this->verifyUser();

        $objLevel = $this->my_model->getARecord('system_dictation_level_code', $level_id);
        if( !is_object($objLevel)) { 
            exit($this->unauthorized_message);
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            
            $this->form_validation->set_rules('question', 'Question', 'trim|required');
            $this->form_validation->set_rules('1st_option', '1st option', 'trim|required|xss_clean');
            $this->form_validation->set_rules('2nd_option', '2nd option', 'trim|required|xss_clean');
            $this->form_validation->set_rules('3rd_option', '3rd option', 'trim|required|xss_clean');
            $this->form_validation->set_rules('4th_option', '4th option', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answere', 'Answere', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger">','</div>' );
            if($this->form_validation->run() == TRUE) {
                //echo "<pre>";print_r($_POST);die;
                
                if(!empty($_FILES["question_audio"]["name"])){
                    
                    $question_audio = strtotime(date("Y-m-d h:i:s A")).'_'.str_replace(" ", "_", $_FILES["question_audio"]["name"]);
                    
                    $config['file_name']   = $question_audio;
                    $config['upload_path'] = './uploads/dictation_files';
                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);

                    if ( ! $this->upload->do_upload('question_audio')) {
                       $this->session->set_flashdata('global_msg',strip_tags($this->upload->display_errors()));
                    }
                }
                
                $qryData = array(
                    'time' => time(),
                    'question' => strtolower($_POST['question']),
                    'question_audio'=>$question_audio,
                    'right_option'=>$_POST['answere'],
                    'level_id' => $level_id,
                );

                if( $this->my_model->insertDataIntoTable('system_dictation_question_code', $qryData) ) {

                    $last_added_id = $this->db->insert_id();
                    
                    $qryOp1Data = array(
                        'time' => time(),
                        'dictation_option' => $_POST['1st_option'],
                        'dictation_id' => $last_added_id
                    );

                    $this->my_model->insertDataIntoTable('system_dictation_option_code', $qryOp1Data);
                    
                    $qryOp2Data = array(
                        'time' => time(),
                        'dictation_option' => $_POST['2nd_option'],
                        'dictation_id' => $last_added_id
                    );

                    $this->my_model->insertDataIntoTable('system_dictation_option_code', $qryOp2Data);
                    
                    $qryOp3Data = array(
                        'time' => time(),
                        'dictation_option' => $_POST['3rd_option'],
                        'dictation_id' => $last_added_id
                    );
                    $this->my_model->insertDataIntoTable('system_dictation_option_code', $qryOp3Data);
                    
                    $qryOp4Data = array(
                        'time' => time(),
                        'dictation_option' => $_POST['4th_option'],
                        'dictation_id' => $last_added_id
                    );
                    $this->my_model->insertDataIntoTable('system_dictation_option_code', $qryOp4Data);

                    // Update total question in level
                    $total_questions = $objLevel->total_questions + 1;
                    $levelData = array(
                        'total_questions' => $total_questions
                    );
                    $this->my_model->updateTable('system_dictation_level_code', $levelData, $objLevel->id);
                    
                    $this->session->set_flashdata('global_msg','Dictation has been added successfully');
                    redirect('superadmin/dictationLevelquestions/'.$level_id);
                }
            
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dictation Tests - Add Question ('.$objLevel->name.')';
        $this->load->view('superadmin/dictationQuestion_add', $this->data);
    }
    
    
    function dictationEditquestion($level_id,$q_id) {
        $this->verifyUser();

        $objLevel = $this->my_model->getARecord('system_dictation_level_code', $level_id);
        if( !is_object($objLevel)) { 
            exit($this->unauthorized_message);
        }
        
        $this->data['objQuestion'] = $this->my_model->getARecord('system_dictation_question_code', $q_id);
        if( !is_object($this->data['objQuestion'])) { 
            exit($this->unauthorized_message);
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            
            $this->form_validation->set_rules('title', 'Question', 'trim|required');
            $this->form_validation->set_rules('option[]', 'option', 'trim|required|xss_clean');
            $this->form_validation->set_rules('answere', 'Answere', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger">','</div>' );
            if($this->form_validation->run() == TRUE) {
                
                //$array[array_key_first($array)];
                //echo $_POST['1st_option'][$key];die;
                //echo "<pre>";print_r($_FILES);die;
                if(!empty($_FILES["question_audio"]["name"])){
                    
                    $question_audio = strtotime(date("Y-m-d h:i:s A")).'_'.str_replace(" ", "_", $_FILES["question_audio"]["name"]);
                    $config['file_name']   = $question_audio;
                    $config['upload_path'] = './uploads/dictation_files';
                    $config['allowed_types'] = 'mpeg|mp3|mp4';
                    $this->load->library('upload', $config);

                    if ( ! $this->upload->do_upload('question_audio')) {
                       $this->session->set_flashdata('global_msg',strip_tags($this->upload->display_errors()));
                    }
                }else{
                    $question_audio = $this->data['objQuestion']->question_audio;
                }
                
                $qryData = array(
                    'time' => time(),
                    'question' => strtolower($_POST['title']),
                    'question_audio'=>$question_audio,
                    'right_option'=>$_POST['answere'],
                    'level_id' => $level_id,
                );
                
                if($this->my_model->updateTable('system_dictation_question_code', $qryData, $q_id)) {
                    
                    foreach($_POST['option'] as $key=>$list_option){
                        $qryOp1Data = array(
                            'dictation_option' => $list_option
                        );
                        $this->my_model->updateTable('system_dictation_option_code', $qryOp1Data, $key);
                    }
                    
                    $this->session->set_flashdata('global_msg','Dictation has been update successfully');
                    redirect('superadmin/dictationLevelquestions/'.$level_id);
                }
            
            }
        }
        
        $where = "dictation_id = '$q_id' ";
        $this->data['objOptions'] = $this->my_model->getWhereOrderRecords('system_dictation_option_code', $where, 'id', 'asc');
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dictation Tests - Edit Question ('.$objLevel->name.')';
        $this->load->view('superadmin/dictationQuestion_edit', $this->data);
    }
    
    function deleteDictationquestion($q_id, $level_id) {
        $this->verifyUser();

        $objQuestion = $this->my_model->getARecord('system_dictation_question_code', $q_id);
        if( !is_object($objQuestion)) { 
            exit($this->unauthorized_message);
        }

        $objLevel = $this->my_model->getARecord('system_dictation_level_code', $level_id);
        if( !is_object($objLevel)) { 
            exit($this->unauthorized_message);
        }

        // Check if entry is in database, then user can delete entry
        if( is_object($objQuestion)) {

            if( $this->my_model->deleteARecord('system_dictation_question_code', $objQuestion->id) ) {

                // Update total question in level
                $total_questions = $objLevel->total_questions - 1;
                $levelData = array(
                    'total_questions' => $total_questions
                );
                $this->my_model->updateTable('system_dictation_level_code', $levelData, $objLevel->id);

                $this->session->set_flashdata('global_msg','Dictation question has been delete successfully');
                redirect('superadmin/dictationLevelquestions/'.$level_id);
            }
        }
        exit($this->unauthorized_message);
    }
    
    
    function comprehensionTests(){
        $this->verifyUser();
        
        $this->data['window_title'] = "Comprehension Tests";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Comprehension Tests';

        $where = "id != '0' ";

        $this->data['test_list'] = $this->my_model->getWhereRecords('system_comprehension_test_code', $where);
        $this->data['total_test'] = count($this->data['test_list']);
        $this->load->view('superadmin/comprehension_passage_listing', $this->data);
        
        
        
        /* # Show all questions of Objective type
        $where = "level_id = '".$this->data['objLevel']->id ."'";
        $this->data['questions'] = $this->my_model->getWhereOrderRecords('system_comprehension_passage_code', $where, 'id', 'asc');
        $this->data['total'] = count($this->data['questions']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Comprehension Tests';
        $this->load->view('superadmin/comprehension_passage_listing', $this->data); */
    }
    
    
    function comprehensionPassageAdd(){
        $this->verifyUser();
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {   
            $this->form_validation->set_rules('comprehension_passage', 'Comprehension Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option4', 'trim|required|xss_clean'); 
            $this->form_validation->set_rules('q1_answere', '1st answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '2nd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answere', '2nd answere', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option4', '3rd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answere', '3rd answere', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_question', '4th Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option1', '4th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option2', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option3', '4th Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option4', '4th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answere', '4th answere', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_question', '5th Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_option1', '5th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_option2', '5th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_option3', '5th Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_option4', '5th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_answere', '5th answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                
                $qryData = array(
                    'comprehension_passage' => $this->input->post('comprehension_passage'),
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_option1' => $this->input->post('q1_option1'),
                    'q1_option2' => $this->input->post('q1_option2'),
                    'q1_option3' => $this->input->post('q1_option3'),
                    'q1_option4' => $this->input->post('q1_option4'),
                    'q1_answere' => $this->input->post('q1_answere'),
                    'q2_question' => $this->input->post('q2_question'),
                    'q2_option1' => $this->input->post('q2_option1'),
                    'q2_option2' => $this->input->post('q2_option2'),
                    'q2_option3' => $this->input->post('q2_option3'),
                    'q2_option4' => $this->input->post('q2_option4'),
                    'q2_answere' => $this->input->post('q2_answere'),
                    'q3_question' => $this->input->post('q3_question'),
                    'q3_option1' => $this->input->post('q3_option1'),
                    'q3_option2' => $this->input->post('q3_option2'),
                    'q3_option3' => $this->input->post('q3_option3'),
                    'q3_option4' => $this->input->post('q3_option4'),
                    'q3_answere' => $this->input->post('q3_answere'),
                    'q4_question' => $this->input->post('q4_question'),
                    'q4_option1' => $this->input->post('q4_option1'),
                    'q4_option2' => $this->input->post('q4_option2'),
                    'q4_option3' => $this->input->post('q4_option3'),
                    'q4_option4' => $this->input->post('q4_option4'),
                    'q4_answere' => $this->input->post('q4_answere'),
                    'q5_question' => $this->input->post('q5_question'),
                    'q5_option1' => $this->input->post('q5_option1'),
                    'q5_option2' => $this->input->post('q5_option2'),
                    'q5_option3' => $this->input->post('q5_option3'),
                    'q5_option4' => $this->input->post('q5_option4'),
                    'q5_answere' => $this->input->post('q5_answere'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );
                //echo "<pre>";print_r($qryData);die;
                if( $this->my_model->insertDataIntoTable('system_comprehension_test_code', $qryData))
                {
                    $this->session->set_flashdata('global_msg', 'Comprehension Passage added successfully!!');
                }
                redirect('superadmin/comprehensionTests');
            }
        }
        
        $this->data['pagetitle'] = 'Comprehension Passage';
        $this->load->view('superadmin/comprehension_passage_add_view',$this->data);
        
    }
    
    function comprehensionPassageEdit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {   
            $this->form_validation->set_rules('comprehension_passage', 'Comprehension Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_question', '1st Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option2', 'trim|required|xss_clean'); 
            $this->form_validation->set_rules('q1_answere', '1st answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q2_question', '2nd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answere', '2nd answere', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_question', '3rd Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option4', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answere', '3rd answere', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_question', '4th Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option1', '4th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option2', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option3', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option4', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answere', '4th answere', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_question', '5th Question', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_option1', '5th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_option2', '5th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_option3', '5th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_option4', '5th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q5_answere', '5th answere', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'comprehension_passage' => $this->input->post('comprehension_passage'),
                    'q1_question' => $this->input->post('q1_question'),
                    'q1_option1' => $this->input->post('q1_option1'),
                    'q1_option2' => $this->input->post('q1_option2'),
                    'q1_option3' => $this->input->post('q1_option3'),
                    'q1_option4' => $this->input->post('q1_option4'),
                    'q1_answere' => $this->input->post('q1_answere'),
                    'q2_question' => $this->input->post('q2_question'),
                    'q2_option1' => $this->input->post('q2_option1'),
                    'q2_option2' => $this->input->post('q2_option2'),
                    'q2_option3' => $this->input->post('q2_option3'),
                    'q2_option4' => $this->input->post('q2_option4'),
                    'q2_answere' => $this->input->post('q2_answere'),
                    'q3_question' => $this->input->post('q3_question'),
                    'q3_option1' => $this->input->post('q3_option1'),
                    'q3_option2' => $this->input->post('q3_option2'),
                    'q3_option3' => $this->input->post('q3_option3'),
                    'q3_option4' => $this->input->post('q3_option4'),
                    'q3_answere' => $this->input->post('q3_answere'),
                    'q4_question' => $this->input->post('q4_question'),
                    'q4_option1' => $this->input->post('q4_option1'),
                    'q4_option2' => $this->input->post('q4_option2'),
                    'q4_option3' => $this->input->post('q4_option3'),
                    'q4_option4' => $this->input->post('q4_option4'),
                    'q4_answere' => $this->input->post('q4_answere'),
                    'q5_question' => $this->input->post('q5_question'),
                    'q5_option1' => $this->input->post('q5_option1'),
                    'q5_option2' => $this->input->post('q5_option2'),
                    'q5_option3' => $this->input->post('q5_option3'),
                    'q5_option4' => $this->input->post('q5_option4'),
                    'q5_answere' => $this->input->post('q5_answere'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_comprehension_test_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Comprehension Passage has been update successfully!!');
                }
                redirect('superadmin/comprehensionTests');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_comprehension_test_code', $where);
        
        $this->data['pagetitle'] = 'Comprehension Passage';
        $this->load->view('superadmin/comprehension_passage_edit',$this->data);
    }
    
    
    function spotting_ErrorTests(){
        $this->verifyUser();
        
        $this->data['window_title'] = "Spotting Error";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Spotting Error Tests';

        $where = "id != '0' ";

        $this->data['test_list'] = $this->my_model->getWhereRecords('system_spotting_errors_code', $where);
        $this->data['total_test'] = count($this->data['test_list']);
        $this->load->view('superadmin/spotting_error_listing', $this->data);
    
    }
    
    
    function spotting_ErrorAdd(){
        $this->verifyUser();
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {   
            $this->form_validation->set_rules('passage', 'Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option4', 'trim|required|xss_clean'); 
            $this->form_validation->set_rules('q1_answere', '1st answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '2nd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answere', '2nd answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option4', '3rd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answere', '3rd answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q4_option1', '4th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option2', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option3', '4th Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option4', '4th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answere', '4th answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                
                $qryData = array(
                    'passage' => $this->input->post('passage'),
                    'q1_option1' => $this->input->post('q1_option1'),
                    'q1_option2' => $this->input->post('q1_option2'),
                    'q1_option3' => $this->input->post('q1_option3'),
                    'q1_option4' => $this->input->post('q1_option4'),
                    'q1_answere' => $this->input->post('q1_answere'),
                    'q2_option1' => $this->input->post('q2_option1'),
                    'q2_option2' => $this->input->post('q2_option2'),
                    'q2_option3' => $this->input->post('q2_option3'),
                    'q2_option4' => $this->input->post('q2_option4'),
                    'q2_answere' => $this->input->post('q2_answere'),
                    'q3_option1' => $this->input->post('q3_option1'),
                    'q3_option2' => $this->input->post('q3_option2'),
                    'q3_option3' => $this->input->post('q3_option3'),
                    'q3_option4' => $this->input->post('q3_option4'),
                    'q3_answere' => $this->input->post('q3_answere'),
                    'q4_option1' => $this->input->post('q4_option1'),
                    'q4_option2' => $this->input->post('q4_option2'),
                    'q4_option3' => $this->input->post('q4_option3'),
                    'q4_option4' => $this->input->post('q4_option4'),
                    'q4_answere' => $this->input->post('q4_answere'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );
                //echo "<pre>";print_r($qryData);die;
                if( $this->my_model->insertDataIntoTable('system_spotting_errors_code', $qryData))
                {
                    $this->session->set_flashdata('global_msg', 'Spotting Error added successfully!!');
                }
                redirect('superadmin/spotting_ErrorTests');
            }
        }
        
        $this->data['pagetitle'] = 'Spotting Error';
        $this->load->view('superadmin/spotting_error_add_view',$this->data);
        
    }
    
    function spotting_ErrorEdit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {   
            $this->form_validation->set_rules('passage', 'Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option2', 'trim|required|xss_clean'); 
            $this->form_validation->set_rules('q1_answere', '1st answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answere', '2nd answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option4', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answere', '3rd answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q4_option1', '4th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option2', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option3', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option4', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answere', '4th answere', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'passage' => $this->input->post('passage'),
                    'q1_option1' => $this->input->post('q1_option1'),
                    'q1_option2' => $this->input->post('q1_option2'),
                    'q1_option3' => $this->input->post('q1_option3'),
                    'q1_option4' => $this->input->post('q1_option4'),
                    'q1_answere' => $this->input->post('q1_answere'),
                    'q2_option1' => $this->input->post('q2_option1'),
                    'q2_option2' => $this->input->post('q2_option2'),
                    'q2_option3' => $this->input->post('q2_option3'),
                    'q2_option4' => $this->input->post('q2_option4'),
                    'q2_answere' => $this->input->post('q2_answere'),
                    'q3_option1' => $this->input->post('q3_option1'),
                    'q3_option2' => $this->input->post('q3_option2'),
                    'q3_option3' => $this->input->post('q3_option3'),
                    'q3_option4' => $this->input->post('q3_option4'),
                    'q3_answere' => $this->input->post('q3_answere'),
                    'q4_option1' => $this->input->post('q4_option1'),
                    'q4_option2' => $this->input->post('q4_option2'),
                    'q4_option3' => $this->input->post('q4_option3'),
                    'q4_option4' => $this->input->post('q4_option4'),
                    'q4_answere' => $this->input->post('q4_answere'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_spotting_errors_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Spotting Error has been update successfully!!');
                }
                redirect('superadmin/spotting_ErrorTests');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_spotting_errors_code', $where);
        
        $this->data['pagetitle'] = 'Spotting Error';
        $this->load->view('superadmin/spotting_error_edit',$this->data);
    }
    
    
    function fill_blanksTests(){
        $this->verifyUser();
        
        $this->data['window_title'] = "Fill in the blanks Test";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Fill in the blanks Test Tests';

        $where = "id != '0' ";

        $this->data['test_list'] = $this->my_model->getWhereRecords('system_fill_in_the_blanks_test_code', $where);
        $this->data['total_test'] = count($this->data['test_list']);
        $this->load->view('superadmin/fill_blanks_listing', $this->data);
    
    }
    
    
    function fill_blanksAdd(){
        $this->verifyUser();
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {   
            $this->form_validation->set_rules('passage', 'Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option4', 'trim|required|xss_clean'); 
            $this->form_validation->set_rules('q1_answere', '1st answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '2nd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answere', '2nd answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option4', '3rd Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answere', '3rd answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q4_option1', '4th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option2', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option3', '4th Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option4', '4th Question option4', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answere', '4th answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                
                $qryData = array(
                    'passage' => $this->input->post('passage'),
                    'q1_option1' => $this->input->post('q1_option1'),
                    'q1_option2' => $this->input->post('q1_option2'),
                    'q1_option3' => $this->input->post('q1_option3'),
                    'q1_option4' => $this->input->post('q1_option4'),
                    'q1_answere' => $this->input->post('q1_answere'),
                    'q2_option1' => $this->input->post('q2_option1'),
                    'q2_option2' => $this->input->post('q2_option2'),
                    'q2_option3' => $this->input->post('q2_option3'),
                    'q2_option4' => $this->input->post('q2_option4'),
                    'q2_answere' => $this->input->post('q2_answere'),
                    'q3_option1' => $this->input->post('q3_option1'),
                    'q3_option2' => $this->input->post('q3_option2'),
                    'q3_option3' => $this->input->post('q3_option3'),
                    'q3_option4' => $this->input->post('q3_option4'),
                    'q3_answere' => $this->input->post('q3_answere'),
                    'q4_option1' => $this->input->post('q4_option1'),
                    'q4_option2' => $this->input->post('q4_option2'),
                    'q4_option3' => $this->input->post('q4_option3'),
                    'q4_option4' => $this->input->post('q4_option4'),
                    'q4_answere' => $this->input->post('q4_answere'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );
                //echo "<pre>";print_r($qryData);die;
                if( $this->my_model->insertDataIntoTable('system_fill_in_the_blanks_test_code', $qryData))
                {
                    $this->session->set_flashdata('global_msg', 'Fill blanks added successfully!!');
                }
                redirect('superadmin/fill_blanksTests');
            }
        }
        
        $this->data['pagetitle'] = 'Fill in the blanks Test';
        $this->load->view('superadmin/fill_blanks_add_view',$this->data);
        
    }
    
    function fill_blanksEdit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {   
            $this->form_validation->set_rules('passage', 'Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option2', 'trim|required|xss_clean'); 
            $this->form_validation->set_rules('q1_answere', '1st answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q2_option1', '2nd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option2', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_option3', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '2nd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q2_answere', '2nd answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q3_option1', '3rd Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option2', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option3', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_option4', '3rd Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q3_answere', '3rd answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('q4_option1', '4th Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option2', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option3', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_option4', '4th Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q4_answere', '4th answere', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'passage' => $this->input->post('passage'),
                    'q1_option1' => $this->input->post('q1_option1'),
                    'q1_option2' => $this->input->post('q1_option2'),
                    'q1_option3' => $this->input->post('q1_option3'),
                    'q1_option4' => $this->input->post('q1_option4'),
                    'q1_answere' => $this->input->post('q1_answere'),
                    'q2_option1' => $this->input->post('q2_option1'),
                    'q2_option2' => $this->input->post('q2_option2'),
                    'q2_option3' => $this->input->post('q2_option3'),
                    'q2_option4' => $this->input->post('q2_option4'),
                    'q2_answere' => $this->input->post('q2_answere'),
                    'q3_option1' => $this->input->post('q3_option1'),
                    'q3_option2' => $this->input->post('q3_option2'),
                    'q3_option3' => $this->input->post('q3_option3'),
                    'q3_option4' => $this->input->post('q3_option4'),
                    'q3_answere' => $this->input->post('q3_answere'),
                    'q4_option1' => $this->input->post('q4_option1'),
                    'q4_option2' => $this->input->post('q4_option2'),
                    'q4_option3' => $this->input->post('q4_option3'),
                    'q4_option4' => $this->input->post('q4_option4'),
                    'q4_answere' => $this->input->post('q4_answere'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_fill_in_the_blanks_test_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Fill blanks has been update successfully!!');
                }
                redirect('superadmin/fill_blanksTests');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_fill_in_the_blanks_test_code', $where);
        
        $this->data['pagetitle'] = 'Fill in the blanks Test';
        $this->load->view('superadmin/fill_blanks_edit',$this->data);
    }
    
    function re_arrangeTests(){
        $this->verifyUser();
        
        $this->data['window_title'] = "Re Arrange";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Re Arrange Tests';

        $where = "id != '0' ";

        $this->data['test_list'] = $this->my_model->getWhereRecords('system_re_arrange_test_code', $where);
        $this->data['total_test'] = count($this->data['test_list']);
        $this->load->view('superadmin/re_arrange_listing', $this->data);
    
    }
    
    function re_arrangeAdd(){
        $this->verifyUser();
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {   
            $this->form_validation->set_rules('passage', 'Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option3', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option4', 'trim|required|xss_clean'); 
            $this->form_validation->set_rules('q1_answere', '1st answere', 'trim|required|xss_clean');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                
                $qryData = array(
                    'passage' => $this->input->post('passage'),
                    'q1_option1' => $this->input->post('q1_option1'),
                    'q1_option2' => $this->input->post('q1_option2'),
                    'q1_option3' => $this->input->post('q1_option3'),
                    'q1_option4' => $this->input->post('q1_option4'),
                    'q1_answere' => $this->input->post('q1_answere'),
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );
                //echo "<pre>";print_r($qryData);die;
                if( $this->my_model->insertDataIntoTable('system_re_arrange_test_code', $qryData))
                {
                    $this->session->set_flashdata('global_msg', 'Re Arrange added successfully!!');
                }
                redirect('superadmin/re_arrangeTests');
            }
        }
        
        $this->data['pagetitle'] = 'Re Arrange';
        $this->load->view('superadmin/re_arrange_add_view',$this->data);
        
    }
    
    function re_arrangeEdit($id){
        $this->verifyUser();
        
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {   
            $this->form_validation->set_rules('passage', 'Passage', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option1', '1st Question option1', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option2', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option3', '1st Question option2', 'trim|required|xss_clean');
            $this->form_validation->set_rules('q1_option4', '1st Question option2', 'trim|required|xss_clean'); 
            $this->form_validation->set_rules('q1_answere', '1st answere', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'passage' => $this->input->post('passage'),
                    'q1_option1' => $this->input->post('q1_option1'),
                    'q1_option2' => $this->input->post('q1_option2'),
                    'q1_option3' => $this->input->post('q1_option3'),
                    'q1_option4' => $this->input->post('q1_option4'),
                    'q1_answere' => $this->input->post('q1_answere'),
                    'updated_date'=>date('Y-m-d H:i:s'),
                );

                if( $this->my_model->updateTable('system_re_arrange_test_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Re Arrange test has been update successfully!!');
                }
                redirect('superadmin/re_arrangeTests');
            }
        }
        
        $where = "id = '$id' ";
        $this->data['test'] = $this->my_model->getWhereOneRecords('system_re_arrange_test_code', $where);
        
        $this->data['pagetitle'] = 'Re Arrange';
        $this->load->view('superadmin/re_arrange_edit',$this->data);
    }
    
    
    function manageBanners(){
        $this->verifyUser();
        
        $this->data['first_banner'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'first_banner');
        $this->data['second_banner'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'second_banner');
        
        $this->data['first_banner_link'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'first_banner_link');
        $this->data['second_banner_link'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'second_banner_link');
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {       
            //echo "<pre>";print_r($_POST);echo "</pre>";
            //echo "<pre>";print_r($_FILES);echo "</pre>";die;
            
            $this->form_validation->set_rules('first_banner_link', 'First Banner No Follow link provision', 'trim|required|xss_clean');
            $this->form_validation->set_rules('second_banner_link', 'Second Banner No Follow link provision', 'trim|required|xss_clean');
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['upload_path'] = './uploads/admin_banner';
            $this->load->library('upload', $config);
            $first_banner='';   
            $second_banner='';  
                  
            if($_FILES['first_banner_img']['name']!="")
            {
                if ( ! $this->upload->do_upload('first_banner_img')) {
                    //$error = array('error' => $this->upload->display_errors());
                    $this->session->set_flashdata('global_msg',strip_tags($this->upload->display_errors()));
                    redirect('superadmin/manageBanners');
                } else {
                    $data =  $this->upload->data();
                    $first_banner = $data['file_name'];
               }
            }else{
                $first_banner = $this->data['first_banner']->meta_value;
            }
            
            
            if($_FILES['second_banner_img']['name']!="")
            {
                if ( ! $this->upload->do_upload('second_banner_img')) {
                    $this->session->set_flashdata('global_msg',strip_tags($this->upload->display_errors()));
                    redirect('superadmin/manageBanners');
                } else {
                    $data =  $this->upload->data();
                    $second_banner = $data['file_name'];
               }
            }else{
                $second_banner = $this->data['second_banner']->meta_value;
            }
            
            $qryData = array(
                'meta_key'=>'first_banner',
                'meta_value' => $first_banner
            );
            
            if($this->data['first_banner']){
                $this->my_model->updateTable('system_superadmin_meta', $qryData, $this->data['first_banner']->id);
            }else{
                $this->my_model->insertDataIntoTable('system_superadmin_meta', $qryData);
            }
            
            $qryData1 = array(
                'meta_key'=>'second_banner',
                'meta_value' => $second_banner
            );
            
            if($this->data['second_banner']){
                $this->my_model->updateTable('system_superadmin_meta', $qryData1, $this->data['second_banner']->id);
            }else{
                $this->my_model->insertDataIntoTable('system_superadmin_meta', $qryData1);
            }
            
            $qryData2 = array(
                'meta_key'=>'second_banner_link',
                'meta_value' => $this->input->post('second_banner_link')
            );
            
            if($this->data['second_banner_link']){
                $this->my_model->updateTable('system_superadmin_meta', $qryData2, $this->data['second_banner_link']->id);
            }else{
                $this->my_model->insertDataIntoTable('system_superadmin_meta', $qryData2);
            }
            
            $qryData3 = array(
                'meta_key'=>'first_banner_link',
                'meta_value' => $this->input->post('first_banner_link')
            );
            
            if($this->data['first_banner_link']){
                $this->my_model->updateTable('system_superadmin_meta', $qryData3, $this->data['first_banner_link']->id);
            }else{
                $this->my_model->insertDataIntoTable('system_superadmin_meta', $qryData3);
            }
            
            $this->session->set_flashdata('global_msg', 'Banner Image has been updated successfully!! ');
            
            redirect('superadmin/manageBanners');
            
        }
  
        //$this->data['first_banner'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'first_banner');
        ///$this->data['second_banner'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'second_banner');
        //echo "<pre>";print_r($this->data['first_banner']);die;
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] =  'Manage Banner';
    
        $this->load->view('superadmin/manage_banner',$this->data);
    }
    
    
    
    
    
    
    
    
    function business() {
        $this->verifyUser();

        $this->data['window_title']="Business";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Business';

        $where = "id != '0' ";

        $this->data['business'] = $this->my_model->getWhereRecords('system_business_code', $where);
        $this->data['total_business'] = count($this->data['business']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    
    function editBusiness($id)
    {
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'reference_no' => $this->input->post('reference_no'), 
                    'reseller_reference_no' => $this->input->post('reseller_reference_no'),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'status' => $this->input->post('status'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                    'status'=>$this->input->post('status')
                );

                if( $this->my_model->updateTable('system_business_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Business update successfully!!');
                }
                redirect('superadmin/business');
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Business Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['business'] = $this->my_model->getARecord('system_business_code', $id);
        if( !is_object($this->data['business'])) { return false; }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function deleteBusiness($id)
    {
        $this->verifyUser();
        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/business'); }
        if( $this->my_model->deleteARecord('system_business_code', $id) )
        {
             $this->session->set_flashdata('global_msg', 'Business has been deleted successfully!!');
        }
        redirect('superadmin/business');
    }
    
    function addBusiness()
    {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_business_code.email]');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_business_code.username]');
            $this->form_validation->set_rules('reference_no', 'Reference Number', 'trim|required|xss_clean|is_unique[system_business_code.reference_no]');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                //echo "<pre>";print_r($_POST);die;
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'reference_no' => $this->input->post('reference_no'),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                    'status'=>$this->input->post('status')
                );

                
                if( $this->my_model->insertDataIntoTable('system_business_code', $qryData) )
                {
                    $this->session->set_flashdata('global_msg', 'Business added successfully!!');
                }
                redirect('superadmin/business');
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Business Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    
    function addBusinessCoins(){ 
        //echo "<pre>";print_r($_REQUEST);die; 
        $this->verifyUser();
        if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }   
        
        $business_id = $_REQUEST['business_id'];
        $description = $_REQUEST['description'];
        $where = "id = '$business_id' ";
        $studentData = $this->my_model->getWhereOneRecords('system_business_code', $where);
    
        $business_coins = $studentData->coins+$_REQUEST['coins'];
        $qryData = array(
            'coins' => $business_coins,
        );

        if( $this->my_model->updateTable('system_business_code', $qryData, $business_id) )
        {
            $this->session->set_flashdata('global_msg', 'Coins has been added successfully!!');
            $response = array(
                'result' => 'success',
                'message' => 'Coins Added successfully'
            );
            
            $coin_data = array('user_id'=>$business_id,
                'user_type'=>'business',
                'description'=>"By Celpip Store $description",
                'credit_coin'=>$_REQUEST['coins'],
                'balance_coin'=>$business_coins,
                'created_date'=>date('Y-m-d H:i:s'),
                'updated_at'=>date('Y-m-d H:i:s'),
            );
            $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
            
        }else{
            $response = array(
                'result' => 'error',
                'message' => 'Please try again'
            );
            $this->session->set_flashdata('global_msg', 'Please try again.');
        }
        echo json_encode($response);die;
    }


    function approvequestion(){ 
        //echo "<pre>";print_r($_REQUEST);die; 
        $this->verifyUser();
        if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }   
        
        $qid = $_REQUEST['qid'];
        $table = $_REQUEST['table'];

        $question = $this->my_model->getARecord($table, $qid);
        
        if(is_object($question)){

            $qryData = array(
                'status' => '1',
            );

            if( $this->my_model->updateTable($table, $qryData, $qid) )
            {
                $this->session->set_flashdata('global_msg', 'Question has been successfully Approved !!');
                $response = array(
                    'result' => 'success',
                    'message' => 'Approved'
                );
                
                $coin_data = array('user_id'=>$business_id,
                    'user_type'=>'business',
                    'description'=>"By Superadmin $description",
                    'credit_coin'=>$_REQUEST['coins'],
                    'balance_coin'=>$business_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
            }    
        }else{
            $response = array(
                'result' => 'error',
                'message' => 'Please try again'
            );
            $this->session->set_flashdata('global_msg', 'Please try again.');
        }
        echo json_encode($response);die;
    }
    
    function sectionListening(){ 
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Listening Section Wise Test';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $where = "id != '0'";
        $limit = 50;
        $start = 0;
        $this->data['tests'] = $this->my_model->getWhereOrderLimitRecords('system_listening_section_wise_code', $where, 'id', 'asc',$limit ,$start);

        $this->load->view('superadmin/listing_sectionListening', $this->data);
        
    }
    
    function editSectionListening($id){
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('test_name', 'test_name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('part6_code', 'part6_code', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                //echo "<pre>";print_r($_POST);die;
                $qryData = array(
                    'test_name' => $this->input->post('test_name'),
                    'practice_code' => $this->input->post('practice_code'),
                    'part1_code' => $this->input->post('part1_code'),
                    'part2_code' => $this->input->post('part2_code'),
                    'part3_code' => $this->input->post('part3_code'),
                    'part4_code' => $this->input->post('part4_code'),
                    'part5_code' => $this->input->post('part5_code'),
                    'part6_code' => $this->input->post('part6_code'),
                    'created_at' => date('Y-m-d H:i:s'),
                );
                //echo "<pre>";print_r($qryData);die;
                
                if( $this->my_model->updateTable('system_listening_section_wise_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Listening test updated successfully!!');
                    redirect('superadmin/sectionListening'); 
                }
            }
        }
        
        $this->data['test'] = $this->my_model->getARecord('system_listening_section_wise_code', $id);
        if( !is_object($this->data['test'])) { return false; }
        
        $where="id !='0' ";
        $this->data['practice'] = $this->my_model->getWhereOrderRecords('system_listening_MCsingle_code', $where, 'id', 'asc');
        $this->data['lspart1'] = $this->my_model->getWhereOrderRecords('system_listening_part1_code', $where, 'id', 'asc');
        $this->data['lspart2'] = $this->my_model->getWhereOrderRecords('system_listening_part2_code', $where, 'id', 'asc');
        $this->data['lspart3'] = $this->my_model->getWhereOrderRecords('system_listening_part3_code', $where, 'id', 'asc');
        $this->data['lspart4'] = $this->my_model->getWhereOrderRecords('system_listening_part4_code', $where, 'id', 'asc');
        $this->data['lspart5'] = $this->my_model->getWhereOrderRecords('system_listening_part5_code', $where, 'id', 'asc');
        $this->data['lspart6'] = $this->my_model->getWhereOrderRecords('system_listening_part6_code', $where, 'id', 'asc');
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Listening Section Test';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view('superadmin/edit_sectionListening', $this->data);
    }
    
    function addSectionListening(){ 
        //echo "<pre>";print_r($_REQUEST);die; 
        $this->verifyUser();
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('test_name', 'test_name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('part6_code', 'part6_code', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                //echo "<pre>";print_r($_POST);die;
                $qryData = array(
                    'test_name' => $this->input->post('test_name'),
                    'practice_code' => $this->input->post('practice_code'),
                    'part1_code' => $this->input->post('part1_code'),
                    'part2_code' => $this->input->post('part2_code'),
                    'part3_code' => $this->input->post('part3_code'),
                    'part4_code' => $this->input->post('part4_code'),
                    'part5_code' => $this->input->post('part5_code'),
                    'part6_code' => $this->input->post('part6_code'),
                    'created_at' => date('Y-m-d H:i:s'),
                );
                //echo "<pre>";print_r($qryData);die;
                if( $this->my_model->insertDataIntoTable('system_listening_section_wise_code', $qryData) )
                {
                    $this->session->set_flashdata('global_msg', 'Listening test added successfully!!');
                    redirect('superadmin/sectionListening');
                }
            }
        }
        
        $where="id !='0' ";
        $this->data['practice'] = $this->my_model->getWhereOrderRecords('system_listening_MCsingle_code', $where, 'id', 'asc');
        $this->data['lspart1'] = $this->my_model->getWhereOrderRecords('system_listening_part1_code', $where, 'id', 'asc');
        $this->data['lspart2'] = $this->my_model->getWhereOrderRecords('system_listening_part2_code', $where, 'id', 'asc');
        $this->data['lspart3'] = $this->my_model->getWhereOrderRecords('system_listening_part3_code', $where, 'id', 'asc');
        $this->data['lspart4'] = $this->my_model->getWhereOrderRecords('system_listening_part4_code', $where, 'id', 'asc');
        $this->data['lspart5'] = $this->my_model->getWhereOrderRecords('system_listening_part5_code', $where, 'id', 'asc');
        $this->data['lspart6'] = $this->my_model->getWhereOrderRecords('system_listening_part6_code', $where, 'id', 'asc');
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Listening Section Test';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view('superadmin/add_sectionListening', $this->data);
    }
    
    function sectionReading(){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Listening Section Wise Test';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
        
        $where="id !='0' ";
        $this->data['tests'] = $this->my_model->getWhereOrderRecords('system_reading_section_wise_code', $where, 'id', 'asc');
        
        $this->load->view('superadmin/listing_sectionReading', $this->data);
        
    }
    
    function addSectionReading(){ 
        //echo "<pre>";print_r($_REQUEST);die; 
        $this->verifyUser();
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('test_name', 'test_name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('part4_code', 'part6_code', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'test_name' => $this->input->post('test_name'),
                    'practice_code' => $this->input->post('practice_code'),
                    'part1_code' => $this->input->post('part1_code'),
                    'part2_code' => $this->input->post('part2_code'),
                    'part3_code' => $this->input->post('part3_code'),
                    'part4_code' => $this->input->post('part4_code'),
                    'created_at' => date('Y-m-d H:i:s'),
                );
                //echo "<pre>";print_r($qryData);die;
                if( $this->my_model->insertDataIntoTable('system_reading_section_wise_code', $qryData) )
                {
                    $this->session->set_flashdata('global_msg', 'Reading test added successfully!!');
                    redirect('superadmin/sectionReading');
                }
            }
        }
        
        $where="id !='0' ";
        $this->data['practice'] = $this->my_model->getWhereOrderRecords('system_reading1_40_code', $where, 'id', 'asc');
        $this->data['rdpart1'] = $this->my_model->getWhereOrderRecords('system_reading_part1_code', $where, 'id', 'asc');
        $this->data['rdpart2'] = $this->my_model->getWhereOrderRecords('system_reading_part2_code', $where, 'id', 'asc');
        $this->data['rdpart3'] = $this->my_model->getWhereOrderRecords('system_reading_part3_code', $where, 'id', 'asc');
        $this->data['rdpart4'] = $this->my_model->getWhereOrderRecords('system_reading_part4_code', $where, 'id', 'asc');
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Reading Section Test';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view('superadmin/add_sectionReading', $this->data);
    }
    
    function editSectionReading($id){
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('test_name', 'test_name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('part4_code', 'part4_code', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            if($this->form_validation->run() == TRUE)
            {
                //echo "<pre>";print_r($_POST);die;
                $qryData = array(
                    'test_name' => $this->input->post('test_name'),
                    'practice_code' => $this->input->post('practice_code'),
                    'part1_code' => $this->input->post('part1_code'),
                    'part2_code' => $this->input->post('part2_code'),
                    'part3_code' => $this->input->post('part3_code'),
                    'part4_code' => $this->input->post('part4_code'),
                    'created_at' => date('Y-m-d H:i:s'),
                );
                
                if( $this->my_model->updateTable('system_reading_section_wise_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Reading test updated successfully!!');
                    redirect('superadmin/sectionReading'); 
                }
            }
        }
        
        $this->data['test'] = $this->my_model->getARecord('system_reading_section_wise_code', $id);
        if( !is_object($this->data['test'])) { return false; }
        
        $where="id !='0' ";
        $this->data['practice'] = $this->my_model->getWhereOrderRecords('system_reading1_40_code', $where, 'id', 'asc');
        $this->data['rdpart1'] = $this->my_model->getWhereOrderRecords('system_reading_part1_code', $where, 'id', 'asc');
        $this->data['rdpart2'] = $this->my_model->getWhereOrderRecords('system_reading_part2_code', $where, 'id', 'asc');
        $this->data['rdpart3'] = $this->my_model->getWhereOrderRecords('system_reading_part3_code', $where, 'id', 'asc');
        $this->data['rdpart4'] = $this->my_model->getWhereOrderRecords('system_reading_part4_code', $where, 'id', 'asc');
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Reading Section Test';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view('superadmin/edit_sectionReading', $this->data);
    }


    function sectionSpeaking(){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Speaking Section Wise Test';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];
        
        $where="id !='0' ";
        $this->data['tests'] = $this->my_model->getWhereOrderRecords('system_speaking_section_wise_code', $where, 'id', 'asc');
        
        $this->load->view('superadmin/listing_sectionSpeaking', $this->data);
        
    }

    function addSectionSpeaking(){ 
        //echo "<pre>";print_r($_REQUEST);die; 
        $this->verifyUser();
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('test_name', 'test_name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('part8_code', 'part8_code', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                //echo "<pre>";print_r($_POST);die;
                $qryData = array(
                    'test_name' => $this->input->post('test_name'),
                    'practice_code' => $this->input->post('practice_code'),
                    'part1_code' => $this->input->post('part1_code'),
                    'part2_code' => $this->input->post('part2_code'),
                    'part3_code' => $this->input->post('part3_code'),
                    'part4_code' => $this->input->post('part4_code'),
                    'part5_code' => $this->input->post('part5_code'),
                    'part6_code' => $this->input->post('part6_code'),
                    'part7_code' => $this->input->post('part7_code'),
                    'part8_code' => $this->input->post('part8_code'),
                    'created_at' => date('Y-m-d H:i:s'),
                );
                //echo "<pre>";print_r($qryData);die;
                if( $this->my_model->insertDataIntoTable('system_speaking_section_wise_code', $qryData) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking test added successfully!!');
                    redirect('superadmin/sectionSpeaking');
                }
            }
        }
        
        $where="id !='0' ";
        $this->data['practice'] = $this->my_model->getWhereOrderRecords('system_speaking_practice_code', $where, 'id', 'asc');
        $this->data['sppart1'] = $this->my_model->getWhereOrderRecords('system_speaking_part1_code', $where, 'id', 'asc');
        $this->data['sppart2'] = $this->my_model->getWhereOrderRecords('system_speaking_part2_code', $where, 'id', 'asc');
        $this->data['sppart3'] = $this->my_model->getWhereOrderRecords('system_speaking_part3_code', $where, 'id', 'asc');
        $this->data['sppart4'] = $this->my_model->getWhereOrderRecords('system_speaking_part4_code', $where, 'id', 'asc');
        $this->data['sppart5'] = $this->my_model->getWhereOrderRecords('system_speaking_part5_code', $where, 'id', 'asc');
        $this->data['sppart6'] = $this->my_model->getWhereOrderRecords('system_speaking_part6_code', $where, 'id', 'asc');
        $this->data['sppart7'] = $this->my_model->getWhereOrderRecords('system_speaking_part7_code', $where, 'id', 'asc');
        $this->data['sppart8'] = $this->my_model->getWhereOrderRecords('system_speaking_part8_code', $where, 'id', 'asc');
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Speaking Section Test';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view('superadmin/add_sectionSpeaking', $this->data);
    }


    function editSectionSpeaking($id){
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('test_name', 'test_name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('part8_code', 'part8_code', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                //echo "<pre>";print_r($_POST);die;
                $qryData = array(
                    'test_name' => $this->input->post('test_name'),
                    'practice_code' => $this->input->post('practice_code'),
                    'part1_code' => $this->input->post('part1_code'),
                    'part2_code' => $this->input->post('part2_code'),
                    'part3_code' => $this->input->post('part3_code'),
                    'part4_code' => $this->input->post('part4_code'),
                    'part5_code' => $this->input->post('part5_code'),
                    'part6_code' => $this->input->post('part6_code'),
                    'part7_code' => $this->input->post('part7_code'),
                    'part8_code' => $this->input->post('part8_code'),
                    'created_at' => date('Y-m-d H:i:s')
                );
                //echo "<pre>";print_r($qryData);die;
                
                if( $this->my_model->updateTable('system_speaking_section_wise_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Speaking test updated successfully!!');
                    redirect('superadmin/sectionSpeaking'); 
                }
            }
        }
        
        $this->data['test'] = $this->my_model->getARecord('system_speaking_section_wise_code', $id);
        if( !is_object($this->data['test'])) { return false; }
        
        $where="id !='0' ";
        $this->data['practice'] = $this->my_model->getWhereOrderRecords('system_speaking_practice_code', $where, 'id', 'asc');
        $this->data['sppart1'] = $this->my_model->getWhereOrderRecords('system_speaking_part1_code', $where, 'id', 'asc');
        $this->data['sppart2'] = $this->my_model->getWhereOrderRecords('system_speaking_part2_code', $where, 'id', 'asc');
        $this->data['sppart3'] = $this->my_model->getWhereOrderRecords('system_speaking_part3_code', $where, 'id', 'asc');
        $this->data['sppart4'] = $this->my_model->getWhereOrderRecords('system_speaking_part4_code', $where, 'id', 'asc');
        $this->data['sppart5'] = $this->my_model->getWhereOrderRecords('system_speaking_part5_code', $where, 'id', 'asc');
        $this->data['sppart6'] = $this->my_model->getWhereOrderRecords('system_speaking_part6_code', $where, 'id', 'asc');
        $this->data['sppart7'] = $this->my_model->getWhereOrderRecords('system_speaking_part7_code', $where, 'id', 'asc');
        $this->data['sppart8'] = $this->my_model->getWhereOrderRecords('system_speaking_part8_code', $where, 'id', 'asc');
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Speaking Section Test';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view('superadmin/edit_sectionSpeaking', $this->data);
    }
    
    function ajax_member(){
        //echo '<pre>hioioi';print_r($_POST);die;
        //echo '<pre>hioioi';print_r($_POST);die;
        $this->verifyUser();
        
        $list = $this->my_model->get_employees();       
        $data = array();
        $no = $_POST['start'];
        //echo "<pre>";print_r($list);die;
        foreach ($list as $member) {
           // print_r($data);die;
           
            if($member->status == '0'){ 
                $status = '<span class="btn btn-xs btn-success"> InActive</span>';
            }elseif($member->status == '1'){
                $status = '<span class="btn btn-xs btn-danger"> Active</span>';
            }
            
            $where = "id = '". $member->country_id ."' ";
            $country_data = $this->my_model->getWhereOrderRecords('system_countries_code', $where,'id','desc');
            if(!empty($country_data)){
                $country = $country_data[0]->name;
            }else{
                $country = '';  
            }
            
            $_onClick = "onclick=\"return confirm('Are you sure you want to delete ".$member->username ." ? This action will delete all data owned by this Client.')\"";
            $action = '';
            
            $action = '<button type="button" title="Add Coins" class="btn btn-default btn-xs student_add_coins" data-id="'.$member->id .'" data-toggle="tooltip"><i class="fa fa-money"></i></button>
            <a href="'. base_url('superadmin/editMember/'.$member->id) .'" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i></a>
            <a href="'. base_url('superadmin/deleteMember/'.$member->id) .'" class="btn btn-default btn-xs btn-danger" title="Delete" '.$_onClick.' data-toggle="tooltip" data-placement="left"><i class="fa fa-trash-o"></i> </a>';
            
            $no++;
            $row = array();
            $row[] = $member->id;
            $row[] = $member->student_reference_no;
            $row[] = $member->username;
            $row[] = $member->coins;
            $row[] = $member->email;
            $row[] = $country;
            $row[] = $member->city_region;
            $row[] = $member->ip_address;
            $row[] = date("d-m-Y",$member->created_time);
            $row[] = $status;
            $row[] = $action;

            $data[] = $row;

           //$_POST['draw']='';
        }

        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->my_model->count_all(),
                        "recordsFiltered" => $this->my_model->count_filtered(),
                        "data" => $data,
                );
        //output to json format
       echo json_encode($output);die;
        
    }
    
    function memberNew() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'student_reference_no'=>$this->input->post('student_reference_no'),
                    'business_reference_no'=>$this->input->post('business_reference_no'),
                    'reference_no'=>$this->input->post('reference_no'),
                    'created_time' => time(),
                    'status' => $this->input->post('status')
                );

                if( $this->my_model->insertDataIntoTable('system_member_code', $qryData) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title']="Add Student";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Students';

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    
        function affiliatememberNew() {
        $this->verifyUser();

        $this->data['window_title']="Affiliate Students";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Students';

        $where = "id != '0' ";
        $this->data['members'] = $this->my_model->getWhereOrderRecords('system_affiliate_code', $where,'id','desc');
        //echo "<pre>";print_r($this->data['members']);die;
        

        $this->data['total_members'] = count($this->data['members']);
        $this->load->view($this->data['currentPath'].'/'.affiliatememberNew, $this->data);
    }
    
    function transactionList() {
        $this->verifyUser();

        $this->data['window_title']="Transaction List";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Transaction list';

        $where = "id != '0' ";
        $this->data['transactions'] = $this->my_model->getWhereOrderRecords('system_transaction_code', $where,'id','desc');
        //print_r($this->data['members']);
        

        $this->data['total_transactions'] = count($this->data['transactions']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
        function affiliatetransactionList() {
        $this->verifyUser();

        $this->data['window_title']="Transaction List";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Transaction list';

        $where = "id != '0' ";
        $this->data['transactions'] = $this->my_model->getWhereOrderRecords('system_affiliate_transaction_code', $where,'id','desc');
        //print_r($this->data['members']);
        

        $this->data['total_transactions'] = count($this->data['transactions']);
        $this->load->view($this->data['currentPath'].'/'.affiliatetransactionList, $this->data);
    }
    
    
    
    function sendPromotion() {
        // check website session, if enabled
        $this->verifyUser();
        
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

           // echo "<pre>";print_r($_POST);die;
           // $this->load->model('my_model');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                
                $where = "email = '".$_POST['email']."' ";
                $getUser = $this->my_model->getWhereOrderRecords('system_member_code', $where, 'id', 'asc');
                
                
                
                if(!empty($getUser)){
                $imgdata = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'first_banner'); 
                
            $latestbanner=$imgdata->meta_value;
                //echo "<pre>";print_r($imgdata);die;
                    //echo "<pre>";print_r($getUser);die;
                    
                    /* Send account detail email */
                        $password = random_string('alnum', 8);
                        $this->load->library('email');
                        $config = array (
                            'mailtype' => 'html',
                            'charset'  => 'utf-8',
                            'wordwrap' => TRUE,
                            'priority' => '1'
                        );
                        $this->email->initialize($config);
                       // $this->email->from($this->app_email, $this->app_name);
                       $this->email->from($this->app_contactemail, 'CELPIP Exam');
                        $this->email->to($this->input->post('email'));
                        #$this->email->cc($this->app_contactemail); // send copy at website contact email address
                        $this->email->subject('Best Offer for you: ');
                     
                   
                        
                        // send text email
                        $this->email->message('<html><body>
                                               
                         
                         <img src="https://www.celpipstore.com/public/images/celpip-store.png" alt="loader" height=50 width=150><br><br>
                         <img src=http://www.celpipstore.com/public/admin_banner/'.$latestbanner.'><br><br><br>
                         <a href=https://www.celpipstore.com>
                         <font color=#F0411C size=5 face=Aerial>Click here to avail the opportunity Now!</font></a><br><br>
                        <b>Note : </b>if you think this email has reached your inbox by mistake, <a href="'.base_url('contact?Eaddress='.$this->input->post('email').'&reporttoken='.$this->data['rn']).'">please report </a><br>

                        Best Wishes,<br>
                        '.$this->app_name.' Team<br><Br><br><Br>
                        
                        
                      
                        
                        
                        </html></body>');
                       
                       
                        
                        //echo '<pre>'; print_r($data); echo '</pre>';
                        $this->email->send();
                        //echo $this->email->print_debugger();
                    // @end email
                    
                    
                    $this->session->set_flashdata('global_msg','Your Password has been reset please check your email for password');
                }else{
                    $this->session->set_flashdata('global_msg','Email is not register please create your account');
                }
                
                redirect($this->data['currentPath'].'/sendPromotion', 'refresh');
            }
        }
        
        $this->data['formAction'] = $this->uri->segment(1). '/' . $this->uri->segment(2);
        $this->load->view('superadmin/sendPromotion', $this->data);
    }
        
        
        
        
        
        
        
        
            function addblog(){
        $this->verifyUser();
        
        $query = $this->db->query("SELECT * FROM system_blog_code ORDER BY id DESC LIMIT 1");
        $result = $query->row();

        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            
            $this->form_validation->set_rules('seo_title', 'seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'seo discription', 'trim|required|xss_clean');
            $this->form_validation->set_rules('blog_title', 'blog title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('blog_content', 'blog_content', 'trim|required|xss_clean');
            $this->form_validation->set_rules('blog_url', 'blog url', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('summary', 'summary', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            
            if($this->form_validation->run() == TRUE)
            {
                $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                $config['upload_path'] = './public/blog';
                $this->load->library('upload', $config);
                $practice_01_img='';
            

               // print_r(($_FILES[$attachment]['name']));
                        
               if($_FILES['practice_01_img']['name']!="")
                {               
                    if ( ! $this->upload->do_upload('practice_01_img')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                         $data =  $this->upload->data();
                         $practice_01_img = $data['file_name'];
                    }
                }
                 
                 
                  $qryData = array(
                        'blog_image' => $practice_01_img,
                        'seo_title' => $this->input->post('seo_title'),
                        
                        'seo_discription' => $this->input->post('seo_discription'),
                        'blog_title' => $this->input->post('blog_title'),
                        'blog_content' => $this->input->post('blog_content'),
                        'blog_url' => $this->input->post('blog_url'),
                        'summary' => $this->input->post('summary'),
                        'status' => $this->input->post('status'),
                        
                    );
                    
                    //echo "<pre>";print_r($qryData);die;

                    if( $this->my_model->insertDataIntoTable('system_blog_code', $qryData) )
                    {
                        
                        $this->session->set_flashdata('global_msg', 'Blog has been added successfully!!');
                    }
                    
                    redirect('superadmin/blog');
            }
        }
        
        $this->load->view('superadmin/addblog',$this->data);
        
    }
    
    
    function blogedit($id){
        $this->verifyUser();
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_REQUEST);die;
                $this->form_validation->set_rules('seo_title', 'seo title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('seo_discription', 'seo discription', 'trim|required|xss_clean');
            $this->form_validation->set_rules('blog_title', 'blog title', 'trim|required|xss_clean');
            $this->form_validation->set_rules('blog_content', 'blog_content', 'trim|required|xss_clean');
            $this->form_validation->set_rules('blog_url', 'blog url', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('summary', 'summary', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );
            
            if($this->form_validation->run() == TRUE)
            {
                
                $getl1data = $this->my_model->getARecord('system_blog_code', $id);
                
                $config['allowed_types'] = 'mpeg|mp3|mp4|gif|jpg|png|jpeg';
                $config['upload_path'] = './public/blog';
                $this->load->library('upload', $config);
                $practice_01_img='';

               if($_FILES['practice_01_img']['name']!="")
                {               
                    if ( ! $this->upload->do_upload('practice_01_img')) {
                        $error = array('error' => $this->upload->display_errors());
                        //return false;
                    } else {
                         $data =  $this->upload->data();
                         $practice_01_img = $data['file_name'];
                    }
                }else{
                    $practice_01_img = $getl1data->blog_image;
                }

                      
             
             
              $qryData = array(
                        'blog_image' => $practice_01_img,
                        'seo_title' => $this->input->post('seo_title'),
                        
                        'seo_discription' => $this->input->post('seo_discription'),
                        'blog_title' => $this->input->post('blog_title'),
                        'blog_content' => $this->input->post('blog_content'),
                        'blog_url' => $this->input->post('blog_url'),
                        'summary' => $this->input->post('summary'),
                        'status' => $this->input->post('status'),
                                        );
                
                //echo "<pre>";print_r($qryData);die;

                if( $this->my_model->updateTable('system_blog_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Update Successfully!!');
                }
                
                redirect('superadmin/blog');
            }
        }
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Blog';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->data['blogdata'] = $this->my_model->getARecord('system_blog_code', $id);
        if( !is_object($this->data['blog'])) 
        $this->load->view('superadmin/blog_edit', $this->data);
        
    }
    
    

    }
    