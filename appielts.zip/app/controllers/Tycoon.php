<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Member controller
* this controller is related to specific user role
*/
class Tycoon extends AKAAL_Controller {

    public function __construct() {
        parent::__construct();
 
        $this->data['currentAccount'] = 'logger_member';
        $this->data['currentPath'] = 'tycoon';
        
        // table name of specific user role; which is related to this controller only
        $this->tb_name = $this->tb_reseller;
    }

    function index() {

        $this->login();
    }

    function login() {
        // check website session, if enabled
		
		///echo "<pre>";print_r($this->session->userdata($this->data['currentAccount']));die;
        if( $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            //echo "<pre>";print_r($loggedUser);die;
			if($loggedUser['user_role']=='tycoon'){
				redirect($this->data['currentPath'].'/dashboard', 'refresh');
			}
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $this->load->model('my_model');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_isValidUser');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }

        $this->data['title'] = '<a href="'.base_url('/'.$this->data['currentPath'].'/login').'">Member Login</a>';

        //$this->data['custom_url'] = 'http://ielts24x7.com/NEW';
        //$this->data['custom_url'] = 'http://ielts24x7.com';
        $this->data['custom_url'] = 'https://ielts24x7.com';

        $window_title = 'Student Login - ' . $this->app_name;

        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );
        $this->data['pagetitle'] = 'Tycoon Login';

        $this->data['formAction'] = $this->uri->segment(1). '/' . $this->uri->segment(2);
        $this->load->view('shared/login', $this->data);
    }

    function isValidUser($password) {
        //Field validation succeeded.  Validate against database
        $username = $this->input->post('username');
        $result = $this->my_model->getUser($this->tb_name, $username, $password);

        if($result)
        {
            $session_array = array();
            foreach($result as $row)
            {
                $session_array = array(
                    'id' => $row->id,
                    'name' => $row->name,
					'user_role'=>'tycoon'
                );

                $this->session->set_userdata($this->data['currentAccount'], $session_array);
            }
            return true;
        }
        else
        {
            $this->form_validation->set_message('isValidUser', 'Invalid username or password');
            return false;
        }
    }

    function logout() {
        // Make sure you destory website session as well.
        $this->session->unset_userdata($this->data['currentAccount']);
        $this->session->sess_destroy();
        // Finally redirect page to desire location
        redirect('tycoon');
    }

    function verifyUser() {

        // check login
        $this->logged = is_user_logged_in(
            $this->data['currentAccount'],
            $this->data['currentPath']
        );

        $this->data['user'] = $this->my_model->getARecord($this->tb_name, $this->logged['id']);
        $this->data['role'] = $this->my_model->getARecord($this->tb_role, $this->data['user']->role_id);

        // checks for valid user get or not
        if( !is_object($this->data['user'])) { return false; }

        $this->data['country'] = $this->my_model->getARecord($this->tb_countries, $this->data['user']->country_id);
    }
	
	 function member() {
        $this->verifyUser();

		if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }	
		
		$user_id = $loggedUser['id'];
		$where = "id = '$user_id' ";
		$getData = $this->my_model->getWhereOneRecords('system_reseller_code', $where);//Get Reference Number
		
        $this->data['window_title']="Students";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Students';

		
		$reference_no = $getData->reference_no;
        $where = "id != '0' AND reference_no='$reference_no'";

        $this->data['members'] = $this->my_model->getWhereRecords('system_member_code', $where);
		
        $this->data['total_members'] = count($this->data['members']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function deleteMember($id)
    {
        $this->verifyUser();
        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/member'); }
        if( $this->my_model->deleteARecord('system_member_code', $id) )
        {
            redirect($this->data['currentPath'].'/member?trash=1');
        }
        redirect($this->data['currentPath'].'/member');
    }
	
	function addCoins(){
		$this->verifyUser();
		if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }	
		
		$user_id = $loggedUser['id'];
		$where = "id = '$user_id' ";
		$getData = $this->my_model->getWhereOneRecords('system_reseller_code', $where);
		
		if($getData->coins <= 0){
			$response = array(
                'result' => 'error',
                'message' => 'You have not balance coin for access test!!'
            );
			echo json_encode ($response) ;
			die;
		}
		
		if($getData->coins < $_POST['coins']){
			$response = array(
                'result' => 'error',
                'message' => 'You have not balance coin for transfer!!'
            );
			$this->session->set_flashdata('global_msg','You have not balance coin for transfer!!');
			echo json_encode ($response) ;
			die;
		}
		
		
		$reseller_coins = $getData->coins-$_POST['coins'];
		$qryData = array(
			'coins' => $reseller_coins,
		);

		if( $this->my_model->updateTable('system_reseller_code', $qryData, $user_id) )
		{
			$description = $_POST['description'];
			$student_id = $_POST['student_id'];
			
			$stuwhere = "id = '$student_id' ";
			$studentData = $this->my_model->getWhereOneRecords('system_member_code', $stuwhere);
			$student_name = $studentData->username;
			
			$reseller_coin_data = array('user_id'=>$user_id,
				'user_type'=>'reseller',
				'description'=>"$description Transfer to student $student_name",
				'debit_coin'=>$_POST['coins'],
				'balance_coin'=>$reseller_coins,
				'created_date'=>date('Y-m-d H:i:s'),
				'updated_at'=>date('Y-m-d H:i:s'),
			);
			$this->my_model->insertDataIntoTable('system_coins_management_code', $reseller_coin_data);
			
			/* $student_id = $_POST['student_id'];
			$stuwhere = "id = '$student_id' ";
			$studentData = $this->my_model->getWhereOneRecords('system_member_code', $stuwhere); */
		
			$student_coins = $studentData->coins+$_POST['coins'];
			$qryData1 = array(
				'coins' => $student_coins,
			);
			
			$this->my_model->updateTable('system_member_code', $qryData1, $student_id);
			
			$reseller_name = $getData->username;
			$student_coin_data = array('user_id'=>$student_id,
				'user_type'=>'member',
				'description'=>"$description Transfer by reseller $reseller_name",
				'credit_coin'=>$_POST['coins'],
				'balance_coin'=>$student_coins,
				'created_date'=>date('Y-m-d H:i:s'),
				'updated_at'=>date('Y-m-d H:i:s'),
			);
			$this->my_model->insertDataIntoTable('system_coins_management_code', $student_coin_data);
			
			$this->session->set_flashdata('global_msg', 'Coins has been added successfully!!');
			$response = array(
                'result' => 'success',
                'message' => 'Coins Added successfully'
            );
		}else{
			$response = array(
                'result' => 'error',
                'message' => 'Please try again'
            );
			$this->session->set_flashdata('global_msg', 'Please try again.');
		}
		echo json_encode($response);die;
		
	}
	
	function editMember($id)
    {
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                );

                if( $this->my_model->updateTable('system_member_code', $qryData, $id) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Student Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['teacher'] = $this->my_model->getARecord('system_member_code', $id);
        if( !is_object($this->data['teacher'])) { return false; }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function addMember()
    {
        $this->verifyUser();
		
		$reseller = $this->my_model->getARecord('system_reseller_code', $this->data['user']->id);
		if( !is_object($reseller)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {    
			//echo "<pre>";print_r($_POST);die;
			$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_member_code.email]');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_member_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            //$this->form_validation->set_rules('username', 'Username', 'trim');
            //$this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $where = "id != '0' AND student_code!='0'" ;
				$get_last_stu_code = $this->my_model->getWhereLastRecords('system_member_code', $where);
				if(!empty($get_last_stu_code)){
					$student_code = $get_last_stu_code->student_code+1;
				}else{
					$student_code = '101';
				}
				
				$qryData = array(
                    'name' => $this->input->post('name'),
					'student_code'=>$student_code,
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'reference_no' => $reseller->reference_no,
					'coins'=>200,
                    'created_time' => time(),
                );

				if( $this->my_model->insertDataIntoTable('system_member_code', $qryData))
                {
					$last_added_id = $this->db->insert_id();
					
					$coin_data = array('user_id'=>$last_added_id,
						'user_type'=>'member',
						'description'=>'By reference Register',
						'credit_coin'=>'200',
						'balance_coin'=>'200',
						'created_date'=>date('Y-m-d H:i:s'),
						'updated_at'=>date('Y-m-d H:i:s'),
					);

					$this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
					
					$this->session->set_flashdata('global_msg', 'Student has been added successfully');
					redirect($this->data['currentPath'].'/member');
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Student Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function account() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Profile';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function vocabulary() {
        $this->verifyUser();

        # Show all vocabulary tests
        $where = "active = 'Yes' ";
        $this->data['levels'] = $this->my_model->getWhereOrderRecords($this->tb_vlevel, $where, 'id', 'asc');
        $this->data['total'] = count($this->data['levels']);


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Vocabulary Tests';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function vtestdetails($level_id, $level_id_md5) {
        $this->verifyUser();

        $this->data['test'] = $this->my_model->getARecord($this->tb_vlevel, $level_id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($level_id);
        if($getId != $level_id_md5) {
            exit($this->unauthorized_message);
        }


        // Get all questions in test
        $where = "level_id = '".$level_id."' ";
        $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_vquestion, $where, 'id', 'asc');
        $this->data['total_questions'] = count($allQuestions);

        // History, in desc order
        $where = "level_id = '".$level_id."' AND member_id = '".$this->data['user']->id."' ";
        $this->data['history'] = $this->my_model->getWhereOrderRecords($this->tb_vtestdetails, $where, 'id', 'desc');

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $this->data['test']->name;
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }












    function sampleQuestion($typeid = '') {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Sample Questions';
        $this->data['test_id'] = '7';

        $this->data['test'] = $this->my_model->getARecord($this->tb_test, '7');

        if( in_array($typeid, array('1','2','3','4')) ) {

            // Speaking
            $where = "PTEtypeid = '1' ";
            $this->data['speaking'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');

            // Writing
            $where = "PTEtypeid = '4' ";
            $this->data['writing'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');

            // Reading
            $where = "PTEtypeid = '2' ";
            $this->data['reading'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');

            // Listening
            $where = "PTEtypeid = '3' AND active = 'Yes' ";
            $this->data['listening'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');
        
        } else {

            exit($this->unauthorized_message);
        }

        $this->data['typeid'] = $typeid;

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function sampleQResult($id, $test_id_md5) {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // questions
        $where = "testid = '".$this->data['test']->id."' AND status = 'Active' AND PTEsubtypeid = '".$this->data['subtype']->id."' ";
        $this->data['allQuestions'] = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');


        /**********************************************
        * DONE - attempted question by logged students
        ***********************************************/

        $where = "subtypeid = '".$this->data['subtype']->id."' AND memberid = '".$this->data['user']->id."' ";
        $this->data['attemptedQuestions'] = $this->my_model->getWhereOrderRecords($this->tb_attempt, $where, 'id', 'asc');


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'sample Questions';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function startTest($id, $test_id_md5) {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // questions
        $where = "testid = '".$this->data['test']->id."' AND status = 'Active' AND PTEsubtypeid = '".$this->data['subtype']->id."' ";
        $this->data['allQuestions'] = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'sample Questions';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function sampleTest($id, $test_id_md5, $page='1') {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                'testid' => $this->data['test']->id,
                'status' => 'Active',
                'PTEsubtypeid' => $this->data['subtype']->id,
            );
            $this->sortby = 'id'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, $this->tb_question );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 5;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination

        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, $this->tb_question );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        $this->data['reporturl'] = base_url('member/sampleQResult/'.$id.'/'.$test_id_md5);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Sample Test';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function uploadrecording() {

        $audiosrc = $this->input->post('audiosrc');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $subtypeid = $this->input->post('subtypeid');
        $questionid = $this->input->post('questionid');

        // upload mp3 - DONE
        $time = time();
        $fname = md5($time).'-'.md5($memberId).'.record';

        write_file('./uploads/attempt/'.$fname, $audiosrc);

        $qryData = array(
            'time' => $time,
            'testid' => $testid,
            'questionid' => $questionid,
            'subtypeid' => $subtypeid,
            'memberid' => $memberId,
            'fname' => $fname
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Recording has been successfully uploaded.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    function uploadattempt() {

        $fname = $this->input->post('fname');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $subtypeid = $this->input->post('subtypeid');
        $questionid = $this->input->post('questionid');

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'testid' => $testid,
            'questionid' => $questionid,
            'subtypeid' => $subtypeid,
            'memberid' => $memberId,
            'fname' => $fname,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Recording has been successfully uploaded.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    function uploadjson() {

        $myresponse = $this->input->post('myresponse');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $subtypeid = $this->input->post('subtypeid');
        $questionid = $this->input->post('questionid');

        $result = array('myresponse' => $myresponse);
        $json_result = json_encode($result);

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'testid' => $testid,
            'questionid' => $questionid,
            'subtypeid' => $subtypeid,
            'memberid' => $memberId,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    function response($id, $id_md5) {
        $this->verifyUser();

        $this->data['attempt'] = $this->my_model->getARecord($this->tb_attempt, $id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($id);
        if($getId != $id_md5) {
            exit($this->unauthorized_message);
        }

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $this->data['attempt']->subtypeid);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id', $this->data['attempt']->testid);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }

        $this->data['type'] = $this->my_model->getARecord($this->tb_type, $this->data['subtype']->PTEtypeid);


        $this->data['question'] = $this->my_model->checkARecord($this->tb_question, 'id', $this->data['attempt']->questionid);
        if( !is_object($this->data['question'])) {
            exit($this->unauthorized_message);
        }

        $myTable = $this->tb_prefix.$this->data['subtype']->tbname.$this->tb_suffix;

        $this->data['qExtra'] = $this->my_model->checkARecord($myTable, 'questionid', $this->data['attempt']->questionid);
        if( !is_object($this->data['qExtra'])) {
            exit($this->unauthorized_message);
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Your Response';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function tests() {
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Tests';

        // Get all tests without - Sample Test = 7
        $where = "id != '7' ";
        $this->data['tests'] = $this->my_model->getWhereOrderRecords($this->tb_test, $where, 'id', 'ASC');

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function testdetails($id, $id_md5) {
        $this->verifyUser();

        $this->data['test'] = $this->my_model->getARecord($this->tb_test, $id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($id);
        if($getId != $id_md5) {
            exit($this->unauthorized_message);
        }

        // Should not be (Sample Test) = 7
        if($id == 7) {
            exit($this->unauthorized_message);
        }


        // Get all questions in test
        $where = "testid = '".$id."' ";
        $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');
        $this->data['total_questions'] = count($allQuestions);


        // history
        $where = "test_id = '".$id."' AND member_id = '".$this->data['user']->id."' ";
        $this->data['history'] = $this->my_model->getWhereOrderRecords($this->tb_testdetails, $where, 'id', 'asc');


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Test Details';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    /*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function testprogress($tdId_md5, $testId_md5, $page='1') {
        $this->verifyUser();

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $testId_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }



        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                'testid' => $this->data['test']->id,
                'status' => 'Active',
                //'PTEsubtypeid' => $this->data['subtype']->id,
            );
            $this->sortby = 'PTEsubtypeid'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, $this->tb_question );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 10;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination

        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, $this->tb_question );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        //$this->data['reporturl'] = base_url('member/sampleQResult/tests');
        $this->data['reporturl'] = current_url();




        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $this->data['test']->test_name;
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    /*
    * Start a new test
    */
    function startnewtest() {

        $testid = $this->input->post('testid');
        $memberid = $this->input->post('memberid');
        $objTest = $this->my_model->getARecord($this->tb_test, $testid);

        if( is_object($objTest)) {

            $qryData = array(
                'test_id' => $testid,
                'member_id' => $memberid,
                'time' => time(),
            );

            if( $this->my_model->insertDataIntoTable($this->tb_testdetails, $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable($this->tb_testdetails, $updateData, $last_added_id);

            }

            // Add entry here
            $response = array(
                'result' => 'success',
                'message' => 'Test Started',
                'tdcode' => $id_md5, // test details code
                'tcode' => $objTest->id_md5 // test code
            );

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        echo json_encode ($response) ;
    }


    function ticket($id) {
        $this->verifyUser();


        $this->data['support'] = $this->my_model->getARecord($this->tb_support, $id);

        $where = "support_id =".$id;

        $this->data['tickets'] = $this->my_model->getWhereOrderRecords($this->tb_ticket, $where ,'id','ASC');
        $this->data['total_tickets'] = count($this->data['tickets']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Ticket';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function support() {
        $this->verifyUser();



        $where = "member_id =".$this->logged['id'];

        $this->data['supports'] = $this->my_model->getWhereRecords($this->tb_support, $where);
        $this->data['total_support'] = count($this->data['supports']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Support';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }  



    function closeTicket($id)
    {
        $this->verifyUser();

                $qryData = array(
                    'status' => "resoloved",
                );

                if( $this->my_model->updateTable($this->tb_support, $qryData, $id) )
                {
                redirect($this->data['currentPath'].'/support?close=1');
                }
       

    }
  
    function replyTicket($id)
    {
        $this->verifyUser();

                $qryData = array(
                    'support_id' => $id,
                    'member_id' => $this->logged['id'],
                    'details' => $this->input->post('details'),
                    'time' => time(),
                );

                if( $this->my_model->insertDataIntoTable($this->tb_ticket, $qryData) )
                {
                   
                redirect($this->data['currentPath'].'/ticket/'.$id);
                }
       

    }

  

    function addTicket() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {

            $this->form_validation->set_rules('title', 'Title', 'trim');
            $this->form_validation->set_rules('type', 'Type', 'trim');
            $this->form_validation->set_rules('details', 'details', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'title' => $this->input->post('title'),
                    'type' => $this->input->post('type'),
                    'details' => $this->input->post('details'),
                    'member_id' => $this->logged['id'],
                    'time' => time(),
                );

                if( $this->my_model->insertDataIntoTable($this->tb_support, $qryData) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Support';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    public function password() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $this->form_validation->set_rules('old', 'Current password', 'trim|required|xss_clean|min_length[3]|max_length[30]');
            $this->form_validation->set_rules('new', 'New password', 'trim|required|xss_clean|min_length[6]|max_length[30]');
            $this->form_validation->set_rules('confirm', 'Confirm password', 'trim|required|xss_clean|max_length[30]|callback_checkPassword');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger">','</div>' );
            if($this->form_validation->run() == TRUE) {
                $this->data['success'] = true;
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Change Password';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function checkPassword() {

        $newPassword = $this->input->post('new');
        $confirmPassword = $this->input->post('confirm');

        if($newPassword == $confirmPassword) {
            
            if(strlen($newPassword) > 5  && strlen($confirmPassword) > 5  ){
                $result = $this->my_model->changePassword($confirmPassword, $this->data['user']->id, $this->tb_name);
                if(!$result) {

                    $this->form_validation->set_message('checkPassword', 'Please enter correct current Password.');
                    return false;
                }
            }
            
        
        } else {
            $this->form_validation->set_message('checkPassword', 'The New password field does not match the Confirm password field.');
            return false;
        }
        return true;
    }

    function dashboard() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dashboard';
		
		$this->data['reseller'] = $this->my_model->getARecord('system_reseller_code', $this->data['user']->id);
		if( !is_object($this->data['reseller'])) { return false; }
		
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function ComingSoon() {
        $this->verifyUser();

        $this->data['window_title']="Select Question Type";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];
        $this->data['pagetitle'] = 'Question';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function manageBanner(){
		$this->verifyUser();
		
		$check_member = $this->my_model->checkARecord('system_reseller_code', 'id', $this->data['user']->id);
        if( !is_object($check_member)) {
            exit($this->unauthorized_message);
        }
		
		$this->data['reseller'] = $check_member;
		
		if ($_SERVER["REQUEST_METHOD"] == "POST")
        {		
			//echo "<pre>";print_r($_POST);echo "</pre>";
			//echo "<pre>";print_r($_FILES);echo "</pre>";die;
			
			if(!empty($_FILES["banner_img"]["name"])){
				$banner_logo_image = strtotime(date("Y-m-d h:i:s A")).'_'.$_FILES["banner_img"]["name"];
				
				$config['file_name']   = $banner_logo_image;
				$config['upload_path'] = './uploads/reseller_banner';
				$config['allowed_types'] = 'gif|jpg|png';
				//$config['max_size']    = '1024';
				//$config['max_width']  = '1024';
				//$config['max_height']  = '768';
				$this->load->library('upload', $config);
				
				if ( ! $this->upload->do_upload('banner_img')){
				   $this->session->set_flashdata('global_msg',strip_tags($this->upload->display_errors()));
				   redirect('tycoon/manageBanner');
				}
			}else{
				$banner_logo_image = $this->data['reseller']->banner_image;
			}
			
			$qryData = array(
				'banner_image' => $banner_logo_image,
				'banner_link' => $this->input->post('banner_link')
			);
			
			$result = $this->my_model->updateTable('system_reseller_code', $qryData, $this->data['user']->id);
			if(!empty($result)){
				$this->session->set_flashdata('global_msg', 'Banner has been updated successfully!! ');
			}
			
		    redirect('tycoon/manageBanner');
			
		}
		
		$this->data['window_title'] = $this->app_name;
		$this->data['pagetitle'] =  'Manage Banner';
	
		if(!empty($this->data['reseller'])){
			$this->load->view('tycoon/manage_banner',$this->data);
		}else{
			redirect('tycoon/dashboard');
		}
	}
	
	function business() {
        $this->verifyUser();

        $this->data['window_title']="Business";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Business';
		
		$reseller = $this->my_model->getARecord('system_reseller_code', $this->data['user']->id);
		if( !is_object($reseller)) { return false; }

        $where = "id != '0' AND reseller_reference_no='".$reseller->reference_no ."'";

        $this->data['business'] = $this->my_model->getWhereRecords('system_business_code', $where);
        $this->data['total_business'] = count($this->data['business']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	
	function editBusiness($id)
    {
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {   
        

                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'reference_no' => $this->input->post('reference_no'),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                    'status'=>$this->input->post('status')
                );

                if( $this->my_model->updateTable('system_business_code', $qryData, $id) )
                {
                    $this->session->set_flashdata('global_msg', 'Business update successfully!!');
                }
				redirect('tycoon/business');
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Business Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['business'] = $this->my_model->getARecord('system_business_code', $id);
        if( !is_object($this->data['business'])) { return false; }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function deleteBusiness($id)
    {
        $this->verifyUser();
        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/business'); }
        if( $this->my_model->deleteARecord('system_business_code', $id) )
        {
            $this->session->set_flashdata('global_msg', 'Business has been deleted successfully!!');
        }
        redirect('tycoon/business');
    }
	
	function addBusiness()
    {
        $this->verifyUser();
		$reseller = $this->my_model->getARecord('system_reseller_code', $this->data['user']->id);
		if( !is_object($reseller)) { return false; }
		
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_business_code.email]');
			$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_business_code.username]');
            $this->form_validation->set_rules('reference_no', 'Reference Number', 'trim|required|xss_clean|is_unique[system_business_code.reference_no]');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim|required|xss_clean');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
				//echo "<pre>";print_r($_POST);die;

                
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'reference_no' => $this->input->post('reference_no'),
					'reseller_reference_no'=>$reseller->reference_no,
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                    'status'=>$this->input->post('status'),
                );

				
                if( $this->my_model->insertDataIntoTable('system_business_code', $qryData) )
                {
                    $this->session->set_flashdata('global_msg', 'Business added successfully!!');
                }
				redirect('tycoon/business');
            }
        }
		
		$where = "id != '0'" ;
		$get_last_business_code = $this->my_model->getWhereLastRecords('system_business_code', $where);
		if(!empty($get_last_business_code)){
			$businessNo = substr($get_last_business_code->reference_no, 1)+1;
			$this->data['auto_business_code'] = 'B'.$businessNo;
		}else{
			$this->data['auto_business_code'] = 'B101';
		}

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Business Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	
	function addBusinessCoins(){ 
		//echo "<pre>";print_r($_REQUEST);die; 
		$this->verifyUser();
		if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }	
		
		
		$user_id = $loggedUser['id'];
		$where = "id = '$user_id' ";
		$getData = $this->my_model->getWhereOneRecords('system_reseller_code', $where);
		
		//echo "<pre>";print_r($getData);die;
		
		if($getData->coins <= 0){
			$response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
			echo json_encode ($response) ;
			die;
		}
		
		if($getData->coins < $_REQUEST['coins']){
			$response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
			$this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
			echo json_encode ($response) ;
			die;
		}
		
		$business_id = $_REQUEST['business_id'];
		$description = $_REQUEST['description'];
		$where = "id = '$business_id' ";
		$studentData = $this->my_model->getWhereOneRecords('system_business_code', $where);
		$business_name = $studentData->username;
		
		$reseller_coins = $getData->coins - $_REQUEST['coins'];
		$qryData = array(
			'coins' => $reseller_coins,
		);
		if($this->my_model->updateTable('system_reseller_code', $qryData, $user_id)){
			$business_coin_data = array('user_id'=>$user_id,
				'user_type'=>'reseller',
				'description'=>"$description Transfer to student $business_name",
				'debit_coin'=>$_REQUEST['coins'],
				'balance_coin'=>$business_coins,
				'created_date'=>date('Y-m-d H:i:s'),
				'updated_at'=>date('Y-m-d H:i:s'),
			);
			$this->my_model->insertDataIntoTable('system_coins_management_code', $business_coin_data);
		}
		
		//echo "<pre>";print_r($getData);die;
	
		$business_coins = $studentData->coins+$_REQUEST['coins'];
		$qryData = array(
			'coins' => $business_coins,
		);

		if( $this->my_model->updateTable('system_business_code', $qryData, $business_id) )
		{
			$this->session->set_flashdata('global_msg', 'Coins has been added successfully!!');
			$response = array(
                'result' => 'success',
                'message' => 'Coins Added successfully'
            );
			$reseller_name = $getData->username;
			$coin_data = array('user_id'=>$business_id,
				'user_type'=>'business',
				'description'=>"By reseller $reseller_name $description",
				'credit_coin'=>$_REQUEST['coins'],
				'balance_coin'=>$business_coins,
				'created_date'=>date('Y-m-d H:i:s'),
				'updated_at'=>date('Y-m-d H:i:s'),
			);
			$this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
			
		}else{
			$response = array(
                'result' => 'error',
                'message' => 'Please try again'
            );
			$this->session->set_flashdata('global_msg', 'Please try again.');
		}
		echo json_encode($response);die;
	}
}