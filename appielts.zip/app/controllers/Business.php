<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Member controller
* this controller is related to specific user role
*/
class Business extends AKAAL_Controller {

    public function __construct() {
        parent::__construct();
 
        $this->data['currentAccount'] = 'logger_member';
        $this->data['currentPath'] = 'business';
        
        // table name of specific user role; which is related to this controller only
        $this->tb_name = 'system_business_code';
    }

    function index() {

        $this->login();
    }

    function login() {
        // check website session, if enabled
        if( $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $this->load->model('my_model');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_isValidUser');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }

        $this->data['title'] = '<a href="'.base_url('/'.$this->data['currentPath'].'/login').'">Member Login</a>';

        //$this->data['custom_url'] = 'http://ielts24x7.com/NEW';
        //$this->data['custom_url'] = 'http://ielts24x7.com';
        $this->data['custom_url'] = 'https://ielts24x7.com';

        $window_title = 'Student Login - ' . $this->app_name;

        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );
        $this->data['pagetitle'] = 'Business Login';

        $this->data['formAction'] = $this->uri->segment(1). '/' . $this->uri->segment(2);
        $this->load->view('shared/login', $this->data);
    }

    function isValidUser($password) {
        //Field validation succeeded.  Validate against database
        $username = $this->input->post('username');
        $result = $this->my_model->getUser($this->tb_name, $username, $password);

        if($result)
        {
            $session_array = array();
            foreach($result as $row)
            {
                $session_array = array(
                    'id' => $row->id,
                    'name' => $row->name,
                );

                if($row->status == '0'){

                    $this->form_validation->set_message('isValidUser', 'Account Blocked !');
                    return false;

                }else{

                    $this->session->set_userdata($this->data['currentAccount'], $session_array);
                }
            }
            return true;
        }
        else
        {
            $this->form_validation->set_message('isValidUser', 'Invalid username or password');
            return false;
        }
    }

    function logout() {
        // Make sure you destory website session as well.
        $this->session->unset_userdata($this->data['currentAccount']);
        $this->session->sess_destroy();
        // Finally redirect page to desire location
        redirect('business');
    }

    function verifyUser() {

        // check login
        $this->logged = is_user_logged_in(
            $this->data['currentAccount'],
            $this->data['currentPath']
        );

        $this->data['user'] = $this->my_model->getARecord($this->tb_name, $this->logged['id']);
        $this->data['role'] = $this->my_model->getARecord($this->tb_role, $this->data['user']->role_id);

        // checks for valid user get or not
        if( !is_object($this->data['user'])) { return false; }

        $this->data['country'] = $this->my_model->getARecord($this->tb_countries, $this->data['user']->country_id);
    }
	
	 function member() {
        $this->verifyUser();

		if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }	
		
		$user_id = $loggedUser['id'];
		$where = "id = '$user_id' ";
		$getData = $this->my_model->getWhereOneRecords('system_business_code', $where);//Get Reference Number
		
        $this->data['window_title']="Students";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];

        $this->data['pagetitle'] = 'Students';
		//echo "<pre>";print_r($getData);die;
		
		if($getData->reference_no!=''){
			$reference_no = $getData->reference_no;
			$where = "id != '0' AND business_reference_no='$reference_no'";
			$this->data['members'] = $this->my_model->getWhereRecords('system_member_code', $where);
		}else{
			$this->data['members'] = array();
		}
		
        $this->data['total_members'] = count($this->data['members']);
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function deleteMember($id)
    {
        $this->verifyUser();
        if (!is_numeric($id)){ redirect($this->data['currentPath'].'/member'); }
        if( $this->my_model->deleteARecord('system_member_code', $id) )
        {
            redirect($this->data['currentPath'].'/member?trash=1');
        }
        redirect($this->data['currentPath'].'/member');
    }
	
	function addCoins(){
		$this->verifyUser();
		if(! $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }	
		
		$user_id = $loggedUser['id'];
		$where = "id = '$user_id' ";
		$getData = $this->my_model->getWhereOneRecords('system_business_code', $where);
		
		if($getData->coins <= 0){
			$response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
			echo json_encode ($response) ;
			die;
		}
		
		if($getData->coins < $_POST['coins']){
			$response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
			$this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
			echo json_encode ($response) ;
			die;
		}
		
		
		$business_coins = $getData->coins - $_POST['coins'];
		$qryData = array(
			'coins' => $business_coins,
		);

		if( $this->my_model->updateTable('system_business_code', $qryData, $user_id) )
		{
			$description = $_POST['description'];
			$student_id = $_POST['student_id'];
			
			$stuwhere = "id = '$student_id' ";
			$studentData = $this->my_model->getWhereOneRecords('system_member_code', $stuwhere);
			$student_name = $studentData->username;
			
			$business_coin_data = array('user_id'=>$user_id,
				'user_type'=>'business',
				'description'=>"$description Transfer to student $student_name",
				'debit_coin'=>$_POST['coins'],
				'balance_coin'=>$business_coins,
				'created_date'=>date('Y-m-d H:i:s'),
				'updated_at'=>date('Y-m-d H:i:s'),
			);
			$this->my_model->insertDataIntoTable('system_coins_management_code', $business_coin_data);
			
			/* $student_id = $_POST['student_id'];
			$stuwhere = "id = '$student_id' ";
			$studentData = $this->my_model->getWhereOneRecords('system_member_code', $stuwhere); */
		
			$student_coins = $studentData->coins+$_POST['coins'];
			$qryData1 = array(
				'coins' => $student_coins,
			);
			
			$this->my_model->updateTable('system_member_code', $qryData1, $student_id);
			
			$business_name = $getData->username;
			$student_coin_data = array('user_id'=>$student_id,
				'user_type'=>'member',
				'description'=>"$description Transfer by business $business_name",
				'credit_coin'=>$_POST['coins'],
				'balance_coin'=>$student_coins,
				'created_date'=>date('Y-m-d H:i:s'),
				'updated_at'=>date('Y-m-d H:i:s'),
			);
			$this->my_model->insertDataIntoTable('system_coins_management_code', $student_coin_data);
			
			$this->session->set_flashdata('global_msg', 'Coins has been added successfully!!');
			$response = array(
                'result' => 'success',
                'message' => 'Coins Added successfully'
            );
		}else{
			$response = array(
                'result' => 'error',
                'message' => 'Please try again'
            );
			$this->session->set_flashdata('global_msg', 'Please try again.');
		}
		echo json_encode($response);die;
		
	}
	
	function editMember($id)
    {
        $this->verifyUser();
        if ( ! is_numeric($id)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_users_code.email]');
            //$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_users_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('username', 'Username', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {    

                $qryData = array(
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('username'),
                    'password' => md5($this->input->post('password')),
                    'md5Email' => md5($this->input->post('email')),
                    'name' => $this->input->post('name'),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'created_time' => time(),
                    'status'=>$this->input->post('status')
                );

                if( $this->my_model->updateTable('system_member_code', $qryData, $id) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Update Student Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];



        $this->data['member'] = $this->my_model->getARecord('system_member_code', $id);
        if( !is_object($this->data['member'])) { return false; }
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function addMember()
    {
        $this->verifyUser();
		
		$business = $this->my_model->getARecord('system_business_code', $this->data['user']->id);
		if( !is_object($business)) { return false; }

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {    
			//echo "<pre>";print_r($_POST);die;
			$this->form_validation->set_rules('email', 'E-mail', 'trim|required|xss_clean|valid_email|is_unique[system_member_code.email]');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|is_unique[system_member_code.username]');
            $this->form_validation->set_rules('name', 'Name', 'trim');
            //$this->form_validation->set_rules('username', 'Username', 'trim');
            //$this->form_validation->set_rules('email', 'Email', 'trim','required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $where = "id != '0' AND student_code!='0'" ;
				$get_last_stu_code = $this->my_model->getWhereLastRecords('system_member_code', $where);
				if(!empty($get_last_stu_code)){
					$student_code = $get_last_stu_code->student_code+1;
				}else{
					$student_code = '101';
				}
				
				$qryData = array(
                    'name' => $this->input->post('name'),
					'student_code'=>$get_last_stu_code->student_code+1,
                    'username' => $this->input->post('username'),
                    'email' => $this->input->post('email'),
                    'md5Email' => md5($this->input->post('email')),
                    'password' => md5($this->input->post('password')),
                    'notMD5password' => $this->input->post('password'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                    'reference_no' => $business->reseller_reference_no,
                    'business_reference_no' => $business->reference_no,
					'coins'=>200,
                    'created_time' => time(),
                    'status'=>$this->input->post('status')
                );

				if( $this->my_model->insertDataIntoTable('system_member_code', $qryData))
                {
					$last_added_id = $this->db->insert_id();
					
					$coin_data = array('user_id'=>$last_added_id,
						'user_type'=>'member',
						'description'=>'by Coupon Redemption',
						'credit_coin'=>'200',
						'balance_coin'=>'200',
						'created_date'=>date('Y-m-d H:i:s'),
						'updated_at'=>date('Y-m-d H:i:s'),
					);

					$this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
					
					$this->session->set_flashdata('global_msg', 'Student has been added successfully');
					redirect($this->data['currentPath'].'/member');
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Add Student Information';
        $this->data['window_title'] = $this->app_name."    -> ".$this->data['pagetitle'];

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function account() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Profile';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	public function password() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $this->form_validation->set_rules('old', 'Current password', 'trim|required|xss_clean|min_length[3]|max_length[30]');
            $this->form_validation->set_rules('new', 'New password', 'trim|required|xss_clean|min_length[6]|max_length[30]');
            $this->form_validation->set_rules('confirm', 'Confirm password', 'trim|required|xss_clean|min_length[6]|max_length[30]|callback_checkPassword');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger">','</div>' );
            if($this->form_validation->run() == TRUE) {
                $this->data['success'] = true;
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Change Password';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function checkPassword() {

        $newPassword = $this->input->post('new');
        $confirmPassword = $this->input->post('confirm');

        if($newPassword == $confirmPassword) {
            
            if(strlen($newPassword) > 5  && strlen($confirmPassword) > 5  ){
                $result = $this->my_model->changePassword($confirmPassword, $this->data['user']->id, $this->tb_name);
                if(!$result) {

                    $this->form_validation->set_message('checkPassword', 'Please enter correct current Password.');
                    return false;
                }
            }
            
        
        } else {
            $this->form_validation->set_message('checkPassword', 'The New password field does not match the Confirm password field.');
            return false;
        }
        return true;
    }

    function dashboard() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dashboard';
		
		$this->data['business'] = $this->my_model->getARecord('system_business_code', $this->data['user']->id);
		if( !is_object($this->data['business'])) { return false; }
		
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function promotionCode(){
        $this->verifyUser();

        $this->data['business'] = $this->my_model->checkARecord('system_business_code', 'id', $this->data['user']->id);
        if( !is_object($this->data['business'])) {
            exit($this->unauthorized_message);
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Promotion Code';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
	
	function manageBanner(){
		$this->verifyUser();
		
		$check_business = $this->my_model->checkARecord('system_business_code', 'id', $this->data['user']->id);
        if( !is_object($check_business)) {
            exit($this->unauthorized_message);
        }
		
		$this->data['business'] = $check_business;
		
		if ($_SERVER["REQUEST_METHOD"] == "POST")
        {		
			//echo "<pre>";print_r($_POST);echo "</pre>";
			//echo "<pre>";print_r($_FILES);echo "</pre>";die;
			
			if(!empty($_FILES["banner_img"]["name"])){
				$banner_logo_image = strtotime(date("Y-m-d h:i:s A")).'_'.$_FILES["banner_img"]["name"];
				
				$config['file_name']   = $banner_logo_image;
				$config['upload_path'] = './uploads/business_banner';
				$config['allowed_types'] = 'gif|jpg|png';
				//$config['max_size']    = '1024';
				//$config['max_width']  = '1024';
				//$config['max_height']  = '768';
				$this->load->library('upload', $config);
				
				if ( ! $this->upload->do_upload('banner_img')){
				   $this->session->set_flashdata('global_msg',strip_tags($this->upload->display_errors()));
				   redirect('business/manageBanner');
				}
			}else{
				$banner_logo_image = $this->data['business']->banner_image;
			}
			
			$qryData = array(
				'banner_image' => $banner_logo_image,
				'banner_link' => $this->input->post('banner_link')
			);
			
			$result = $this->my_model->updateTable('system_business_code', $qryData, $this->data['user']->id);
			if(!empty($result)){
				$this->session->set_flashdata('global_msg', 'Banner has been updated successfully!! ');
			}
			
		    redirect('business/manageBanner');
			
		}
		
		$this->data['window_title'] = $this->app_name;
		$this->data['pagetitle'] =  'Manage Banner';
	
		if(!empty($this->data['business'])){
			$this->load->view('business/manage_banner',$this->data);
		}else{
			redirect('business/dashboard');
		}
	}
	  function viewReadReport(){
                    $testid=$_REQUEST['testid'];
             $testcode=$_REQUEST['testcode'];
             $member_id=$_REQUEST['memberid'];
             $where="test_id = '$testid' AND member_id = '$member_id' AND test_code = '$testcode' ";
        $this->data['testdetail'] = $this->Webservice_model->getWhereLastRecords('system_testdetails_code', $where);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->Webservice_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);
        $this->data['test_type_id'] = $check_test->PTEtypeid;

  //      echo $this->data['test_type_id'];
//print_r($this->data['testdetail'] );
//print_r($check_test);die;
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

     
        $this->data['attempt'] = $this->Webservice_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
       // print_r($this->data['attempt']);die;
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $attempt_data = json_decode($this->data['attempt']->json_result, true);
    //    echo "<pre>"; print_r($this->data['attempt_data']);
    
    
    if(!is_object($attempt_data)){
        $response=array( "status" => "1",
                "message" => $attempt_data,);
    }else{
        $response=array( "status" => "0",);
    }
        echo json_encode ($response) ;
    

            }
}