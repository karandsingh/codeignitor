<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Member controller
* this controller is related to specific user role
*/
class Audiotest extends AKAAL_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Webservice_model'); 
		$this->data['rn'] = random_string('nozero',8);
		$this->load->library('email');     		
	}

    public function index()
	{
	 $this->load->view('audio_test');
	}

}