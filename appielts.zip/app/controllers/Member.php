<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Member controller
* this controller is related to specific user role
*/
class Member extends AKAAL_Controller {

    public function __construct() {
        parent::__construct();
 
        $this->data['currentAccount'] = 'logger_member';
        $this->data['currentPath'] = 'member';


        $this->config->load('akaal');
        $this->data['number_of_visible_questions'] = $this->config->item('number_of_visible_questions');
        
        // table name of specific user role; which is related to this controller only
        $this->tb_name = $this->tb_member;
        $this->data['rn'] = random_string('nozero',8);
    }

    function index() {
                   // Submit form
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            
            //echo $this->app_email .' '. $this->app_name;die;

            $this->form_validation->set_rules('email', 'Email Address', 'trim|required|max_length[80]|valid_email|is_unique['.$this->tb_member.'.email]');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|max_length[50]|is_unique['.$this->tb_member.'.username]|alpha_numeric');
            $this->form_validation->set_rules('g-recaptcha-response', 'recaptcha', 'trim|required|xss_clean|callback_checkRecaptcha');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE) {
                
                $student_reference_no = '';
                $tycoon_reference_no = '';
                $business_reference_no = '';
                $affiliate_reference_no = '';

                $get_referred_coins = 0;
                $get_coins = '200';
                $description = 'Register and get free Coins';
                
                $where = 'id != 0';
                $get_last_stu_code = $this->my_model->getWhereLastRecords('system_member_code', $where);
                
                $reference_no = $this->input->post('reference_no');
        
                if(!empty($reference_no)){
                    $firstCharacter = substr($reference_no, 0, 1);
                         //echo $firstCharacter.","; exit();
                        if($firstCharacter == 'T'){
                            $check_reseller = $this->my_model->checkARecord('system_reseller_code', 'reference_no',$reference_no );
                            if(!empty($check_reseller)){
                                $tycoon_reference_no = $check_reseller->reference_no;
                                $get_coins = '200';
                                $description = 'By Tycoon reference Register';
                            }
                              
                        }

                        elseif($firstCharacter == 'B'){
                            //echo $business_reference_no.","; echo $tycoon_reference_no; exit();

                            $check_business = $this->my_model->checkARecord('system_business_code', 'reference_no',$reference_no );
                            if(!empty($check_business)){
                                $business_reference_no = $check_business->reference_no;
                                $tycoon_reference_no = $check_business->reseller_reference_no;
                                $get_coins = '200';
                                $description = 'By Business reference Register';
                                //echo $check_business->reseller_reference_no; exit();
                            }

                            

                        }   elseif($firstCharacter == 'A'){
                            //echo $business_reference_no.","; echo $tycoon_reference_no; exit();

                            $check_business = $this->input->post('reference_no');
                            if(!empty($check_business)){
                                $affiliate_reference_no = $check_business;
                                $get_coins = '290';
                                $description = 'By Affiliate reference Register';
                                //echo $check_business->reseller_reference_no; exit();
                            }

                            

                        } 

                    else{
                        $check_student_ref = $this->my_model->checkARecord('system_member_code', 'student_code',$reference_no);
                        if(!empty($check_student_ref)){
                            $student_reference_no = $check_student_ref->student_code;
                            $tycoon_reference_no = $check_student_ref->reference_no;
                            $get_referred_coins = 1;
                            $get_coins = '300';
                            /* $get_coins = '100';
                            $description = 'By Student reference Register';
                            
                            $earned_coin = $check_student_ref->coins + 100;
                            $stu_earn_coin_data = array(
                                'user_id'=>$check_student_ref->id,
                                'user_type'=>'member',
                                'description'=>'New Student Referral',
                                'credit_coin'=>'100',
                                'balance_coin'=>$earned_coin,
                                'created_date'=>date('Y-m-d H:i:s'),
                                'updated_at'=>date('Y-m-d H:i:s'),
                            );
                            $this->my_model->insertDataIntoTable('system_coins_management_code', $stu_earn_coin_data);
                            
                            $earn_qryData = array(
                                'coins' => $earned_coin
                            );
                            $this->my_model->updateTable('system_member_code', $earn_qryData, $check_student_ref->id); */
                        }
                    }
                }
                
                $urlkey = url_title($this->input->post('name'), '-', true);
                $password = random_string('alnum', 8);
                
                $ip = $_SERVER['REMOTE_ADDR'];
                $country_id = '';
                $city = '';
                $dataArray = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
                if(!empty($dataArray)){
                    
                    $city = $dataArray->geoplugin_city;
                    $country_name = $dataArray->geoplugin_countryName;
                    $where = "name = '$country_name'";
                    $country_data = $this->my_model->getWhereOneRecords($this->tb_countries,$where);
                    if(!empty($country_data)){
                        $country_id = $country_data->id;
                    }
                }

                // Default : confirm = yes , role_id = 2 (member)
                $qryData = array(
                    'student_code'=>$get_last_stu_code->student_code+1,
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('username'),
                    'password' => md5($password),
                    'notMD5password' => $password,
                    'confirm' => 'yes', // we are going to Active new user , bcoz we are sending password by email.
                    'md5Email' => md5($this->input->post('email')),
                    'created_time' => time(),
                    'reference_no' => $tycoon_reference_no,
                    'student_reference_no' => $student_reference_no,
                    'affiliate_reference_no' => $affiliate_reference_no,
                    'business_reference_no' => $business_reference_no ,
                    'get_referred_coins' => $get_referred_coins ,
                    'coins'=>$get_coins,
                    'country_id'=>$country_id,
                    'city_region'=>$city,
                    'ip_address'=>$_SERVER['REMOTE_ADDR']
                );

                if( $this->my_model->insertDataIntoTable($this->tb_member, $qryData) ) {
                    $this->data['success'] = true;
                    $last_added_id = $this->db->insert_id();
                    
                    $coin_data = array('user_id'=>$last_added_id,
                        'user_type'=>'member',
                        'description'=>$description,
                        'credit_coin'=>$get_coins,
                        'balance_coin'=>$get_coins,
                        'created_date'=>date('Y-m-d H:i:s'),
                        'updated_at'=>date('Y-m-d H:i:s'),
                    );
               $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
               
               
               if(!empty($affiliate_reference_no)){
                     $affiliatedata = array(
                    'student_code'=>$last_added_id,
                    'email' => $this->input->post('email'),
                    'username' => $this->input->post('username'),
                    'password' => md5($password),
                    'notMD5password' => $password,
                    'confirm' => 'yes', // we are going to Active new user , bcoz we are sending password by email.
                    'md5Email' => md5($this->input->post('email')),
                    'created_time' => time(),

                    'affiliate_reference_no' => $affiliate_reference_no,
                    'coins'=>$get_coins,
                    'country_id'=>$country_id,
                    'city_region'=>$city,
                    'ip_address'=>$_SERVER['REMOTE_ADDR']
                );
                $this->my_model->insertDataIntoTable('system_affiliate_code', $affiliatedata);
               
               }
                    
                    $url_key = $urlkey.'-'.$last_added_id;
                    // added other information related to member
                    $memberDetail = array(
                        'id' => $last_added_id, // same as member ID
                        'created_time' => time(),
                        'urlkey' => $url_key,
                    );
                    $this->my_model->insertDataIntoTable($this->tb_member_extras, $memberDetail);
                    
                    /* Send account detail email */
                        $this->load->library('email');
                        $config = array (
                            'mailtype' => 'html',
                            'charset'  => 'utf-8',
                            'wordwrap' => TRUE,
                            'priority' => '1'
                        );
                        $this->email->initialize($config);
                        $this->email->from($this->app_email, $this->app_name);
                        $this->email->to($this->input->post('email'));
                        #$this->email->cc($this->app_contactemail); // send copy at website contact email address
                        $this->email->subject('Welcome to '.$this->app_name);


                        // send text email
                        $this->email->message('<html><body>
                        <h4>Thanks for signing up!</h4>

                        Your account has been created, you can login with the following credentials to
                        manage your account.<br> After login you can access CELPIP material on our website.
                        <br><br>

                        Login URL : '.base_url('/login').'<br>
                        Username : '.$this->input->post('username').'<br>
                        Password : '.$password.'<br><br>
                        

                        <b>Note : </b>if you think this email has reached your inbox by mistake, <a href="'.base_url('contact?Eaddress='.$this->input->post('email').'&reporttoken='.$this->data['rn']).'">please report </a><br>

                        Best Wishes,<br>
                        '.$this->app_name.' Team<br>
                        </html></body>');
                        
                        //echo '<pre>'; print_r($data); echo '</pre>';
                        $this->email->send();
                        //echo $this->email->print_debugger();
                    // @end email

                    //$this->data['success'] = true;
                    /*$this->session->set_flashdata('global_msg', 'Account has been created successfully!! ');
                    redirect('');*/
                    redirect($this->data['currentPath'].'/registrationsuccess?successtoken='.random_string('nozero',12));
                }
          
        }    
            
        } 
        $this->load->view(web.'/home',$this->data);        
    }

    function contact(){
        //echo $this->app_contactemail;die;
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            
            //echo $this->app_email .' '. $this->app_name;die;

            $this->form_validation->set_rules('name', 'Name', 'trim|required|max_length[50]|xss_clean');

            $this->form_validation->set_rules('email', 'Email Address', 'trim|required|max_length[80]|valid_email');

            $this->form_validation->set_rules('subject', 'Subject', 'trim|required|xss_clean');
            $this->form_validation->set_rules('message', 'Message', 'trim|required|xss_clean');
            
            $this->form_validation->set_rules('g-recaptcha-response', 'recaptcha', 'trim|required|xss_clean|callback_checkRecaptcha');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE) {
                    
            /* Send account detail email */
                $this->load->library('email');
                $config = array (
                    'mailtype' => 'html',
                    'charset'  => 'utf-8',
                    'wordwrap' => TRUE,
                    'priority' => '1'
                );
                $this->email->initialize($config);
                $this->email->from($this->input->post('email'));
                //$this->email->to('puneetgarg964@gmail.com');
                $this->email->to($this->app_contactemail);
                #$this->email->cc($this->app_contactemail); // send copy at website contact email address
                $this->email->subject($this->input->post('subject'));


                // send text email
                //$this->email->message($this->input->post('message'));
                
                
                $this->email->message('<html><body>
                        <h4>Contact us mail</h4>
                        
                        UserName : '.$this->input->post('name').'<br>
                        UserEmail : '.$this->input->post('email').'<br>
                        Message : '.$this->input->post('message').'<br><br>
                        

                        Best Wishes,<br>
                        '.$this->app_name .' Team<br>
                        </html></body>');
                
                //echo '<pre>'; print_r($data); echo '</pre>';
                $this->email->send();
                
                $this->session->set_flashdata('global_msg', 'Your mail has been successfully sent !');
                redirect($this->data['currentPath'].'/contact');
                }
            }

       
        $this->load->view('web/contact',$this->data, $this->data);  
              
    }


    function registrationsuccess(){
        if($_GET['successtoken']){
            $this->load->view($this->data['currentPath'].'/registrationsuccess', $this->data);
        }
    }
    
    
    function applogin() {
        // check website session, if enabled
        if( $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            if($loggedUser['user_role']=='member'){
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $this->load->model('my_model');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_isValidUser');
            $_POST['login_from'] = 'app';
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }

        $this->data['title'] = '<a href="'.base_url('/'.$this->data['currentPath'].'/login').'">Member Login</a>';

        //$this->data['custom_url'] = 'http://ielts24x7.com/NEW';
        //$this->data['custom_url'] = 'http://ielts24x7.com';
        $this->data['custom_url'] = 'https://ielts24x7.com';

        $window_title = 'Student Login - ' . $this->app_name;

        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );
        $this->data['pagetitle'] = 'Student Login';

        $this->data['formAction'] = $this->uri->segment(1). '/' . $this->uri->segment(2);
        $this->load->view('shared/login', $this->data);
    }

    function login() {
        // check website session, if enabled
        if( $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            if($loggedUser['user_role']=='member'){
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            //echo "<pre>";print_r($_POST);die;
        
            $this->load->model('my_model');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_isValidUser');
            $this->form_validation->set_rules('g-recaptcha-response', 'recaptcha', 'trim|required|xss_clean|callback_checkRecaptcha');
            $_POST['login_from'] = 'web';
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }
        
        $this->data['formAction'] = $this->uri->segment(1). '/' . $this->uri->segment(2);
        $this->load->view('web/login', $this->data);
    }
    
    /*
    * Check Google Recaptcha
    */
    function checkRecaptcha($recaptcha_response) {

        if($this->verifyRecaptcha($recaptcha_response)) {
            return true;
        } else {
            $this->form_validation->set_message(__FUNCTION__, 'The reCaptcha verification was not verified, please try again.');
            return false;
        }
    }

    function isValidUser($password) {
        //Field validation succeeded.  Validate against database
        $username = $this->input->post('username');
        $login_from = $this->input->post('login_from');
        $result = $this->my_model->getUser($this->tb_name, $username, $password);
        if($result)
        {
            //echo "<pre>";print_r($result);die;
            $session_array = array();
            foreach($result as $row)
            {
                if($row->status==0){
                    $this->session->set_flashdata('global_msg', 'Your account has been blocked please contact support team !');
                    redirect($this->data['currentPath'].'/login');
                }
                
                $session_array = array(
                    'id' => $row->id,
                    'name' => $row->name,
                    'user_role'=>'member'
                );
                
                $getudata = $this->my_model->getARecord($this->tb_name, $row->id);
                //echo "<pre>";print_r($getudata);die;
                
                
                if($getudata->get_referred_coins==1 && $getudata->student_reference_no != 0){
                    
                    $where = "student_code = '". $getudata->student_reference_no ."'";
                    $stu_data = $this->my_model->getWhereOneRecords('system_member_code',$where);
                    if(!empty($stu_data)){
                        //echo "<pre>hhiii";print_r($stu_data);die;
                        $get_coin = '100';
                        if($stu_data->country_id==99){
                            $get_coin = '150';
                        }else if($stu_data->country_id==4){
                            $get_coin = '500';
                        }else if($stu_data->country_id==38){
                            $get_coin = '400';
                        }else{
                            $get_coin = '300';
                        }
                        
                        $description = 'By Student reference Register';
                        $earned_coin = $stu_data->coins + $get_coin;
                        $stu_earn_coin_data = array(
                            'user_id'=>$stu_data->id,
                            'user_type'=>'member',
                            'description'=>'New Student Referral',
                            'credit_coin'=>$get_coin,
                            'balance_coin'=>$earned_coin,
                            'created_date'=>date('Y-m-d H:i:s'),
                            'updated_at'=>date('Y-m-d H:i:s'),
                        );
                        $this->my_model->insertDataIntoTable('system_coins_management_code', $stu_earn_coin_data);
                        
                        $earn_qryData = array(
                            'coins' => $earned_coin
                        );
                        $this->my_model->updateTable('system_member_code', $earn_qryData, $stu_data->id);
                        
                        $qryData = array(
                            'get_referred_coins' => '0'
                        );
                        $this->my_model->updateTable('system_member_code', $qryData, $row->id);
                        
                    }
                    
                    //$check_student_ref = $this->my_model->checkARecord('system_member_code', 'student_code',$getudata->student_reference_no);
                    
                    //echo "<pre>hhiii";print_r($check_student_ref);die;
                    //if(!empty($check_student_ref)){
                        //$get_coins = '100';
                        /* $description = 'By Student reference Register';
                        $earned_coin = $check_student_ref->coins + 500;
                        $stu_earn_coin_data = array(
                            'user_id'=>$check_student_ref->id,
                            'user_type'=>'member',
                            'description'=>'New Student Referral',
                            'credit_coin'=>'500',
                            'balance_coin'=>$earned_coin,
                            'created_date'=>date('Y-m-d H:i:s'),
                            'updated_at'=>date('Y-m-d H:i:s'),
                        );
                        $this->my_model->insertDataIntoTable('system_coins_management_code', $stu_earn_coin_data);
                        
                        $earn_qryData = array(
                            'coins' => $earned_coin
                        );
                        $this->my_model->updateTable('system_member_code', $earn_qryData, $check_student_ref->id);
                        
                        $qryData = array(
                            'get_referred_coins' => '0'
                        );
                        $this->my_model->updateTable('system_member_code', $qryData, $row->id); */
                    //}
                }
                
                $updateData = array(
                    'login_from' => $login_from,
                );
                $this->my_model->updateTable('system_member_code', $updateData, $row->id);
                
                $this->session->set_userdata($this->data['currentAccount'], $session_array);
            }
            return true;
        }
        else
        {
            $this->form_validation->set_message('isValidUser', 'Invalid username or password');
            return false;
        }
    }

    function logout() {
        if( $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            $this->verifyUser();
            $user = $this->my_model->getARecord($this->tb_name, $this->data['user']->id);
            
            // Make sure you destory website session as well.
            $this->session->unset_userdata($this->data['currentAccount']);
            $this->session->sess_destroy();
            // Finally redirect page to desire location
            if($user->login_from=='web'){
                redirect();
            }else{
                redirect($this->data['currentPath'].'/applogin');
            }
        }else{
            redirect($this->data['currentPath']);
        }
    }

    function verifyUser() {
        //echo "<pre>";print_r($this->data['currentAccount']);die;
        // check login
        $this->logged = is_user_logged_in(
            $this->data['currentAccount'],
            $this->data['currentPath']
        );

        $this->data['user'] = $this->my_model->getARecord($this->tb_name, $this->logged['id']);
        $this->data['role'] = $this->my_model->getARecord($this->tb_role, $this->data['user']->role_id);

        // checks for valid user get or not
        if( !is_object($this->data['user'])) { return false; }

        $this->data['country'] = $this->my_model->getARecord($this->tb_countries, $this->data['user']->country_id);
    }
    

    function account() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Profile';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function vocabulary() {
        $this->verifyUser();

        # Show all vocabulary tests
        $where = "active = 'Yes' ";
        $this->data['levels'] = $this->my_model->getWhereOrderRecords($this->tb_vlevel, $where, 'id', 'asc');
        $this->data['total'] = count($this->data['levels']);


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Vocabulary Tests';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function dictation() {
        $this->verifyUser();

        # Show all dictation tests
        $where = "active = 'Yes' ";
        $this->data['levels'] = $this->my_model->getWhereOrderRecords('system_dictation_level_code', $where, 'id', 'asc');
        $this->data['total'] = count($this->data['levels']);


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dictation Tests';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function dictationTestdetails($level_id, $level_id_md5) {
        $this->verifyUser();

        $this->data['test'] = $this->my_model->getARecord('system_dictation_level_code', $level_id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($level_id);
        if($getId != $level_id_md5) {
            exit($this->unauthorized_message);
        }


        // Get all questions in test
        $where = "level_id = '".$level_id."' ";
        $allQuestions = $this->my_model->getWhereOrderRecords('system_dictation_question_code', $where, 'id', 'asc');
        $this->data['total_questions'] = count($allQuestions);

        // History, in desc order
        $where = "level_id = '".$level_id."' AND member_id = '".$this->data['user']->id."' ";
        $this->data['history'] = $this->my_model->getWhereOrderRecords('system_dictation_testdetails_code', $where, 'id', 'desc');

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $this->data['test']->name;
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    /*
    * Start a new dictation test
    */
    function startDictationtest() {

        $testid = $this->input->post('testid');
        $memberid = $this->input->post('memberid');
        $objTest = $this->my_model->getARecord('system_dictation_level_code', $testid);
        
        $objMember = $this->my_model->getARecord('system_member_code', $memberid);      
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < $objTest->coin_cost)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }

        if( is_object($objTest)) {

            $qryData = array(
                'level_id' => $testid,
                'member_id' => $memberid,
                'time' => time(),
            );

            if( $this->my_model->insertDataIntoTable('system_dictation_testdetails_code', $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_dictation_testdetails_code', $updateData, $last_added_id);
                
                $balance_coins = $objMember->coins - $objTest->coin_cost;
                $updateMemCoins = array('coins'=>$balance_coins);
                $this->my_model->updateTable('system_member_code', $updateMemCoins, $memberid);
                
                $coin_data = array('user_id'=>$memberid,
                    'user_type'=>'member',
                    'description'=>"Cost Dictation ".$objTest->name."",
                    'debit_coin'=>$objTest->coin_cost,
                    'balance_coin'=>$balance_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                
                // Add entry here
                $response = array(
                    'result' => 'success',
                    'message' => 'Test Started',
                    'tdcode' => $id_md5, // vocabulary test details code
                    'tcode' => md5($objTest->id) // level/test code
                );

            }else{
                $response = array(
                    'result' => 'error',
                    'message' => $this->ajaxerror_message
                );
            }

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        echo json_encode ($response) ;
    }
    
    /*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function dictationTestprogress($tdId_md5, $testId_md5, $page='1') {
        $this->verifyUser();

        $this->data['testdetail'] = $this->my_model->checkARecord('system_dictation_testdetails_code', 'id_md5', $tdId_md5);
        
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($this->data['testdetail']->level_id);
        if($getId != $testId_md5) {
            exit($this->unauthorized_message);
        }
        // $this->data['testdetail']->level_id;

        $this->data['test'] = $this->my_model->checkARecord('system_dictation_level_code', 'id', $this->data['testdetail']->level_id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }


        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                'level_id' => $this->data['test']->id,
                ///'type' => 'Objective',
            );
            $this->sortby = 'id'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, 'system_dictation_question_code' );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 10;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination
        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, 'system_dictation_question_code' );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        $this->data['reporturl'] = current_url();
//echo "<pre>";print_r($this->data['allQuestions']);die;

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $this->data['test']->test_name;
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function dictation_uploadjson() {

        $myresponse = $this->input->post('myresponse');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $questionid = $this->input->post('questionid');

        $result = array('myresponse' => $myresponse);
        $json_result = json_encode($result);

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'testid' => $testid,
            'questionid' => $questionid,
            'memberid' => $memberId,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable('system_dictation_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function vtestdetails($level_id, $level_id_md5) {
        $this->verifyUser();

        $this->data['test'] = $this->my_model->getARecord($this->tb_vlevel, $level_id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($level_id);
        if($getId != $level_id_md5) {
            exit($this->unauthorized_message);
        }


        // Get all questions in test
        $where = "level_id = '".$level_id."' ";
        $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_vquestion, $where, 'id', 'asc');
        $this->data['total_questions'] = count($allQuestions);

        // History, in desc order
        $where = "level_id = '".$level_id."' AND member_id = '".$this->data['user']->id."' ";
        $this->data['history'] = $this->my_model->getWhereOrderRecords($this->tb_vtestdetails, $where, 'id', 'desc');

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $this->data['test']->name;
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    /*
    * Start a new vocabulary test
    */
    function startnewvtest() {

        $testid = $this->input->post('testid');
        $memberid = $this->input->post('memberid');
        $objTest = $this->my_model->getARecord($this->tb_vlevel, $testid);
        
        $objMember = $this->my_model->getARecord('system_member_code', $memberid);
        $meber_coins = $objMember->coins;
        $test_cost = $objTest->coin_cost;
        
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < $objTest->coin_cost)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }

        if( is_object($objTest)) {

            $qryData = array(
                'level_id' => $testid,
                'member_id' => $memberid,
                'time' => time(),
            );

            if( $this->my_model->insertDataIntoTable($this->tb_vtestdetails, $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable($this->tb_vtestdetails, $updateData, $last_added_id);
                    
                $balance_coins = $objMember->coins - $objTest->coin_cost;
                $updateMemCoins = array('coins'=>$balance_coins);
                $this->my_model->updateTable('system_member_code', $updateMemCoins, $memberid);
                
                $coin_data = array('user_id'=>$memberid,
                    'user_type'=>'member',
                    'description'=>"Cost vocabulary ".$objTest->name."",
                    'debit_coin'=>$objTest->coin_cost,
                    'balance_coin'=>$balance_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                
                // Add entry here
                $response = array(
                    'result' => 'success',
                    'message' => 'Test Started',
                    'tdcode' => $id_md5, // vocabulary test details code
                    'tcode' => md5($objTest->id) // level/test code
                );

            }else{
                $response = array(
                    'result' => 'error',
                    'message' => $this->ajaxerror_message
                );
            }

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        //echo "<pre>";print_r($response);die;
        echo json_encode ($response) ;
    }

    /*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function vtestprogress($tdId_md5, $testId_md5, $page='1') {
        $this->verifyUser();

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_vtestdetails, 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($this->data['testdetail']->level_id);
        if($getId != $testId_md5) {
            exit($this->unauthorized_message);
        }
        // $this->data['testdetail']->level_id;

        $this->data['test'] = $this->my_model->checkARecord($this->tb_vlevel, 'id', $this->data['testdetail']->level_id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }


        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                'level_id' => $this->data['test']->id,
                'type' => 'Objective',
            );
            $this->sortby = 'id'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, $this->tb_vquestion );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 10;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination

        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, $this->tb_vquestion );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        $this->data['reporturl'] = current_url();


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $this->data['test']->test_name;
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function vuploadjson() {

        $myresponse = $this->input->post('myresponse');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $questionid = $this->input->post('questionid');

        $result = array('myresponse' => $myresponse);
        $json_result = json_encode($result);

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'testid' => $testid,
            'questionid' => $questionid,
            'memberid' => $memberId,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_vattempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    function sampleQuestion($typeid = '') {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Sample Questions';
        $this->data['test_id'] = '7';

        $this->data['test'] = $this->my_model->getARecord($this->tb_test, '7');

        if( in_array($typeid, array('1','2','3','4','5','6')) ) {

           if($typeid==1){
                $this->data['pagetitle'] = 'Listening Questions';
            }elseif($typeid==2){
                $this->data['pagetitle'] = 'Academic Reading Questions';
            }elseif($typeid==3){
                $this->data['pagetitle'] = 'General Reading Questions';
            }elseif($typeid==4){
                $this->data['pagetitle'] = 'Academic Writing Questions';
            }elseif($typeid==5){
                $this->data['pagetitle'] = 'General Writing Questions';
            }elseif($typeid==6){
                $this->data['pagetitle'] = 'Speaking Questions';
            }

            // Speaking
            $where = "PTEtypeid = '1' ";
            $this->data['listening'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'ASC');

            // Writing
            $where = "PTEtypeid = '4' ";
            $this->data['academicwriting'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'ASC');

            // Reading
            $where = "PTEtypeid = '2' ";
            $this->data['academicreading'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'ASC');

            // Listening
            $where = "PTEtypeid = '3' AND active = 'Yes' ";
            $this->data['generalreading'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'ASC');
            
            // Listening
            $where = "PTEtypeid = '5' AND active = 'Yes' ";
            $this->data['generalwriting'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'ASC');
            
            $where = "PTEtypeid = '6' AND active = 'Yes' ";
            $this->data['speaking'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'ASC');
        
        } else {

            exit($this->unauthorized_message);
        }

        $this->data['typeid'] = $typeid;

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function sampleQResult($id, $test_id_md5) {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // questions
        $where = "testid = '".$this->data['test']->id."' AND status = 'Active' AND PTEsubtypeid = '".$this->data['subtype']->id."' ";
        $this->data['allQuestions'] = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');


        /**********************************************
        * DONE - attempted question by logged students
        ***********************************************/

        $where = "subtypeid = '".$this->data['subtype']->id."' AND memberid = '".$this->data['user']->id."' ";
        $this->data['attemptedQuestions'] = $this->my_model->getWhereOrderRecords($this->tb_attempt, $where, 'id', 'asc');


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'sample Questions';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function startTest($id, $test_id_md5) {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // questions
        $where = "testid = '".$this->data['test']->id."' AND status = 'Active' AND PTEsubtypeid = '".$this->data['subtype']->id."' ";
        $this->data['allQuestions'] = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'sample Questions';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function sampleTest($id, $test_id_md5, $page='1') {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                'testid' => $this->data['test']->id,
                'status' => 'Active',
                'PTEsubtypeid' => $this->data['subtype']->id,
            );
            $this->sortby = 'id'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, $this->tb_question );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 5;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = ' Previous';

            $this->pagination->initialize($config);
            // end pagination

        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, $this->tb_question );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        $this->data['reporturl'] = base_url('member/sampleQResult/'.$id.'/'.$test_id_md5);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Sample Test';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function uploadrecording() {

        $audiosrc = $this->input->post('audiosrc');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $subtypeid = $this->input->post('subtypeid');
        $questionid = $this->input->post('questionid');

        // upload mp3 - DONE
        $time = time();
        $fname = md5($time).'-'.md5($memberId).'.record';
        print_r($audiosrc);die;


        write_file('./uploads/attempt/'.$fname, $audiosrc);
        

        $qryData = array(
            'time' => $time,
            'testid' => $testid,
            'questionid' => $questionid,
            'subtypeid' => $subtypeid,
            'memberid' => $memberId,
            'fname' => $fname
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Recording has been successfully uploaded.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    function uploadattempt() {

        $fname = $this->input->post('fname');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $subtypeid = $this->input->post('subtypeid');
        $questionid = $this->input->post('questionid');

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'testid' => $testid,
            'questionid' => $questionid,
            'subtypeid' => $subtypeid,
            'memberid' => $memberId,
            'fname' => $fname,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Recording has been successfully uploaded.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    function uploadjson() {

        $myresponse = $this->input->post('myresponse');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $subtypeid = $this->input->post('subtypeid');
        $questionid = $this->input->post('questionid');

        $result = array('myresponse' => $myresponse);
        $json_result = json_encode($result);

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'testid' => $testid,
            'questionid' => $questionid,
            'subtypeid' => $subtypeid,
            'memberid' => $memberId,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    

      function response($id_md5) {
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;



        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $id_md5);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }


        //print_r($this->data['testdetail'] );

        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);

        $this->data['test_type_id'] = $check_test->PTEtypeid;

       // echo $this->data['test_type_id'];

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }



        $this->data['attempt'] = $this->my_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }



        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $this->data['attempt']->subtypeid);

        $this->data['type'] = $this->my_model->getARecord($this->tb_type, $this->data['subtype']->PTEtypeid);

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);

        $myTable = $this->tb_prefix.$this->data['subtype']->tbname.$this->tb_suffix;

        $this->data['qExtra'] = $this->my_model->checkARecord($myTable, 'test_code', $this->data['attempt']->questionid);
        if( !is_object($this->data['qExtra'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['qExtra']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Your Response';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    /*function response($id, $id_md5) {
        $this->verifyUser();

        $this->data['attempt'] = $this->my_model->getARecord($this->tb_attempt, $id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($id);
        if($getId != $id_md5) {
            exit($this->unauthorized_message);
        }

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $this->data['attempt']->subtypeid);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id', $this->data['attempt']->testid);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }

        $this->data['type'] = $this->my_model->getARecord($this->tb_type, $this->data['subtype']->PTEtypeid);


        $this->data['question'] = $this->my_model->checkARecord($this->tb_question, 'id', $this->data['attempt']->questionid);
        if( !is_object($this->data['question'])) {
            exit($this->unauthorized_message);
        }

        $myTable = $this->tb_prefix.$this->data['subtype']->tbname.$this->tb_suffix;

        $this->data['qExtra'] = $this->my_model->checkARecord($myTable, 'questionid', $this->data['attempt']->questionid);
        if( !is_object($this->data['qExtra'])) {
            exit($this->unauthorized_message);
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Your Response';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }*/

    function tests() {
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Tests';

        // Get all tests without - Sample Test = 7
        $where = "id != '7' ";
        $this->data['tests'] = $this->my_model->getWhereOrderRecords($this->tb_test, $where, 'id', 'ASC');

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function testdetails($id, $id_md5) {
        $this->verifyUser();

        $this->data['test'] = $this->my_model->getARecord($this->tb_test, $id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($id);
        if($getId != $id_md5) {
            exit($this->unauthorized_message);
        }

        // Should not be (Sample Test) = 7
        if($id == 7) {
            exit($this->unauthorized_message);
        }


        // Get all questions in test
        $where = "testid = '".$id."' ";
        $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');
        $this->data['total_questions'] = count($allQuestions);


        // history
        $where = "test_id = '".$id."' AND member_id = '".$this->data['user']->id."' ";
        $this->data['history'] = $this->my_model->getWhereOrderRecords($this->tb_testdetails, $where, 'id', 'asc');


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Test Details';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    /*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function testprogress($tdId_md5, $testId_md5, $page='1') {
        $this->verifyUser();

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $testId_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }



        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                'testid' => $this->data['test']->id,
                'status' => 'Active',
                //'PTEsubtypeid' => $this->data['subtype']->id,
            );
            $this->sortby = 'PTEsubtypeid'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, $this->tb_question );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 10;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination

        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, $this->tb_question );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        //$this->data['reporturl'] = base_url('member/sampleQResult/tests');
        $this->data['reporturl'] = current_url();




        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $this->data['test']->test_name;
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    /*
    * Start a new test
    */
    function startnewtest() {

        $testid = $this->input->post('testid');
        $memberid = $this->input->post('memberid');
        $objTest = $this->my_model->getARecord($this->tb_test, $testid);
        
        if( is_object($objTest)) {

            $qryData = array(
                'test_id' => $testid,
                'member_id' => $memberid,
                'time' => time(),
            );

            if( $this->my_model->insertDataIntoTable($this->tb_testdetails, $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable($this->tb_testdetails, $updateData, $last_added_id);

            }

            // Add entry here
            $response = array(
                'result' => 'success',
                'message' => 'Test Started',
                'tdcode' => $id_md5, // test details code
                'tcode' => $objTest->id_md5 // test code
            );

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        echo json_encode ($response) ;
    }


    function ticket($id) {
        $this->verifyUser();


        $this->data['support'] = $this->my_model->getARecord($this->tb_support, $id);

        $where = "support_id =".$id;

        $this->data['tickets'] = $this->my_model->getWhereOrderRecords($this->tb_ticket, $where ,'id','ASC');
        $this->data['total_tickets'] = count($this->data['tickets']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Ticket';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function support() {
        $this->verifyUser();



        $where = "member_id =".$this->logged['id'];

        $this->data['supports'] = $this->my_model->getWhereRecords($this->tb_support, $where);
        $this->data['total_support'] = count($this->data['supports']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Support';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }  



    function closeTicket($id)
    {
        $this->verifyUser();

                $qryData = array(
                    'status' => "resoloved",
                );

                if( $this->my_model->updateTable($this->tb_support, $qryData, $id) )
                {
                redirect($this->data['currentPath'].'/support?close=1');
                }
       

    }
  
    function replyTicket($id)
    {
        $this->verifyUser();

                $qryData = array(
                    'support_id' => $id,
                    'member_id' => $this->logged['id'],
                    'details' => $this->input->post('details'),
                    'time' => time(),
                );

                if( $this->my_model->insertDataIntoTable($this->tb_ticket, $qryData) )
                {
                   
                redirect($this->data['currentPath'].'/ticket/'.$id);
                }
       

    }

  

    function addTicket() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {

            $this->form_validation->set_rules('title', 'Title', 'trim');
            $this->form_validation->set_rules('type', 'Type', 'trim');
            $this->form_validation->set_rules('details', 'details', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'title' => $this->input->post('title'),
                    'type' => $this->input->post('type'),
                    'details' => $this->input->post('details'),
                    'member_id' => $this->logged['id'],
                    'time' => time(),
                );

                if( $this->my_model->insertDataIntoTable($this->tb_support, $qryData) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Support';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    public function password() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $this->form_validation->set_rules('old', 'Current password', 'trim|required|xss_clean|min_length[3]|max_length[30]');
            $this->form_validation->set_rules('new', 'New password', 'trim|required|xss_clean|min_length[6]|max_length[30]');
            $this->form_validation->set_rules('confirm', 'Confirm password', 'trim|required|xss_clean|min_length[6]|max_length[30]|callback_checkPassword');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger">','</div>' );
            if($this->form_validation->run() == TRUE) {
                $this->data['success'] = true;
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Change Password';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function checkPassword() {

        $newPassword = $this->input->post('new');
        $confirmPassword = $this->input->post('confirm');

        if($newPassword == $confirmPassword) {

            $result = $this->my_model->changePassword($confirmPassword, $this->data['user']->id, $this->tb_name);
            if(!$result) {

                $this->form_validation->set_message('checkPassword', 'Please enter correct Current Password.');
                return false;
            }
        
        } else {
            $this->form_validation->set_message('checkPassword', 'The New password field does not match the Confirm password field.');
            return false;
        }
        return true;
    }

    function dashboard() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dashboard';
        
        $objMember = $this->my_model->getARecord('system_member_code', $this->data['user']->id);
        
        $check_reseller = $this->my_model->checkARecord('system_reseller_code', 'reference_no', $objMember->reference_no);
        if (!empty( $check_reseller)){
        $this->data['school_banner'] = $check_reseller->banner_image;
        $this->data['school_banner_link'] = $check_reseller->banner_link;
        }
        $this->data['first_banner'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'first_banner');
        $this->data['second_banner'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'second_banner');
        $this->data['first_banner_link'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'first_banner_link');
        $this->data['second_banner_link'] = $this->my_model->checkARecord('system_superadmin_meta', 'meta_key', 'second_banner_link');
        
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function ComingSoon() {
        $this->verifyUser();

        $this->data['window_title']="Select Question Type";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];
        $this->data['pagetitle'] = 'Question';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function sectionViseTest(){
        $this->verifyUser();
        
        $this->data['window_title']="Select section Vise Test";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];
        $this->data['pagetitle'] = 'Section Vise Test';
        
        $where = "id != 0 ";
        $this->data['PTEtypes'] = $this->my_model->getWhereOrderRecords($this->tb_type, $where, 'id', 'asc');
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
        //echo "<pre>";print_r($allQuestions);die;
    }
    
    
    function practiceTask($id){
        $this->verifyUser();
        
        
        
        
        /* $this->data['window_title']="Select section Vise Test";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];
        $this->data['pagetitle'] = 'Section Vise Test';
        
        $where = "id != 0 ";
        $this->data['PTEtypes'] = $this->my_model->getWhereOrderRecords($this->tb_type, $where, 'id', 'asc'); */
        
        
        $this->data['test'] = $this->my_model->getARecord('system_listening_MCsingle_code', $id);
        if(!empty($this->data['test'])){
            $this->load->view('member/practice_task_play',$this->data);
        }else{
            redirect('member/getTestList');
        }
    }
    
    
    /*
    * Start a new test
    */
    function accessnewtest() {
        
        $testid = $this->input->post('testid');
        $memberid = $this->input->post('memberid');
        $testcode = $this->input->post('testcode');
        $objTest = $this->my_model->getARecord('system_PTEsubtype_code', $testid);
        
        $objMember = $this->my_model->getARecord('system_member_code', $memberid);
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < $objTest->coin_cost)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }
        
        if( is_object($objTest)) {

            $qryData = array(
                'test_id' => $testid,
                'test_code'=> $testcode,
                'member_id' => $memberid,
                'time' => time(),
                'created_at'=> date('Y-m-d H:i:s')
            );

            if( $this->my_model->insertDataIntoTable($this->tb_testdetails, $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable($this->tb_testdetails, $updateData, $last_added_id);
                
                //CHARGE COIN COST
                $objMember = $this->my_model->getARecord('system_member_code', $memberid);  
                $balance_coins = $objMember->coins - $objTest->coin_cost;
                $updateMemCoins = array('coins'=>$balance_coins);
                $this->my_model->updateTable('system_member_code', $updateMemCoins, $memberid);
                
                $coin_data = array('user_id'=>$memberid,
                    'user_type'=>'member',
                    'description'=>"Cost test ".$objTest->PTEsubtype ." (".$testcode.")",
                    'debit_coin'=>$objTest->coin_cost,
                    'balance_coin'=>$balance_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                
                // Add entry here
                $response = array(
                    'result' => 'success',
                    'message' => 'Test Started',
                    'tdcode' => $id_md5, // test details code
                    //'tcode' => $objTest->id_md5 // test code
                );
                
            }

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        echo json_encode ($response) ;
    }
    
    function accessnewtimertest() {
        
        $testid = $this->input->post('testid');
        $memberid = $this->input->post('memberid');
        $testcode = $this->input->post('testcode');
        $objTest = $this->my_model->getARecord('system_PTEsubtype_code', $testid);
        
        $objMember = $this->my_model->getARecord('system_member_code', $memberid);
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < $objTest->coin_cost)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }
        
        if( is_object($objTest)) {

            $qryData = array(
                'test_id' => $testid,
                'test_code'=> $testcode,
                'member_id' => $memberid,
                'time' => time(),
                'created_at'=> date('Y-m-d H:i:s')
            );

            if( $this->my_model->insertDataIntoTable($this->tb_testdetails, $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable($this->tb_testdetails, $updateData, $last_added_id);
                
                //CHARGE COIN COST
                $objMember = $this->my_model->getARecord('system_member_code', $memberid);  
                $balance_coins = $objMember->coins - $objTest->coin_cost;
                $updateMemCoins = array('coins'=>$balance_coins);
                $this->my_model->updateTable('system_member_code', $updateMemCoins, $memberid);
                
                $coin_data = array('user_id'=>$memberid,
                    'user_type'=>'member',
                    'description'=>"Cost test ".$objTest->PTEsubtype ." (".$testcode.")",
                    'debit_coin'=>$objTest->coin_cost,
                    'balance_coin'=>$balance_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                
                // Add entry here
                $response = array(
                    'result' => 'success',
                    'message' => 'Test Started',
                    'tdcode' => $id_md5, // test details code
                    //'tcode' => $objTest->id_md5 // test code
                );
                
            }

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        echo json_encode ($response) ;
    }

    
    function rdPart1Submit(){
        $this->verifyUser();
        //echo "<pre>";print_r($_REQUEST);die;
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part2_MCOA_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = 'q1_option'.$getTestdetail->q1_answer;
        $q2_right_option = 'q2_option'.$getTestdetail->q2_answer;
        $q3_right_option = 'q3_option'.$getTestdetail->q3_answer;
        $q4_right_option = 'q4_option'.$getTestdetail->q4_answer;
      
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
      
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 1: Multiple choice question with one answer','response_data'=>array(
        array('q_number'=>'Academic Reading Part 1: Multiple choice question with one answer - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $getTestdetail->$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Multiple choice question with one answer - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $getTestdetail->$q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Multiple choice question with one answer - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $getTestdetail->$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Multiple choice question with one answer - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $getTestdetail->$q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$getTestdetail->$q4_right_option),
        
     
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    function wtPart1Submit(){
        $this->verifyUser();
        //echo "<pre>";print_r($_REQUEST);die;
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part4_SAWPA_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Writing Part 1:','response_data'=>array(
        array('q_number'=>'Academic Writing Part 1: - Q1','q_response_type'=>'text','q_response_email_content' => $_REQUEST['q1_response']),
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '4',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function wtPart2Submit(){
        $this->verifyUser();
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part4_SAWPB_code','test_code',$testdetail->test_code);
        

        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Writing Part 2:','response_data'=>array(
        array('q_number'=>'Academic Writing Part 2:  - Q1','q_response_type'=>'text','q_response_email_content' => $_REQUEST['q1_response']),
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '4',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
     function gwPart1Submit(){
        $this->verifyUser();
        //echo "<pre>";print_r($_REQUEST);die;
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part5_SGWPA_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Writing Part 1:','response_data'=>array(
        array('q_number'=>'General Writing Part 1: - Q1','q_response_type'=>'text','q_response_email_content' => $_REQUEST['q1_response']),
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '5',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    function gwPart2Submit(){
        $this->verifyUser();
        //echo "<pre>";print_r($_REQUEST);die;
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part5_SGWPB_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Writing Part 2:','response_data'=>array(
        array('q_number'=>'General Writing Part 2: - Q1','q_response_type'=>'text','q_response_email_content' => $_REQUEST['q1_response']),
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '5',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
      function grPart1Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part3_MI_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;
        $q6_right_option = $getTestdetail->q6_answer;
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];
        $q6_response_val = $_REQUEST['q6_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 1: Matching Information Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q6','q_response_type'=>'text','q_response' => $_REQUEST['q6_response'],'q_response_val' => $q6_response_val,'q_right_option'=>$q6_right_option,'q_right_option_val'=>$q6_right_option),
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
     function grPart2Submit(){
    $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part3_TFN_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;
        $q6_right_option = $getTestdetail->q6_answer;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];
        $q6_response_val = $_REQUEST['q6_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 2: True/False/Not Given Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q6','q_response_type'=>'text','q_response' => $_REQUEST['q6_response'],'q_response_val' => $q6_response_val,'q_right_option'=>$q6_right_option,'q_right_option_val'=>$q6_right_option),
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function grPart3Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part3_NC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;

        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];

        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Reading Part 3: Note Completion Answer Key','response_data'=>array(
        array('q_number'=>'General Reading Part 3: Note Completion  - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'General Reading Part 3: Note Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'General Reading Part 3: Note Completion - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'General Reading Part 3: Note Completion  - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'General Reading Part 3: Note Completion  - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
    
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
       function grPart4Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part3_SC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;

        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];

        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Reading Part 4: Summary Completion Answer Key','response_data'=>array(
        array('q_number'=>'General Reading Part 4: Summary Completion  - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'General Reading Part 4: Summary Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'General Reading Part 4: Summary Completion - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'General Reading Part 4: Summary Completion  - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
        function grPart5Submit(){
        $this->verifyUser();
        //echo "<pre>";print_r($_REQUEST);die;
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part3_MFC_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option ='q_option'.$getTestdetail->q1_answer;
        $q2_right_option ='q_option'.$getTestdetail->q2_answer;
        $q3_right_option ='q_option'.$getTestdetail->q3_answer;
        $q4_right_option ='q_option'.$getTestdetail->q4_answer;
      
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
      
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 5 : Matching Features','response_data'=>array(
        array('q_number'=>'Listening Part 5 : Matching Features - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' =>$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'General Reading Part 5 : Matching Features - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'Listening Part 5 : Matching Features - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
         array('q_number'=>'Listening Part 5 : Matching Features - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' =>$q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$getTestdetail->$q4_right_option),
        
     
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    


 function grPart6Submit(){
        $this->verifyUser(); 
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part3_MC_code','test_code',$testdetail->test_code);

        $q1_right_option ='q1_option'.$getTestdetail->q1_answer1;
        $q2_right_option ='q1_option'.$getTestdetail->q1_answer2;
     
        
        $right_option=array($getTestdetail->$q1_right_option,$getTestdetail->$q2_right_option);
        $q1_response_val = $_REQUEST['q1_response'];

       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Reading Part 6: Multiple Choice  Answer Key','response_data'=>array(
          array('q_number'=>'General Reading Part 6: Multiple Choice - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$right_option,'q_right_option_val'=>$right_option),
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    
    
      function grPart7Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part3_SMC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_words;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Reading Part 7: Summary Completion Answer Key','response_data'=>array(
        array('q_number'=>'General Reading Part 7: Summary Completion - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function rdPart4Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part2_NC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;
        $q6_right_option = $getTestdetail->q6_answer;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];
        $q6_response_val = $_REQUEST['q6_response'];
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 4: Note Completion Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q6','q_response_type'=>'text','q_response' => $_REQUEST['q6_response'],'q_response_val' => $q6_response_val,'q_right_option'=>$q6_right_option,'q_right_option_val'=>$q6_right_option),
        
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function rdPart5Submit(){
        $this->verifyUser(); 
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part2_MH_code','test_code',$testdetail->test_code);

        $q1_right_option =$getTestdetail->p1_answer;
        $q2_right_option =$getTestdetail->p2_answer;
        $q3_right_option =$getTestdetail->p3_answer;
        $q4_right_option =$getTestdetail->p4_answer;
        
        
        
        $q1_response = $_REQUEST['q1_response'];
        $q1_response_val=strip_tags($q1_response);
        
        $q2_response = $_REQUEST['q2_response'];
        $q2_response_val=strip_tags($q2_response);
        
        $q3_response = $_REQUEST['q3_response'];
        $q3_response_val=strip_tags($q3_response);
        
        $q4_response = $_REQUEST['q4_response'];
        $q4_response_val=strip_tags($q4_response);
      
       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 5: Matching Headings Answer Key','response_data'=>array(
          array('q_number'=>'Academic Reading Part 5: Matching Headings - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
           array('q_number'=>'Academic Reading Part 5: Matching Headings - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
            array('q_number'=>'Academic Reading Part 5: Matching Headings - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
             array('q_number'=>'Academic Reading Part 5: Matching Headings - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    
    
        function rdPart6Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part2_SC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_words;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 6: Summary Completion Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 6: Summary Completion - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    function rdPart7Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part2_SCA_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        
        $q1_response = $_REQUEST['q1_response'];
        $q1_response_val=strip_tags($q1_response);
        
        $q2_response = $_REQUEST['q2_response'];
        $q2_response_val=strip_tags($q2_response);
        
        $q3_response = $_REQUEST['q3_response'];
        $q3_response_val=strip_tags($q3_response);
        
        $q4_response = $_REQUEST['q4_response'];
        $q4_response_val=strip_tags($q4_response);
    
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 3: Matching Answer Key','response_data'=>array(
          array('q_number'=>'Academic Reading Part 7: Summary Completion  - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
           array('q_number'=>'Academic Reading Part 7: Summary Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
            array('q_number'=>'Academic Reading Part 7: Summary Completion  - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
             array('q_number'=>'Academic Reading Part 7: Summary Completion - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
             
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
       function rdPart8submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part2_FCC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;

        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 8: Flow-chart Completion Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 8: Flow-chart Completion  - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 8: Flow-chart Completion Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 8: Flow-chart Completion Completion  - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
   function rdPart9Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part2_SCB_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;

        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];

        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 9: Sentence Completion Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 9: Sentence Completion - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 9: Sentence Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 9: Sentence Completion  - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 9: Sentence Completion  - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'Academic Reading Part 9: Sentence Completion  - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
    
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
     function rdPart10Submit(){
        $this->verifyUser(); 
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part2_MSE_code','test_code',$testdetail->test_code);

        $q1_right_option =$getTestdetail->p1_answer;
        $q2_right_option =$getTestdetail->p2_answer;
        $q3_right_option =$getTestdetail->p3_answer;

        
        
        $q1_response = $_REQUEST['q1_response'];
        $q1_response_val=strip_tags($q1_response);
        
        $q2_response = $_REQUEST['q2_response'];
        $q2_response_val=strip_tags($q2_response);
        
        $q3_response = $_REQUEST['q3_response'];
        $q3_response_val=strip_tags($q3_response);
        
      
       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 10: Matching Sentence Endings Answer Key','response_data'=>array(
          array('q_number'=>'Academic Reading Part 10: Matching Sentence Endings - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
           array('q_number'=>'Academic Reading Part 10: Matching Sentence Endings - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
            array('q_number'=>'Academic Reading Part 10: Matching Sentence Endings - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    
    
    function rdPart3Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part2_II_code','test_code',$testdetail->test_code);
        //echo "<pre>";print_r($getTestdetail);die;
        
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Reading Part 3: Identifying Information (True/False/Not Given) Answer Key','response_data'=>array(
        array('q_number'=>'Reading Part 3: Identifying Information (True/False/Not Given) - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Reading Part 3: Identifying Information (True/False/Not Given) - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' =>$q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Reading Part 3: Identifying Information (True/False/Not Given) - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option)
        
       
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }
        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function rdPart2Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_part2_MCMTOA_code','test_code',$testdetail->test_code);
        
        $q1_right_option1 ='q1_option'.$getTestdetail->q1_answer1;
        $q1_right_option2 ='q1_option'.$getTestdetail->q1_answer2;
        
          $q2_right_option1 ='q1_option'.$getTestdetail->q2_answer1;
        $q2_right_option2 ='q1_option'.$getTestdetail->q2_answer2;
        
        
       $right_option1=array($getTestdetail->$q1_right_option1,$getTestdetail->$q1_right_option2);
       
       $right_option2=array($getTestdetail->$q2_right_option1,$getTestdetail->$q2_right_option2);

        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Reading Part 2:Multiple choice with more than one answer','response_data'=>array(
        array('q_number'=>'Reading Part 2:Multiple choice with more than one answer - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' =>$q1_response_val,'q_right_option'=>$right_option1,'q_right_option_val'=>$right_option1),
        
        array('q_number'=>'Reading Part 2:Multiple choice with more than one answer - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$right_option2,'q_right_option_val'=>$right_option2)
        
      
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }
        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function lsPart2Submit(){
        $this->verifyUser(); 
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part1_MCMTOA_code','test_code',$testdetail->test_code);

        $q1_right_option ='q1_option'.$getTestdetail->q1_answer1;
        $q2_right_option ='q1_option'.$getTestdetail->q1_answer2;
        $q3_right_option ='q1_option'.$getTestdetail->q1_answer3;
        
        $right_option=array($getTestdetail->$q1_right_option,$getTestdetail->$q2_right_option,$getTestdetail->$q3_right_option);
        $q1_response_val = $_REQUEST['q1_response'];

       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 2: Listening to Daily Life Conversation Answer Key','response_data'=>array(
          array('q_number'=>'Listening Part 2: Listening to Daily Life Conversation - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$right_option,'q_right_option_val'=>$right_option),
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    
     function lsPart3Submit(){
        $this->verifyUser(); 
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part1_MH_code','test_code',$testdetail->test_code);

        $q1_right_option =$getTestdetail->h1_answer;
        $q2_right_option =$getTestdetail->h2_answer;
        $q3_right_option =$getTestdetail->h3_answer;
        $q4_right_option =$getTestdetail->h4_answer;
        $q5_right_option =$getTestdetail->h5_answer;
        
        
        
        $q1_response = $_REQUEST['q1_response'];
        $q1_response_val=strip_tags($q1_response);
        
        $q2_response = $_REQUEST['q2_response'];
        $q2_response_val=strip_tags($q2_response);
        
        $q3_response = $_REQUEST['q3_response'];
        $q3_response_val=strip_tags($q3_response);
        
        $q4_response = $_REQUEST['q4_response'];
        $q4_response_val=strip_tags($q4_response);
        
        $q5_response = $_REQUEST['q5_response'];
        $q5_response_val=strip_tags($q5_response);

       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 3: Matching Answer Key','response_data'=>array(
          array('q_number'=>'Listening Part 3: Matching - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
           array('q_number'=>'Listening Part 3: Matching - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
            array('q_number'=>'Listening Part 3: Matching - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
             array('q_number'=>'Listening Part 3: Matching - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
              array('q_number'=>'Listening Part 3: Matching - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function lsPart6Submit(){
        $this->verifyUser();
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part1_FGOWA_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = $getTestdetail->answer1;
        $q2_right_option = $getTestdetail->answer2;
        $q3_right_option = $getTestdetail->answer3;
       
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 6: Fill in the gaps: short answers Answer Key','response_data'=>array(
        array('q_number'=>'Listening Part 6: Fill in the gaps: short answers - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Part 6: Fill in the gaps: short answers - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Listening Part 6: Fill in the gaps: short answers - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        
        
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function lsPart5Submit(){
        $this->verifyUser();
        //echo "<pre>";print_r($_REQUEST);die;
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part1_FIG_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = $getTestdetail->q1_words;
        $q2_right_option = $getTestdetail->q2_words;
        $q3_right_option = $getTestdetail->q3_words;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 5: Fill in the Gaps Answer Key','response_data'=>array(
        array('q_number'=>'Listening Part 5: Fill in the Gaps - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Listening Part 5: Fill in the Gaps - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' =>$q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Listening Part 5: Fill in the Gaps - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),

        
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function lsPart1Submit(){
        $this->verifyUser();
        //echo "<pre>";print_r($_REQUEST);die;
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part1_MCOA_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = 'q1_option'.$getTestdetail->q1_answer;
        $q2_right_option = 'q2_option'.$getTestdetail->q2_answer;
        $q3_right_option = 'q3_option'.$getTestdetail->q3_answer;
      
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
      
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 1: Multiple choice question with one answer','response_data'=>array(
        array('q_number'=>'Listening Part 1: Multiple choice question with one answer - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $getTestdetail->$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'Listening Part 1: Multiple choice question with one answer - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $getTestdetail->$q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'Listening Part 1: Multiple choice question with one answer - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $getTestdetail->$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
        
     
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
  
    function lsPart4Submit(){
        $this->verifyUser();
        //echo "<pre>";print_r($_REQUEST);die;
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part1_LOM_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = q1_answer;
        $q2_right_option = q2_answer;
        $q3_right_option = q3_answer;
      
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
      
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 4 : Labelling on a map','response_data'=>array(
        array('q_number'=>'Listening Part 4 : Labelling on a map - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' =>$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'Listening Part 4 : Labelling on a map - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'Listening Part 4 : Labelling on a map - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
        
     
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function gtPart1Submit(){
        $this->verifyUser();
        //echo "<pre>";print_r($_REQUEST);die;
        
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part3_MI_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = q1_answer;
        $q2_right_option = q2_answer;
        $q3_right_option = q3_answer;
        $q4_right_option = q4_answer;
        $q5_right_option = q5_answer;
        $q6_right_option = q6_answer;
      
      
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];
        $q6_response_val = $_REQUEST['q6_response'];
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Reading Part 1 : Matching Information','response_data'=>array(
        array('q_number'=>'General Reading Part 1 : Matching Information - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' =>$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'General Reading Part 1 : Matching Information - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'General Reading Part 1 : Matching Information - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
        array('q_number'=>'General Reading Part 1 : Matching Information - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' =>$q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$getTestdetail->$q4_right_option),
        
        array('q_number'=>'General Reading Part 1 : Matching Information - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$getTestdetail->$q5_right_option),
        
        array('q_number'=>'General Reading Part 1 : Matching Information - Q6','q_response_type'=>'text','q_response' => $_REQUEST['q6_response'],'q_response_val' =>$q6_response_val,'q_right_option'=>$q6_right_option,'q_right_option_val'=>$getTestdetail->$q6_right_option),
        
     
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function practiceTaskSubmit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_listening_MCsingle_code','test_code',$testdetail->test_code);

        $q1_right_option = 'option'.$getTestdetail->answer;
        $q1_mp3=$getTestdetail->mp3URL;
        $q1_response_val = $_REQUEST['q1_response'];
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening: Practice Task Details Answer Key','response_data'=>array(
        array('q_number'=>'Listening: Practice Task','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $getTestdetail->$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option,'qaudio'=>$q1_mp3)
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => $getTestdetail->PTEtypeid,
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function readingPracticeTaskSubmit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_reading1_40_code','test_code',$testdetail->test_code);

        $q1_right_option = 'option'.$getTestdetail->answer;
        $response_val = $_REQUEST['q1_response'];
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Reading: Practice Task Answer Key','response_data'=>array(
        array('q_number'=>'Practice Task','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $getTestdetail->$response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option)
        ));
        $json_result = json_encode($result);
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
        //echo "<pre>";print_r($qryData);die;
        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    
    
    function getTestList($id){
        
        $this->verifyUser();
        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $id);
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['coins'] = $this->my_model->getARecord("system_PTEsubtype_code",$id);

        $this->data['test_type_id'] = $this->data['coins']->PTEtypeid;
        //echo $this->data['test_type_id'];
        
        $this->data['member_id'] = $this->data['user']->id;
        $this->data['test_id'] = $id;
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $check_test->PTEsubtype;
        
        $this->data['gettest'] = array();
         if($id==16){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part1_FGOWA_code', $where, 'id', 'asc',$limit,$start);
        }
        if($id==15){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part1_FIG_code', $where, 'id', 'asc',$limit,$start);
        }
        if($id==14){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part1_LOM_code', $where, 'id', 'asc',$limit,$start);
        }
        if($id==13){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part1_MH_code', $where, 'id', 'asc',$limit ,$start);
        }
         if($id==12){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part1_MCMTOA_code', $where, 'id', 'asc',$limit ,$start);
        }
        if($id==11){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part1_MCOA_code', $where, 'id', 'asc',$limit ,$start);

            /*echo "<pre>";
            print_r($this->data['gettest']);*/
        }
        
      
     
        
        if($id==22){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_MCMTOA_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==23){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_II_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        
        if($id==24){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_NC_code', $where, 'id', 'asc',$limit ,$start);
        }
         if($id==25){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_MH_code', $where, 'id', 'asc',$limit,$start);
        } if($id==26){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_SC_code', $where, 'id', 'asc',$limit,$start);
        } if($id==27){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_SCA_code', $where, 'id', 'asc',$limit,$start);
        } if($id==28){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_FCC_code', $where, 'id', 'asc',$limit,$start);
        } if($id==29){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_SCB_code', $where, 'id', 'asc',$limit,$start);
        }
        if($id==30){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_MSE_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==52){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part5_SGWPB_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==51){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part5_SGWPA_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==21){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part2_MCOA_code', $where, 'id', 'asc',$limit ,$start);
        }
        
       

       
        if($id==41){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part4_SAWPA_code', $where, 'id', 'asc',$limit ,$start);
        }
        
         if($id==42){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part4_SAWPB_code', $where, 'id', 'asc',$limit ,$start);
        }
        
      
        if($id==31){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part3_MI_code', $where, 'id', 'asc',$limit ,$start);
        }
         if($id==32){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part3_TFN_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        
         if($id==33){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part3_NC_code', $where, 'id', 'asc',$limit,$start);
        }
         if($id==34){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part3_SC_code', $where, 'id', 'asc',$limit,$start);
        }
         if($id==35){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part3_MFC_code', $where, 'id', 'asc',$limit,$start);
        }
         if($id==36){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_no_test_code', $where, 'id', 'asc',$limit,$start);
        }
        
         if($id==37){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part3_SMC_code', $where, 'id', 'asc',$limit,$start);
        }
        
        if($id==61){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part6_TAPE_code', $where, 'id', 'asc',$limit ,$start);
        }if($id==62){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part6_II_code', $where, 'id', 'asc',$limit ,$start);
        }if($id==63){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part6_ILT_code', $where, 'id', 'asc',$limit ,$start);
        }
        if($id==64){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part6_D_code', $where, 'id', 'asc',$limit ,$start);
        }
        if($id==36){
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $where = "id != '0'";
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part3_MC_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        $this->load->view('member/getTests', $this->data);
    }


    /*function viewReport($id){
        $this->verifyUser();
        $check_testDetails = $this->my_model->checkARecord('system_testdetails_code', 'id_md5', $id);
        
        if( !is_object($check_testDetails)) {
            exit($this->unauthorized_message);
        }
        
        $this->data['attempt'] = $this->my_model->checkARecord('system_attempt_code', 'testdetail_id', $check_testDetails->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }
        
        $this->load->view('member/view_report', $this->data);
    }
*/
    // OLD REPORT BACKUP
    /*function viewReport($id){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $id);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);

        $this->data['test_type_id'] = $check_test->PTEtypeid;

       // echo $this->data['test_type_id'];

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->my_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;

        # check marks assigned or not 
        $where = "test_part_id = '".$this->data['testdetail']->test_id."' AND member_id = '".$this->logged['id']."' AND testdetail_idmd5 = '".$this->data['testdetail']->id_md5."' ";
        $this->data['marksAssigned'] = $this->my_model->getWhereRecords("system_marks_code",$where);
        
       /* echo "member_id=>".$this->data['testdetail']->member_id."<br>";  
        echo "teacher_id=>".$this->logged['id']."<br>"; 
        echo "md5_id=>".$this->data['testdetail']->id_md5."<br>"; 
        //print_r($this->data['marksAssigned'] );

        $this->data['teacher_name'] = $this->my_model->getARecord("system_teacher_code",$this->data['marksAssigned'][0]->teacher_id);

        //print_r($this->data['marksAssigned']);

        
        $this->load->view('member/view_report', $this->data);
    }*/


    function viewListenReport($id){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $id);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);

        $this->data['test_type_id'] = $check_test->PTEtypeid;

       // echo $this->data['test_type_id'];

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->my_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;

        # check marks assigned or not 
        $where = "test_part_id = '".$this->data['testdetail']->test_id."' AND member_id = '".$this->logged['id']."' AND testdetail_idmd5 = '".$this->data['testdetail']->id_md5."' ";
        $this->data['marksAssigned'] = $this->my_model->getWhereRecords("system_marks_code",$where);
        if(!empty($this->data['marksAssigned'][0]->teacher_id)){
        $this->data['teacher_name'] = $this->my_model->getARecord("system_teacher_code",$this->data['marksAssigned'][0]->teacher_id);
}
        //print_r($this->data['marksAssigned']);

        
        $this->load->view('member/view_listening_report', $this->data);
    }


    function viewReadReport($id){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $id);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);

        $this->data['test_type_id'] = $check_test->PTEtypeid;

       // echo $this->data['test_type_id'];

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->my_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;

        # check marks assigned or not 
        $where = "test_part_id = '".$this->data['testdetail']->test_id."' AND member_id = '".$this->logged['id']."' AND testdetail_idmd5 = '".$this->data['testdetail']->id_md5."' ";
        $this->data['marksAssigned'] = $this->my_model->getWhereRecords("system_marks_code",$where);
        

      if(!empty($this->data['marksAssigned'][0]->teacher_id)){
        $this->data['teacher_name'] = $this->my_model->getARecord("system_teacher_code",$this->data['marksAssigned'][0]->teacher_id);
}
        //print_r($this->data['marksAssigned']);

        
        $this->load->view('member/view_reading_report', $this->data);
    }


    function viewSpeakReport($id){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $id);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);

        $this->data['test_type_id'] = $check_test->PTEtypeid;

       // echo $this->data['test_type_id'];

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->my_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;

        # check marks assigned or not 
        $where = "test_part_id = '".$this->data['testdetail']->test_id."' AND member_id = '".$this->logged['id']."' AND testdetail_idmd5 = '".$this->data['testdetail']->id_md5."' ";
        $this->data['marksAssigned'] = $this->my_model->getWhereRecords("system_marks_code",$where);


        $this->data['teacher_name'] = $this->my_model->getARecord("system_teacher_code",$this->data['marksAssigned'][0]->teacher_id);

        //print_r($this->data['marksAssigned']);
        
        $this->load->view('member/view_speaking_report', $this->data);
    }


    function viewWriteReport($id){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $id);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);

        $this->data['test_type_id'] = $check_test->PTEtypeid;

       // echo $this->data['test_type_id'];

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->my_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;

        # check marks assigned or not 
        $where = "test_part_id = '".$this->data['testdetail']->test_id."' AND member_id = '".$this->logged['id']."' AND testdetail_idmd5 = '".$this->data['testdetail']->id_md5."' ";
        $this->data['marksAssigned'] = $this->my_model->getWhereRecords("system_marks_code",$where);


        $this->data['teacher_name'] = $this->my_model->getARecord("system_teacher_code",$this->data['marksAssigned'][0]->teacher_id);

        //print_r($this->data['marksAssigned']);

        
        $this->load->view('member/view_writing_report', $this->data);
    }



     function getfile($path,$image_path)
     {
     require 'aws-s3-bucket/vendor/autoload.php';

  
    $BUCKET_NAME = 'celpipstore-media-files';
    $IAM_KEY = 'AKIA323GRW63FBO3HGTM';
    $IAM_SECRET = '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';
    
    
    $this->load->library('S3'); //load S3 library

    //S3 connection 
    $s3 = new Aws\S3\S3Client(
    array(
    'credentials' => array(
    'key' => $IAM_KEY,
    'secret' => $IAM_SECRET
    ),
    'version' => 'latest',
    'region'  => 'us-west-2'
    )
    );
    $keyPath = $path.'/'.$image_path; // file name(can also include the folder name and the file name. eg."member1/IoT-Arduino-Monitor-circuit.png")
    //S3 connection 
    $fileName = $image_path;
    
    $command = $s3->getCommand('GetObject', array(
    'Bucket'      => $BUCKET_NAME,
    'Key'         => 'ielts/'.$keyPath,
    'ContentType' => 'image/png/mp3/mp4/audio/mpeg',
    'ResponseContentDisposition' => 'attachment; filename="'.$fileName.'"'
    ));
    $signedUrl = $s3->createPresignedRequest($command, "+6 days"); 
    // Create a signed URL from the command object that will last for
    // 6 days from the current time
    $presignedUrl = (string)$signedUrl->getUri();
   // echo file_get_contents($presignedUrl);
       $data['message']   = "sucess";
       $data['imageurl'] = $presignedUrl;
             return $data;

 }
    
    
    /*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function testnewprogress($tdId_md5) {
        $this->verifyUser();
        
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }
        
        
        
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        
        
        if(!empty($this->data['test']->l1_conversation_1_audio))
        {
             $audio_table=$this->data['test']->l1_conversation_1_audio;
             $foldername=$check_test->tbname;
            $fetch= $this->getfile($foldername,$audio_table);
            $this->data['audiourl']=$fetch['imageurl'];
            
        }
        
        
        if(!empty($this->data['test']->q1_image))
        {
             $image_table=$this->data['test']->q1_image;
             $foldername=$check_test->tbname;
            $fetch= $this->getfile($foldername,$image_table);
            $this->data['imageurl']=$fetch['imageurl'];
        }
        //echo "<pre>";print_r($this->data['test']);die;
        if(!empty($this->data['test'])){
            $this->load->view('member/practice_task_play',$this->data);

            /*$this->load->view('practice_task_play',$this->data);*/
        }else{
            redirect('member/getTestList');
        }
    }
    
    function timertestnewprogress($tdId_md5) {
        $this->verifyUser();
        
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;
        if(!empty($this->data['test'])){
            $this->load->view('member/timer_practice_task_play',$this->data);
        }else{
            redirect('member/getTimerTestList');
        }
    }



    function upload(){
     print_r($_FILES); //this will print out the received name, temp name, type, size, etc.

    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    /** Autoload the file with composer autoloader */

    require 'aws-s3-bucket/vendor/autoload.php';

    // Create an S3 client


    /** AWS S3 Bucket Name */
    $bucket_name = 'celpipstore-media-files';


    /** AWS S3 Bucket Access Key ID */
    $access_key_id    = 'AKIA323GRW63FBO3HGTM';


    /** AWS S3 Bucket Secret Access Key */
    $secret = 'qyrBf/My3tdUOzyECywRBH6oIm7cqL4qe/MUopVY';


     $size = $_FILES['audio_data']['size']; //the size in bytes

     $input = $_FILES['audio_data']['tmp_name']; //temporary name that PHP gave to the uploaded file

     $output = 'testupload/'.$_FILES['audio_data']['name'].".wav"; //letting the client control the filename is a rather bad idea

     move_uploaded_file($input, $output);
    }



    
    function upload_audio_on_s3(){
     print_r($_FILES); //this will print out the received name, temp name, type, size, etc.

    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    /** Autoload the file with composer autoloader */

    require 'aws-s3-bucket/vendor/autoload.php';

    // Create an S3 client


    /** AWS S3 Bucket Name */
    $bucket_name = 'celpipstore-media-files';


    /** AWS S3 Bucket Access Key ID */
    $access_key_id    = 'AKIA323GRW63FBO3HGTM';


    /** AWS S3 Bucket Secret Access Key */
    $secret = 'qyrBf/My3tdUOzyECywRBH6oIm7cqL4qe/MUopVY';


     $size = $_FILES['audio_data']['size']; //the size in bytes

     $input = $_FILES['audio_data']['tmp_name']; //temporary name that PHP gave to the uploaded file

     $output = 'testupload/'.$_FILES['audio_data']['name'].".wav"; //letting the client control the filename is a rather bad idea

     $upload_audio_server = move_uploaded_file($input, $output);

     if($upload_audio_server)
     {
        $client = new Aws\S3\S3Client([
        /** Region you had selected, if don't know check in S3 listing */
        'region'  => 'us-west-2',
        'version' => 'latest',
        /** Your AWS S3 Credential will be added here */
        'credentials' => [
        'key'    => $access_key_id,
        'secret' => $secret,
        ]
        ]);

        $uploaded_server_file_name = $_FILES['audio_data']['name'].".wav";


        $source = $_SERVER['DOCUMENT_ROOT'].'/testupload/'.$uploaded_server_file_name;

        // Where the files will be transferred to
        $dest = 's3://celpipstore-media-files/ielts/uploads';

        $result = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name,
        'SourceFile' => $source,
        ));

        if($result)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT'].'/testupload/'.$uploaded_server_file_name);
        }

     }
    }

    function s3_bucket_upload($temppath, $image_path)
    {
      require 'aws-s3-bucket/vendor/autoload.php';

        $bucket = "celpipstore-media-files";

        $folder = 'uploads';


        /*$pathToFile =
        APPPATH.'testupload/Desert-1.jpg';*/

        $pathToFile = 'home/app.ielts24x7.com/public_html/testupload/Desert-1.jpg';

        //$bucket = "com.homepie.staging.images";

       // print_r($image_path);die;









        $data = array();

        $data['message'] = "false";



        try {

            //staging homepie

            /* $s3Client = new Aws\S3\S3Client([

                'version'     => 'latest',

                'region'      => 'us-west-2',

                'credentials' => [

                    'key'    => 'AKIAQ5TUPBP67S6PCJ6U',

                    'secret' => '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',

                ],

            ]); */



            //celpip bucket

            $s3Client = new Aws\S3\S3Client([

                'version'     => 'latest',

                'region'      => 'us-west-2',

                'credentials' => [

                    'key'    => 'AKIA323GRW63FBO3HGTM',

                    'secret' => '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',

                ],

            ]);



            // For website only

            $result = $s3Client->putObject([

                'Bucket'     => $bucket,

                'Key'        => 'ielts/uploads/Desert-1.jpg',

                'SourceFile' => $pathToFile,

                //'body'=> $file_Path,

                //'ACL'        => 'public-read',

                //'StorageClass' => 'REDUCED_REDUNDANCY',

            ]);

            $data['message']   = "sucess";

            $data['imagename'] = 'Desert-1.jpg';

            $data['imagepath'] = $result['ObjectURL'];



            //Get a command to GetObject

       



        } catch (Exception $e) {

            $data['message'] = "false";

            echo $e->getMessage() . "\n";

        }



        return $data;  
    }


    function test_records() {
        $this->load->view('member/test_records');
    }

    
    
    //function reArrange() {
    function reArrangeTestdetails() {
        $this->verifyUser();

        /* # Show all reArrange tests
        $where = "id != '0' ";
        $this->data['tests'] = $this->my_model->getWhereOrderRecords('system_re_arrange_test_code', $where, 'id', 'asc');
        $this->data['total'] = count($this->data['tests']);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Re Arrange Tests';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data); */
        
        
        // Get all questions in test
        
        $where = "id != '0' ";
        $allQuestions = $this->my_model->getWhereOrderRecords('system_re_arrange_test_code', $where, 'id', 'asc');
        $this->data['total_questions'] = count($allQuestions);

        // History, in desc order
        $where = "member_id = '". $this->data['user']->id ."' ";
        $this->data['history'] = $this->my_model->getWhereOrderRecords('system_reArrange_testdetails_code', $where, 'id', 'desc');
        
        $get_testcoin = $this->my_model->checkARecord('system_set_test_coin_cost_code', 'test_type', 're_arrange');
        
        $this->data['coin_cost'] = $get_testcoin->coin_cost;

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Re Arrange';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    /*
    * Start a new reArrange test
    */
    function startreArrangetest() {
        $this->verifyUser();
        //$memberid = $this->input->post('memberid');
        $memberid = $this->data['user']->id;
        
        $get_testcoin = $this->my_model->checkARecord('system_set_test_coin_cost_code', 'test_type', 're_arrange');
        
        $objMember = $this->my_model->getARecord('system_member_code', $this->data['user']->id);
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < $get_testcoin->coin_cost)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }

        //if( $testid = 101 ) {

        $qryData = array(
            //'level_id' => $testid,
            'member_id' => $memberid,
            'time' => time(),
        );

        if( $this->my_model->insertDataIntoTable('system_reArrange_testdetails_code', $qryData) )
        {
            $this->data['success'] = true;
            $last_added_id = $this->db->insert_id();

            $id_md5 = md5($last_added_id);

            $updateData = array(
                'id_md5' => $id_md5,
            );
            $this->my_model->updateTable('system_reArrange_testdetails_code', $updateData, $last_added_id);

            // Add entry here
            $response = array(
                'result' => 'success',
                'message' => 'Test Started',
                'tdcode' => $id_md5, // reArrange test details code
                'tcode' => md5(101) // level/test code
            );
            
            $balance_coins = $objMember->coins - $get_testcoin->coin_cost;
            $updateMemCoins = array('coins'=>$balance_coins);
            $this->my_model->updateTable('system_member_code', $updateMemCoins, $this->data['user']->id);
            
            $coin_data = array('user_id'=>$this->data['user']->id,
                'user_type'=>'member',
                'description'=>"Cost test reArrange",
                'debit_coin'=>$get_testcoin->coin_cost,
                'balance_coin'=>$balance_coins,
                'created_date'=>date('Y-m-d H:i:s'),
                'updated_at'=>date('Y-m-d H:i:s'),
            );
            $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
            
        }else{
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }
        // Return ajax response as json
        echo json_encode ($response) ;
    }
    
    function reArrangeTestprogress($tdId_md5, $testId_md5, $page='1') {
        $this->verifyUser();

        $this->data['testdetail'] = $this->my_model->checkARecord('system_reArrange_testdetails_code', 'id_md5', $tdId_md5);
        
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

       /*  $getId = md5($this->data['testdetail']->level_id);
        if($getId != $testId_md5) {
            exit($this->unauthorized_message);
        } */
        // $this->data['testdetail']->level_id;

        /* $this->data['test'] = $this->my_model->checkARecord('system_dictation_level_code', 'id', $this->data['testdetail']->level_id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        } */


        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                //'level_id' => $this->data['test']->id,
            );
            $this->sortby = 'id'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, 'system_re_arrange_test_code' );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 10;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination
        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, 'system_re_arrange_test_code' );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        $this->data['reporturl'] = current_url();
        //echo "<pre>";print_r($this->data['allQuestions']);die;

        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;
        $this->data['pagetitle'] = 'Re Arrange Test';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function reArrange_uploadjson() {

        $myresponse = $this->input->post('myresponse');
        $memberId = $this->input->post('mid');
        //$testid = $this->input->post('testid');
        $questionid = $this->input->post('questionid');

        $result = array('myresponse' => $myresponse);
        $json_result = json_encode($result);

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'questionid' => $questionid,
            'memberid' => $memberId,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable('system_reArrange_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    
     public function coinManage(){
        $this->verifyUser();

        $where = "user_id = '". $this->data['user']->id ."' AND user_type = 'member'";
        $this->data['history'] = $this->my_model->getWhereOrderRecords('system_coins_management_code', $where, 'id', 'desc');
        
        $userid=$this->data['user']->id;
        $this->data['affiliate']= $this->my_model->checkARecord('system_member_code', 'id',$userid);
        
        $affiliate_code=$this->data['affiliate']->affiliate_reference_no;
     //   print_r($affiliate_code);die;
        if(isset($_GET['amt'])){

            // Get the transaction data
            $txn_id = $_GET['tx'];
            $payment_gross = $_GET['amt'];
            $currency_code = $_GET['cc'];
            $payment_status = $_GET['st'];
            
            $coinscount = $this->my_model->checkARecord('system_coins_code','cost',$payment_gross);
            $cointogive=$coinscount->coins;
            $additivecoins=(45/100) * $cointogive;
            $cointogiveaffiliate=$cointogive +$additivecoins;
            
            if(!empty($affiliate_code)){
                    $this->data['buy_coins'] =$cointogiveaffiliate; 
                
                }
                else{ $this->data['buy_coins'] = $cointogive; }
                    
            
            $querydata = array(

                     "member_id" => $this->logged['id'],
                     "txn_id"=> $txn_id,
                     "payment"=>$payment_gross,
                     "status"=>$payment_status,
                     "coins"=>$this->data['buy_coins'],
                     "date"=> date('Y-m-d')
                    );

            if($this->my_model->insertDataIntoTable("system_membership_code",$querydata)){
                
                if(!empty($affiliate_code)){
                    $this->data['buy_coins'] =$cointogiveaffiliate; 
                
                }
                else{ $this->data['buy_coins'] = $cointogive; }
                    
                
                $transaction_querydata = array(
                    "user_id" => $this->logged['id'],
                    "transaction_id"=> $txn_id,
                    "plan_type"=> $payment_gross,
                    "transaction_status"=>$payment_status,
                    "buy_coins"=>$this->data['buy_coins'],
                    "created_date"=> date('Y-m-d H:i:s')
                    );
                    
                //echo "<pre>";print_r($transaction_querydata);die;
                
        $this->my_model->insertDataIntoTable('system_transaction_code', $transaction_querydata);
    
    
                if(!empty($affiliate_code))
                {
                    $transaction_affiliate_querydata = array(
                    "user_id" => $this->logged['id'],
                    "transaction_id"=> $txn_id,
                    "plan_type"=> $payment_gross,
                    "transaction_status"=>$payment_status,
                    "buy_coins"=>$this->data['buy_coins'],
                    "affiliate_reference_no"=>$affiliate_code,
                    "created_date"=> date('Y-m-d H:i:s')
                    );
                        $this->my_model->insertDataIntoTable('system_affiliate_transaction_code', $transaction_affiliate_querydata);
                }
                
                
                $coins_bought = $this->data['user']->coins + $this->data['buy_coins'];

                $updateData = array(
                    'coins' => $coins_bought 
                    );

                if($this->my_model->updateTable("system_member_code",$updateData,$this->logged['id'])){

                    //CHARGE COIN COST
                    $objMember = $this->my_model->getARecord('system_member_code', $this->logged['id']);  
                    $balance_coins = $coins_bought;
                    $updateMemCoins = array('coins'=>$balance_coins);
                    $this->my_model->updateTable('system_member_code', $updateMemCoins, $objMember->id);
                    
                    $coin_data = array('user_id'=>$objMember->id,
                        'user_type'=>'member',
                        'description'=>"Purchased coins $".$payment_gross,
                        'credit_coin'=>$this->data['buy_coins'],
                        'balance_coin'=>$coins_bought,
                        'created_date'=>date('Y-m-d H:i:s'),
                        'updated_at'=>date('Y-m-d H:i:s'),
                    );
                    $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                    
                    
                    if($objMember->student_reference_no != '0'){
                        $anotherMember = $this->my_model->getARecord('system_member_code', $objMember->student_reference_no);
                        
                        $get_free_coins = $anotherMember->coins + $this->data['buy_coins']/3;

                        $updateData = array(
                            'coins' => $get_free_coins 
                            );

                        $this->my_model->updateTable("system_member_code",$updateData,$anotherMember->id);
                        
                        $coin_data = array('user_id'=>$anotherMember->id,
                            'user_type'=>'member',
                            'description'=>"Referred student just purchased coins ",
                            'credit_coin'=>(($this->data['buy_coins'])/3),
                            'balance_coin'=>$get_free_coins,
                            'created_date'=>date('Y-m-d H:i:s'),
                            'updated_at'=>date('Y-m-d H:i:s'),
                        );
                        $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                    }

                    $this->session->set_flashdata('global_msg','Your payment is completed and you have successfully bought coins !');
                    redirect('member/coinManage',refresh);
                }
                
                /* if($objMember->business_reference_no != ''){
                    $anotherU_id = preg_replace('/[^0-9]/', '', $objMember->business_reference_no);
                    $anotherMember = $this->my_model->getARecord('system_member_code', $anotherU_id);
                        $get_free_coins = $anotherMember->coins + $this->data['buy_coins'];

                        $updateData = array(
                            'coins' => $get_free_coins 
                            );

                        $this->my_model->updateTable("system_member_code",$updateData,$anotherMember->id);
                        
                        $coin_data = array('user_id'=>$anotherMember->id,
                            'user_type'=>'member',
                            'description'=>"Get free coins on buy referenced user ",
                            'credit_coin'=>$this->data['buy_coins'],
                            'balance_coin'=>$get_free_coins,
                            'created_date'=>date('Y-m-d H:i:s'),
                            'updated_at'=>date('Y-m-d H:i:s'),
                        );
                        $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                } */
                
            }

        }

        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Coins Management History';

        $this->load->view('member/coin_manage_view', $this->data);
        
    }

    /*function paypalsuccess() {
        $this->verifyUser();
        
        // Get the transaction data
        $item_number = $_GET['item_number'];
        $txn_id = $_GET['tx'];
        $payment_gross = $_GET['amt'];
        $currency_code = $_GET['cc'];
        $payment_status = $_GET['st'];

        if(isset($_GET['amt'])){

            //save transaction to database..

            $querydata = array(

                     "member_id" => $this->logged['id'],
                     "txn_id"=> $txn_id,
                     "payment"=>$payment_gross,
                     "status"=>$payment_status,
                     "coins"=>$this->data['buy_coins'],
                     "date"=> date('Y-m-d')
                    );

            if($this->my_model->insertDataIntoTable("system_membership_code",$querydata)){
        
                $this->data['buy_coins'] = '';
                if($payment_gross == '10'){
                    $this->data['buy_coins'] = '5000'; //For $10
                }
                if($payment_gross == '35'){
                    $this->data['buy_coins'] = '25000'; //For $35
                }
                if($payment_gross == '150'){
                    $this->data['buy_coins'] = '150000'; //For $150
                }

                $coins_bought = $this->data['user']->coins + $this->data['buy_coins'];

                $updateData = array(
                    'coins' => $coins_bought 
                    );

                if($this->my_model->updateTable("system_member_code",$updateData,$this->logged['id'])){

                    //CHARGE COIN COST
                    $objMember = $this->my_model->getARecord('system_member_code', $this->logged['id']);  
                    $balance_coins = $coins_bought;
                    $updateMemCoins = array('coins'=>$balance_coins);
                    $this->my_model->updateTable('system_member_code', $updateMemCoins, $objMember->id);
                    
                    $coin_data = array('user_id'=>$objMember->id,
                        'user_type'=>'member',
                        'description'=>"bought coins with $".$payment_gross,
                        'debit_coin'=>$this->data['buy_coins'],
                        'balance_coin'=>$coins_bought,
                        'created_date'=>date('Y-m-d H:i:s'),
                        'updated_at'=>date('Y-m-d H:i:s'),
                    );
                    $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);


                    $this->session->set_flashdata('global_msg','Your payment is completed and you have successfully bought coins !');
                    redirect($this->data['currentPath'].'/'.__FUNCTION__);
                }
                
            }

        }
        
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }*/


     
     function cancel(){
        $this->verifyUser();
        // Load payment failed view
        $this->load->view('member/cancel');
     }
     

     function payment(){

        $this->verifyUser();
               
        define("DEBUG", 1);
        // Set to 0 once you're ready to go live
        define("USE_SANDBOX", 1);
        define("LOG_FILE", "ipn.log");
       
        $raw_post_data = file_get_contents('php://input');
        $raw_post_array = explode('&', $raw_post_data);
        $myPost = array();
        foreach ($raw_post_array as $keyval) {
            $keyval = explode ('=', $keyval);
            if (count($keyval) == 2)
                $myPost[$keyval[0]] = urldecode($keyval[1]);
        }
        // read the post from PayPal system and add 'cmd'
        $req = 'cmd=_notify-validate';
        if(function_exists('get_magic_quotes_gpc')) {
            $get_magic_quotes_exists = true;
        }
        foreach ($myPost as $key => $value) {
            if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
                $value = urlencode(stripslashes($value));
            } else {
                $value = urlencode($value);
            }
            $req .= "&$key=$value";
        }
        // Post IPN data back to PayPal to validate the IPN data is genuine
        // Without this step anyone can fake IPN data
        if(USE_SANDBOX == true) {
            $paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
        } else {
            $paypal_url = "https://www.paypal.com/cgi-bin/webscr";
        }
        $ch = curl_init($paypal_url);
        if ($ch == FALSE) {
            return FALSE;
        }
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
        if(DEBUG == true) {
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
        }
        // CONFIG: Optional proxy configuration
        //curl_setopt($ch, CURLOPT_PROXY, $proxy);
        //curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
        // Set TCP timeout to 30 seconds
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));
        // CONFIG: Please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path
        // of the certificate as shown below. Ensure the file is readable by the webserver.
        // This is mandatory for some environments.
        //$cert = __DIR__ . "./cacert.pem";
        //curl_setopt($ch, CURLOPT_CAINFO, $cert);
        $res = curl_exec($ch);
        if (curl_errno($ch) != 0) // cURL error
            {
            if(DEBUG == true) { 
                error_log(date('[Y-m-d H:i e] '). "Can't connect to PayPal to validate IPN message: " . curl_error($ch) . PHP_EOL, 3, LOG_FILE);
            }
            curl_close($ch);
            exit;
        } else {
                // Log the entire HTTP response if debug is switched on.
                if(DEBUG == true) {
                    error_log(date('[Y-m-d H:i e] '). "HTTP request of validation request:". curl_getinfo($ch, CURLINFO_HEADER_OUT) ." for IPN payload: $req" . PHP_EOL, 3, LOG_FILE);
                    error_log(date('[Y-m-d H:i e] '). "HTTP response of validation request: $res" . PHP_EOL, 3, LOG_FILE);
                }
                curl_close($ch);
        }
        // Inspect IPN validation result and act accordingly
        // Split response headers and payload, a better way for strcmp
        $tokens = explode("\r\n\r\n", trim($res));
        $res = trim(end($tokens));
        if (strcmp ($res, "VERIFIED") == 0) {
            // assign posted variables to local variables
            $item_name = $_POST['item_name'];
            $item_number = $_POST['item_number'];
            $payment_status = $_POST['payment_status'];
            $payment_amount = $_POST['mc_gross'];
            $payment_currency = $_POST['mc_currency'];
            $txn_id = $_POST['txn_id'];
            $receiver_email = $_POST['receiver_email'];
            $payer_email = $_POST['payer_email'];
        
            
            // check whether the payment_status is Completed
            $isPaymentCompleted = false;
            if($payment_status == "Completed") {
                $isPaymentCompleted = true;
            }
            // check that txn_id has not been previously processed
            $isUniqueTxnId = false; 

            $where = "txn_id = '".$txn_id."' ";
            $result = $this->my_model->getWhereRecords("system_membership_code",$where);

           // $result = $db->selectQuery("SELECT * FROM payments WHERE txn_id = '$txn_id'");
            if(empty($result)) {
                $isUniqueTxnId = true;
            }   
            // check that receiver_email is your PayPal email
            // check that payment_amount/payment_currency are correct
            if($isPaymentCompleted && $isUniqueTxnId && $payment_amount == $payment_amount && $payment_currency == "USD") {

                $querydata = array(

                     "member_id" => $member_id,
                     "txn_id"=> $txn_id,
                     "payment"=>$payment_amount,
                     "date"=> date('Y-m-d')

                    );

                $this->my_model->insertDataIntoTable("system_membership_code",$querydata );
               // $payment_id = $db->insertQuery("INSERT INTO payment(item_number, item_name, payment_status, payment_amount, payment_currency, txn_id) VALUES('$item_number', '$item_name', $payment_status, '$payment_amount', '$payment_currency', '$txn_id')");
            }
            // process payment and mark item as paid.
            
            
            if(DEBUG == true) {
                error_log(date('[Y-m-d H:i e] '). "Verified IPN: $req ". PHP_EOL, 3, LOG_FILE);
            }
            
        } else if (strcmp ($res, "INVALID") == 0) {
            // log for manual investigation
            // Add business logic here which deals with invalid IPN messages
            if(DEBUG == true) {
                error_log(date('[Y-m-d H:i e] '). "Invalid IPN: $req" . PHP_EOL, 3, LOG_FILE);
            }
        }
    }


    
    function fillblanks() {
        $this->verifyUser();
        
        // Get all questions in test
        $where = "id != '0' ";
        $allQuestions = $this->my_model->getWhereOrderRecords('system_fill_in_the_blanks_test_code', $where, 'id', 'asc');
        $this->data['total_questions'] = count($allQuestions);

        // History, in desc order
        $where = "member_id = '". $this->data['user']->id ."' ";
        $this->data['history'] = $this->my_model->getWhereOrderRecords('system_fill_blanks_testdetails_code', $where, 'id', 'desc');
        
        $get_testcoin = $this->my_model->checkARecord('system_set_test_coin_cost_code', 'test_type', 'fill_blanks');
        $this->data['coin_cost'] = $get_testcoin->coin_cost;

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Fill in the blanks Tests';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    
    /*
    * Start a new reArrange test
    */   
    function startfillBlankstest() {
        
        $this->verifyUser();
        //$memberid = $this->input->post('memberid');
        $memberid = $this->data['user']->id;
        
        $get_testcoin = $this->my_model->checkARecord('system_set_test_coin_cost_code', 'test_type', 'fill_blanks');
        $objMember = $this->my_model->getARecord('system_member_code', $this->data['user']->id);
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < $get_testcoin->coin_cost)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }

        //if( $testid = 101 ) {

            $qryData = array(
                //'level_id' => $testid,
                'member_id' => $memberid,
                'time' => time(),
            );

            if( $this->my_model->insertDataIntoTable('system_fill_blanks_testdetails_code', $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_fill_blanks_testdetails_code', $updateData, $last_added_id);

                $balance_coins = $objMember->coins - $get_testcoin->coin_cost;
                $updateMemCoins = array('coins'=>$balance_coins);
                $this->my_model->updateTable('system_member_code', $updateMemCoins, $this->data['user']->id);
                
                $coin_data = array('user_id'=>$this->data['user']->id,
                    'user_type'=>'member',
                    'description'=>"Coin Cost for fill blanks",
                    'debit_coin'=>$get_testcoin->coin_cost,
                    'balance_coin'=>$balance_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                
                // Add entry here
                $response = array(
                    'result' => 'success',
                    'message' => 'Test Started',
                    'tdcode' => $id_md5, // reArrange test details code
                    'tcode' => md5(101) // level/test code
                );
                
            }else {
                $response = array(
                    'result' => 'error',
                    'message' => $this->ajaxerror_message
                );
            }

            

        /* } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        } */

        // Return ajax response as json
        echo json_encode ($response) ;
    }
    
    function fillBlanksTestprogress($tdId_md5, $testId_md5, $page='1') {
        $this->verifyUser();

        $this->data['testdetail'] = $this->my_model->checkARecord('system_fill_blanks_testdetails_code', 'id_md5', $tdId_md5);
        //echo "<pre>";print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

       /*  $getId = md5($this->data['testdetail']->level_id);
        if($getId != $testId_md5) {
            exit($this->unauthorized_message);
        } */
        // $this->data['testdetail']->level_id;

        /* $this->data['test'] = $this->my_model->checkARecord('system_dictation_level_code', 'id', $this->data['testdetail']->level_id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        } */


        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                //'level_id' => $this->data['test']->id,
            );
            $this->sortby = 'id'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, 'system_fill_in_the_blanks_test_code' );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 10;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination
        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, 'system_fill_in_the_blanks_test_code' );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        $this->data['reporturl'] = current_url();
        //echo "<pre>";print_r($this->data['allQuestions']);die;

        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;
        $this->data['pagetitle'] = 'Fill in the blanks Tests';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function fillBlanks_uploadjson() {
        
        $myresponse1 = $this->input->post('myresponse1');
        $myresponse2 = $this->input->post('myresponse2');
        $myresponse3 = $this->input->post('myresponse3');
        $myresponse4 = $this->input->post('myresponse4');
        $memberId = $this->input->post('mid');
        //$testid = $this->input->post('testid');
        $questionid = $this->input->post('questionid');

        $result = array('myresponse1' => $myresponse1,'myresponse2' => $myresponse2,'myresponse3' => $myresponse3,'myresponse4' => $myresponse4);
        $json_result = json_encode($result);

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'questionid' => $questionid,
            'memberid' => $memberId,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable('system_fill_blanks_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spottingErrors() {
        $this->verifyUser();
        
        // Get all questions in test
        $where = "id != '0' ";
        $allQuestions = $this->my_model->getWhereOrderRecords('system_spotting_errors_code', $where, 'id', 'asc');
        $this->data['total_questions'] = count($allQuestions);

        // History, in desc order
        $where = "member_id = '". $this->data['user']->id ."' ";
        $this->data['history'] = $this->my_model->getWhereOrderRecords('system_spotting_errors_testdetails_code', $where, 'id', 'desc');
        
        $get_testcoin = $this->my_model->checkARecord('system_set_test_coin_cost_code', 'test_type', 'spotting_errors');
        
        $this->data['coin_cost'] = $get_testcoin->coin_cost;

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Spotting the Errors';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    /*
    * Start a new Spotting Errors test
    */   
    function startSpottingErrorstest() {
        $this->verifyUser();
        //$memberid = $this->input->post('memberid');
        $memberid = $this->data['user']->id;
        
        $get_testcoin = $this->my_model->checkARecord('system_set_test_coin_cost_code', 'test_type', 'spotting_errors');
        
        $objMember = $this->my_model->getARecord('system_member_code', $this->data['user']->id);
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < $get_testcoin->coin_cost)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }


        $qryData = array(
            'member_id' => $memberid,
            'time' => time(),
        );

        if( $this->my_model->insertDataIntoTable('system_spotting_errors_testdetails_code', $qryData) )
        {
            $this->data['success'] = true;
            $last_added_id = $this->db->insert_id();

            $id_md5 = md5($last_added_id);

            $updateData = array(
                'id_md5' => $id_md5,
            );
            $this->my_model->updateTable('system_spotting_errors_testdetails_code', $updateData, $last_added_id);
            
            // Add entry here
            $response = array(
                'result' => 'success',
                'message' => 'Test Started',
                'tdcode' => $id_md5, // reArrange test details code
                'tcode' => md5(103) // level/test code
            );
            
            $balance_coins = $objMember->coins - $get_testcoin->coin_cost;
            $updateMemCoins = array('coins'=>$balance_coins);
            $this->my_model->updateTable('system_member_code', $updateMemCoins, $this->data['user']->id);
            
            $coin_data = array('user_id'=>$this->data['user']->id,
                'user_type'=>'member',
                'description'=>"Cost test Spotting Errors",
                'debit_coin'=>$get_testcoin->coin_cost,
                'balance_coin'=>$balance_coins,
                'created_date'=>date('Y-m-d H:i:s'),
                'updated_at'=>date('Y-m-d H:i:s'),
            );
            $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);

        }else{
             $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }
        // Return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spottingErrorsTestprogress($tdId_md5, $testId_md5, $page='1') {
        $this->verifyUser();

        $this->data['testdetail'] = $this->my_model->checkARecord('system_spotting_errors_testdetails_code', 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }


        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array();
            $this->sortby = 'id'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, 'system_spotting_errors_code' );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 10;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next ';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination
        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, 'system_spotting_errors_code' );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        $this->data['reporturl'] = current_url();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Spotting the Errors';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function spottingErrors_uploadjson() {
        
        $myresponse1 = $this->input->post('myresponse1');
        $myresponse2 = $this->input->post('myresponse2');
        $myresponse3 = $this->input->post('myresponse3');
        $myresponse4 = $this->input->post('myresponse4');
        $memberId = $this->input->post('mid');
        $questionid = $this->input->post('questionid');

        $result = array('myresponse1' => $myresponse1,'myresponse2' => $myresponse2,'myresponse3' => $myresponse3,'myresponse4' => $myresponse4);
        $json_result = json_encode($result);

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'questionid' => $questionid,
            'memberid' => $memberId,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable('system_spotting_errors_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function manageBanner(){
        $this->verifyUser();
        
        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {       
            //echo "<pre>";print_r($_POST);echo "</pre>";
            //echo "<pre>";print_r($_FILES);echo "</pre>";die;
            
            if(!empty($_FILES["banner_img"]["name"])){
                $banner_logo_image = strtotime(date("Y-m-d h:i:s A")).'_'.$_FILES["banner_img"]["name"];
                
                $config['file_name']   = $banner_logo_image;
                $config['upload_path'] = './uploads/member_banner';
                $config['allowed_types'] = 'gif|jpg|png';
                //$config['max_size']    = '1024';
                $config['max_width']  = '1024';
                $config['max_height']  = '768';
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('banner_img')){
                   $this->session->set_flashdata('global_msg',strip_tags($this->upload->display_errors()));
                }
                
                $qryData = array(
                    'banner_image' => $banner_logo_image
                );
                
                $result = $this->my_model->updateTable('system_member_code', $qryData, $this->data['user']->id);
                if(!empty($result)){
                    $this->session->set_flashdata('global_msg', 'Banner has been updated successfully!! ');
                }
            }else{
                $this->session->set_flashdata('global_msg', 'Image field is required');
            }
            redirect('member/manageBanner');
            
        }
  
        $check_member = $this->my_model->checkARecord('system_member_code', 'id', $this->data['user']->id);
        if( !is_object($check_member)) {
            exit($this->unauthorized_message);
        }
        
        $this->data['member'] = $check_member;
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] =  'Manage Banner';
    
        if(!empty($this->data['member'])){
            $this->load->view('member/manage_banner',$this->data);
        }else{
            redirect('member/dashboard');
        }
    }
    
    function earnCoins(){
        $this->verifyUser();

        $this->data['member'] = $this->my_model->checkARecord('system_member_code', 'id', $this->data['user']->id);
        if( !is_object($this->data['member'])) {
            exit($this->unauthorized_message);
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Earn Free Coins';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function speakingPracticeTaskSubmit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_speaking_practice_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking: Practice Task','response_data'=>array(
        array('q_number'=>'Speaking: Practice Task','q_response_type'=>'audio','sp_response_file' => $_REQUEST['q1_response'])
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spPart1Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_speaking_part1_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking: Practice Task','response_data'=>array(
        array('q_number'=>'Speaking: Practice Task','q_response_type'=>'audio','sp_response_file' => $_REQUEST['q1_response'])
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spPart2Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->my_model->checkARecord('system_part6_TAPE_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking Task 2: Talking about a Personal Experience','response_data'=>array(
        array('q_number'=>'Speaking Task 2: Talking about a Personal Experience','q_response_type'=>'audio','sp_response_file' => $_REQUEST['q1_response'])
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => '6',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spPart3Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_speaking_part3_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking Task 3: Describing a Scene','response_data'=>array(
        array('q_number'=>'Speaking Task 3: Describing a Scene','q_response_type'=>'audio','sp_response_file' => $_REQUEST['q1_response'])
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spPart4Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_speaking_part4_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Task 4: Making Predictions Details ','response_data'=>array(
        array('q_number'=>'Task 4: Making Predictions Details','q_response_type'=>'audio','sp_response_file' => $_REQUEST['q1_response'])
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spPart5Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_speaking_part5_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking Task 5: Comparing and Persuading','response_data'=>array(
        array('q_number'=>'Speaking Task 5: Comparing and Persuading','q_response_type'=>'audio','sp_response_file' => $_REQUEST['q1_response'])
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spPart6Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_speaking_part6_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking Task 6: Dealing with a Difficult Situation','response_data'=>array(
        array('q_number'=>'Speaking Task 6: Dealing with a Difficult Situation','q_response_type'=>'audio','sp_response_file' => $_REQUEST['q1_response'])
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spPart7Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_speaking_part7_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking Task 7: Expressing Opinions','response_data'=>array(
        array('q_number'=>'Speaking Task 7: Expressing Opinions','q_response_type'=>'audio','sp_response_file' => $_REQUEST['q1_response'])
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function spPart8Submit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_speaking_part8_code','test_code',$testdetail->test_code);
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking Task 8: Describing an Unusual Situation','response_data'=>array(
        array('q_number'=>'Speaking Task 8: Describing an Unusual Situation','q_response_type'=>'audio','sp_response_file' => $_REQUEST['q1_response'])
        ));
        $json_result = json_encode($result);       

        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->my_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    
    function editProfile() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {
            //echo "<pre>";print_r($_POST);die;
            $this->form_validation->set_rules('name', 'Name', 'trim');
            $this->form_validation->set_rules('street_address', 'Street_address', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert"></button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                
                $qryData = array(
                    'name' => $this->input->post('name'),
                    'street_address' => $this->input->post('street_address'),
                    'city_region' => $this->input->post('city_region'),
                    'mobile' => $this->input->post('mobile'),
                    'country_id' => $this->input->post('country_id'),
                    'postal_code' => $this->input->post('postal_code'),
                );
                
                if( $this->my_model->updateTable('system_member_code', $qryData, $this->data['user']->id) )
                {
                    $this->session->set_flashdata('global_msg','Profile fas been update successfully.');
                }
                redirect('member/editProfile');
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Edit Profile';
        
        $this->data['member'] = $this->my_model->getARecord('system_member_code', $this->data['user']->id);
        
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function getSectionListening(){
        
        $this->verifyUser();
        
        $this->data['member_id'] = $this->data['user']->id;
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Listening Section Wise';
        
        $this->data['gettest'] = array();
        
        $where = "id != '0'";
        $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_listening_section_wise_code', $where, 'id', 'asc');
        
        //echo "<pre>";print_r($this->data['gettest']);die;
        
        $this->load->view('member/getSectionListening', $this->data);
    }
    
    function getSectionReading(){
        
        $this->verifyUser();
        
        $this->data['member_id'] = $this->data['user']->id;
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Reading Section Wise';
        
        $this->data['gettest'] = array();
        
        $where = "id != '0'";
        $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_reading_section_wise_code', $where, 'id', 'asc');
        
        //echo "<pre>";print_r($this->data['gettest']);die;
        
        $this->load->view('member/getSectionReading', $this->data);
    }


    function viewSectionListenReport($id){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord("system_section_testdetails_code", 'id_md5', $id);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->my_model->checkARecord('system_listening_section_wise_code', 'id', $this->data['testdetail']->test_id);

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->my_model->checkARecord('system_section_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $id = $this->data['testdetail']->id;
        $table = 'system_listening_section_wise_code';
        $where = "id = '$id'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;
        
        
        $this->load->view('member/view_section_listening_report', $this->data);
    }
    
    /*
    * Start a new test
    */
    function accessReadingSectionWisetest() {
        $this->verifyUser();
        
        $testid = $this->input->post('testid');
        $memberid = $this->data['user']->id;
        
        $objTest = $this->my_model->getARecord('system_reading_section_wise_code', $testid);
        //echo "<pre>";print_r($objTest);die;
        $objMember = $this->my_model->getARecord('system_member_code', $memberid);
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < 250)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }
        
        if( is_object($objTest)) {

            $qryData = array(
                'test_id' => $testid,
                'test_type'=> 'reading',
                'member_id' => $memberid,
                'time' => time(),
                'created_at'=> date('Y-m-d H:i:s')
            );

            if( $this->my_model->insertDataIntoTable('system_section_testdetails_code', $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_section_testdetails_code', $updateData, $last_added_id);
                
                //CHARGE COIN COST
                $objMember = $this->my_model->getARecord('system_member_code', $memberid);  
                $balance_coins = $objMember->coins - 250;
                $updateMemCoins = array('coins'=>$balance_coins);
                $this->my_model->updateTable('system_member_code', $updateMemCoins, $memberid);
                
                $coin_data = array('user_id'=>$memberid,
                    'user_type'=>'member',
                    'description'=>"Cost test Section wise reading (testid ".$testid.")",
                    'debit_coin'=>250,
                    'balance_coin'=>$balance_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                
                // Add entry here
                $response = array(
                    'result' => 'success',
                    'message' => 'Test Started',
                    'tdcode' => $id_md5
                );
                
            }

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        echo json_encode ($response) ;
    }
    
    /*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function testReadingSectionWiseprogress($tdId_md5) {
        $this->verifyUser();
        
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord('system_section_testdetails_code', 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }
        
        $check_test = $this->my_model->checkARecord('system_reading_section_wise_code', 'id', $this->data['testdetail']->test_id);
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        //echo "<pre>";print_r($check_test);die;
        
        $test_code = $check_test->practice_code;
        $table = 'system_reading1_40_code';
        $where = "test_code = '$test_code'";
        $this->data['practice'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part1_code;
        $table = 'system_reading_part1_code';
        $where = "test_code = '$test_code'";
        $this->data['part1'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part2_code;
        $table = 'system_reading_part2_code';
        $where = "test_code = '$test_code'";
        $this->data['part2'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part3_code;
        $table = 'system_reading_part3_code';
        $where = "test_code = '$test_code'";
        $this->data['part3'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part4_code;
        $table = 'system_reading_part4_code';
        $where = "test_code = '$test_code'";
        $this->data['part4'] = $this->my_model->getWhereOneRecords($table,$where);
         
        if(!empty($this->data['practice'])){
            $this->load->view('member/section_wise_reading_test_play',$this->data);
        }else{
            redirect('member/getSectionReading');
        }
    }
    
    /*
    * Start a new test
    */
    function accessSectionWisetest() {
        $this->verifyUser();
        
        $testid = $this->input->post('testid');
        $memberid = $this->data['user']->id;
        
        $objTest = $this->my_model->getARecord('system_listening_section_wise_code', $testid);
        //echo "<pre>";print_r($objTest);die;
        $objMember = $this->my_model->getARecord('system_member_code', $memberid);
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < 310)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }
        
        if( is_object($objTest)) {

            $qryData = array(
                'test_id' => $testid,
                'test_type'=> 'listening',
                'member_id' => $memberid,
                'time' => time(),
                'created_at'=> date('Y-m-d H:i:s')
            );

            if( $this->my_model->insertDataIntoTable('system_section_testdetails_code', $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_section_testdetails_code', $updateData, $last_added_id);
                
                //CHARGE COIN COST
                $objMember = $this->my_model->getARecord('system_member_code', $memberid);  
                $balance_coins = $objMember->coins - 310;
                $updateMemCoins = array('coins'=>$balance_coins);
                $this->my_model->updateTable('system_member_code', $updateMemCoins, $memberid);
                
                $coin_data = array('user_id'=>$memberid,
                    'user_type'=>'member',
                    'description'=>"Cost test Section wise listening (testid ".$testid.")",
                    'debit_coin'=>310,
                    'balance_coin'=>$balance_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                
                // Add entry here
                $response = array(
                    'result' => 'success',
                    'message' => 'Test Started',
                    'tdcode' => $id_md5
                );
                
            }

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        echo json_encode ($response) ;
    }
    
    /*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function testSectionWiseprogress($tdId_md5) {
        $this->verifyUser();
        
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord('system_section_testdetails_code', 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }
        
        $check_test = $this->my_model->checkARecord('system_listening_section_wise_code', 'id', $this->data['testdetail']->test_id);
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }


        
        $test_code = $check_test->practice_code;
        $table = 'system_listening_MCsingle_code';
        $where = "test_code = '$test_code'";
        $this->data['practice'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part1_code;
        $table = 'system_part1_MCOA_code';
        $where = "test_code = '$test_code'";
        $this->data['part1'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part2_code;
        $table = 'system_listening_part2_code';
        $where = "test_code = '$test_code'";
        $this->data['part2'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part3_code;
        $table = 'system_part3_code';
        $where = "test_code = '$test_code'";
        $this->data['part3'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part4_code;
        $table = 'system_part1_LOM_code';
        $where = "test_code = '$test_code'";
        $this->data['part4'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part5_code;
        $table = 'system_listening_part5_code';
        $where = "test_code = '$test_code'";
        $this->data['part5'] = $this->my_model->getWhereOneRecords($table,$where);
        
        $test_code = $check_test->part6_code;
        $table = 'system_listening_part6_code';
        $where = "test_code = '$test_code'";
        $this->data['part6'] = $this->my_model->getWhereOneRecords($table,$where);
         
        if(!empty($this->data['practice'])){
            $this->load->view('member/section_wise_test_play',$this->data);
        }else{
            redirect('member/getSectionListening');
        }
    }
    
    function listeningSectionSubmit(){

        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_section_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestCodeDetail = $this->my_model->checkARecord('system_listening_section_wise_code','id',$testdetail->test_id);
        //echo "<pre>";print_r($getTestCodeDetail);die;
        
        $getPart1detail = $this->my_model->checkARecord('system_part1_MCOA_code','test_code',$getTestCodeDetail->part1_code);
        
        $q1_right_option = 'l1_q1_option'.$getPart1detail->q1_answer;
        $q2_right_option = 'l1_q2_option'.$getPart1detail->q2_answer;
        $q3_right_option = 'l1_q3_option'.$getPart1detail->q3_answer;
      
        
        $q1_response_val = $_REQUEST['p1_q1_response'];
        $q2_response_val = $_REQUEST['p1_q2_response'];
        $q3_response_val = $_REQUEST['p1_q3_response'];
        
        
        /*echo $getTestdetail->$q1_right_option;die;
        echo $getTestdetail->$_REQUEST['q1_response'];die;*/
        
        $part1result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part1_code,
            'test_name'=>'Listening Part 1: Multiple choice question with one answer',
            'response_data'=>array(
                            array(
                            'q_number'=>'Listening Part 1: Listening to Problem Solving - Q1',
                            'q_response_type'=>'image',
                            'q_response' => $_REQUEST['p1_q1_response'],
                            'q_response_val' => $getPart1detail->$q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>$getPart1detail->$q1_right_option,
                            ),
    
                            array(
                            'q_number'=>'Listening Part 1: Listening to Problem Solving - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q2_response'],
                            'q_response_val' => $getPart1detail->$q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>$getPart1detail->$q2_right_option,
                            ),
    
                            array(
                            'q_number'=>'Listening Part 1: Listening to Problem Solving - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q3_response'],
                            'q_response_val' => $getPart1detail->$q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>$getPart1detail->$q3_right_option,
                            )
    
                        /*    array(
                            'q_number'=>'Listening Part 1: Listening to Problem Solving - Q4',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q4_response'],
                            'q_response_val' => $getPart1detail->$q4_response_val,
                            'q_right_option'=>$q4_right_option,
                            'q_right_option_val'=>$getPart1detail->$q4_right_option,
                            ),
    
                            array(
                            'q_number'=>'Listening Part 1: Listening to Problem Solving - Q5',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q5_response'],
                            'q_response_val' => $getPart1detail->$q5_response_val,
                            'q_right_option'=>$q5_right_option,
                            'q_right_option_val'=>$getPart1detail->$q5_right_option,
                            ),
    
                            array(
                            'q_number'=>'Listening Part 1: Listening to Problem Solving - Q6',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q6_response'],
                            'q_response_val' => $getPart1detail->$q6_response_val,
                            'q_right_option'=>$q6_right_option,
                            'q_right_option_val'=>$getPart1detail->$q6_right_option,
                            ),
    
                            array(
                            'q_number'=>'Listening Part 1: Listening to Problem Solving - Q7',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q7_response'],
                            'q_response_val' => $getPart1detail->$q7_response_val,
                            'q_right_option'=>$q7_right_option,
                            'q_right_option_val'=>$getPart1detail->$q7_right_option,
                            ),
    
                            array(
                            'q_number'=>'Listening Part 1: Listening to Problem Solving - Q8',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q8_response'],
                            'q_response_val' => $getPart1detail->$q8_response_val,
                            'q_right_option'=>$q8_right_option,
                            'q_right_option_val'=>$getPart1detail->$q8_right_option,
                            )*/
        ));
        
        //echo "<pre>";print_r($part1result);die;
        
        
        $getPart2detail = $this->my_model->checkARecord('system_listening_part2_code','test_code',$getTestCodeDetail->part2_code);

        //echo "<pre>";print_r($getPart2detail);die;
        
        $q1_right_option = 'q1_option'.$getPart2detail->q1_answer;
        $q2_right_option = 'q2_option'.$getPart2detail->q2_answer;
        $q3_right_option = 'q3_option'.$getPart2detail->q3_answer;
        $q4_right_option = 'q4_option'.$getPart2detail->q4_answer;
        $q5_right_option = 'q5_option'.$getPart2detail->q5_answer;
        
        $q1_response_val = $_REQUEST['p2_q1_response'];
        $q2_response_val = $_REQUEST['p2_q2_response'];
        $q3_response_val = $_REQUEST['p2_q3_response'];
        $q4_response_val = $_REQUEST['p2_q4_response'];
        $q5_response_val = $_REQUEST['p2_q5_response'];
        
    
        
        $part2result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part2_code,
            'test_name'=>'Listening Part 2: Listening to Daily Life Conversation Answer Key',
            'response_data'=>array(

                            array(
                            'q_number'=>'Listening Part 2: Listening to Daily Life Conversation - Q1',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q1_response'],
                            'q_response_val' => $getPart2detail->$q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>$getPart2detail->$q1_right_option,
                            ),

                            array(
                            'q_number'=>'Listening Part 2: Listening to Daily Life Conversation - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q2_response'],
                            'q_response_val' => $getPart2detail->$q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>$getPart2detail->$q2_right_option,
                            ),

                            array(
                            'q_number'=>'Listening Part 2: Listening to Daily Life Conversation - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q3_response'],
                            'q_response_val' => $getPart2detail->$q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>$getPart2detail->$q3_right_option,
                            ),

                            array(
                            'q_number'=>'Listening Part 2: Listening to Daily Life Conversation - Q4',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q4_response'],
                            'q_response_val' => $getPart2detail->$q4_response_val,
                            'q_right_option'=>$q4_right_option,
                            'q_right_option_val'=>$getPart2detail->$q4_right_option,
                            ),

                            array(
                            'q_number'=>'Listening Part 2: Listening to Daily Life Conversation - Q5',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q5_response'],
                            'q_response_val' => $getPart2detail->$q5_response_val,
                            'q_right_option'=>$q5_right_option,
                            'q_right_option_val'=>$getPart2detail->$q5_right_option,
                            ),

        ));
        
        //echo "<pre>";print_r($part2result);die;
        
        
        $getPart3detail = $this->my_model->checkARecord('system_listening_part3_code','test_code',$getTestCodeDetail->part3_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        
        $q1_right_option = 'q1_option'.$getPart3detail->q1_answer;
        $q2_right_option = 'q2_option'.$getPart3detail->q2_answer;
        $q3_right_option = 'q3_option'.$getPart3detail->q3_answer;
        $q4_right_option = 'q4_option'.$getPart3detail->q4_answer;
        $q5_right_option = 'q5_option'.$getPart3detail->q5_answer;
        
        $q1_response_val = $_REQUEST['p3_q1_response'];
        $q2_response_val = $_REQUEST['p3_q2_response'];
        $q3_response_val = $_REQUEST['p3_q3_response'];
        $q4_response_val = $_REQUEST['p3_q4_response'];
        $q5_response_val = $_REQUEST['p3_q5_response'];
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $part3result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part2_code,
            'test_name'=>'Listening Part 3: Listening for Information Answer Key',
            'response_data'=>array(
                            array(
                            'q_number'=>'Listening Part 3: Listening for Information - Q1',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q1_response'],
                            'q_response_val' => $getPart3detail->$q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>$getPart3detail->$q1_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 3: Listening for Information - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q2_response'],
                            'q_response_val' => $getPart3detail->$q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>$getPart3detail->$q2_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 3: Listening for Information - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q3_response'],
                            'q_response_val' => $getPart3detail->$q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>$getPart3detail->$q3_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 3: Listening for Information - Q4',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q4_response'],
                            'q_response_val' => $getPart3detail->$q4_response_val,
                            'q_right_option'=>$q4_right_option,
                            'q_right_option_val'=>$getPart3detail->$q4_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 3: Listening for Information - Q5',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q5_response'],
                            'q_response_val' => $getPart3detail->$q5_response_val,
                            'q_right_option'=>$q5_right_option,
                            'q_right_option_val'=>$getPart3detail->$q5_right_option,
                            ),
        
        ));

        $getPart1detail = $this->my_model->checkARecord('system_part1_LOM_code','test_code',$getTestCodeDetail->part1_code);
        
        $q1_right_option = 'l1_q1_option'.$getPart1detail->q1_answer;
        $q2_right_option = 'l1_q2_option'.$getPart1detail->q2_answer;
        $q3_right_option = 'l1_q3_option'.$getPart1detail->q3_answer;
      
        
        $q1_response_val = $_REQUEST['p1_q1_response'];
        $q2_response_val = $_REQUEST['p1_q2_response'];
        $q3_response_val = $_REQUEST['p1_q3_response'];
        
        
        /*echo $getTestdetail->$q1_right_option;die;
        echo $getTestdetail->$_REQUEST['q1_response'];die;*/
        
        $part1result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part4_code,
            'test_name'=>'Listening Part 4 : Labelling on a Map',
            'response_data'=>array(
                            array(
                            'q_number'=>'Listening Part 4 : Labelling on a Map - Q1',
                            'q_response_type'=>'image',
                            'q_response' => $_REQUEST['p1_q1_response'],
                            'q_response_val' => $getPart4detail->$q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>$getPart4detail->$q1_right_option,
                            ),
    
                            array(
                            'q_number'=>'Listening Part 4 : Labelling on a Map - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q2_response'],
                            'q_response_val' => $getPart4detail->$q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>$getPart4detail->$q2_right_option,
                            ),
    
                            array(
                            'q_number'=>'Listening Part 4 : Labelling on a Map - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q3_response'],
                            'q_response_val' => $getPart4detail->$q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>$getPart4detail->$q3_right_option,
                            )
    
        
        ));

        $getPart5detail = $this->my_model->checkARecord('system_listening_part5_code','test_code',$getTestCodeDetail->part5_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        
        $q1_right_option = 'q1_option'.$getPart5detail->q1_answer;
        $q2_right_option = 'q2_option'.$getPart5detail->q2_answer;
        $q3_right_option = 'q3_option'.$getPart5detail->q3_answer;
        $q4_right_option = 'q4_option'.$getPart5detail->q4_answer;
        $q5_right_option = 'q5_option'.$getPart5detail->q5_answer;
        $q6_right_option = 'q6_option'.$getPart5detail->q6_answer;
        $q7_right_option = 'q7_option'.$getPart5detail->q7_answer;
        $q8_right_option = 'q8_option'.$getPart5detail->q8_answer;
        
        $q1_response_val = $_REQUEST['p5_q1_response'];
        $q2_response_val = $_REQUEST['p5_q2_response'];
        $q3_response_val = $_REQUEST['p5_q3_response'];
        $q4_response_val = $_REQUEST['p5_q4_response'];
        $q5_response_val = $_REQUEST['p5_q5_response'];
        $q6_response_val = $_REQUEST['p5_q6_response'];
        $q7_response_val = $_REQUEST['p5_q7_response'];
        $q8_response_val = $_REQUEST['p5_q8_response'];
        
        //echo $getPart4detail->$q1_right_option;die;
        //echo $getPart4detail->$_REQUEST['q1_response'];die;
        
        $part5result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part5_code,
            'test_name'=>'Listening Part 5: Listening To a Discussion Answer Key',
            'response_data'=>array(
                            array(
                            'q_number'=>'Listening Part 5: Listening To a Discussion - Q1',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p5_q1_response'],
                            'q_response_val' => $getPart5detail->$q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>$getPart5detail->$q1_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 5: Listening To a Discussion - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p5_q2_response'],
                            'q_response_val' => $getPart5detail->$q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>$getPart5detail->$q2_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 5: Listening To a Discussion - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p5_q3_response'],
                            'q_response_val' => $getPart5detail->$q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>$getPart5detail->$q3_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 5: Listening To a Discussion - Q4',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p5_q4_response'],
                            'q_response_val' => $getPart5detail->$q4_response_val,
                            'q_right_option'=>$q4_right_option,
                            'q_right_option_val'=>$getPart5detail->$q4_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 5: Listening To a Discussion - Q5',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p5_q5_response'],
                            'q_response_val' => $getPart5detail->$q5_response_val,
                            'q_right_option'=>$q5_right_option,
                            'q_right_option_val'=>$getPart5detail->$q5_right_option,
                            ),

                            array(
                            'q_number'=>'Listening Part 5: Listening To a Discussion - Q6',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p5_q6_response'],
                            'q_response_val' => $getPart5detail->$q6_response_val,
                            'q_right_option'=>$q6_right_option,
                            'q_right_option_val'=>$getPart5detail->$q6_right_option,
                            ),

                            array(
                            'q_number'=>'Listening Part 5: Listening To a Discussion - Q7',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p5_q7_response'],
                            'q_response_val' => $getPart5detail->$q7_response_val,
                            'q_right_option'=>$q7_right_option,
                            'q_right_option_val'=>$getPart5detail->$q7_right_option,
                            ),

                            array(
                            'q_number'=>'Listening Part 5: Listening To a Discussion - Q8',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p5_q8_response'],
                            'q_response_val' => $getPart5detail->$q8_response_val,
                            'q_right_option'=>$q8_right_option,
                            'q_right_option_val'=>$getPart5detail->$q8_right_option,
                            ),
        
        ));

        $getPart6detail = $this->my_model->checkARecord('system_listening_part6_code','test_code',$getTestCodeDetail->part6_code);
        
       // echo "<pre>";print_r($getTestdetail);die;
        
        $q1_right_option = 'q1_option'.$getPart6detail->q1_answer;
        $q2_right_option = 'q2_option'.$getPart6detail->q2_answer;
        $q3_right_option = 'q3_option'.$getPart6detail->q3_answer;
        $q4_right_option = 'q4_option'.$getPart6detail->q4_answer;
        $q5_right_option = 'q5_option'.$getPart6detail->q5_answer;
        $q6_right_option = 'q6_option'.$getPart6detail->q6_answer;
       
        
        $q1_response_val = $_REQUEST['p6_q1_response'];
        $q2_response_val = $_REQUEST['p6_q2_response'];
        $q3_response_val = $_REQUEST['p6_q3_response'];
        $q4_response_val = $_REQUEST['p6_q4_response'];
        $q5_response_val = $_REQUEST['p6_q5_response'];
        $q6_response_val = $_REQUEST['p6_q6_response'];

        
        //echo $getPart4detail->$q1_right_option;die;
        //echo $getPart4detail->$_REQUEST['q1_response'];die;
        
        $part6result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part6_code,
            'test_name'=>'Listening Part 6: Listening to Viewpoints Answer Key',
            'response_data'=>array(
                            array(
                            'q_number'=>'Listening Part 6: Listening to Viewpoints - Q1',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p6_q1_response'],
                            'q_response_val' => $getPart6detail->$q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>$getPart6detail->$q1_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 6: Listening to Viewpoints - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p6_q2_response'],
                            'q_response_val' => $getPart6detail->$q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>$getPart6detail->$q2_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 6: Listening to Viewpoints - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p6_q3_response'],
                            'q_response_val' => $getPart6detail->$q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>$getPart6detail->$q3_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 6: Listening to Viewpoints - Q4',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p6_q4_response'],
                            'q_response_val' => $getPart6detail->$q4_response_val,
                            'q_right_option'=>$q4_right_option,
                            'q_right_option_val'=>$getPart6detail->$q4_right_option,
                            ),
        
                            array(
                            'q_number'=>'Listening Part 6: Listening to Viewpoints - Q5',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p6_q5_response'],
                            'q_response_val' => $getPart6detail->$q5_response_val,
                            'q_right_option'=>$q5_right_option,
                            'q_right_option_val'=>$getPart6detail->$q5_right_option,
                            ),

                            array(
                            'q_number'=>'Listening Part 6: Listening to Viewpoints - Q6',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p6_q6_response'],
                            'q_response_val' => $getPart6detail->$q6_response_val,
                            'q_right_option'=>$q6_right_option,
                            'q_right_option_val'=>$getPart6detail->$q6_right_option,
                            ),
        
        ));    

        
        $result = array($part1result,$part2result,$part3result,$part4result,$part5result,$part6result);
        
        $json_result = json_encode($result,true);

        //echo "<pre>"; print_r($json_result); exit();
        
        $qryData = array(
            'time' => time(),
            'testid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable('system_section_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_section_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
        
        
        
    }

    function getSectionSpeaking(){
        
        $this->verifyUser();
        
        $this->data['member_id'] = $this->data['user']->id;
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Speaking Section Wise';
        
        $this->data['gettest'] = array();
        
        $where = "id != '0'";
        $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_speaking_section_wise_code', $where, 'id', 'asc');
        
        //echo "<pre>";print_r($this->data['gettest']);die;
        
        $this->load->view('member/getSectionSpeaking', $this->data);
    }
    
    function readingSectionSubmit(){
        //echo "<pre>";print_r($_POST);die;
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_section_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestCodeDetail = $this->my_model->checkARecord('system_reading_section_wise_code','id',$testdetail->test_id);
        //echo "<pre>";print_r($getTestCodeDetail);die;
        
        $getPart1detail = $this->my_model->checkARecord('system_reading_part1_code','test_code',$getTestCodeDetail->part1_code);
        
        //echo "<pre>";print_r($getPart1detail);die;
        $q1_right_option = 'q1_option'.$getPart1detail->q1_answere;
        $q2_right_option = 'q2_option'.$getPart1detail->q2_answere;
        $q3_right_option = 'q3_option'.$getPart1detail->q3_answere;
        $q4_right_option = 'q4_option'.$getPart1detail->q4_answere;
        $q5_right_option = 'q5_option'.$getPart1detail->q5_answere;
        $q6_right_option = 'q6_option'.$getPart1detail->q6_answere;
        $q7_right_option = 'q7_option'.$getPart1detail->q7_answere;
        $q8_right_option = 'q8_option'.$getPart1detail->q8_answere;
        $q9_right_option = 'q9_option'.$getPart1detail->q9_answere;
        $q10_right_option = 'q10_option'.$getPart1detail->q10_answere;
        $q11_right_option = 'q11_option'.$getPart1detail->q11_answere;
        
        $q1_response_val = $_REQUEST['p1_q1_response'];
        $q2_response_val = $_REQUEST['p1_q2_response'];
        $q3_response_val = $_REQUEST['p1_q3_response'];
        $q4_response_val = $_REQUEST['p1_q4_response'];
        $q5_response_val = $_REQUEST['p1_q5_response'];
        $q6_response_val = $_REQUEST['p1_q6_response'];
        $q7_response_val = $_REQUEST['p1_q7_response'];
        $q8_response_val = $_REQUEST['p1_q8_response'];
        $q9_response_val = $_REQUEST['p1_q9_response'];
        $q10_response_val = $_REQUEST['p1_q10_response'];
        $q11_response_val = $_REQUEST['p1_q11_response'];
        
        /*echo $getTestdetail->$q1_right_option;die;
        echo $getTestdetail->$_REQUEST['q1_response'];die;*/
        
        $part1result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part1_code,
            'test_name'=>'Part 1: Reading Correspondence',
            'response_data'=>array(
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q1',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q1_response'],
                            'q_response_val' => $getPart1detail->$q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>$getPart1detail->$q1_right_option,
                            ),
    
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q2_response'],
                            'q_response_val' => $getPart1detail->$q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>$getPart1detail->$q2_right_option,
                            ),
    
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q3_response'],
                            'q_response_val' => $getPart1detail->$q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>$getPart1detail->$q3_right_option,
                            ),
    
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q4',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q4_response'],
                            'q_response_val' => $getPart1detail->$q4_response_val,
                            'q_right_option'=>$q4_right_option,
                            'q_right_option_val'=>$getPart1detail->$q4_right_option,
                            ),
    
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q5',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q5_response'],
                            'q_response_val' => $getPart1detail->$q5_response_val,
                            'q_right_option'=>$q5_right_option,
                            'q_right_option_val'=>$getPart1detail->$q5_right_option,
                            ),
    
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q6',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q6_response'],
                            'q_response_val' => $getPart1detail->$q6_response_val,
                            'q_right_option'=>$q6_right_option,
                            'q_right_option_val'=>$getPart1detail->$q6_right_option,
                            ),
    
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q7',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q7_response'],
                            'q_response_val' => $getPart1detail->$q7_response_val,
                            'q_right_option'=>$q7_right_option,
                            'q_right_option_val'=>$getPart1detail->$q7_right_option,
                            ),
    
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q8',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q8_response'],
                            'q_response_val' => $getPart1detail->$q8_response_val,
                            'q_right_option'=>$q8_right_option,
                            'q_right_option_val'=>$getPart1detail->$q8_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q9',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q9_response'],
                            'q_response_val' => $getPart1detail->$q9_response_val,
                            'q_right_option'=>$q9_right_option,
                            'q_right_option_val'=>$getPart1detail->$q9_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q10',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q10_response'],
                            'q_response_val' => $getPart1detail->$q10_response_val,
                            'q_right_option'=>$q10_right_option,
                            'q_right_option_val'=>$getPart1detail->$q10_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Part 1: Reading Correspondence - Q11',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p1_q11_response'],
                            'q_response_val' => $getPart1detail->$q11_response_val,
                            'q_right_option'=>$q11_right_option,
                            'q_right_option_val'=>$getPart1detail->$q11_right_option,
                            ),
        ));
        
        //echo "<pre>";print_r($part1result);die;
        
        
        $getPart2detail = $this->my_model->checkARecord('system_reading_part2_code','test_code',$getTestCodeDetail->part2_code);

        //echo "<pre>";print_r($getPart2detail);die;
        
        $q1_right_option = 'q1_option'.$getPart2detail->q1_answere;
        $q2_right_option = 'q2_option'.$getPart2detail->q2_answere;
        $q3_right_option = 'q3_option'.$getPart2detail->q3_answere;
        $q4_right_option = 'q4_option'.$getPart2detail->q4_answere;
        $q5_right_option = 'q5_option'.$getPart2detail->q5_answere;
        $q6_right_option = 'q6_option'.$getPart2detail->q6_answere;
        $q7_right_option = 'q7_option'.$getPart2detail->q7_answere;
        $q8_right_option = 'q8_option'.$getPart2detail->q8_answere;
        
        $q1_response_val = $_REQUEST['p2_q1_response'];
        $q2_response_val = $_REQUEST['p2_q2_response'];
        $q3_response_val = $_REQUEST['p2_q3_response'];
        $q4_response_val = $_REQUEST['p2_q4_response'];
        $q5_response_val = $_REQUEST['p2_q5_response'];
        $q6_response_val = $_REQUEST['p2_q6_response'];
        $q7_response_val = $_REQUEST['p2_q7_response'];
        $q8_response_val = $_REQUEST['p2_q8_response'];
        
    
        
        $part2result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part2_code,
            'test_name'=>'Reading Part 2: Reading to Apply a Diagramy',
            'response_data'=>array(

                            array(
                            'q_number'=>'Reading Part 2: Reading to Apply a Diagram - Q1',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q1_response'],
                            'q_response_val' => $getPart2detail->$q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>$getPart2detail->$q1_right_option,
                            ),

                            array(
                            'q_number'=>'Reading Part 2: Reading to Apply a Diagram - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q2_response'],
                            'q_response_val' => $getPart2detail->$q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>$getPart2detail->$q2_right_option,
                            ),

                            array(
                            'q_number'=>'Reading Part 2: Reading to Apply a Diagram - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q3_response'],
                            'q_response_val' => $getPart2detail->$q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>$getPart2detail->$q3_right_option,
                            ),

                            array(
                            'q_number'=>'Reading Part 2: Reading to Apply a Diagram - Q4',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q4_response'],
                            'q_response_val' => $getPart2detail->$q4_response_val,
                            'q_right_option'=>$q4_right_option,
                            'q_right_option_val'=>$getPart2detail->$q4_right_option,
                            ),

                            array(
                            'q_number'=>'Reading Part 2: Reading to Apply a Diagram - Q5',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q5_response'],
                            'q_response_val' => $getPart2detail->$q5_response_val,
                            'q_right_option'=>$q5_right_option,
                            'q_right_option_val'=>$getPart2detail->$q5_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 2: Reading to Apply a Diagram - Q6',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q6_response'],
                            'q_response_val' => $getPart2detail->$q6_response_val,
                            'q_right_option'=>$q6_right_option,
                            'q_right_option_val'=>$getPart2detail->$q6_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 2: Reading to Apply a Diagram - Q7',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q7_response'],
                            'q_response_val' => $getPart2detail->$q7_response_val,
                            'q_right_option'=>$q6_right_option,
                            'q_right_option_val'=>$getPart2detail->$q7_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 2: Reading to Apply a Diagram - Q8',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p2_q8_response'],
                            'q_response_val' => $getPart2detail->$q8_response_val,
                            'q_right_option'=>$q8_right_option,
                            'q_right_option_val'=>$getPart2detail->$q8_right_option,
                            ),

        ));
        
        //echo "<pre>";print_r($part2result);die;
        
        
        $getPart3detail = $this->my_model->checkARecord('system_reading_part3_code','test_code',$getTestCodeDetail->part3_code);
        
        //echo "<pre>";print_r($getPart3detail);die;
        
        $q1_right_option = $getPart3detail->q1_answere;
        $q2_right_option = $getPart3detail->q2_answere;
        $q3_right_option = $getPart3detail->q3_answere;
        $q4_right_option = $getPart3detail->q4_answere;
        $q5_right_option = $getPart3detail->q5_answere;
        $q6_right_option = $getPart3detail->q6_answere;
        $q7_right_option = $getPart3detail->q7_answere;
        $q8_right_option = $getPart3detail->q8_answere;
        $q9_right_option = $getPart3detail->q9_answere;
        
        $q1_response_val = $_REQUEST['p3_q1_response'];
        $q2_response_val = $_REQUEST['p3_q2_response'];
        $q3_response_val = $_REQUEST['p3_q3_response'];
        $q4_response_val = $_REQUEST['p3_q4_response'];
        $q5_response_val = $_REQUEST['p3_q5_response'];
        $q6_response_val = $_REQUEST['p3_q6_response'];
        $q7_response_val = $_REQUEST['p3_q7_response'];
        $q8_response_val = $_REQUEST['p3_q8_response'];
        $q9_response_val = $_REQUEST['p3_q9_response'];
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $part3result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part2_code,
            'test_name'=>'Reading Part 3: Reading for Information Answer Key',
            'response_data'=>array(
                            array(
                            'q_number'=>'Reading Part 3: Reading for Information - Q1',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q1_response'],
                            'q_response_val' => $q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>ucfirst($q1_right_option),
                            ),
        
                            array(
                            'q_number'=>'Reading Part 3: Reading for Information - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q2_response'],
                            'q_response_val' => $q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>ucfirst($q2_right_option),
                            ),
        
                            array(
                            'q_number'=>'Reading Part 3: Reading for Information - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q3_response'],
                            'q_response_val' => $q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>ucfirst($q3_right_option),
                            ),
        
                            array(
                            'q_number'=>'Reading Part 3: Reading for Information - Q4',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q4_response'],
                            'q_response_val' => $q4_response_val,
                            'q_right_option'=>$q4_right_option,
                            'q_right_option_val'=>ucfirst($q4_right_option),
                            ),
        
                            array(
                            'q_number'=>'Reading Part 3: Reading for Information - Q5',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q5_response'],
                            'q_response_val' => $q5_response_val,
                            'q_right_option'=>$q5_right_option,
                            'q_right_option_val'=>ucfirst($q5_right_option),
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 3: Reading for Information - Q6',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q6_response'],
                            'q_response_val' => $q6_response_val,
                            'q_right_option'=>$q6_right_option,
                            'q_right_option_val'=>ucfirst($q6_right_option),
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 3: Reading for Information - Q7',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q7_response'],
                            'q_response_val' => $q7_response_val,
                            'q_right_option'=>$q7_right_option,
                            'q_right_option_val'=>ucfirst($q7_right_option),
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 3: Reading for Information - Q8',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q8_response'],
                            'q_response_val' => $q8_response_val,
                            'q_right_option'=>$q8_right_option,
                            'q_right_option_val'=>ucfirst($q8_right_option),
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 3: Reading for Information - Q9',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p3_q9_response'],
                            'q_response_val' => $q9_response_val,
                            'q_right_option'=>$q9_right_option,
                            'q_right_option_val'=>ucfirst($q9_right_option),
                            ),
        
        ));
        //echo "<pre>"; print_r($part3result);die;
        $getPart4detail = $this->my_model->checkARecord('system_reading_part4_code','test_code',$getTestCodeDetail->part4_code);
        
        //echo "<pre>"; print_r($getPart4detail);die;
        
        $q1_right_option = 'q1_option'.$getPart4detail->q1_answere;
        $q2_right_option = 'q2_option'.$getPart4detail->q2_answere;
        $q3_right_option = 'q3_option'.$getPart4detail->q3_answere;
        $q4_right_option = 'q4_option'.$getPart4detail->q4_answere;
        $q5_right_option = 'q5_option'.$getPart4detail->q5_answere;
        $q6_right_option = 'q6_option'.$getPart4detail->q6_answere;
        $q7_right_option = 'q7_option'.$getPart4detail->q7_answere;
        $q8_right_option = 'q8_option'.$getPart4detail->q8_answere;
        $q9_right_option = 'q9_option'.$getPart4detail->q9_answere;
        $q10_right_option = 'q10_option'.$getPart4detail->q10_answere;
        
        $q1_response_val = $_REQUEST['p4_q1_response'];
        $q2_response_val = $_REQUEST['p4_q2_response'];
        $q3_response_val = $_REQUEST['p4_q3_response'];
        $q4_response_val = $_REQUEST['p4_q4_response'];
        $q5_response_val = $_REQUEST['p4_q5_response'];
        $q6_response_val = $_REQUEST['p4_q6_response'];
        $q7_response_val = $_REQUEST['p4_q7_response'];
        $q8_response_val = $_REQUEST['p4_q8_response'];
        $q9_response_val = $_REQUEST['p4_q9_response'];
        $q10_response_val = $_REQUEST['p4_q10_response'];
        
        //echo $getPart4detail->$q1_right_option;die;
        //echo $getPart4detail->$_REQUEST['q1_response'];die;
        
        $part4result = array(

            'test_id'=>$testdetail->test_id,
            'test'=>$getTestCodeDetail->part4_code,
            'test_name'=>'Reading Part 4: Reading for Viewpoints Answer Key',
            'response_data'=>array(
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q1',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q1_response'],
                            'q_response_val' => $getPart4detail->$q1_response_val,
                            'q_right_option'=>$q1_right_option,
                            'q_right_option_val'=>$getPart4detail->$q1_right_option,
                            ),
        
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q2',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q2_response'],
                            'q_response_val' => $getPart4detail->$q2_response_val,
                            'q_right_option'=>$q2_right_option,
                            'q_right_option_val'=>$getPart4detail->$q2_right_option,
                            ),
        
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q3',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q3_response'],
                            'q_response_val' => $getPart4detail->$q3_response_val,
                            'q_right_option'=>$q3_right_option,
                            'q_right_option_val'=>$getPart4detail->$q3_right_option,
                            ),
        
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q4',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q4_response'],
                            'q_response_val' => $getPart4detail->$q4_response_val,
                            'q_right_option'=>$q4_right_option,
                            'q_right_option_val'=>$getPart4detail->$q4_right_option,
                            ),
        
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q5',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q5_response'],
                            'q_response_val' => $getPart4detail->$q5_response_val,
                            'q_right_option'=>$q5_right_option,
                            'q_right_option_val'=>$getPart4detail->$q5_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q6',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q6_response'],
                            'q_response_val' => $getPart4detail->$q6_response_val,
                            'q_right_option'=>$q6_right_option,
                            'q_right_option_val'=>$getPart4detail->$q6_right_option,
                            ),
        
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q7',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q7_response'],
                            'q_response_val' => $getPart4detail->$q7_response_val,
                            'q_right_option'=>$q7_right_option,
                            'q_right_option_val'=>$getPart4detail->$q7_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q8',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q8_response'],
                            'q_response_val' => $getPart4detail->$q8_response_val,
                            'q_right_option'=>$q8_right_option,
                            'q_right_option_val'=>$getPart4detail->$q8_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q9',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q9_response'],
                            'q_response_val' => $getPart4detail->$q9_response_val,
                            'q_right_option'=>$q9_right_option,
                            'q_right_option_val'=>$getPart4detail->$q9_right_option,
                            ),
                            
                            array(
                            'q_number'=>'Reading Part 4: Reading for Viewpoints - Q10',
                            'q_response_type'=>'text',
                            'q_response' => $_REQUEST['p4_q10_response'],
                            'q_response_val' => $getPart4detail->$q10_response_val,
                            'q_right_option'=>$q10_right_option,
                            'q_right_option_val'=>$getPart4detail->$q10_right_option,
                            ),
        ));
        //echo "<pre>"; print_r($part4result);die;
        $result = array($part1result,$part2result,$part3result,$part4result);
        
        $json_result = json_encode($result,true);

        //echo "<pre>"; print_r($result); exit();
        
        $qryData = array(
            'time' => time(),
            'testid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->my_model->insertDataIntoTable('system_section_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_section_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
        
    }
    
    function viewSectionReadingReport($id){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord("system_section_testdetails_code", 'id_md5', $id);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->my_model->checkARecord('system_listening_section_wise_code', 'id', $this->data['testdetail']->test_id);

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->my_model->checkARecord('system_section_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $id = $this->data['testdetail']->id;
        $table = 'system_listening_section_wise_code';
        $where = "id = '$id'";
        $this->data['test'] = $this->my_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;
        
        
        $this->load->view('member/view_section_reading_report', $this->data);
    }
    
    function comprehensionTest() {
        $this->verifyUser();

        # Show all comprehension tests
        $this->data['member_id'] = $this->data['user']->id;
        $where = "id != '0' ";
        $this->data['tests'] = $this->my_model->getWhereOrderRecords('system_comprehension_test_code', $where, 'id', 'asc');
        $this->data['total'] = count($this->data['tests']);

        //echo "<pre>";print_r($this->data['tests']);die;
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Comprehension Tests';
        $this->load->view('member/comprehensionList', $this->data);
    }
    
    /*
    * Start a new test
    */
    function accessComprehensionTest() {
        //echo "<pre>";print_r($_POST);die;
        $testid = $this->input->post('testid');
        $memberid = $this->input->post('memberid');
        $objTest = $this->my_model->getARecord('system_comprehension_test_code', $testid);
        
        $objMember = $this->my_model->getARecord('system_member_code', $memberid);
        if($objMember->coins <= 0){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < 5)){
            $response = array(
                'result' => 'error',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }
        //echo "<pre>";print_r($objTest);die;
        if( is_object($objTest)) {

            $qryData = array(
                'test_id' => $testid,
                'member_id' => $memberid,
                'time' => time(),
                'created_at'=> date('Y-m-d H:i:s')
            );
            //echo "<pre>";print_r($qryData);die;
            if( $this->my_model->insertDataIntoTable('system_comprehension_testdetails_code', $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();
                //echo $last_added_id;die;
                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable('system_comprehension_testdetails_code', $updateData, $last_added_id);
                
                //CHARGE COIN COST
                $objMember = $this->my_model->getARecord('system_member_code', $memberid);  
                $balance_coins = $objMember->coins - 5;
                $updateMemCoins = array('coins'=>$balance_coins);
                $this->my_model->updateTable('system_member_code', $updateMemCoins, $memberid);
                
                $coin_data = array('user_id'=>$memberid,
                    'user_type'=>'member',
                    'description'=>"Comprehension Cost test",
                    'debit_coin'=>5,
                    'balance_coin'=>$balance_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->my_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                
                // Add entry here
                $response = array(
                    'result' => 'success',
                    'message' => 'Test Started',
                    'tdcode' => $id_md5, // test details code
                    //'tcode' => $objTest->id_md5 // test code
                );
                
            }

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }
        
        // Return ajax response as json
        echo json_encode ($response) ;
    }
    
    /*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function testComprehensionProgress($tdId_md5) {
        $this->verifyUser();
        
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord('system_comprehension_testdetails_code', 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        $check_test = $this->my_model->checkARecord('system_comprehension_test_code', 'id', $this->data['testdetail']->test_id);
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }
        
        //echo "<pre>";print_r($check_test);die;
        
        
        $this->data['test'] = $check_test;
        //echo "<pre>";print_r($this->data['test']);die;
        if(!empty($this->data['test'])){
            $this->load->view('member/comprehension_test_play',$this->data);
        }else{
            redirect('member/getTestList');
        }
    }
    
    function comprehensionSubmit(){
        $this->verifyUser();
        $testdetail = $this->my_model->checkARecord('system_comprehension_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->my_model->checkARecord('system_comprehension_test_code','id',$testdetail->test_id);
        $q1_right_option = 'q1_option'.$getTestdetail->q1_answere;
        $q2_right_option = 'q2_option'.$getTestdetail->q2_answere;
        $q3_right_option = 'q3_option'.$getTestdetail->q3_answere;
        $q4_right_option = 'q4_option'.$getTestdetail->q4_answere;
        $q5_right_option = 'q5_option'.$getTestdetail->q5_answere;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];
        
        $result = array('test_id'=>$testdetail->test_id,'test_name'=>'Comprehension test Answer Key','response_data'=>array(
        array('q_number'=>'Comprehension test - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $getTestdetail->$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'Comprehension test - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $getTestdetail->$q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'Comprehension test - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $getTestdetail->$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
        
        array('q_number'=>'Comprehension test - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $getTestdetail->$q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$getTestdetail->$q4_right_option),
        
        array('q_number'=>'Comprehension test - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $getTestdetail->$q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$getTestdetail->$q5_right_option)));
        //echo "<pre>";print_r($result);die;
        
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => $testdetail->test_id,
            'memberid' => $this->data['user']->id,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
        //echo "<pre>";print_r($qryData);die;
        if( $this->my_model->insertDataIntoTable('system_comprehension_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->my_model->updateTable('system_comprehension_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function viewComprehensionReport($id){
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        //$this->data['pagetitle'] = $this->data['test']->test_name;

        $this->data['testdetail'] = $this->my_model->checkARecord("system_comprehension_testdetails_code", 'id_md5', $id);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->my_model->checkARecord('system_comprehension_test_code', 'id', $this->data['testdetail']->test_id);

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->my_model->checkARecord('system_comprehension_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $this->data['test'] = $check_test;
        //echo "<pre>";print_r($this->data['test']);die;
        
        $this->load->view('member/view_comprehension_report', $this->data);
    }
    
    
    function forgotPassword() {
        // check website session, if enabled
        if( $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            if($loggedUser['user_role']=='member'){
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }
        
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

           // echo "<pre>";print_r($_POST);die;
            $this->load->model('my_model');
            $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                
                $where = "email = '".$_POST['email']."' ";
                $getUser = $this->my_model->getWhereOrderRecords('system_member_code', $where, 'id', 'asc');
                
                
                
                if(!empty($getUser)){
                    
                    //echo "<pre>";print_r($getUser);die;
                    
                    /* Send account detail email */
                        $password = random_string('alnum', 8);
                        $this->load->library('email');
                        $config = array (
                            'mailtype' => 'html',
                            'charset'  => 'utf-8',
                            'wordwrap' => TRUE,
                            'priority' => '1'
                        );
                        $this->email->initialize($config);
                        $this->email->from($this->app_email, $this->app_name);
                        $this->email->to($this->input->post('email'));
                        #$this->email->cc($this->app_contactemail); // send copy at website contact email address
                        $this->email->subject('Welcome to '.$this->app_name);


                        // send text email
                        $this->email->message('<html><body>
                        <h4>Thanks for forget password!</h4>

                        Your password has been reset, you can login with the following credentials to
                        manage your account.<br> After login you can access CELPIP material on our website.
                        <br><br>

                        Login URL : '.base_url('/login').'<br>
                        Username : '.$getUser[0]->username .'<br>
                        Password : '.$password.'<br><br>
                        

                        <b>Note : </b>if you think this email has reached your inbox by mistake, <a href="'.base_url('contact?Eaddress='.$this->input->post('email').'&reporttoken='.$this->data['rn']).'">please report </a><br>

                        Best Wishes,<br>
                        '.$this->app_name.' Team<br>
                        </html></body>');
                        
                        //echo '<pre>'; print_r($data); echo '</pre>';
                        $this->email->send();
                        //echo $this->email->print_debugger();
                    // @end email
                    
                    $update_password = array('password'=>md5($password),'notMD5password'=>$password);
                    $this->my_model->updateTable('system_member_code', $update_password, $getUser[0]->id);
                    $this->session->set_flashdata('global_msg','Your Password has been reset please check your email for password');
                }else{
                    $this->session->set_flashdata('global_msg','Email is not register please create your account');
                }
                
                redirect($this->data['currentPath'].'/forgotPassword', 'refresh');
            }
        }
        
        $this->data['formAction'] = $this->uri->segment(1). '/' . $this->uri->segment(2);
        $this->load->view('web/forgotPassword', $this->data);
    }
    
    function sampleQuestionList($typeid = '') {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Sample Questions';
        $this->data['test_id'] = '7';

        $this->data['test'] = $this->my_model->getARecord($this->tb_test, '7');

        if( in_array($typeid, array('1','2','3','4')) ) {

           if($typeid==1){
                $this->data['pagetitle'] = 'Speaking Questions';
            }elseif($typeid==2){
                $this->data['pagetitle'] = 'Reading Questions';
            }elseif($typeid==3){
                $this->data['pagetitle'] = 'Listening Questions';
            }elseif($typeid==4){
                $this->data['pagetitle'] = 'Writing Questions';
            }

            // Speaking
            $where = "PTEtypeid = '1' ";
            $this->data['speaking'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');

            // Writing
            $where = "PTEtypeid = '4' ";
            $this->data['writing'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');

            // Reading
            $where = "PTEtypeid = '2' ";
            $this->data['reading'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');

            // Listening
            $where = "PTEtypeid = '3' AND active = 'Yes' ";
            $this->data['listening'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');
        
        } else {

            exit($this->unauthorized_message);
        }

        $this->data['typeid'] = $typeid;

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
    
    function getTimerTestList($id){
        
        $this->verifyUser();
        $check_test = $this->my_model->checkARecord('system_PTEsubtype_code', 'id', $id);
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['coins'] = $this->my_model->getARecord("system_PTEsubtype_code",$id);

        $this->data['test_type_id'] = $this->data['coins']->PTEtypeid;
        //echo $this->data['test_type_id'];
        
        $this->data['member_id'] = $this->data['user']->id;
        $this->data['test_id'] = $id;
        
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $check_test->PTEsubtype;
        
        $this->data['gettest'] = array();
        
        if($id==29){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_listening_MCsingle_code', $where, 'id', 'asc',$limit,$start);
        }
        
        if($id==20){ 
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_listening_part1_code', $where, 'id', 'asc',$limit,$start);
        }
        
        if($id==19){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_listening_part2_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==18){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_listening_part3_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==11){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part1_MCOA_code', $where, 'id', 'asc',$limit ,$start);

            /*echo "<pre>";
            print_r($this->data['gettest']);*/
        }
        
        if($id==14){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part1_LOM_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==15){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_listening_part6_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==47){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_writing_task1_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==46){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_writing_task2_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==59){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_speaking_practice_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==58){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_speaking_part1_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==61){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_part6_TAPE_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==56){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_speaking_part3_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==55){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_speaking_part4_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==54){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_speaking_part5_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==53){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_speaking_part6_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==52){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_speaking_part7_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==51){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_speaking_part8_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==40){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_reading1_40_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==39){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_reading_part1_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==38){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_reading_part2_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==37){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_reading_part3_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==36){
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $where = "id != '0'";
            $this->data['gettest'] = $this->my_model->getWhereOrderLimitRecords('system_reading_part4_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        $this->load->view('member/getTimerTestList', $this->data);
    }
}