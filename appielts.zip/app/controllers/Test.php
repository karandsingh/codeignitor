<?php

    function sampleTest($id, $test_id_md5, $page='1') {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                'testid' => $this->data['test']->id,
                'status' => 'Active',
                'PTEsubtypeid' => $this->data['subtype']->id,
            );
            $this->sortby = 'id'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, $this->tb_question );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 5;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination

        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, $this->tb_question );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        $this->data['reporturl'] = base_url('member/sampleQResult/'.$id.'/'.$test_id_md5);


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Sample Test';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }