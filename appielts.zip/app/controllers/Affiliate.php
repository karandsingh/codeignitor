<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Member controller
* this controller is related to specific user role
*/
class Affiliate extends AKAAL_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Webservice_model'); 
		$this->data['rn'] = random_string('nozero',8);
		$this->load->library('email');     		
	}

    public function index()
	{
		echo 'working';die;
		$this->load->view('welcome_message');
	}
	
	  public function getaffiliatedata(){
     $token=$_REQUEST['api_token'];
     $where="token_md5='$token' ";
      $check_pass=  $this->Webservice_model->checkARecord('system_api_token_code', 'token_md5',$token);
      if(!empty($check_pass))
       {
          
           $where1="id !='0' ";
        $affiliate_details = $this->Webservice_model->getWhereRecords('system_affiliate_code', $where1);
         if(!empty($affiliate_details)){
             			foreach($affiliate_details as $affiliate){

             	$array[] = array('network'=>'ielts24x7',
             	'student_id'=>$affiliate->student_code,
             	'username'=>$affiliate->username,
							'created_date'=>date("d-m-Y",$affiliate->created_time),
							'city_region'=>$affiliate->city_region,
							'affiliate_reference_no'=>$affiliate->affiliate_reference_no,
							);
			}
			$result_array = array('response'=>1,'message' => 'Get list successfully','data'=>$array);
		}else{
			$result_array = array('response'=>0,'message' => 'No test found');
		}
       }
		echo json_encode($result_array);
	    exit();
}


	  public function affiliatetransactiondata(){
     $token=$_REQUEST['api_token'];
     $where="token_md5='$token' ";
      $check_pass=  $this->Webservice_model->checkARecord('system_api_token_code', 'token_md5',$token);
      if(!empty($check_pass))
       {
          
           $where1="id !='0' ";
        $affiliate_details = $this->Webservice_model->getWhereRecords('system_affiliate_transaction_code', $where1);
         if(!empty($affiliate_details)){
             			foreach($affiliate_details as $affiliate){

             	$array[] = array('network'=>'ielts24x7',
             	'student_id'=>$affiliate->user_id,
							'transaction_date'=>$affiliate->created_date,
							'plan'=>$affiliate->plan_type,
							'affiliate_reference_no'=>$affiliate->affiliate_reference_no,
							);
			}
			$result_array = array('response'=>1,'message' => 'Get list successfully','data'=>$array);
		}else{
			$result_array = array('response'=>0,'message' => 'No test found');
		}
       }
		echo json_encode($result_array);
	    exit();
}
}