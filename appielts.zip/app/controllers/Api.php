 <?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Member controller
* this controller is related to specific user role
*/
class Api extends AKAAL_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Webservice_model');   
		$this->data['number_of_visible_questions']='100';
	}

    public function index()
	{
		echo 'working';die;
		$this->load->view('welcome_message');
	}
	
	
public function register()
	{
		//echo "<pre>";print_r($_REQUEST);die;
		
		
		$email=$_REQUEST['email'];
		$username=$_REQUEST['username'];
		 $checkemail = "email = '".$email."'";
		 $getemail = $this->Webservice_model->getWhereRecords('system_member_code', $checkemail);
		 if(!empty($getemail))
		 { 
		     $response = array(
                'response' => '0',
                'message' => 'Email already exist!!'
                        );
            echo json_encode ($response) ;
		 }else{
		     $checkuser = "username = '".$username."'";
		     $getusername = $this->Webservice_model->getWhereRecords('system_member_code', $checkuser);
		 if(!empty($getusername))
		 { 
		     $response = array(
                'response' => '0',
                'message' => 'Username already exist!!'
                        );
            echo json_encode ($response) ;
		 }else{
		 

		//if($this->form_validation->run() == TRUE) {
			//echo "<pre>";print_r($_REQUEST);die;
			$student_reference_no = '';
			$tycoon_reference_no = '';
			$get_coins = '100';
			$description = 'By Register';
			
			$where = 'id != 0';
			$get_last_stu_code = $this->Webservice_model->getWhereLastRecords('system_member_code', $where);
			
			$reference_no = $_REQUEST['reference_no'];
			if(!empty($reference_no)){
				$firstCharacter = substr($reference_no, 0, 1);
				if($firstCharacter=='T'){
					$check_reseller = $this->Webservice_model->checkARecord('system_reseller_code', 'reference_no',$reference_no );
					if(!empty($check_reseller)){
						$tycoon_reference_no = $check_reseller->reference_no;
						$get_coins = '200';
						$description = 'By Tycoon reference Register';
					}
				
				    
                        elseif($firstCharacter == 'B'){
                            //echo $business_reference_no.","; echo $tycoon_reference_no; exit();

                            $check_business = $this->Webservice_model->checkARecord('system_business_code', 'reference_no',$reference_no );
                            if(!empty($check_business)){
                                $business_reference_no = $check_business->reference_no;
                                $tycoon_reference_no = $check_business->reseller_reference_no;
                                $get_coins = '200';
                                $description = 'By Business reference Register';
                                //echo $check_business->reseller_reference_no; exit();
                            }

                            

                        }   elseif($firstCharacter == 'A'){
                            //echo $business_reference_no.","; echo $tycoon_reference_no; exit();

                            $check_business = $_REQUEST['reference_no'];
                            if(!empty($check_business)){
                                $affiliate_reference_no = $check_business;
                                $get_coins = '290';
                                $description = 'By Affiliate reference Register';
                                //echo $check_business->reseller_reference_no; exit();
                            }

                            

                        } 
				}else{
					$check_student_ref = $this->Webservice_model->checkARecord('system_member_code', 'student_code',$reference_no);
					if(!empty($check_student_ref)){
						$student_reference_no = $check_student_ref->student_code;
						$tycoon_reference_no = $check_student_ref->reference_no;
						$get_coins = '200';
						$description = 'By Student reference Register';
						
						$earned_coin = $check_student_ref->coins + 100;
						$stu_earn_coin_data = array('user_id'=>$check_student_ref->id,
							'user_type'=>'member',
							'description'=>'Join Student By Coupon Code',
							'credit_coin'=>'100',
							'balance_coin'=>$earned_coin,
							'created_date'=>date('Y-m-d H:i:s'),
							'updated_at'=>date('Y-m-d H:i:s'),
						);
						$this->Webservice_model->insertDataIntoTable('system_coins_management_code', $stu_earn_coin_data);
						
						$earn_qryData = array(
							'coins' => $earned_coin
						);
						$this->Webservice_model->updateTable('system_member_code', $earn_qryData, $check_student_ref->id);
					}
				}
			}
			
			//$urlkey = url_title($_REQUEST['username'], '-', true);
			$password = random_string('alnum', 8);

			// Default : confirm = yes , role_id = 2 (member)
			$qryData = array(
				'student_code'=>$get_last_stu_code->student_code+1,
				'email' => $_REQUEST['email'],
				'username' => $_REQUEST['username'],
				'password' => md5($password),
				'notMD5password' => $password,
				'confirm' => 'yes', // we are going to Active new user , bcoz we are sending password by email.
				'md5Email' => md5($_REQUEST['email']),
				'created_time' => time(),
				'student_reference_no' => $student_reference_no,
				'reference_no' => $tycoon_reference_no,
				'coins'=>$get_coins
			);

			if( $this->Webservice_model->insertDataIntoTable('system_member_code', $qryData) ) {
				$this->data['success'] = true;
				$last_added_id = $this->db->insert_id();
				
				$coin_data = array('user_id'=>$last_added_id,
					'user_type'=>'member',
					'description'=>$description,
					'credit_coin'=>$get_coins,
					'balance_coin'=>$get_coins,
					'created_date'=>date('Y-m-d H:i:s'),
					'updated_at'=>date('Y-m-d H:i:s'),
				);
				$this->Webservice_model->insertDataIntoTable('system_coins_management_code', $coin_data);
				
				
				if(!empty($affiliate_reference_no)){
                     $affiliatedata = array(
                    'student_code'=>$last_added_id,
                    'email' => $email,
                    'username' => $username,
                    'password' => md5($password),
                    'notMD5password' => $password,
                    'confirm' => 'yes', // we are going to Active new user , bcoz we are sending password by email.
                    'md5Email' => md5($email),
                    'created_time' => time(),

                    'affiliate_reference_no' => $affiliate_reference_no,
                    'coins'=>$get_coins,
					'country_id'=>$country_id,
					'city_region'=>$city,
					'ip_address'=>$_SERVER['REMOTE_ADDR']
                );
                $this->Webservice_model->insertDataIntoTable('system_affiliate_code', $affiliatedata);
               
               }
               
               
	    
	    
	    
	    
	    
				        $this->load->library('email');
                        $config = array (
                            'mailtype' => 'html',
                            'charset'  => 'utf-8',
                            'wordwrap' => TRUE,
                            'priority' => '1'
                        );
                        $this->email->initialize($config);
                        $this->email->from($this->app_email, $this->app_name);
                        $this->email->to($_REQUEST['email']);
                        #$this->email->cc($this->app_contactemail); // send copy at website contact email address
                        $this->email->subject('Welcome to '.$this->app_name);


                        // send text email
                        $this->email->message('<html><body>
                        <h4>Thanks for signing up!</h4>

                        Your account has been created, you can login with the following credentials to
                        manage your account.<br> After login you can access CELPIP material on our website.
                        <br><br>

                        Login URL : '.base_url('/login').'<br>
                        Username : '.$_REQUEST['username'].'<br>
                        password : '.$password.'<br>
         
                        <b>Note : </b>if you think this email has reached your inbox by mistake, <a href="'.base_url('contact?Eaddress='.$_REQUEST['email']).'">please report </a><br>

                        Best Wishes,<br>
                        '.$this->app_name.' Team<br>
                        </html></body>');
                        
                        //echo '<pre>'; print_r($data); echo '</pre>';
                      $result= $this->email->send();
                 
	
				$result_array = array('response'=>1,'message' => "User has been register success",);
				
				
				
				     

                }
            /* }else{
				
				
				$errorArray = $this->form_validation->error_array();
				echo "<pre>";print_r($errorArray);die;
			    foreach($errorArray as $error)
			    {
					$result_array = array('response'=>0,'message' => $error);
					goto a;
			    }
			} */
        
		
		//a:
		echo json_encode($result_array);
       
	}
	              
	}
	}
	
	
	function login() {
		
		//echo "<pre>";print_r($_REQUEST);die;
		$username = $_REQUEST['username'];
		$password = $_REQUEST['password'];
        $result = $this->Webservice_model->getUser('system_member_code', $username, $password);
        if($result)
        {
			$session_array = array();
            foreach($result as $row)
            {
                if($row->status==0){
					$result_array = array('response'=>0,'message' => 'Your account has been blocked please contact support team !');
					goto a;
				}
				
				$session_array = array(
                    'id' => $row->id,
                    'coupon_code' => $row->student_code,
                    'coins' => $row->coins,
                    'username' => $row->username
                );
				
				$getudata = $this->Webservice_model->getARecord('system_member_code', $row->id);
				if($getudata->get_referred_coins==1 && $getudata->student_reference_no != 0){
					$check_student_ref = $this->Webservice_model->checkARecord('system_member_code', 'student_code',$row->student_reference_no);
					if(!empty($check_student_ref)){
						$get_coins = '100';
						$description = 'By Student reference Register';
						
						$earned_coin = $check_student_ref->coins + 100;
						$stu_earn_coin_data = array(
							'user_id'=>$check_student_ref->id,
							'user_type'=>'member',
							'description'=>'New Student Referral',
							'credit_coin'=>'100',
							'balance_coin'=>$earned_coin,
							'created_date'=>date('Y-m-d H:i:s'),
							'updated_at'=>date('Y-m-d H:i:s'),
						);
						$this->Webservice_model->insertDataIntoTable('system_coins_management_code', $stu_earn_coin_data);
						
						$earn_qryData = array(
							'coins' => $earned_coin
						);
						$this->Webservice_model->updateTable('system_member_code', $earn_qryData, $check_student_ref->id);
						
						$qryData = array(
							'get_referred_coins' => '0'
						);
						$this->Webservice_model->updateTable('system_member_code', $qryData, $row->id);
					}
				}
				$data="data";
				$result_array = array('response'=>1,'message'=>'Account has been login successfully',$data=>$session_array);
            }

		}else{
			$result_array = array('response'=>0,'message' => 'Invalid username or password');
		}
		a:
		echo json_encode($result_array);
	    exit();
    }
	
	
	public function testlisting()
	{   
	    $ieltstestid=$_REQUEST['ieltstestid'];
		$where = "PTEtypeid = $ieltstestid";
        $getTest = $this->Webservice_model->getWhereRecords('system_PTEsubtype_code', $where);
		//echo "<pre>";print_r($getTest);die;
		if(!empty($getTest)){
			foreach($getTest as $test){
				$array[] = array('id'=>$test->id,
							'PTEsubtype'=>$test->PTEsubtype,
							'coin_cost'=>$test->coin_cost,
							'total_test'=>$test->total_test,
							);
			}
			$result_array = array('response'=>1,'message' => 'Get list successfully','data'=>$array);
		}else{
			$result_array = array('response'=>0,'message' => 'No test found');
		}
		echo json_encode($result_array);
	    exit();
	}
	
		 function getfile($image_path)
	 {
     require 'aws-s3-bucket/vendor/autoload.php';

  
    $BUCKET_NAME = 'celpipstore-media-files';
    $IAM_KEY = 'AKIA323GRW63FBO3HGTM';
    $IAM_SECRET = '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';
    
    
    $this->load->library('S3'); //load S3 library

    //S3 connection 
    $s3 = new Aws\S3\S3Client(
    array(
    'credentials' => array(
    'key' => $IAM_KEY,
    'secret' => $IAM_SECRET
    ),
    'version' => 'latest',
    'region'  => 'us-west-2'
    )
    );
    $keyPath = 'ielts/uploads/'.$image_path; // file name(can also include the folder name and the file name. eg."member1/IoT-Arduino-Monitor-circuit.png")
    //S3 connection 
    $fileName = $image_path;
    
    $command = $s3->getCommand('GetObject', array(
    'Bucket'      => $BUCKET_NAME,
    'Key'         => $keyPath,
    'ContentType' => 'image/png/mp3/mp4/audio/mpeg',
    'ResponseContentDisposition' => 'attachment; filename="'.$fileName.'"'
    ));
    $signedUrl = $s3->createPresignedRequest($command, "+6 days"); 
    // Create a signed URL from the command object that will last for
    // 6 days from the current time
    $presignedUrl = (string)$signedUrl->getUri();
   // echo file_get_contents($presignedUrl);
       $data['message']   = "sucess";
       $data['imageurl'] = $presignedUrl;
             return $data;

 }

	
    public function changepassword() {
      
        $member_id=$_REQUEST['member_id'];
        $oldpassword=$_REQUEST['old_password'];
        $newpassword=$_REQUEST['new_password'];

        
        $where = "id = '".$member_id."' AND notMD5password = '". $oldpassword."'";
        $getuser = $this->Webservice_model->getWhereRecords('system_member_code',$where);
        if(!empty($getuser)){
            $updatepass = array(
            'password'=>md5($newpassword),
            'notMD5password'=>$newpassword,);
                if($this->Webservice_model->updateTable('system_member_code', $updatepass,$member_id))
                
                {
			$result_array = array('response'=>1,'message' => 'Password changed',);
		echo json_encode($result_array);
            
            
                }
            $response=array("message"=>'password changed');
        }else{
            $response = array('response'=>0,'message' => 'Your password is incorrect',);
            
        }
        echo json_encode($response);
    }
    
    
    
     function account() {
        $member_id=$_REQUEST['member_id'];
        $where = "student_code = '". $member_id."'";
        $getuser = $this->Webservice_model->getWhereRecords('system_member_code',$where);
        if(!empty($getuser)){
            $response = array('response'=>1,'data' =>$getuser,);}
            echo json_encode($response);

    }
    
    
     public function testcoins(){
        $where = "user_id = '". $_REQUEST['member_id'] ."' AND user_type = 'member'";
        $this->data['history'] = $this->Webservice_model->getWhereOrderRecords('system_coins_management_code', $where, 'id', 'desc');
         if(!empty($this->data['history'])){
            $response = array('response'=>1,'data' =>$this->data['history'],);}
            echo json_encode($response);
     }
     
     
     
     
     
      
    function editProfile() {

                
                $qryData = array(
                    'name' => $_REQUEST['name'],
                    'mobile' => $_REQUEST['mobile'], 
                    'street_address' => $_REQUEST['street_address'],
                    'city_region' =>$_REQUEST['city_region'],
                    'country_id' =>$_REQUEST['country_id'],
                    'postal_code' =>$_REQUEST['postal_code']
                    );
                
                if( $this->Webservice_model->updateTable('system_member_code', $qryData, $_REQUEST['member_id'] ))
                {
                        $response = array('response'=>1,'message' =>"Your account has been updated",);
                    
                }
            echo json_encode($response);

    }
	
    
	public function ptetestlisting()
	{   

		$where = "id !='0'";
        $getTest = $this->Webservice_model->getWhereRecords('system_PTEtype_code', $where);
		//echo "<pre>";print_r($getTest);die;
		if(!empty($getTest)){
			foreach($getTest as $test){
				$array[] = array('id'=>$test->id,
							'PTEsubtype'=>$test->PTEtype,
							);
			}
			$result_array = array('response'=>1,'message' => 'Get list successfully','data'=>$array);
		}else{
			$result_array = array('response'=>0,'message' => 'No test found');
		}
		echo json_encode($result_array);
	    exit();
	}
	
	

	public function speakingTest()
	{
		$where = "PTEtypeid = '6' ";
        $getTest = $this->Webservice_model->getWhereRecords('system_PTEsubtype_code', $where);
		if(!empty($getTest)){
			foreach($getTest as $test){
				$array[] = array('id'=>$test->id,
							'PTEsubtype'=>$test->PTEsubtype,
							'coin_cost'=>$test->coin_cost,
							'total_test'=>$test->total_test,
							);
			}
			$result_array = array('response'=>1,'message' => 'Get list successfully','data'=>$array);
		}else{
			$result_array = array('response'=>0,'message' => 'No test found');
		}
		echo json_encode($result_array);
	    exit();
	}
	
	public function academicreadingTest()
	{
		$where = "PTEtypeid = '2' ";
        $getTest = $this->Webservice_model->getWhereRecords('system_PTEsubtype_code', $where);
		if(!empty($getTest)){
			foreach($getTest as $test){
				$array[] = array('id'=>$test->id,
							'PTEsubtype'=>$test->PTEsubtype,
							'coin_cost'=>$test->coin_cost,
							'total_test'=>$test->total_test,
							);
			}
			$result_array = array('response'=>1,'message' => 'Get list successfully','data'=>$array);
		}else{
			$result_array = array('response'=>0,'message' => 'No test found');
		}
		echo json_encode($result_array);
	    exit();
	}
	
	public function academicwritingTest()
	{
		$where = "PTEtypeid = '5' ";
        $getTest = $this->Webservice_model->getWhereRecords('system_PTEsubtype_code', $where);
		//echo "<pre>";print_r($getTest);die;
		if(!empty($getTest)){
			foreach($getTest as $test){
				$array[] = array('id'=>$test->id,
							'PTEsubtype'=>$test->PTEsubtype,
							'coin_cost'=>$test->coin_cost,
							'total_test'=>$test->total_test,
							);
			}
			$result_array = array('response'=>1,'message' => 'Get list successfully','data'=>$array);
		}else{
			$result_array = array('response'=>0,'message' => 'No test found');
		}
		echo json_encode($result_array);
	    exit();
	}
	
	function getTestList(){
		
		$id = $_REQUEST['testId'];
		$this->data['coins'] = $this->Webservice_model->getARecord("system_PTEsubtype_code",$id);

        $this->data['test_type_id'] = $this->data['coins']->PTEtypeid;
        
        $this->data['gettest'] = array();
        
        if($id==16){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part1_FGOWA_code', $where, 'id', 'asc',$limit,$start);
        }
        if($id==15){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part1_FIG_code', $where, 'id', 'asc',$limit,$start);
        }
        if($id==14){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part1_LOM_code', $where, 'id', 'asc',$limit,$start);
        }
        if($id==13){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part1_MH_code', $where, 'id', 'asc',$limit ,$start);
        }
         if($id==12){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part1_MCMTOA_code', $where, 'id', 'asc',$limit ,$start);
        }
        if($id==11){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part1_MCOA_code', $where, 'id', 'asc',$limit ,$start);

            /*echo "<pre>";
            print_r($this->data['gettest']);*/
        }
        
      
     
        
        if($id==22){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_MCMTOA_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==23){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_II_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        
        if($id==24){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_NC_code', $where, 'id', 'asc',$limit ,$start);
        }
         if($id==25){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_MH_code', $where, 'id', 'asc',$limit,$start);
        } if($id==26){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_SC_code', $where, 'id', 'asc',$limit,$start);
        } if($id==27){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_SCA_code', $where, 'id', 'asc',$limit,$start);
        } if($id==28){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_FCC_code', $where, 'id', 'asc',$limit,$start);
        } if($id==29){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_SCB_code', $where, 'id', 'asc',$limit,$start);
        }
        if($id==30){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_MSE_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==52){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part5_SGWPB_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==51){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part5_SGWPA_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        if($id==21){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part2_MCOA_code', $where, 'id', 'asc',$limit ,$start);
        }
        
       

       
        if($id==41){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part4_SAWPA_code', $where, 'id', 'asc',$limit ,$start);
        }
        
         if($id==42){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part4_SAWPB_code', $where, 'id', 'asc',$limit ,$start);
        }
        
      
        if($id==31){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part3_MI_code', $where, 'id', 'asc',$limit ,$start);
        }
         if($id==32){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part3_TFN_code', $where, 'id', 'asc',$limit ,$start);
        }
        
        
         if($id==33){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part3_NC_code', $where, 'id', 'asc',$limit,$start);
        }
         if($id==34){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part3_SC_code', $where, 'id', 'asc',$limit,$start);
        }
         if($id==35){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part3_MFC_code', $where, 'id', 'asc',$limit,$start);
        }
        
         if($id==37){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part3_SMC_code', $where, 'id', 'asc',$limit,$start);
        }
        
       
        
        if($id==36){
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $where = "id != '0'";
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part3_MC_code', $where, 'id', 'asc',$limit ,$start);
        }
         if($id==62){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part6_II_code', $where, 'id', 'asc',$limit ,$start);
        }
         if($id==63){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part6_ILT_code', $where, 'id', 'asc',$limit ,$start);
        }
         if($id==64){
            $where = "id != '0'";
            $limit = $this->data['number_of_visible_questions'];
            $start = 0;
            $this->data['gettest'] = $this->Webservice_model->getWhereOrderLimitRecords('system_part6_D_code', $where, 'id', 'asc',$limit ,$start);
        }
		//echo "<pre>";print_r($this->data['gettest']);die;
		
		if(!empty($this->data['gettest'])){
			foreach($this->data['gettest'] as $test){
				$data[] = array('id'=>$test->id,
								'test_code'=>$test->test_code);
			}
			$result_array = array('response'=>1,'message' => "Get test successfully",'data'=>$data);
		}else{
			$result_array = array('response'=>0,'message' => 'No test found');
		}
		
		echo json_encode($result_array);
	    exit();
	}
	
	
	function vocabularyLevels(){
		$where = "active = 'Yes' ";
        $getLevels = $this->Webservice_model->getWhereOrderRecords('system_vlevel_code', $where, 'id', 'asc');
		if(!empty($getLevels)){
			$result_array = array('response'=>1,'message' => 'Get list successfully','data'=>$getLevels);
		}else{
			$result_array = array('response'=>0,'message' => 'No vocabulary test found');
		}
		echo json_encode($result_array);
	    exit();
	}
	
	function vocabularyQuestion(){
		$where = "level_id = '".$_REQUEST['lavelId']."' ";
        $getQuestions = $this->Webservice_model->getWhereOrderRecords('system_vquestion_code', $where, 'id', 'asc');
		if(!empty($getQuestions)){
			foreach($getQuestions as $question){
				$where = "question_id = '". $question->id ."' ";
				$getOptions = $this->Webservice_model->getWhereOrderRecords('system_voption_code', $where, 'id', 'asc');
				//echo "<pre>";print_r($getOptions);die;
				$option = array();
				foreach($getOptions as $Option){
					$option[] = array('question_id'=>$Option->question_id,'option_id'=>$Option->id,'title'=>$Option->title,'is_correct'=>$Option->is_correct);
				}
				
				$data[] = array('id'=>$question->id,'level_id'=>$question->level_id,'title'=>$question->title,'question_image'=>$question->question_image,'options'=>$option);
				unset($option);
			}
			//echo "<pre>";print_r($data);die;
			//echo "<pre>";print_r($getQuestions);die;
			$result_array = array('response'=>1,'message' => 'Get list successfully','data'=>$data);
		}else{
			$result_array = array('response'=>0,'message' => 'No vocabulary test found');
		}
		echo json_encode($result_array);
	    exit();
	}
	
	function accessnewtest() {
		
        $testid = $_REQUEST['testid'];
        $memberid = $_REQUEST['memberid'];
        $testcode = $_REQUEST['testcode'];
        $objTest = $this->Webservice_model->getARecord('system_PTEsubtype_code', $testid);
        
        $objMember = $this->Webservice_model->getARecord('system_member_code', $memberid);
        if($objMember->coins <= 0){
            $response = array(
                'response' => '0',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            echo json_encode ($response) ;
            die;
        }
        
        if(($objMember->coins < $objTest->coin_cost)){
            $response = array(
                'response' => '0',
                'message' => 'You have insufficient Coin Balance to proceed!!'
            );
            $this->session->set_flashdata('global_msg','You have insufficient Coin Balance to proceed!!');
            echo json_encode ($response) ;
            die;
        }
        
        if( is_object($objTest)) {

            $qryData = array(
                'test_id' => $testid,
                'test_code'=> $testcode,
                'member_id' => $memberid,
                'time' => time(),
                'created_at'=> date('Y-m-d H:i:s')
            );

            if( $this->Webservice_model->insertDataIntoTable('system_testdetails_code', $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->Webservice_model->updateTable('system_testdetails_code', $updateData, $last_added_id);
                
                //CHARGE COIN COST
                $objMember = $this->Webservice_model->getARecord('system_member_code', $memberid);  
                $balance_coins = $objMember->coins - $objTest->coin_cost;
                $updateMemCoins = array('coins'=>$balance_coins);
                $this->Webservice_model->updateTable('system_member_code', $updateMemCoins, $memberid);
                
                $coin_data = array('user_id'=>$memberid,
                    'user_type'=>'member',
                    'description'=>"Cost test ".$objTest->PTEsubtype ." (".$testcode.")",
                    'debit_coin'=>$objTest->coin_cost,
                    'balance_coin'=>$balance_coins,
                    'created_date'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s'),
                );
                $this->Webservice_model->insertDataIntoTable('system_coins_management_code', $coin_data);
                
                // Add entry here
                $response = array(
                    'response' => '1',
                    'message' => 'Test Started',
                    'tdcode' => $id_md5, // test details code
                    //'tcode' => $objTest->id_md5 // test code
                );
                
            }

        } else {
            $response = array(
                'response' => '0',
                //'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        echo json_encode ($response) ;
		die;
    }
	
	/*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function testnewprogress() {
		$l1_url = base_url('uploads/part1_MCOA/');
		$l2_url = base_url('uploads/part1_MCMTOA/');
      	$l3_url = base_url('uploads/part1_MH/');
		$l4_url = base_url('uploads/part1_LOM/');
		$l5_url = base_url('uploads/part1_FIG/');
		$l6_url = base_url('uploads/part1_FGOWA/');

		
		$tdId_md5 = $_REQUEST['token'];
       $this->data['testdetail'] = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            $result_array = array('response'=>0,'message' => 'No vocabulary test found');
			echo json_encode($result_array);
			exit();
        }

        $check_test = $this->Webservice_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);
        if( !is_object($check_test)) {
            $result_array = array('response'=>0,'message' => 'No vocabulary test found');
			echo json_encode($result_array);
			exit();
        }
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->Webservice_model->getWhereOneRecords($table,$where);
		
        //echo "<pre>";print_r($this->data['test']);die;
        if(!empty($this->data['test'])){
            $result_array = array('response'=>1,'message' => 'test data get successfully','data'=>$this->data['test'],'part1_url'=>$l1_url,'part2_url'=>$l2_url,'part3_url'=>$l3_url,'part4_url'=>$l4_url,'part5_url'=>$l5_url,'part6_url'=>$l6_url);
        }else{
            $result_array = array('response'=>0,'message' => 'No vocabulary test found');
        }
		
		echo json_encode ($result_array) ;
		die;
    }
	
	
	
	function lsPart1Submit(){    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->Webservice_model->checkARecord('system_part1_MCOA_code','test_code',$testdetail->test_code);

   
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = 'q1_option'.$getTestdetail->q1_answer;
        $q2_right_option = 'q2_option'.$getTestdetail->q2_answer;
        $q3_right_option = 'q3_option'.$getTestdetail->q3_answer;
      
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
      
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 1: Multiple choice question with one answer','response_data'=>array(
        array('q_number'=>'Listening Part 1: Multiple choice question with one answer - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $getTestdetail->$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'Listening Part 1: Multiple choice question with one answer - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $getTestdetail->$q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'Listening Part 1: Multiple choice question with one answer - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $getTestdetail->$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
        
     
        ));
        $json_result = json_encode($result);
        
     
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;die;
    }
	
	
	function lsPart2Submit(){
    $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
      $getTestdetail = $this->Webservice_model->checkARecord('system_part1_MCMTOA_code','test_code',$testdetail->test_code);

        $q1_right_option ='q1_option'.$getTestdetail->q1_answer1;
        $q2_right_option ='q1_option'.$getTestdetail->q1_answer2;
        $q3_right_option ='q1_option'.$getTestdetail->q1_answer3;
        
        $right_option=array($getTestdetail->$q1_right_option,$getTestdetail->$q2_right_option,$getTestdetail->$q3_right_option);
        $q1_response_val = $_REQUEST['q1_response'];

       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 2: Listening to Daily Life Conversation Answer Key','response_data'=>array(
          array('q_number'=>'Listening Part 2: Listening to Daily Life Conversation - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$right_option,'q_right_option_val'=>$right_option),
        ));
        $json_result = json_encode($result);
        
     
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;die;
        
    }
        
	
	function lsPart3Submit(){
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
         $getTestdetail = $this->Webservice_model->checkARecord('system_part1_MH_code','test_code',$testdetail->test_code);

        $q1_right_option =$getTestdetail->h1_answer;
        $q2_right_option =$getTestdetail->h2_answer;
        $q3_right_option =$getTestdetail->h3_answer;
        $q4_right_option =$getTestdetail->h4_answer;
        $q5_right_option =$getTestdetail->h5_answer;
        
        
        
        $q1_response = $_REQUEST['q1_response'];
        $q1_response_val=strip_tags($q1_response);
        
        $q2_response = $_REQUEST['q2_response'];
        $q2_response_val=strip_tags($q2_response);
        
        $q3_response = $_REQUEST['q3_response'];
        $q3_response_val=strip_tags($q3_response);
        
        $q4_response = $_REQUEST['q4_response'];
        $q4_response_val=strip_tags($q4_response);
        
        $q5_response = $_REQUEST['q5_response'];
        $q5_response_val=strip_tags($q5_response);

       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 3: Matching Answer Key','response_data'=>array(
          array('q_number'=>'Listening Part 3: Matching - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
           array('q_number'=>'Listening Part 3: Matching - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
            array('q_number'=>'Listening Part 3: Matching - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
             array('q_number'=>'Listening Part 3: Matching - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
              array('q_number'=>'Listening Part 3: Matching - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "response"=>1,
                "message" => "Data has been successfully submitted.",
            );
        } else {
            $response = array(
                "response"=>0,
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
	
	function lsPart4Submit(){
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
            $getTestdetail = $this->Webservice_model->checkARecord('system_part1_LOM_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = q1_answer;
        $q2_right_option = q2_answer;
        $q3_right_option = q3_answer;
      
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
      
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 4 : Labelling on a map','response_data'=>array(
        array('q_number'=>'Listening Part 4 : Labelling on a map - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' =>$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'Listening Part 4 : Labelling on a map - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'Listening Part 4 : Labelling on a map - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
        
     
        ));
        $json_result = json_encode($result);
        
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "response"=>1,
                "message" => "Data has been successfully submitted.",
            );
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
	
	
	
	function lsPart5Submit(){
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
      $getTestdetail = $this->Webservice_model->checkARecord('system_part1_FIG_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = $getTestdetail->q1_words;
        $q2_right_option = $getTestdetail->q2_words;
        $q3_right_option = $getTestdetail->q3_words;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];
        $q6_response_val = $_REQUEST['q6_response'];
        $q7_response_val = $_REQUEST['q7_response'];
        
        
        $select_options1=$q1_response_val.','.$q2_response_val.','.$q3_response_val;
        $select_options2=$q4_response_val.','.$q5_response_val;
        $select_options3=$q6_response_val.','.$q7_response_val;
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 5: Fill in the Gaps Answer Key','response_data'=>array(
        array('q_number'=>'Listening Part 5: Fill in the Gaps - Q1','q_response_type'=>'text','q_response' => $select_options1,'q_response_val' => $select_options1,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Listening Part 5: Fill in the Gaps - Q2','q_response_type'=>'text','q_response' =>$select_options2,'q_response_val' =>$select_options2,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Listening Part 5: Fill in the Gaps - Q3','q_response_type'=>'text','q_response' =>$select_options3,'q_response_val' =>$select_options3,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),

        
        ));
        $json_result = json_encode($result);
        
	
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "response"=>1,
                "message" => "Data has been successfully submitted.",
            );
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
}
    
    	function lsPart6Submit(){
        //echo "<pre>";print_r($_REQUEST);die;
    $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
          $getTestdetail = $this->Webservice_model->checkARecord('system_part1_FGOWA_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = $getTestdetail->answer1;
        $q2_right_option = $getTestdetail->answer2;
        $q3_right_option = $getTestdetail->answer3;
       
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 6: Fill in the gaps: short answers Answer Key','response_data'=>array(
        array('q_number'=>'Listening Part 6: Fill in the gaps: short answers - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Part 6: Fill in the gaps: short answers - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Listening Part 6: Fill in the gaps: short answers - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        
        
        ));
        $json_result = json_encode($result);
           
        $qryData = array(
            'time' => time(),
            'testid' => '1',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
            $response = array(
                "response"=>1,
                "message" => "Data has been successfully submitted.",
            );
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    function rdPart1Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->Webservice_model->checkARecord('system_part2_MCOA_code','test_code',$testdetail->test_code);

   
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option = 'q1_option'.$getTestdetail->q1_answer;
        $q2_right_option = 'q2_option'.$getTestdetail->q2_answer;
        $q3_right_option = 'q3_option'.$getTestdetail->q3_answer;
        $q4_right_option = 'q4_option'.$getTestdetail->q4_answer;
      
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
      
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 1: Multiple choice question with one answer','response_data'=>array(
        array('q_number'=>'Academic Reading Part 1: Multiple choice question with one answer - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $getTestdetail->$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Multiple choice question with one answer - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $getTestdetail->$q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Multiple choice question with one answer - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $getTestdetail->$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Multiple choice question with one answer - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $getTestdetail->$q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$getTestdetail->$q4_right_option),
                ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    
    function rdPart2Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
          $getTestdetail = $this->Webservice_model->checkARecord('system_part2_MCMTOA_code','test_code',$testdetail->test_code);
        
        $q1_right_option1 ='q1_option'.$getTestdetail->q1_answer1;
        $q1_right_option2 ='q1_option'.$getTestdetail->q1_answer2;
        
          $q2_right_option1 ='q1_option'.$getTestdetail->q2_answer1;
        $q2_right_option2 ='q1_option'.$getTestdetail->q2_answer2;
        
        
       $right_option1=array($getTestdetail->$q1_right_option1,$getTestdetail->$q1_right_option2);
       
       $right_option2=array($getTestdetail->$q2_right_option1,$getTestdetail->$q2_right_option2);

        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Reading Part 2:Multiple choice with more than one answer','response_data'=>array(
        array('q_number'=>'Reading Part 2:Multiple choice with more than one answer - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' =>$q1_response_val,'q_right_option'=>$right_option1,'q_right_option_val'=>$right_option1),
        
        array('q_number'=>'Reading Part 2:Multiple choice with more than one answer - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$right_option2,'q_right_option_val'=>$right_option2)
        
      
        ));
        $json_result = json_encode($result);
        
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function rdPart3Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
         $getTestdetail = $this->Webservice_model->checkARecord('system_part2_II_code','test_code',$testdetail->test_code);
        //echo "<pre>";print_r($getTestdetail);die;
        
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Reading Part 3: Identifying Information (True/False/Not Given) Answer Key','response_data'=>array(
        array('q_number'=>'Reading Part 3: Identifying Information (True/False/Not Given) - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Reading Part 3: Identifying Information (True/False/Not Given) - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' =>$q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Reading Part 3: Identifying Information (True/False/Not Given) - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option)
        
       
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function rdPart4Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
          $getTestdetail = $this->Webservice_model->checkARecord('system_part2_NC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;
        $q6_right_option = $getTestdetail->q6_answer;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];
        $q6_response_val = $_REQUEST['q6_response'];
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 4: Note Completion Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
        
        array('q_number'=>'Academic Reading Part 4: Note Completion - Q6','q_response_type'=>'text','q_response' => $_REQUEST['q6_response'],'q_response_val' => $q6_response_val,'q_right_option'=>$q6_right_option,'q_right_option_val'=>$q6_right_option),
        
        
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function rdPart5Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
         $getTestdetail = $this->Webservice_model->checkARecord('system_part2_MH_code','test_code',$testdetail->test_code);

        $q1_right_option =$getTestdetail->p1_answer;
        $q2_right_option =$getTestdetail->p2_answer;
        $q3_right_option =$getTestdetail->p3_answer;
        $q4_right_option =$getTestdetail->p4_answer;
        
        
        
        $q1_response = $_REQUEST['q1_response'];
        $q1_response_val=strip_tags($q1_response);
        
        $q2_response = $_REQUEST['q2_response'];
        $q2_response_val=strip_tags($q2_response);
        
        $q3_response = $_REQUEST['q3_response'];
        $q3_response_val=strip_tags($q3_response);
        
        $q4_response = $_REQUEST['q4_response'];
        $q4_response_val=strip_tags($q4_response);
      
       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 5: Matching Headings Answer Key','response_data'=>array(
          array('q_number'=>'Academic Reading Part 5: Matching Headings - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
           array('q_number'=>'Academic Reading Part 5: Matching Headings - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
            array('q_number'=>'Academic Reading Part 5: Matching Headings - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
             array('q_number'=>'Academic Reading Part 5: Matching Headings - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function rdPart6Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
            $getTestdetail = $this->Webservice_model->checkARecord('system_part2_SC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_words;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 6: Summary Completion Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 6: Summary Completion - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        
        
        ));
        $json_result = json_encode($result);
        // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function rdPart7Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
               $getTestdetail = $this->Webservice_model->checkARecord('system_part2_SCA_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        
        $q1_response = $_REQUEST['q1_response'];
        $q1_response_val=strip_tags($q1_response);
        
        $q2_response = $_REQUEST['q2_response'];
        $q2_response_val=strip_tags($q2_response);
        
        $q3_response = $_REQUEST['q3_response'];
        $q3_response_val=strip_tags($q3_response);
        
        $q4_response = $_REQUEST['q4_response'];
        $q4_response_val=strip_tags($q4_response);
    
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 3: Matching Answer Key','response_data'=>array(
          array('q_number'=>'Academic Reading Part 7: Summary Completion  - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
           array('q_number'=>'Academic Reading Part 7: Summary Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
            array('q_number'=>'Academic Reading Part 7: Summary Completion  - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
             array('q_number'=>'Academic Reading Part 7: Summary Completion - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
             
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function rdPart8Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->Webservice_model->checkARecord('system_part2_FCC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;

        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 8: Flow-chart Completion Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 8: Flow-chart Completion  - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 8: Flow-chart Completion Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 8: Flow-chart Completion Completion  - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function rdPart9Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
     $getTestdetail = $this->Webservice_model->checkARecord('system_part2_SCB_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;

        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];

        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 9: Sentence Completion Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 9: Sentence Completion - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 9: Sentence Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 9: Sentence Completion  - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 9: Sentence Completion  - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'Academic Reading Part 9: Sentence Completion  - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
    
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function rdPart10Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
     $getTestdetail = $this->Webservice_model->checkARecord('system_part2_MSE_code','test_code',$testdetail->test_code);

        $q1_right_option =$getTestdetail->p1_answer;
        $q2_right_option =$getTestdetail->p2_answer;
        $q3_right_option =$getTestdetail->p3_answer;

        
        
        $q1_response = $_REQUEST['q1_response'];
        $q1_response_val=strip_tags($q1_response);
        
        $q2_response = $_REQUEST['q2_response'];
        $q2_response_val=strip_tags($q2_response);
        
        $q3_response = $_REQUEST['q3_response'];
        $q3_response_val=strip_tags($q3_response);
        
      
       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 10: Matching Sentence Endings Answer Key','response_data'=>array(
          array('q_number'=>'Academic Reading Part 10: Matching Sentence Endings - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
           array('q_number'=>'Academic Reading Part 10: Matching Sentence Endings - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
            array('q_number'=>'Academic Reading Part 10: Matching Sentence Endings - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '2',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
     function grPart1Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->Webservice_model->checkARecord('system_part3_MI_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;
        $q6_right_option = $getTestdetail->q6_answer;
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];
        $q6_response_val = $_REQUEST['q6_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 1: Matching Information Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
        
        array('q_number'=>'Academic Reading Part 1: Matching Information - Q6','q_response_type'=>'text','q_response' => $_REQUEST['q6_response'],'q_response_val' => $q6_response_val,'q_right_option'=>$q6_right_option,'q_right_option_val'=>$q6_right_option),
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    
    function grPart2Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
       $getTestdetail = $this->Webservice_model->checkARecord('system_part3_TFN_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;
        $q6_right_option = $getTestdetail->q6_answer;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];
        $q6_response_val = $_REQUEST['q6_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Reading Part 2: True/False/Not Given Answer Key','response_data'=>array(
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
        
        array('q_number'=>'Academic Reading Part 2: True/False/Not Given - Q6','q_response_type'=>'text','q_response' => $_REQUEST['q6_response'],'q_response_val' => $q6_response_val,'q_right_option'=>$q6_right_option,'q_right_option_val'=>$q6_right_option),
        ));
        $json_result = json_encode($result);
        
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function grPart3Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
       $getTestdetail = $this->Webservice_model->checkARecord('system_part3_NC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;
        $q5_right_option = $getTestdetail->q5_answer;

        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
        $q5_response_val = $_REQUEST['q5_response'];

        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Reading Part 3: Note Completion Answer Key','response_data'=>array(
        array('q_number'=>'General Reading Part 3: Note Completion  - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'General Reading Part 3: Note Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'General Reading Part 3: Note Completion - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'General Reading Part 3: Note Completion  - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        array('q_number'=>'General Reading Part 3: Note Completion  - Q5','q_response_type'=>'text','q_response' => $_REQUEST['q5_response'],'q_response_val' => $q5_response_val,'q_right_option'=>$q5_right_option,'q_right_option_val'=>$q5_right_option),
    
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function grPart4Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        $getTestdetail = $this->Webservice_model->checkARecord('system_part3_SC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_answer;
        $q2_right_option = $getTestdetail->q2_answer;
        $q3_right_option = $getTestdetail->q3_answer;
        $q4_right_option = $getTestdetail->q4_answer;

        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];

        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Reading Part 4: Summary Completion Answer Key','response_data'=>array(
        array('q_number'=>'General Reading Part 4: Summary Completion  - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        array('q_number'=>'General Reading Part 4: Summary Completion  - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$q2_right_option),
        
        array('q_number'=>'General Reading Part 4: Summary Completion - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' => $q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$q3_right_option),
        
        array('q_number'=>'General Reading Part 4: Summary Completion  - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' => $q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$q4_right_option),
        
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function grPart5Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
           $getTestdetail = $this->Webservice_model->checkARecord('system_part3_MFC_code','test_code',$testdetail->test_code);
        
        //echo "<pre>";print_r($getTestdetail);die;
        $q1_right_option ='q_option'.$getTestdetail->q1_answer;
        $q2_right_option ='q_option'.$getTestdetail->q2_answer;
        $q3_right_option ='q_option'.$getTestdetail->q3_answer;
        $q4_right_option ='q_option'.$getTestdetail->q4_answer;
      
        
        $q1_response_val = $_REQUEST['q1_response'];
        $q2_response_val = $_REQUEST['q2_response'];
        $q3_response_val = $_REQUEST['q3_response'];
        $q4_response_val = $_REQUEST['q4_response'];
      
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Listening Part 5 : Matching Features','response_data'=>array(
        array('q_number'=>'Listening Part 5 : Matching Features - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' =>$q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$getTestdetail->$q1_right_option),
        
        array('q_number'=>'General Reading Part 5 : Matching Features - Q2','q_response_type'=>'text','q_response' => $_REQUEST['q2_response'],'q_response_val' => $q2_response_val,'q_right_option'=>$q2_right_option,'q_right_option_val'=>$getTestdetail->$q2_right_option),
        
        array('q_number'=>'Listening Part 5 : Matching Features - Q3','q_response_type'=>'text','q_response' => $_REQUEST['q3_response'],'q_response_val' =>$q3_response_val,'q_right_option'=>$q3_right_option,'q_right_option_val'=>$getTestdetail->$q3_right_option),
         array('q_number'=>'Listening Part 5 : Matching Features - Q4','q_response_type'=>'text','q_response' => $_REQUEST['q4_response'],'q_response_val' =>$q4_response_val,'q_right_option'=>$q4_right_option,'q_right_option_val'=>$getTestdetail->$q4_right_option),
        
     
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function grPart6Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
     $getTestdetail = $this->Webservice_model->checkARecord('system_part3_MC_code','test_code',$testdetail->test_code);

        $q1_right_option ='q1_option'.$getTestdetail->q1_answer1;
        $q2_right_option ='q1_option'.$getTestdetail->q1_answer2;
     
        
        $right_option=array($getTestdetail->$q1_right_option,$getTestdetail->$q2_right_option);
        $q1_response_val = $_REQUEST['q1_response'];

       
        
        //echo $getTestdetail->$q1_right_option;die;
        //echo $getTestdetail->$_REQUEST['q1_response'];die;
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Reading Part 6: Multiple Choice  Answer Key','response_data'=>array(
          array('q_number'=>'General Reading Part 6: Multiple Choice - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$right_option,'q_right_option_val'=>$right_option),
        ));
        $json_result = json_encode($result);
        // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    function grPart7Submit(){  
	    
        $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code','id_md5',$_REQUEST['token']);
        
           $getTestdetail = $this->Webservice_model->checkARecord('system_part3_SMC_code','test_code',$testdetail->test_code);
        $q1_right_option = $getTestdetail->q1_words;
        
        $q1_response_val = $_REQUEST['q1_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Reading Part 7: Summary Completion Answer Key','response_data'=>array(
        array('q_number'=>'General Reading Part 7: Summary Completion - Q1','q_response_type'=>'text','q_response' => $_REQUEST['q1_response'],'q_response_val' => $q1_response_val,'q_right_option'=>$q1_right_option,'q_right_option_val'=>$q1_right_option),
        
        
        
        ));
        $json_result = json_encode($result);
      // print_r($json_result);die; 
     
        $qryData = array(
            'time' => time(),
            'testid' => '3',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id
        );
    //    print_r($qryData);die;

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            $is_attempt_data = array('is_attempt'=>'1');
            
            if($this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id));
            $response = array(
				"response"=>1,
                "message" => "Data has been successfully submitted.",
            );
          
            //$this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
            //$this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode($response);
    }
    
    
    function wtPart1Submit(){
       
	$testdetail = $this->Webservice_model->checkARecord
    ('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->Webservice_model->checkARecord('system_part4_SAWPA_code','test_code',$testdetail->test_code);
                
$q1_response_val = $_REQUEST['q1_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Writing Part 1:','response_data'=>array(
        array('q_number'=>'Academic Writing Part 1: - Q1','q_response_type'=>'text','q_response_email_content' =>$q1_response_val),
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '4',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
     function wtPart2Submit(){
       
	    $testdetail = $this->Webservice_model->checkARecord
    ('system_testdetails_code', 'id_md5',$_REQUEST['token']);
      $getTestdetail = $this->Webservice_model->checkARecord('system_part4_SAWPB_code','test_code',$testdetail->test_code);
        
$q1_response_val = $_REQUEST['q1_response'];

        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Academic Writing Part 2:','response_data'=>array(
        array('q_number'=>'Academic Writing Part 2:  - Q1','q_response_type'=>'text','q_response_email_content' =>$q1_response_val),
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '4',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    
    
     function gwPart1Submit(){
       
	    $testdetail = $this->Webservice_model->checkARecord
    ('system_testdetails_code', 'id_md5',$_REQUEST['token']);
     $getTestdetail = $this->Webservice_model->checkARecord('system_part5_SGWPA_code','test_code',$testdetail->test_code);
        
$q1_response_val = $_REQUEST['q1_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Writing Part 1:','response_data'=>array(
        array('q_number'=>'General Writing Part 1: - Q1','q_response_type'=>'text','q_response_email_content' =>$q1_response_val),
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '5',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
     function gwPart2Submit(){
       
	    $testdetail = $this->Webservice_model->checkARecord
    ('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        $getTestdetail = $this->Webservice_model->checkARecord('system_part5_SGWPB_code','test_code',$testdetail->test_code);
        
$q1_response_val = $_REQUEST['q1_response'];
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'General Writing Part 2:','response_data'=>array(
        array('q_number'=>'General Writing Part 2: - Q1','q_response_type'=>'text','q_response_email_content' => $q1_response_val),
        
        ));
        $json_result = json_encode($result);
        //echo "<pre>";print_r($result);die;
        $qryData = array(
            'time' => time(),
            'testid' => '5',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' => $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

        if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData) )
        {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data,$testdetail->id);
            
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }
    
    
    
    function viewListenReport(){
                    $testid=$_REQUEST['testid'];
             $testcode=$_REQUEST['testcode'];
             $member_id=$_REQUEST['memberid'];
             $where="test_id = '$testid' AND member_id = '$member_id' AND test_code = '$testcode' ";
        $this->data['testdetail'] = $this->Webservice_model->getWhereLastRecords('system_testdetails_code', $where);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->Webservice_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);
        $this->data['test_type_id'] = $check_test->PTEtypeid;

  //      echo $this->data['test_type_id'];
//print_r($this->data['testdetail'] );
//print_r($check_test);die;
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

     
        $this->data['attempt'] = $this->Webservice_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
       // print_r($this->data['attempt']);die;
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $attempt_data = json_decode($this->data['attempt']->json_result, true);
    //    echo "<pre>"; print_r($this->data['attempt_data']);
    
    
    if(!is_object($attempt_data)){
        $response=array( "status" => "1",
                "message" => $attempt_data,);
    }else{
        $response=array( "status" => "0",);
    }
        echo json_encode ($response) ;
    

            }
    
 
    function viewWriteReport(){
        
             $testid=$_REQUEST['testid'];
             $testcode=$_REQUEST['testcode'];
             $member_id=$_REQUEST['memberid'];
             $where="test_id = '$testid' AND member_id = '$member_id' AND test_code = '$testcode' ";
        $this->data['testdetail'] = $this->Webservice_model->getWhereLastRecords('system_testdetails_code', $where);
      // print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }
        
        
        $reviewing=2;
        if($this->data['testdetail']->test_check_status!=$reviewing)
        {
        $check_test = $this->Webservice_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);

        $this->data['test_type_id'] = $check_test->PTEtypeid;

//        echo $this->data['test_type_id'];

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->Webservice_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        //echo "<pre>"; print_r($this->data['attempt_data']);
        
        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->Webservice_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;

        # check marks assigned or not 
        $where = "test_part_id = '".$this->data['testdetail']->test_id."' AND member_id = '".$_REQUEST['memberid']."' AND testdetail_idmd5 = '".$this->data['testdetail']->id_md5."' ";
        $this->data['marksAssigned'] = $this->Webservice_model->getWhereRecords("system_marks_code",$where);


        $this->data['teacher_name'] = $this->Webservice_model->getARecord("system_teacher_code",$this->data['marksAssigned'][0]->teacher_id);

  //     print_r($this->data['teacher_name']);die;
     $response=array( "status" => "1",
                "test" => $this->data['attempt_data'],
                "teacher"=>$this->data['teacher_name']->username,
                "marks_assigned"=> $this->data['marksAssigned'][0]->marks,
                "remarks"=>$this->data['marksAssigned'][0]->remarks);

            
        }else{
        
            $response=array( "status" => "2",
            "message"=>"reviewing",);
            
        }
        echo json_encode ($response) ;
       

    }
    function viewSpeakreport(){
       $testid=$_REQUEST['testid'];
             $testcode=$_REQUEST['testcode'];
             $member_id=$_REQUEST['memberid'];
             $where="test_id = '$testid' AND member_id = '$member_id' AND test_code = '$testcode' ";
        $this->data['testdetail'] = $this->Webservice_model->getWhereLastRecords('system_testdetails_code', $where);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }
          if($this->data['testdetail']->test_check_status==1)
        {
         
        $check_test = $this->Webservice_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);

        $this->data['test_type_id'] = $check_test->PTEtypeid;

       // echo $this->data['test_type_id'];

        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt'] = $this->Webservice_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $this->data['attempt_data'] = json_decode($this->data['attempt']->json_result, true);
        
        
        
        if($this->data['attempt']->testid==6 and $this->data['attempt']->subtypeid==62){
         $audio1 = $this->data['attempt_data']['response_data'][0][sp_response_file1];
         $audio2 = $this->data['attempt_data']['response_data'][1][sp_response_file2];
         $audio3 = $this->data['attempt_data']['response_data'][2][sp_response_file3];
         $audio4 = $this->data['attempt_data']['response_data'][3][sp_response_file4];
         $audio5 = $this->data['attempt_data']['response_data'][4][sp_response_file5];
         
         
     
         if(!empty($audio1)){
             $fetch= $this->getfile($audio1);        
            $this->data['s3audio1']=$fetch['imageurl'];
             
         }if(!empty($audio2)){
             $fetch= $this->getfile($audio2);        
            $this->data['s3audio2']=$fetch['imageurl'];
             
         }if(!empty($audio3)){
             $fetch= $this->getfile($audio3);        
            $this->data['s3audio3']=$fetch['imageurl'];
             
         }if(!empty($audio4)){
             $fetch= $this->getfile($audio4);        
            $this->data['s3audio4']=$fetch['imageurl'];
             
         }if(!empty($audio5)){
             $fetch= $this->getfile($audio5);        
            $this->data['s3audio5']=$fetch['imageurl'];
             
         }
        }
        
        if($this->data['attempt']->testid==6 and $this->data['attempt']->subtypeid==63){
         $audio1 = $this->data['attempt_data']['response_data'][0][sp_response_file1];
         $audio2 = $this->data['attempt_data']['response_data'][1][sp_response_file2];
         
         
     
         if(!empty($audio1)){
             $fetch= $this->getfile($audio1);        
            $this->data['s3audio1']=$fetch['imageurl'];
             
         }if(!empty($audio2)){
             $fetch= $this->getfile($audio2);        
            $this->data['s3audio2']=$fetch['imageurl'];
         }
        }
        
           if($this->data['attempt']->testid==6 and $this->data['attempt']->subtypeid==64){
         $audio1 = $this->data['attempt_data']['response_data'][0][sp_response_file1];
         $audio2 = $this->data['attempt_data']['response_data'][1][sp_response_file2];
         $audio3 = $this->data['attempt_data']['response_data'][2][sp_response_file3];
         
         
     
         if(!empty($audio1)){
             $fetch= $this->getfile($audio1);        
            $this->data['s3audio1']=$fetch['imageurl'];
             
         }if(!empty($audio2)){
             $fetch= $this->getfile($audio2);        
            $this->data['s3audio2']=$fetch['imageurl'];
             
         }if(!empty($audio3)){
             $fetch= $this->getfile($audio3);        
            $this->data['s3audio3']=$fetch['imageurl'];
         }
        }

        $test_code = $this->data['testdetail']->test_code;
        $table = 'system_'. $check_test->tbname .'_code';
        $where = "test_code = '$test_code'";
        $this->data['test'] = $this->Webservice_model->getWhereOneRecords($table,$where);
        //echo "<pre>";print_r($this->data['test']);die;

        # check marks assigned or not 
        $where = "test_part_id = '".$this->data['testdetail']->test_id."' AND member_id = '".$_REQUEST['memberid']."' AND testdetail_idmd5 = '".$this->data['testdetail']->id_md5."' ";
        $this->data['marksAssigned'] = $this->Webservice_model->getWhereRecords("system_marks_code",$where);


        $this->data['teacher_name'] = $this->Webservice_model->getARecord("system_teacher_code",$this->data['marksAssigned'][0]->teacher_id);

        //print_r($this->data['marksAssigned']);
        
        
        if($this->data['attempt']->testid==6 and $this->data['attempt']->subtypeid==62){
                $response=array( "status" => "1",
                "test" => $this->data['attempt_data'],
                "teacher"=>$this->data['teacher_name']->username,
                "marks_assigned"=> $this->data['marksAssigned'][0]->marks,
                "remarks"=>$this->data['marksAssigned'][0]->remarks,
                "uploadpath"=>"/uploads/attempt",
                "audio1" => $this->data['s3audio1'],
                "audio2" => $this->data['s3audio2'],
                "audio3" => $this->data['s3audio3'],
                "audio4" => $this->data['s3audio4'],
                "audio5" => $this->data['s3audio5'],);
        }
        if($this->data['attempt']->testid==6 and $this->data['attempt']->subtypeid==63){
                $response=array( "status" => "1",
                "test" => $this->data['attempt_data'],
                "teacher"=>$this->data['teacher_name']->username,
                "marks_assigned"=> $this->data['marksAssigned'][0]->marks,
                "remarks"=>$this->data['marksAssigned'][0]->remarks,
                "uploadpath"=>"/uploads/attempt",
                "audio1" => $this->data['s3audio1'],
                "audio2" => $this->data['s3audio2'],);
        }
        if($this->data['attempt']->testid==6 and $this->data['attempt']->subtypeid==64){
                $response=array( "status" => "1",
                "test" => $this->data['attempt_data'],
                "teacher"=>$this->data['teacher_name']->username,
                "marks_assigned"=> $this->data['marksAssigned'][0]->marks,
                "remarks"=>$this->data['marksAssigned'][0]->remarks,
                "uploadpath"=>"/uploads/attempt",
                "audio1" => $this->data['s3audio1'],
                "audio2" => $this->data['s3audio2'],
                "audio3" => $this->data['s3audio3'],);
        }
        
            
        }else{

                
            $response=array( "status" => "0",
            "message"=>"reviewing",
            );
}
        echo json_encode ($response) ;  
        }





    function spPart1Submit()
	{
	    
	    
	    
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    /** Autoload the file with composer autoloader */

    require 'aws-s3-bucket/vendor/autoload.php';

    // Create an S3 client


    /** AWS S3 Bucket Name */
    $bucket_name = 'celpipstore-media-files';


    /** AWS S3 Bucket Access Key ID */
    $access_key_id    = 'AKIA323GRW63FBO3HGTM';


    /** AWS S3 Bucket Secret Access Key */
    $secret = 'qyrBf/My3tdUOzyECywRBH6oIm7cqL4qe/MUopVY';


	    
	    
	    $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->Webservice_model->checkARecord('system_part6_II_code','test_code',$testdetail->test_code);
        
        
        if(!empty($testdetail)){
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking: Introduction and Interview','response_data'=>array(
        array('q_number'=>'Speaking: Introduction and Interview','q_response_type'=>'audio','sp_response_file1' => $_REQUEST['token'].'1'.'.mp3'),
        array('q_number'=>'Speaking: Introduction and Interview','q_response_type'=>'audio','sp_response_file2' => $_REQUEST['token'].'2'.'.mp3'),
        array('q_number'=>'Speaking: Introduction and Interview','q_response_type'=>'audio','sp_response_file3' => $_REQUEST['token'].'3'.'.mp3'),
        array('q_number'=>'Speaking: Introduction and Interview','q_response_type'=>'audio','sp_response_file4' => $_REQUEST['token'].'4'.'.mp3'),
        array('q_number'=>'Speaking: Introduction and Interview','q_response_type'=>'audio','sp_response_file5' => $_REQUEST['token'].'5'.'.mp3')
        )); 
        file_put_contents($_REQUEST['token'].'1'.'.mp3',base64_decode($_REQUEST['q1_response']));
        file_put_contents($_REQUEST['token'].'2'.'.mp3',base64_decode($_REQUEST['q2_response']));
        file_put_contents($_REQUEST['token'].'3'.'.mp3',base64_decode($_REQUEST['q3_response']));
        file_put_contents($_REQUEST['token'].'4'.'.mp3',base64_decode($_REQUEST['q4_response']));
        file_put_contents($_REQUEST['token'].'5'.'.mp3',base64_decode($_REQUEST['q5_response']));
        
        $json_result = json_encode($result);
        $config['upload_path'] = '/uploads/attempt';
        $config['allowed_types'] = '.mp3';
        $config['max_size']    = '2048';
        $json_result = json_encode($result);       
        $this->load->library('upload', $config);

        $qryData = array(
            'time' => time(),
            'testid' => '6',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' =>  $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

         if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData))
         {
             
             
     $input = $_REQUEST['token'].'1'; //temporary name that PHP gave to the uploaded file
     $input2 = $_REQUEST['token'].'2';
     $input3 = $_REQUEST['token'].'3'; //temporary name that PHP gave to the uploaded file
     $input4 = $_REQUEST['token'].'4';
     $input5 = $_REQUEST['token'].'5'; //temporary name that PHP gave to the uploaded file
    
     $output ='/'. $_REQUEST['token'].'1'.'.mp3'; //letting the client control the filename is a rather bad idea
     $output2 ='/'. $_REQUEST['token'].'2'.'.mp3'; //letting the client control the filename is a rather bad idea
     $output3 ='/'. $_REQUEST['token'].'3'.'.mp3'; //letting the client control the filename is a rather bad idea
     $output4 ='/'. $_REQUEST['token'].'4'.'.mp3'; //letting the client control the filename is a rather bad idea
     $output5 ='/'. $_REQUEST['token'].'5'.'.mp3'; //letting the client control the filename is a rather bad idea
     $upload_audio_server = move_uploaded_file($output);
     $upload_audio_server2 = move_uploaded_file($output2);
     $upload_audio_server3 = move_uploaded_file($output3);
     $upload_audio_server4 = move_uploaded_file($output4);
     $upload_audio_server5 = move_uploaded_file($output5);
     
        $client = new Aws\S3\S3Client([
        /** Region you had selected, if don't know check in S3 listing */
        'region'  => 'us-west-2',
        'version' => 'latest',
        /** Your AWS S3 Credential will be added here */
        'credentials' => [
        'key'    => $access_key_id,
        'secret' => $secret,
        ]
        ]);

        $uploaded_server_file_name = $_REQUEST['token'].'1'.'.mp3';
        $uploaded_server_file_name2 = $_REQUEST['token'].'2'.'.mp3';
        $uploaded_server_file_name3 = $_REQUEST['token'].'3'.'.mp3';
        $uploaded_server_file_name4 = $_REQUEST['token'].'4'.'.mp3';
        $uploaded_server_file_name5 = $_REQUEST['token'].'5'.'.mp3';
        

        $source = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name;
        $source2 = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name2;
        $source3 = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name3;
        $source4 = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name4;
        $source5 = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name5;


        // Where the files will be transferred to
        $dest = 's3://celpipstore-media-files/ielts/uploads';

        $result = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name,
        'SourceFile' => $source,
        ));
        $result2 = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name2,
        'SourceFile' => $source2,
        ));
        
        $result3 = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name3,
        'SourceFile' => $source3,
        ));
        $result4 = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name4,
        'SourceFile' => $source4,
        ));
        $result5 = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name5,
        'SourceFile' => $source5,
        ));
        
        

        if($result)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name);
        }
        if($result2)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name2);
        }
        
        if($result3)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name3);
        }
        if($result4)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name4);
        }
        if($result5)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name5);
        }
        
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }else  
    {  
        echo "no data found";
    }
	    
	}
    
    function spPart2Submit()
	{
	    

    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    /** Autoload the file with composer autoloader */

    require 'aws-s3-bucket/vendor/autoload.php';

    // Create an S3 client


    /** AWS S3 Bucket Name */
    $bucket_name = 'celpipstore-media-files';


    /** AWS S3 Bucket Access Key ID */
    $access_key_id    = 'AKIA323GRW63FBO3HGTM';


    /** AWS S3 Bucket Secret Access Key */
    $secret = 'qyrBf/My3tdUOzyECywRBH6oIm7cqL4qe/MUopVY';


	    
	    
	    $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->Webservice_model->checkARecord('system_part6_ILT_code','test_code',$testdetail->test_code);
    
        if(!empty($testdetail)){
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking: individual long turn (Cue Card)','response_data'=>array(
        array('q_number'=>'Speaking: individual long turn (Cue Card)','q_response_type'=>'audio','sp_response_file1' => $_REQUEST['token'].'1'.'.mp3'),
        array('q_number'=>'Speaking: individual long turn (Cue Card)','q_response_type'=>'audio','sp_response_file2' => $_REQUEST['token'].'2'.'.mp3'),
        ));
        
        file_put_contents($_REQUEST['token'].'1'.'.mp3',base64_decode($_REQUEST['q1_response']));
        
        file_put_contents($_REQUEST['token'].'2'.'.mp3',base64_decode($_REQUEST['q2_response']));
         
    
        $json_result = json_encode($result);
        $config['allowed_types'] = '.mp3';
        $config['max_size']    = '2048';
        $json_result = json_encode($result);       
        $this->load->library('upload', $config);

        $qryData = array(
            'time' => time(),
            'testid' => '6',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' =>  $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

         if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData))
         {
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);
            
     $input = $_REQUEST['token'].'1'; //temporary name that PHP gave to the uploaded file
     $input2 = $_REQUEST['token'].'2';
     $output ='/'. $_REQUEST['token'].'1'.'.mp3'; //letting the client control the filename is a rather bad idea
     $output2 ='/'. $_REQUEST['token'].'2'.'.mp3'; //letting the client control the filename is a rather bad idea
     $upload_audio_server = move_uploaded_file($output);
     $upload_audio_server2 = move_uploaded_file($output2);
     
        $client = new Aws\S3\S3Client([
        /** Region you had selected, if don't know check in S3 listing */
        'region'  => 'us-west-2',
        'version' => 'latest',
        /** Your AWS S3 Credential will be added here */
        'credentials' => [
        'key'    => $access_key_id,
        'secret' => $secret,
        ]
        ]);

        $uploaded_server_file_name = $_REQUEST['token'].'1'.'.mp3';
        $uploaded_server_file_name2 = $_REQUEST['token'].'2'.'.mp3';


        $source = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name;
        $source2 = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name2;


        // Where the files will be transferred to
        $dest = 's3://celpipstore-media-files/ielts/uploads';

        $result = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name,
        'SourceFile' => $source,
        ));
        $result2 = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name2,
        'SourceFile' => $source2,
        ));
        
        

        if($result)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name);
        }
        if($result2)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name2);
        }
            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }else{
        echo "data not found";
    }
	}
	
    
    
    
    
    function spPart3Submit()
	{
	    
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    /** Autoload the file with composer autoloader */

    require 'aws-s3-bucket/vendor/autoload.php';

    // Create an S3 client


    /** AWS S3 Bucket Name */
    $bucket_name = 'celpipstore-media-files';


    /** AWS S3 Bucket Access Key ID */
    $access_key_id    = 'AKIA323GRW63FBO3HGTM';


    /** AWS S3 Bucket Secret Access Key */
    $secret = 'qyrBf/My3tdUOzyECywRBH6oIm7cqL4qe/MUopVY';


	    
	    
	    $testdetail = $this->Webservice_model->checkARecord('system_testdetails_code', 'id_md5',$_REQUEST['token']);
        
        $getTestdetail = $this->Webservice_model->checkARecord('system_part6_D_code','test_code',$testdetail->test_code);
        
        if(!empty($testdetail)){
        
        $result = array('test_id'=>$testdetail->test_id,'test'=>$testdetail->test_code,'test_name'=>'Speaking: Discussion','response_data'=>array(
        array('q_number'=>'Speaking: Discussion','q_response_type'=>'audio','sp_response_file1' => $_REQUEST['token'].'1'.'.mp3'),
        array('q_number'=>'Speaking: Discussion','q_response_type'=>'audio','sp_response_file2' => $_REQUEST['token'].'2'.'.mp3'),
        array('q_number'=>'Speaking: Discussion','q_response_type'=>'audio','sp_response_file3' => $_REQUEST['token'].'3'.'.mp3'),
        )); 
        file_put_contents($_REQUEST['token'].'1'.'.mp3',base64_decode($_REQUEST['q1_response']));
        file_put_contents($_REQUEST['token'].'2'.'.mp3',base64_decode($_REQUEST['q2_response']));
        file_put_contents($_REQUEST['token'].'3'.'.mp3',base64_decode($_REQUEST['q3_response']));
        
        $json_result = json_encode($result);
        $config['upload_path'] = '/uploads/attempt';
        $config['allowed_types'] = '.mp3';
        $config['max_size']    = '2048';
        $json_result = json_encode($result);       
        $this->load->library('upload', $config);

        $qryData = array(
            'time' => time(),
            'testid' => '6',
            'questionid' => $testdetail->test_code,
            'subtypeid' => $testdetail->test_id,
            'memberid' =>  $_REQUEST['memberid'],
            'json_result' => $json_result,
            'testdetail_id' => $testdetail->id,
            'test_check_status'=>'2'
        );

         if( $this->Webservice_model->insertDataIntoTable('system_attempt_code', $qryData))
         {
                      
     $input = $_REQUEST['token'].'1'; //temporary name that PHP gave to the uploaded file
     $input2 = $_REQUEST['token'].'2';
     $input3 = $_REQUEST['token'].'3';
     $output ='/'. $_REQUEST['token'].'1'.'.mp3'; //letting the client control the filename is a rather bad idea
     $output2 ='/'. $_REQUEST['token'].'2'.'.mp3';//letting the client control the filename is a rather bad idea
     $output3 ='/'. $_REQUEST['token'].'3'.'.mp3'; //letting the client control the filename is a rather bad idea
     $upload_audio_server = move_uploaded_file($output);
     $upload_audio_server2 = move_uploaded_file($output2);
     $upload_audio_server3 = move_uploaded_file($output3);
     
        $client = new Aws\S3\S3Client([
        /** Region you had selected, if don't know check in S3 listing */
        'region'  => 'us-west-2',
        'version' => 'latest',
        /** Your AWS S3 Credential will be added here */
        'credentials' => [
        'key'    => $access_key_id,
        'secret' => $secret,
        ]
        ]);

        $uploaded_server_file_name = $_REQUEST['token'].'1'.'.mp3';
        $uploaded_server_file_name2 = $_REQUEST['token'].'2'.'.mp3';
        $uploaded_server_file_name3 = $_REQUEST['token'].'3'.'.mp3';


        $source = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name;
        $source2 = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name2;
        $source3 = $_SERVER['DOCUMENT_ROOT'].'/'.$uploaded_server_file_name3;



        // Where the files will be transferred to
        $dest = 's3://celpipstore-media-files/ielts/uploads';

        $result = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name,
        'SourceFile' => $source,
        ));
        $result2 = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name2,
        'SourceFile' => $source2,
        ));
        $result3 = $client->putObject(array(
        'Bucket'     => $bucket_name,
        'Key'        => 'ielts/uploads/'.$uploaded_server_file_name3,
        'SourceFile' => $source3,
        ));
        
        

        if($result)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name);
        }
        if($result2)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name2);
        }
        
        if($result3)
        {
          unlink('/'.$_SERVER['DOCUMENT_ROOT']."/".$uploaded_server_file_name3);
        }
             
             
            $last_added_id = $this->db->insert_id();
            
            $is_attempt_data = array('is_attempt'=>'1','test_check_status'=>'2');
            $this->Webservice_model->updateTable('system_testdetails_code', $is_attempt_data, $testdetail->id);

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
            $this->session->set_flashdata('global_msg','Data has been successfully submitted.');
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
            $this->session->set_flashdata('global_msg','Report to webmaster.');
        }

        // return ajax response as json
        echo json_encode ($response) ;
      }  else{
        echo "data not found";
    }
    }
    
    
    
    
    function coinsdata(){
        $where= "id != 0";
          $this->data['coins'] = $this->Webservice_model->getWhereOrderRecords('system_coins_code', $where, 'id', 'asc');
          
          $response = array(
                "status" => "1",
                "data" =>$this->data['coins'],

            );
            
        echo json_encode ($response) ;

    }
      function country(){
        $where= "id != 0";
          $this->data['country'] = $this->Webservice_model->getWhereOrderRecords('system_countries_code', $where, 'id', 'asc');
          
          $response = array(
                "status" => "1",
                "data" =>$this->data['country'],

            );
            
        echo json_encode ($response) ;

    }
    
   	function forgotPassword() {
     
                
				$where = "email = '".$_REQUEST['email']."' ";
				$getUser = $this->Webservice_model->getWhereOrderRecords('system_member_code', $where, 'id', 'asc');
				
				
				
				if(!empty($getUser)){
					
					//echo "<pre>";print_r($getUser);die;
					
					/* Send account detail email */
                        $password = random_string('alnum', 8);
					
				        $this->load->library('email');
                        $config = array (
                            'mailtype' => 'html',
                            'charset'  => 'utf-8',
                            'wordwrap' => TRUE,
                            'priority' => '1'
                        );
                        $this->email->initialize($config);
                        $this->email->from($this->app_email, $this->app_name);
                        $this->email->to($_REQUEST['email']);
                        #$this->email->cc($this->app_contactemail); // send copy at website contact email address
                        $this->email->subject('Your Latest password '.$this->app_name);


                        // send text email
                        $this->email->message('<html><body>
                        <h4>Your new password</h4>

                          Your password has been reset, you can login with the following credentials to
                        manage your account.<br> After login you can access CELPIP material on our website.
                        <br><br>

                        Login URL : '.base_url('/login').'<br>
                         Username : '.$getUser[0]->username .'<br>
                        password : '.$password.'<br>
         
                        <b>Note : </b>if you think this email has reached your inbox by mistake, <a href="'.base_url('contact?Eaddress='.$_REQUEST['email']).'">please report </a><br>

                        Best Wishes,<br>
                        '.$this->app_name.' Team<br>
                        </html></body>');
                        
                        //echo '<pre>'; print_r($data); echo '</pre>';
                      $result= $this->email->send();
                 
	
				$result_array = array('response'=>1,'message' => "User has been register success",);
				
				
				
				     
					$update_password = array('password'=>md5($password),'notMD5password'=>$password);
				if($this->Webservice_model->updateTable('system_member_code', $update_password, $getUser[0]->id))
				{
				     $response = array(
				"response"=>1,
                "message" => "Please check your inbox.");
				}
				else{
				    $response = array(
				"response"=>0,
                "message" => "Report to webmaster."
            );
				}
				      echo json_encode ($response) ;
            
					
					$this->session->set_flashdata('global_msg','Your Password has been reset please check your email for password');
				}else{
					$this->session->set_flashdata('global_msg','Email is not register please create your account');
				}
            }
        
        
        function contactus(){
            $email="contact@ielts24x7.com";
            $mobile="858-935-7686";
            	$result_array = array('email' => $email, 'mobile' => $mobile);
			
				      echo json_encode ($result_array) ;
        }
    
    function coinManage(){
        $where = "user_id = '".$_REQUEST['memberid']."' AND user_type = 'member'";
        $this->data['history'] = $this->Webservice_model->getWhereOrderRecords('system_coins_management_code', $where, 'id', 'desc');
        
        $userid= $_REQUEST['memberid'];
        $this->data['affiliate']= $this->Webservice_model->checkARecord('system_member_code', 'id',$userid);
//   print_r($this->data['affiliate']);die;
        if(isset($_REQUEST['amt'])){

            // Get the transaction data
            $txn_id = $_REQUEST['tx'];
            $payment_gross = $_REQUEST['amt'];
            $currency_code = $_REQUEST['cc'];
            $payment_status = $_REQUEST['st'];
            
            $coinscount = $this->Webservice_model->checkARecord('system_coins_code','cost',$payment_gross);
            $cointogive=$coinscount->coins;
            $additivecoins=(45/100) * $cointogive;
            $cointogiveaffiliate=$cointogive +$additivecoins;
        //    print_r($coinscount);die;
            if(!empty($this->data['affiliate']->affiliate_reference_no)){
                    $this->data['buy_coins'] =$cointogiveaffiliate; 
                
                }
                else{ $this->data['buy_coins'] = $cointogive; }
                    
            
            $querydata = array(

                     "member_id" =>  $_REQUEST['memberid'],
                     "txn_id"=> $txn_id,
                     "payment"=>$payment_gross,
                     "status"=>$payment_status,
                     "coins"=>$this->data['buy_coins'],
                     "date"=> date('Y-m-d')
                    );
                   // print_r($querydata);die;

            if($this->Webservice_model->insertDataIntoTable("system_membership_code",$querydata)){
                
                if(!empty($this->data['affiliate']->affiliate_reference_no)){
                    $this->data['buy_coins'] =$cointogiveaffiliate; 
                
                }
                else{ $this->data['buy_coins'] = $cointogive; }
                    
                
				$transaction_querydata = array(
					"user_id" =>  $userid,
					"transaction_id"=> $txn_id,
					"plan_type"=> $payment_gross,
					"transaction_status"=>$payment_status,
					"buy_coins"=>$this->data['buy_coins'],
					"created_date"=> date('Y-m-d H:i:s')
                    );
					
			//	echo "<pre>";print_r($transaction_querydata);die;
				
		$this->Webservice_model->insertDataIntoTable('system_transaction_code', $transaction_querydata);
	
	
				if(!empty($this->data['affiliate']->affiliate_reference_no))
				{
				    $transaction_affiliate_querydata = array(
					"user_id" =>  $userid,
					"transaction_id"=> $txn_id,
					"plan_type"=> $payment_gross,
					"transaction_status"=>$payment_status,
					"buy_coins"=>$this->data['buy_coins'],
					"affiliate_reference_no"=>$this->data['affiliate']->affiliate_reference_no,
					"created_date"=> date('Y-m-d H:i:s')
                    );
                    	$this->Webservice_model->insertDataIntoTable('system_affiliate_transaction_code', $transaction_affiliate_querydata);
				}
				
				
                $coins_bought = $this->data['affiliate']->coins + $this->data['buy_coins'];
 
                $updateData = array(
                    'coins' => $coins_bought 
                    );

                if($this->Webservice_model->updateTable('system_member_code',$updateData, $userid))
                {

                    //CHARGE COIN COST
                    $objMember = $this->Webservice_model->getARecord('system_member_code',  $userid);  
                    $balance_coins = $coins_bought;
                    $updateMemCoins = array('coins'=>$balance_coins);
                    $this->Webservice_model->updateTable('system_member_code', $updateMemCoins, $objMember->id);
                    $coin_data = array('user_id'=>$objMember->id,
                        'user_type'=>'member',
                        'description'=>"Purchased coins $".$payment_gross,
                        'credit_coin'=>$this->data['buy_coins'],
                        'balance_coin'=>$coins_bought,
                        'created_date'=>date('Y-m-d H:i:s'),
                        'updated_at'=>date('Y-m-d H:i:s'),
                    );
                    $this->Webservice_model->insertDataIntoTable('system_coins_management_code', $coin_data);
					;
			//		print_r($coin_data);die;
					
					if($objMember->student_reference_no != '0'){
						$anotherMember = $this->Webservice_model->getARecord('system_member_code', $objMember->student_reference_no);
					//	print_r($anotherMember);die;
						$get_free_coins = $anotherMember->coins + $this->data['buy_coins']/3;

						$updateData = array(
							'coins' => $get_free_coins 
							);

						$this->Webservice_model->updateTable("system_member_code",$updateData,$anotherMember->id);
						
						$coin_data = array('user_id'=>$anotherMember->id,
							'user_type'=>'member',
							'description'=>"Referred student just purchased coins ",
							'credit_coin'=>(($this->data['buy_coins'])/3),
							'balance_coin'=>$get_free_coins,
							'created_date'=>date('Y-m-d H:i:s'),
							'updated_at'=>date('Y-m-d H:i:s'),
						);
						$this->Webservice_model->insertDataIntoTable('system_coins_management_code', $coin_data);
					}
				
				/* if($objMember->business_reference_no != ''){
					$anotherU_id = preg_replace('/[^0-9]/', '', $objMember->business_reference_no);
					$anotherMember = $this->Webservice_model->getARecord('system_member_code', $anotherU_id);
						$get_free_coins = $anotherMember->coins + $this->data['buy_coins'];

						$updateData = array(
							'coins' => $get_free_coins 
							);

						$this->Webservice_model->updateTable("system_member_code",$updateData,$anotherMember->id);
						
						$coin_data = array('user_id'=>$anotherMember->id,
							'user_type'=>'member',
							'description'=>"Get free coins on buy referenced user ",
							'credit_coin'=>$this->data['buy_coins'],
							'balance_coin'=>$get_free_coins,
							'created_date'=>date('Y-m-d H:i:s'),
							'updated_at'=>date('Y-m-d H:i:s'),
						);
						$this->Webservice_model->insertDataIntoTable('system_coins_management_code', $coin_data);
				} */
				

                
            }
            
$response = array(
                'response' => '1',
                'message' => 'coins added!!'
                        );
                                                echo json_encode ($response) ;


                }
        }
    }
    
  function addTicket() {
         $title=$_REQUEST['title'];
             $type=$_REQUEST['type'];
             $details=$_REQUEST['details'];
                    
                    
                    $qryData = array(
                    'title' => $title,
                    'type' => $type,
                    'details' => $details,
                    'member_id' =>$_REQUEST['member_id'],
                    'status'=>'open',
                    'time' => time(),
                );

                if( $this->Webservice_model->insertDataIntoTable('system_support_code', $qryData) )
                {
                     $response = array(
				"response"=>1,
                "message" => "Ticket added");
                }else{
                      $response = array(
				"response"=>0,
                "message" => "Report to webmaster.");
                }
                 echo json_encode ($response) ;
            }
            
            
            
    function viewtickets() {
        $where = "member_id = '".$_REQUEST['member_id']."' ";
				
        $this->data['supports'] = $this->Webservice_model->getWhereRecords('system_support_code', $where);
        if(!empty(supports)){

       $response = array(
				"response"=>1,
                "data" =>$this->data['supports']);
                }else{
                      $response = array(
				"response"=>0,
                "message" => "Report to webmaster.");
                }
                 echo json_encode ($response) ;
            
    }  
    	  function viewReadReport(){
                    $testid=$_REQUEST['testid'];
             $testcode=$_REQUEST['testcode'];
             $member_id=$_REQUEST['memberid'];
             $where="test_id = '$testid' AND member_id = '$member_id' AND test_code = '$testcode' ";
        $this->data['testdetail'] = $this->Webservice_model->getWhereLastRecords('system_testdetails_code', $where);
        //print_r($this->data['testdetail']);die;
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        //print_r($this->data['testdetail'] );

        $check_test = $this->Webservice_model->checkARecord('system_PTEsubtype_code', 'id', $this->data['testdetail']->test_id);
        $this->data['test_type_id'] = $check_test->PTEtypeid;

   //      echo $this->data['test_type_id'];
   //print_r($this->data['testdetail'] );
   //print_r($check_test);die;
        if( !is_object($check_test)) {
            exit($this->unauthorized_message);
        }

     
        $this->data['attempt'] = $this->Webservice_model->checkARecord('system_attempt_code', 'testdetail_id', $this->data['testdetail']->id);
       // print_r($this->data['attempt']);die;
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $attempt_data = json_decode($this->data['attempt']->json_result, true);
    //    echo "<pre>"; print_r($this->data['attempt_data']);
    
    
    if(!is_object($attempt_data)){
        $response=array( "status" => "1",
                "message" => $attempt_data,);
    }else{
        $response=array( "status" => "0",);
    }
        echo json_encode ($response) ;
    

            }

}
