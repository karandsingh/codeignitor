 <?php   

    function project() {
        //upload image
        $path = $_FILES['file']['tmp_name'];

        $image_name = preg_replace("/[^a-z0-9\._]+/", "-", strtolower(uniqid() . $_FILES['file']['name']));

        $data['message'] = "sucess";

        $s3_bucket = $this->s3_bucket_upload($path, $image_name);
        echo "<pre>hiii";print_r($s3_bucket);die;
        if ($s3_bucket['message'] == "sucess") {
            $data['imagename'] = $s3_bucket['imagepath'];
            $data['imagepath'] = $s3_bucket['imagename'];
        }
    }

    function s3_bucket_upload($temppath, $image_path)
    {
        require 'aws-s3-bucket/vendor/autoload.php';
        $bucket = "celpipstore-media-files";
        //$bucket = "com.homepie.staging.images";

        $data = array();
        $data['message'] = "false";

        try {
            //staging homepie
            /* $s3Client = new Aws\S3\S3Client([
                'version'     => 'latest',
                'region'      => 'us-west-2',
                'credentials' => [
                    'key'    => 'AKIAQ5TUPBP67S6PCJ6U',
                    'secret' => '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',
                ],
            ]); */

            //celpip bucket
            $s3Client = new Aws\S3\S3Client([
                'version'     => 'latest',
                'region'      => 'us-west-2',
                'credentials' => [
                    'key'    => 'AKIA323GRW63FBO3HGTM',
                    'secret' => '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',
                ],
            ]);

            // For website only
            $result = $s3Client->putObject([
                'Bucket'     => $bucket,
                'Key'        => 'images/'.$image_path,
                'SourceFile' => $temppath,
                //'body'=> $file_Path,
                //'ACL'        => 'public-read',
                //'StorageClass' => 'REDUCED_REDUNDANCY',
            ]);

            $data['message']   = "sucess";
            $data['imagename'] = $image_path;
            $data['imagepath'] = $result['ObjectURL'];



            //Get a command to GetObject
            $cmd = $s3Client->getCommand('GetObject', [
                'Bucket' => $bucket,
                'Key'    => $image_path
            ]);

            //The period of availability
            $request = $s3Client->createPresignedRequest($cmd, '+10 minutes');

            //Get the pre-signed URL
            $signedUrl = (string) $request->getUri();
            echo $signedUrl;die;


        } catch (Exception $e) {
            $data['message'] = "false";
            echo $e->getMessage() . "\n";
        }

        return $data;
    }
    
    
    
    function gets3()
    {
        require 'aws-s3-bucket/vendor/autoload.php';
    //    use Aws\S3\S3Client;
     //   use Aws\S3\Exception\S3Exception;

$bucket = "celpipstore-media-files";
$keyname = 'AKIA323GRW63FBO3HGTM';

$s3 = new S3Client([
    'version' => 'latest',
    'region'  => 'us-east-1'
]);

try {
    // Get the object.
    $result = $s3->getObject([
        'Bucket' => $bucket,
        'Key'    => $keyname
    ]);

    // Display the object in the browser.
    header("Content-Type: {$result['ContentType']}");
    echo $result['Body'];
} catch (S3Exception $e) {
    echo $e->getMessage() . PHP_EOL;
}
    }