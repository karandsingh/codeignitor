<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?><small><?php echo $pagetitle; ?> details</small></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?> Manager </li>
      </ol>
    </section>

    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <div class="box">
                  <div class="box-header">
                    <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
                      <h4><i class="fa fa-info"></i> Note:</h4>
                      Edit Question Under category Task 2: Responding to Survey Questions</strong>
                      <a href="<?php echo base_url('teacher/wtTask2List'); ?>">   <span class="pull-right badge bg-red">Click here to Go Back</span></a>
                    </div>
                  </div>
				  
				  <?php if($this->session->flashdata('global_msg')){ ?>
					 <div class="alert alert-success">
					  <button class="close" type="button" data-dismiss="alert">
						<span aria-hidden="true">&times;</span>
					  </button>
					  <?=$this->session->flashdata('global_msg')?>
					</div>
				   <?php } ?>

                  <div class="box-body">
                    <table class="table table-bordered">
                      <tr>
                        <td>Type</td>
                        <td><strong>Writing</strong></td>
                      </tr>
                      <tr>
                        <td>Sub Type</td>
                        <td><strong>Task 2: Responding to Survey Questions</strong></td>
                      </tr>
					  <tr>
                        <td>Test Code</td>
                        <td><strong><?php echo $test->test_code; ?></strong></td>
                      </tr>
                    </table>

                    <?php
                      if($errors) {
                        foreach ($errors as $error) {
                          echo '<div class="alert alert-danger">'.$error.'</div>';
                        }
                      }
                    ?>

                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('teacher/wtTask2_edit/'.$this->uri->rsegment(3), array('id' => mb_strtolower($this->uri->rsegment(3)), 'class' => 'clearfix' )); ?>
                      <hr />
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Question Title</label>
									<input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question',$test->question_title); ?>" required>
								</div>
							</div>
							
                            <div class="col-md-12">
								<div class="form-group">
									<label>Option A</label>
									<textarea class="form-control" rows="5" name="option_1" placeholder="Place some text here" required=""><?php echo $test->option_1; ?></textarea>
								</div>
							</div>
							
							<div class="col-md-12">
								<div class="form-group">
									<label>Option B</label>
									<textarea class="form-control" rows="5" name="option_2" placeholder="Place some text here" required=""><?php echo $test->option_2; ?></textarea>
								</div>
							</div>
						</div>	  
						  
						 <button type="submit" class="btn btn-info btn-fill pull-right">Edit</button>
                         <div class="clearfix"></div> 

                      </form>

                  </div>


              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>