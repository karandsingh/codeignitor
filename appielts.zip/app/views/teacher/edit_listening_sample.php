<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?></h1>
     
    </section>

    

    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <h1><?php if($test->Subtypeid==11){
					echo "Listening Part 1: Multiple Choice with one answer";
				}elseif($test->Subtypeid==12){
					echo "Listening Part 2: Multiple choice with more than one answer";
					}elseif($test->Subtypeid==13){
					echo "Listening Part 3: Matching";
					}elseif($test->Subtypeid==14){
					echo "Listening Part 4: Labelling on a Map";
					}elseif($test->Subtypeid==15){
					echo "Listening Part 5: Fill in the Blanks";
					}elseif($test->Subtypeid==16){
					echo "Listening Part 6: Fill in the Blanks : Short Answer";
					}
					else 
					{
		    echo "Listening Sample Test";
		}
              ?></h1>
         </div>
         </div>

                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('teacher/editsamplelistening/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(3), 'class' => 'clearfix' )); ?>
                      <hr />
						
						<div class="row">
						    	<div class="col-md-12">
								<div class="form-group">
									<label>Seo Title</label>
									<input type="text" class="form-control" placeholder="Seo title" name="seo_title" value="<?php echo set_value('seo_title',$test->seo_title); ?>" required>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label>Seo Discription</label>
									<textarea class="form-control" rows="5" name="seo_discription" placeholder="Place some text here" required=""><?php echo $test->seo_discription; ?></textarea>
								</div>
							</div>
						     <div class="col-md-12">
								<div class="form-group">
									<label>Question Title</label>
									<input type="text" class="form-control" placeholder="Question title" name="title" value="<?php echo set_value('title',$test->title); ?>" required>
								</div>
							</div>
							
							 
						  
						  <div class="col-md-12">
								<div class="form-group">
									<label>Youtube Embed</label>
									<textarea class="form-control" rows="5" name="youtubelink" placeholder="Paste youtube url here" required=""><?php echo $test->video_url; ?></textarea>
								</div>
							</div>
						
						</div>	  
						 <button type="submit" class="btn btn-info btn-fill pull-right">Edit</button>
                         <div class="clearfix"></div> 

                      </form>

                  </div>


              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>