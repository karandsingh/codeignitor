<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

        <style type="text/css">
    .widget-user .widget-user-header {
    padding: 15px;
    height: 90px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
}
  </style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
    <h1 style="text-align:center;color:#000">    
    <?php 
			
		
		
		if($Subtypeid->Subtypeid==21){$this->data['pagetitle'] = 'Sample Academic Reading Part 1: Multiple Choice with one answer';}
                    elseif($Subtypeid->Subtypeid==22){$this->data['pagetitle'] = 'Sample Academic Reading Part 2: Multiple Choice with more than one answer';}
                    elseif($Subtypeid->Subtypeid==23){$this->data['pagetitle'] = 'Sample Academic Reading Part 3: Identify Information : True/False/Not Given';}
                    elseif($Subtypeid->Subtypeid==24){$this->data['pagetitle'] = 'Sample Academic Reading Part 4: Note Completion';} 
                    elseif($Subtypeid->Subtypeid==25){$this->data['pagetitle'] = 'Sample Academic Reading Part 5: Matching Headings';} 
                    elseif($Subtypeid->Subtypeid==26){$this->data['pagetitle'] = 'Sample Academic Reading Part 6: Summary Completion (Selecting Word from a text)';} 
                    elseif($Subtypeid->Subtypeid==27){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Summary Completion (Selecting from a list of words or phase)';}
                    elseif($Subtypeid->Subtypeid==28){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Flow -Chart Completion';}
                    elseif($Subtypeid->Subtypeid==29){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Sentence Completion';}
                    elseif($Subtypeid->Subtypeid==30){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Matching Sentence endings';}
			?></h1>
			
		
     
    </section>

    <!-- Main content -->

          <div class="box"
          >            <div class="box-header">
  <h3 class="box-title" stle="text-align:center">Sample Questions</h3>
              <?php if($Subtypeid->Subtypeid==21){
                                  ?>
                                       <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/21" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                  <?php }elseif($Subtypeid->Subtypeid==22){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/22" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==23){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/23" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==24){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/24" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==25){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/25" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==26){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/26" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==27){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/27" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==28){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/28" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==29){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/29" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==30){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addacademicreadingsample/30" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php } ?>
                                 </div></div>
              <div class="box-body" style="overflow:scroll;">	
              <table id="example1" class="table table-bordered table-striped">
                              <thead>
                                 <tr>         
                                 <th>Id</th>
                                  <th>Test Title</th>
                                <th></th>
                                </tr>
                              </thead>

                              <tbody>
   <?php if($Subtypeid->Subtypeid==21){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     
     <?php if($Subtypeid->Subtypeid==22){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     <?php if($Subtypeid->Subtypeid==23){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     <?php if($Subtypeid->Subtypeid==24){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     
     
      <?php if($Subtypeid->Subtypeid==25){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
      <?php if($Subtypeid->Subtypeid==26){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
      <?php if($Subtypeid->Subtypeid==27){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     
     
      <?php if($Subtypeid->Subtypeid==28){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
      <?php if($Subtypeid->Subtypeid==29){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
      <?php if($Subtypeid->Subtypeid==30){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editacademicreadingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     
     

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  
	<div id="section-writing-instructions" class="modal fade">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-body">
			
		  </div>
		</div>
	  </div>
	</div>

  <?php include_once('common/scripts.php'); ?>
  
</body>
</html>
