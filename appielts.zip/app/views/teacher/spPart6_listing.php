<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
	      Task 6: Dealing with a Difficult Situation
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <?php if($this->session->flashdata('global_msg')){ ?>
			 <div class="alert alert-success">
			  <button class="close" type="button" data-dismiss="alert">
				<span aria-hidden="true">&times;</span>
			  </button>
			  <?=$this->session->flashdata('global_msg')?>
			</div>
		   <?php } ?>
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Task 6: Dealing with a Difficult Situation</h3>
			  <a href="<?php echo base_url(); ?>teacher/spPart6" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
				  <thead>
					 <tr>
					  <th>Id</th>
					  <th>Test Codes</th>
					  <th>Action</th>
					</tr>
				    </thead>
					  <tbody>
                    <?php
						if (!empty($sppart_list)) {
						foreach ($sppart_list as $key => $sppart) { ?>

                     <tr>
                        <td><span class="online"><?=$sppart->id?></span></td>     
                        <td><span class="online"><?=$sppart->test_code?></span></td>     
						<td><a href="<?php echo base_url(); ?>teacher/spPart6_edit/<?=$sppart->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i></a></td>
                        </tr>
                      <?php }} ?>
                    </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

 
  <?php include_once('common/scripts.php'); ?>
</body>
</html>
