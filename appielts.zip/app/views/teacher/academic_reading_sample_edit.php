<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?></h1>
     
    </section>

    

    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <h1><?php if($test->Subtypeid==21){$this->data['pagetitle'] = 'Sample Academic Reading Part 1: Multiple Choice with one answer';}
                    elseif($test->Subtypeid==22){$this->data['pagetitle'] = 'Sample Academic Reading Part 2: Multiple Choice with more than one answer';}
                    elseif($test->Subtypeid==23){$this->data['pagetitle'] = 'Sample Academic Reading Part 3: Identify Information : True/False/Not Given';}
                    elseif($test->Subtypeid==24){$this->data['pagetitle'] = 'Sample Academic Reading Part 4: Note Completion';} 
                    elseif($test->Subtypeid==25){$this->data['pagetitle'] = 'Sample Academic Reading Part 5: Matching Headings';} 
                    elseif($test->Subtypeid==26){$this->data['pagetitle'] = 'Sample Academic Reading Part 6: Summary Completion (Selecting Word from a text)';} 
                    elseif($test->Subtypeid==27){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Summary Completion (Selecting from a list of words or phase)';}
                    elseif($test->Subtypeid==28){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Flow -Chart Completion';}
                    elseif($test->Subtypeid==29){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Sentence Completion';}
                    elseif($test->Subtypeid==30){$this->data['pagetitle'] = 'Sample Academic Reading Part 7: Matching Sentence endings';}
              ?></h1>
         </div>
         </div>

                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('teacher/editacademicreadingsample/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(3), 'class' => 'clearfix' )); ?>
                      <hr />
						
						<div class="row">
						    	<div class="col-md-12">
								<div class="form-group">
									<label>Seo Title</label>
									<input type="text" class="form-control" placeholder="Seo title" name="seo_title" value="<?php echo set_value('seo_title',$test->seo_title); ?>" required>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label>Seo Discription</label>
									<textarea class="form-control" rows="5" name="seo_discription" placeholder="Place some text here" required=""><?php echo $test->seo_discription; ?></textarea>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label>Question Title</label>
									<input type="text" class="form-control" placeholder="Question title" name="title" value="<?php echo set_value('title',$test->title); ?>" required>
								</div>
							</div>
							
							 
						  
						  <div class="col-md-12">
								<div class="form-group">
									<label>Youtube Embed</label>
									<textarea class="form-control" rows="5" name="youtubelink" placeholder="Paste youtube url here" required=""><?php echo $test->video_url; ?></textarea>
								</div>
							</div>
							
						
						</div>	  
						 <button type="submit" class="btn btn-info btn-fill pull-right">Edit</button>
                         <div class="clearfix"></div> 

                      </form>

                  </div>


              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>