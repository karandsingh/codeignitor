<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Teacher
        <small>Teacher details</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Teacher</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
            </div>


            <!-- /.box-header -->
            <div class="box-body">
                                <?php echo validation_errors(); ?>



                                    <?php if ($success) { ?>
                  <div class="alert alert-success">
                    <button class="close" type="button" data-dismiss="alert">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    Your account password changed.
                  </div>
                <?php } else { ?>
       
                   
                  <div class="row">
                    <div class="col-md-6">
                      <!-- form start -->
                      <?php echo form_open($this->uri->segment(1).'/'.$this->uri->segment(2), array('id' => $this->uri->segment(2),'role'=>'form')) ?>
                        <div class="box-body">

                          <div class="form-group">
                            <label for="old">Current password</label>
                            <div class="input-group">
                              <span class="input-group-addon"><i class="fa fa-key"></i></span>
                              <input type="text" class="form-control" id="old" name="old" value="<?php echo set_value('old'); ?>">
                            </div>
                          </div>


                          <div class="form-group">
                            <label for="new">New password</label>
                            <div class="input-group">
                              <span class="input-group-addon"><i class="fa fa-key"></i></span>
                              <input type="text" class="form-control" id="new" name="new" value="<?php echo set_value('new'); ?>">
                            </div>
                          </div>


                          <div class="form-group">
                            <label for="confirm">Confirm password</label>
                            <div class="input-group">
                              <span class="input-group-addon"><i class="fa fa-key"></i></span>
                              <input type="text" class="form-control" id="confirm" name="confirm" value="<?php echo set_value('confirm'); ?>">
                            </div>
                          </div>


                        </div>
                        <div class="box-footer">
                          <button type="submit" class="btn btn-success">Update</button>
                        </div>
                      <?php echo form_close() ?>
                    </div>
                  </div>
       
                <?php } ?>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

 
  <?php include_once('common/scripts.php'); ?>
</body>
</html>
