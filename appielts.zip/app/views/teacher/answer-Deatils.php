<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
  <style type="text/css">
    .widget-user .widget-user-header {
      padding: 15px;
      height: 90px;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
    }
    @media only screen and (max-width: 600px) {
  .scrollbar1 {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 600px) {
  .scrollbar {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
}
}
@media only screen and (max-width: 600px) {
.page-title-wrapper {
  margin-bottom: 30px !important;
  border-top: 1px solid #fff;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  -ms-border-radius: 3px;
  -o-border-radius: 3px;
  border-radius: 3px;
  margin-top: 100px !important;
  margin-left: 10px !important;
  margin-right: 10px !important;
}
}
.radio-gap {
    margin-top: 35px;
}
.student_ans_dtail {
    white-space: pre-wrap;
}
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="page-wrapper">
    <div id="page-content">
    <header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip</h1>
              <a href="<?php echo base_url('member/dashboard'); ?>"><!--font size="20px"><strong>CELPIP</strong></font--><img src="images/logo-celpip.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            
          </div>
        </div>
      </header>

    <div class="page-title-wrapper fixed-width">
        <div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1><?php 
				if($testdetail->test_id==14){
					echo 'Listening Part 4: Labelling on a map Details ';
				}elseif($testdetail->test_id==29){
					echo 'Listening Practice Task Questions:';
				}elseif($testdetail->test_id==16){
					echo 'Listening Part 6: Fill i3.Where do Gn the gaps: short answers:';
				}elseif($testdetail->test_id==13){
					echo 'Listening Part 3: Matching:';
				}elseif($testdetail->test_id==11){
					echo 'Listening Part 1 : Multiple choice with one answer';
				}elseif($testdetail->test_id==12){
					echo 'Listening Part 2: Multiple choice question with more than one answer';
				}elseif($testdetail->test_id==15){
					echo 'Listening Part 6: Listening to Viewpoints';
				}elseif($testdetail->test_id==47){
					echo 'Writing Task 1: Writing an Email Details';
				}elseif($testdetail->test_id==46){
					echo 'Writing Task 2: Responding to Survey Questions';
				}elseif($testdetail->test_id==59){
					echo 'Speaking: Practice Task';
				}elseif($testdetail->test_id==58){
					echo 'Speaking Task 1: Giving Advice ';
				}elseif($testdetail->test_id==62){
					echo 'Speaking Part 1 : Introduction & Interview';
				}elseif($testdetail->test_id==63){
					echo 'Speaking Part 2: Individual Long Turn (Cue-Card)';
				}elseif($testdetail->test_id==64){
					echo 'Speaking Part 3: Discussion';
				}elseif($testdetail->test_id==56){
					echo 'Speaking Task 3: Describing a Scene';
				}elseif($testdetail->test_id==55){
					echo 'Speaking Task 4: Making Predictions';
				}elseif($testdetail->test_id==54){
					echo 'Speaking Task 5: Comparing and Persuading';
				}elseif($testdetail->test_id==51){
					echo 'Academic General Part 1';
				}elseif($testdetail->test_id==52){
					echo 'Academic General Part 2';
				}elseif($testdetail->test_id==42){
					echo 'Academic Writing Part 2';
			
				}elseif($testdetail->test_id==41){
					echo 'Academic Writing Part 1';
				}elseif($testdetail->test_id==21){
					echo 'Academic Reading Part 1 : Multiple choice with one answer';
				}elseif($testdetail->test_id==22){
					echo 'Academic Reading Part 2: Multiple choice question with more than one answer';
				}elseif($testdetail->test_id==23){
					echo 'Reading Part 3: Identifying Information (True/False/Not Given)';
				}elseif($testdetail->test_id==31){
					echo 'Academic Reading Part 1: Matching Information';
				}elseif($testdetail->test_id==32){
					echo 'Academic Reading Part 2: True/False/Not Given';
				}elseif($testdetail->test_id==36){
					echo 'Academic Reading Part 6: Multiple Choice';
				}
				else{
					echo '';
				} ?>
      </h1>
            
          </div>
          <div class="otw-five otw-columns">
            <!--<form name="submit_ptest" enctype="multipart/form-data" id="submit_ptest" action="<?php echo base_url('member/PracticeTaskSubmit')?>" method="get" class="searchform">-->
                <!--<button type="button" class="btn btn-danger"><i class="fa fa-hand-o-right"></i>Submit</button>-->
        
        <?php /*if($testdetail->test_id==29){ ?>
                <input type="submit" title="Next" name="submit" value="Submit">
        <?php } */ ?>
        
        <?php if($testdetail->test_id==20){ ?>
          <!--button type="button" class="btn ls1_next_btn" data-screenid="2">Next</button-->
        <?php } ?>
        
        <?php if($testdetail->test_id==19){ ?>
          <!--button type="button" class="btn ls2_next_btn" data-screenid="2">Next</button-->
        <?php } ?>
        
        <?php if($testdetail->test_id==18){ ?>
          <!--button type="button" class="btn ls3_next_btn" data-screenid="2">Next</button-->
        <?php } ?>
        
        <?php if($testdetail->test_id==17){ ?>
          <!--button type="button" class="btn ls4_next_btn" data-screenid="2">Next</button-->
        <?php } ?>
        
        <?php if($testdetail->test_id==16){ ?>
          <!--button type="button" class="btn ls5_next_btn" data-screenid="2">Next</button-->
        <?php } ?>
        
        <?php if($testdetail->test_id==15){ ?>
          <!--button type="button" class="btn ls6_next_btn" data-screenid="2">Next</button-->
        <?php } ?>
        
        <?php if($testdetail->test_id==47){ ?>
          <!--button type="button" class="btn wt1_next_btn" data-screenid="2">Next</button-->
        <?php } ?>
          </div>
        </div>
       
      </div>
    
      <!--header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip Practice Test</h1>
              <a href="<?php //echo base_url(); ?>"><img src="images/logo-celpip.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            
          </div>
        </div>
      </header-->

      
        <?php /*<div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1><?php 
        if($testdetail->test_id==20){
          echo 'Part 1: Listening to Problem Solving';
        }elseif($testdetail->test_id==29){
          echo 'Listening Practice Task Questions:';
        }elseif($testdetail->test_id==19){
          echo 'Part 2: Listening to Daily Life Conversation:';
        }elseif($testdetail->test_id==18){
          echo 'Part 3: Listening for Information:';
        }elseif($testdetail->test_id==17){
          echo 'Part 4: Listening to a News Item';
        }else{
          echo '';
        } ?>
      </h1>
          </div>
          <div class="otw-five otw-columns">
            <form name="submit_ptest" enctype="multipart/form-data" id="submit_ptest" action="<?php echo base_url('member/PracticeTaskSubmit')?>" method="get" class="searchform">
                <!--button type="button" class="btn btn-danger"><i class="fa fa-hand-o-right"></i>Submit</button-->
        
        <?php if($testdetail->test_id==29){ ?>
                <input type="submit" title="Next" name="submit" value="Submit">
        <?php } ?>
        
        <?php if($testdetail->test_id==20){ ?>
          <button type="button" class="btn ls1_next_btn" data-screenid="2">Next</button>
        <?php } ?>
        
        <?php if($testdetail->test_id==19){ ?>
          <button type="button" class="btn ls2_next_btn" data-screenid="2">Next</button>
        <?php } ?>
        
        <?php if($testdetail->test_id==18){ ?>
          <button type="button" class="btn ls3_next_btn" data-screenid="2">Next</button>
        <?php } ?>
        
        <?php if($testdetail->test_id==17){ ?>
          <button type="button" class="btn ls4_next_btn" data-screenid="2">Next</button>
        <?php } ?>
            
          </div>
        </div>*/ ?>

      </div>
        
      <div class="otw-row main-content">


        <?php if($this->session->flashdata('global_msg')){ ?>
           <div class="col-md-12 alert alert-success">
            <button class="close" type="button" data-dismiss="alert">
            <span aria-hidden="true">&times;</span>
            </button>
            <?=$this->session->flashdata('global_msg')?>
          </div>
        <?php } ?>


        <div class="otw-twentyfour otw-columns otw-content-section">
        <?php if($testdetail->test_id==29){ ?>
          <div class="otw-row">
            <div class="otw-ten otw-columns">
                <div class="border-sec">
              <h2> Listen to a short statement. In actual test You will hear it only once.</h2>
              <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
               <p align="center">
               <audio controls>
                   <source src="<?php echo base_url(); ?>uploads/listening_practiceTask/<?php echo $test->mp3URL;?>" type="audio/ogg">
                    <source src="<?php echo base_url(); ?>uploads/listening_practiceTask/<?php echo $test->mp3URL;?>" type="audio/mpeg">
               </audio></p>
               <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
               <p align="center">This playbar will not appear in the official test.</p></div>
              <div class="otw-sc-hr"></div>
              <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
            </div></div>
             <div class="otw-thirteen otw-columns">
              <h2> Choose the sentence that is closest in meaning to the statement.</h2>
              
                <table>
                  <div><input type="radio" checked name="q1-response" value="option1">&nbsp;&nbsp;&nbsp;<?php echo $test->option1;?></div><br>
                  <div><input type="radio" name="q1-response" value="option2">&nbsp;&nbsp;&nbsp;<?php echo $test->option2;?></div><Br>
                  <div><input type="radio" name="q1-response" value="option3">&nbsp;&nbsp;&nbsp;<?php echo $test->option3;?></div><Br>
                  <div><input type="radio" name="q1-response" value="option4">&nbsp;&nbsp;&nbsp;<?php echo $test->option4;?></div><br>
                </table>
              
              
            </div>
          </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==20){ 
      //echo "<pre>";print_r($test);
    ?>
      <div class="otw-row ls-part1 ls-part1-screen-1">
        <div class="otw-twentyfour otw-columns">
          <p><div><font style="font-size: 30px;"> Instructions:</font>
          &nbsp; <?php echo $test->l1_practice_01_text; ?></div></p>
         
          <img src="<?php echo base_url('uploads/part1_listening/').$test->l1_practice_01_img; ?>" class="test-img">
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-2" style="display:none">
        <div class="otw-twentyfour otw-columns">
          <h1> Listen to the conversation. You will hear the conversation only once. It is about 1 to 1.5 minutes long. </h1>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
          <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_conversation_1_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      
      <div class="otw-row ls-part1 ls-part1-screen-3" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border">
          <h2><!--<img src="images/1.png">--> Listen to a short statement.<br>&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 1 of 8</p>
          <h2> Choose the best answer to each question.</h2>
          <form>
          <table>
            <div><input type="radio" name="q1-response" checked value="l1_q1_option1">&nbsp;&nbsp;&nbsp;<img width="100" height="100" src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_option1; ?>"></div>&nbsp;
            <div><input type="radio" name="q1-response" value="l1_q1_option2">&nbsp;&nbsp;&nbsp;<img width="100" height="100" src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_option2; ?>"></div>&nbsp;
            <div><input type="radio" name="q1-response" value="l1_q1_option3">&nbsp;&nbsp;&nbsp;<img width="100" height="100" src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_option3; ?>"></div>&nbsp;
            <div><input type="radio" name="q1-response" value="l1_q1_option4">&nbsp;&nbsp;&nbsp;<img width="100" height="100" src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_option4; ?>"></div>&nbsp;
          </table>
          </form>
          
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-4" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q2_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 2 of 8</p>
          <h2><!--<img src="images/1.png">--> Choose the best answer to each question.</h2>
          <form>
          <table>
            <div><input type="radio" name="q2-response" checked value="l1_q2_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q2_option1; ?></div>
            <div><input type="radio" name="q2-response" value="l1_q2_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q2_option2; ?></div>
            <div><input type="radio" name="q2-response" value="l1_q2_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q2_option3; ?></div>
            <div><input type="radio" name="q2-response" value="l1_q2_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q2_option4; ?></div>
          </table>
          </form>
          
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-5" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q3_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 3 of 8</p>
          <h2> Choose the best answer to each question.</h2>
          <form>
          <table>
            <div><input type="radio" name="q3-response" checked value="l1_q3_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q3_option1; ?></div>
            <div><input type="radio" name="q3-response" value="l1_q3_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q3_option2; ?></div>
            <div><input type="radio" name="q3-response" value="l1_q3_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q3_option3; ?></div>
            <div><input type="radio" name="q3-response" value="l1_q3_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q3_option4; ?></div>
          </table>
          </form>
          
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-6" style="display:none">
        <div class="otw-twentyfour otw-columns">
          <h1> Listen to the conversation. You will hear the conversation only once. It is about 1 to 1.5 minutes long. </h1>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
          <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_conversation_2_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-7" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q4_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 4 of 8</p>
          <h2> Choose the best answer to each question.</h2>
          <form>
          <table>
            <div><input type="radio" name="q4-response" checked value="l1_q4_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q4_option1; ?></div>
            <div><input type="radio" name="q4-response" value="l1_q4_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q4_option2; ?></div>
            <div><input type="radio" name="q4-response" value="l1_q4_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q4_option3; ?></div>
            <div><input type="radio" name="q4-response" value="l1_q4_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q4_option4; ?></div>
          </table>
          </form>
          
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-8" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q5_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 5 of 8</p>
          <h2> Choose the best answer to each question.</h2>
          <form>
          <table>
            <div><input type="radio" name="q5-response" value="l1_q5_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q5_option1; ?></div>
            <div><input type="radio" name="q5-response" checked value="l1_q5_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q5_option2; ?></div>
            <div><input type="radio" name="q5-response" value="l1_q5_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q5_option3; ?></div>
            <div><input type="radio" name="q5-response" value="l1_q5_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q5_option4; ?></div>
          </table>
          </form>
          
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-9" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q6_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 6 of 8</p>
          <h2> Choose the best answer to each question.</h2>
          <form>
          <table>
            <div><input type="radio" name="q6-response" checked value="l1_q6_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q6_option1; ?></div>
            <div><input type="radio" name="q6-response" value="l1_q6_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q6_option2; ?></div>
            <div><input type="radio" name="q6-response" value="l1_q6_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q6_option3; ?></div>
            <div><input type="radio" name="q6-response" value="l1_q6_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q6_option4; ?></div>
          </table>
          </form>
          
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-10" style="display:none">
        <div class="otw-twentyfour otw-columns">
          <h1> Listen to the conversation. You will hear the conversation only once. It is about 1 to 1.5 minutes long. </h1>
          <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>
          <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_conversation_3_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-11" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q7_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 7 of 8</p>
          <h2> Choose the best answer to each question.</h2>
          <form>
          <table>
            <div><input type="radio" name="q7-response" checked value="l1_q7_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q7_option1; ?></div>
            <div><input type="radio" name="q7-response" value="l1_q7_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q7_option2; ?></div>
            <div><input type="radio" name="q7-response" value="l1_q7_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q7_option3; ?></div>
            <div><input type="radio" name="q7-response" value="l1_q7_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q7_option4; ?></div>
          </table>
          </form>
          
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part1 ls-part1-screen-12" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q8_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 8 of 8</p>
          <h2> Choose the best answer to each question.</h2>
          <form>
          <table>
            <div><input type="radio" name="q8-response" checked value="l1_q8_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q8_option1; ?></div>
            <div><input type="radio" name="q8-response" value="l1_q8_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q8_option2; ?></div>
            <div><input type="radio" name="q8-response" value="l1_q8_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q8_option3; ?></div>
            <div><input type="radio" name="q8-response" value="l1_q8_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q8_option4; ?></div>
          </table>
          </form>
          
          <div class="otw-sc-hr"></div>
        </div>
      </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==19){ 
      //echo "<pre>";print_r($test);
    ?>
    
      <div class="otw-row ls-part2 ls-part2-screen-1">
        <div class="otw-twentyfour otw-columns">
          <h1> Listen to the conversation. You will hear the conversation only once. It is about 1 to 1.5 minutes long. </h1>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
          <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part2_listening/').$test->conversation_1_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part2 ls-part2-screen-2" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part2_listening/').$test->q1_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
          <p>Question 1 of 5</p>
          <h2> Choose the best answer to each question.</h2>
          <div><input type="radio" name="q1-response" checked value="q1_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option1; ?></div>
          <div><input type="radio" name="q1-response" value="q1_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option2; ?></div>
          <div><input type="radio" name="q1-response" value="q1_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option3; ?></div>
          <div><input type="radio" name="q1-response" value="q1_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option4; ?></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      
      <div class="otw-row ls-part2 ls-part2-screen-3" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part2_listening/').$test->q2_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
          <p>Question 2 of 5</p>
          <h2> Choose the best answer to each question.</h2>
          <div><input type="radio" name="q2-response" checked value="q2_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option1; ?></div>
          <div><input type="radio" name="q2-response" value="q2_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option2; ?></div>
          <div><input type="radio" name="q2-response" value="q2_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option3; ?></div>
          <div><input type="radio" name="q2-response" value="q2_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option4; ?></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part2 ls-part2-screen-4" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part2_listening/').$test->q3_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
          <p>Question 3 of 5</p>
          <h2> Choose the best answer to each question.</h2>
          <div><input type="radio" name="q3-response" checked value="q3_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option1; ?></div>
          <div><input type="radio" name="q3-response" value="q3_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option2; ?></div>
          <div><input type="radio" name="q3-response" value="q3_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option3; ?></div>
          <div><input type="radio" name="q3-response" value="q3_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option4; ?></div>
        <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part2 ls-part2-screen-5" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part2_listening/').$test->q4_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
          <p>Question 4 of 5</p>
          <h2> Choose the best answer to each question.</h2>
          <div><input type="radio" name="q4-response" checked value="q4_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option1; ?></div>
          <div><input type="radio" name="q4-response" value="q4_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option2; ?></div>
          <div><input type="radio" name="q4-response" value="q4_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option3; ?></div>
          <div><input type="radio" name="q4-response" value="q4_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option4; ?></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
    
      <div class="otw-row ls-part2 ls-part2-screen-6" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part2_listening/').$test->q5_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
          <p>Question 5 of 5</p>
          <h2> Choose the best answer to each question.</h2>
          <div><input type="radio" name="q5-response" checked value="q5_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option1; ?></div>
          <div><input type="radio" name="q5-response" value="q5_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option2; ?></div>
          <div><input type="radio" name="q5-response" value="q5_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option3; ?></div>
          <div><input type="radio" name="q5-response" value="q5_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option4; ?></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
    <?php } ?>
    <?php if($testdetail->test_id==18){ 
      //echo "<pre>";print_r($test);
    ?>
      <div class="otw-row ls-part3 ls-part3-screen-1">
        <div class="otw-twentyfour otw-columns">
          <h1> Listen to the conversation. You will hear the conversation only once. It is about 1 to 1.5 minutes long. </h1>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
          <p align="center">
            <audio controls>
            <source src="<?php echo base_url('uploads/part3_listening/').$test->conversation_1_audio; ?>" type="audio/mpeg">
            </audio></p>
          <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
          <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part3 ls-part3-screen-2" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
         <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part3_listening/').$test->q1_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 1 of 5</p>
          <h2> Choose the best answer to each question.</h2>
            <div><input type="radio" name="q1-response" checked value="q1_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option1; ?></div>
            <div><input type="radio" name="q1-response" value="q1_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option2; ?></div>
            <div><input type="radio" name="q1-response" value="q1_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option3; ?></div>
            <div><input type="radio" name="q1-response" value="q1_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option4; ?></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part3 ls-part3-screen-3" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part3_listening/').$test->q2_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 2 of 5</p>
          <h2> Choose the best answer to each question.</h2>
            <div><input type="radio" name="q2-response" checked value="q2_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option1; ?></div>
            <div><input type="radio" name="q2-response" value="q2_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option2; ?></div>
            <div><input type="radio" name="q2-response" value="q2_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option3; ?></div>
            <div><input type="radio" name="q2-response" value="q2_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option4; ?></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part3 ls-part3-screen-4" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part3_listening/').$test->q3_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 3 of 5</p>
          <h2>Choose the best answer to each question.</h2>
            <div><input type="radio" name="q3-response" checked value="q3_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option1; ?></div>
            <div><input type="radio" name="q3-response" value="q3_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option2; ?></div>
            <div><input type="radio" name="q3-response" value="q3_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option3; ?></div>
            <div><input type="radio" name="q3-response" value="q3_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option4; ?></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part3 ls-part3-screen-5" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part3_listening/').$test->q4_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 4 of 5</p>
          <h2> Choose the best answer to each question.</h2>
            <div><input type="radio" name="q4-response" checked value="q4_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option1; ?></div>
            <div><input type="radio" name="q4-response" value="q4_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option2; ?></div>
            <div><input type="radio" name="q4-response" value="q4_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option3; ?></div>
            <div><input type="radio" name="q4-response" value="q4_option4">&nbsp;&nsbp;&nsbp;<?php echo $test->q4_option4; ?></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part3 ls-part3-screen-6" style="display:none">
        <div class="otw-ten otw-columns">
            <div class="border-sec">
          <h2> Listen to a short statement.<br>&nbsp; You will hear it only once.</h2>
          <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
           <p align="center">
           <audio controls>
            <source src="<?php echo base_url('uploads/part3_listening/').$test->q5_audio; ?>" type="audio/mpeg">
           </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
          <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
        </div></div>
        <div class="otw-thirteen otw-columns">
         <p>Question 5 of 5</p>
          <h2> Choose the best answer to each question.</h2>
          <div><input type="radio" name="q5-response" checked value="q5_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option1; ?></div>
          <div><input type="radio" name="q5-response" value="q5_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option2; ?></div>
          <div><input type="radio" name="q5-response" value="q5_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option3; ?></div>
          <div><input type="radio" name="q5-response" value="q5_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option4; ?></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==17){ 
      //echo "<pre>";print_r($test);
    ?>
      <div class="otw-row ls-part4 ls-part4-screen-1">
        <div class="otw-twentyfour otw-columns">
          <h1> Listen to the following news item. You will hear the news item only once. It is about 1 to 1.5 minutes long. </h1>
         <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
          <p align="center">
            <audio controls>
            <source src="<?php echo base_url('uploads/part4_listening/').$test->conversation_1_audio; ?>" type="audio/mpeg">
            </audio></p>
           <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
           <p align="center">This playbar will not appear in the official test.</p></div>
          <div class="otw-sc-hr"></div>
        </div>
      </div>
      
      <div class="otw-row ls-part4 ls-part4-screen-2" style="display:none">
        <div class="otw-twentyfour otw-columns">
          <h2>Choose the best way to complete each statement from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>)</h2>
          
          <p>1. <?php echo $test->q1_question; ?>
             <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
             <option value=""></option>
             <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
             <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
             <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
             <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
             </select>
             <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
          </p>
          
          <p>2. <?php echo $test->q2_question; ?>
             <select type="drop-down" style="width: 150px;" class="searchform q2-sel-opt" name="q2-response">
             <option value=""></option>
             <option value="q4_option1"><?php echo $test->q2_option1; ?></option>
             <option value="q4_option2"><?php echo $test->q2_option2; ?></option>
             <option value="q4_option3"><?php echo $test->q2_option3; ?></option>
             <option value="q4_option4"><?php echo $test->q2_option4; ?></option>
             </select>
             <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
          </p>
          
          <p>3. <?php echo $test->q3_question; ?>
             <select type="drop-down" style="width: 150px;" class="searchform q3-sel-opt" name="q3-response">
              <option value=""></option>
            <option value="q3_option1"><?php echo $test->q3_option1; ?></option>
            <option value="q3_option2"><?php echo $test->q3_option2; ?></option>
            <option value="q3_option3"><?php echo $test->q3_option3; ?></option>
            <option value="q3_option4"><?php echo $test->q3_option4; ?></option>
             </select>
             <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
          </p>
          
          <p>4. <?php echo $test->q4_question; ?>
             <select type="drop-down" style="width: 150px;" class="searchform q4-sel-opt" name="q4-response">
              <option value=""></option>
            <option value="q4_option1"><?php echo $test->q4_option1; ?></option>
            <option value="q4_option2"><?php echo $test->q4_option2; ?></option>
            <option value="q4_option3"><?php echo $test->q4_option3; ?></option>
            <option value="q4_option4"><?php echo $test->q4_option4; ?></option>
             </select>
             <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
          </p>
          
          <p>5. <?php echo $test->q5_question; ?>
             <select type="drop-down" style="width: 150px;" class="searchform q5-sel-opt" name="q5-response">
              <option value=""></option>
            <option value="q5_option1"><?php echo $test->q5_option1; ?></option>
            <option value="q5_option2"><?php echo $test->q5_option2; ?></option>
            <option value="q5_option3"><?php echo $test->q5_option3; ?></option>
            <option value="q5_option4"><?php echo $test->q5_option4; ?></option>
             </select>
             <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
          </p>
        </div>
      </div>
    
    <?php } ?>
    
    
    <?php if($testdetail->test_id==16){ 
      //echo "<pre>";print_r($test);
    ?>
    <div class="otw-row ls-part5 ls-part5-screen-1" style="margin-bottom: -80px;">
      <div class="otw-twentyfour otw-columns">
        <h1><!-- <img src="images/1.png"> --> Watch the discussion. You will watch the discussion only once. It is about 1.5 to 2 minutes long.  </h1>
        <p align="center">
         <video width="100%" height="100%" controls>
          <source src="<?php echo base_url('uploads/part5_listening/').$test->conversation_1_video; ?>" type="video/mp4">
         </video> 
        </p>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    
    <div class="otw-row ls-part5 ls-part5-screen-2" style="display:none">
      <div class="otw-twentyfour otw-columns">
        <h2>Choose the best way to complete each statement from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>)</h2>
        
        <p>1. <?php echo $test->q1_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
           <option value=""></option>
           <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
           <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
           <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
           <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
           </select>
           <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>2. <?php echo $test->q2_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q2-sel-opt" name="q2-response">
           <option value=""></option>
           <option value="q2_option1"><?php echo $test->q2_option1; ?></option>
           <option value="q2_option2"><?php echo $test->q2_option2; ?></option>
           <option value="q2_option3"><?php echo $test->q2_option3; ?></option>
           <option value="q2_option4"><?php echo $test->q2_option4; ?></option>
           </select>
           <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>3. <?php echo $test->q3_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q3-sel-opt" name="q3-response">
          <option value=""></option>
          <option value="q3_option1"><?php echo $test->q3_option1; ?></option>
          <option value="q3_option2"><?php echo $test->q3_option2; ?></option>
          <option value="q3_option3"><?php echo $test->q3_option3; ?></option>
          <option value="q3_option4"><?php echo $test->q3_option4; ?></option>
           </select>
           <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>4. <?php echo $test->q4_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q4-sel-opt" name="q4-response">
          <option value=""></option>
          <option value="q4_option1"><?php echo $test->q4_option1; ?></option>
          <option value="q4_option2"><?php echo $test->q4_option2; ?></option>
          <option value="q4_option3"><?php echo $test->q4_option3; ?></option>
          <option value="q4_option4"><?php echo $test->q4_option4; ?></option>
           </select>
           <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>5. <?php echo $test->q5_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q5-sel-opt" name="q5-response">
          <option value=""></option>
          <option value="q5_option1"><?php echo $test->q5_option1; ?></option>
          <option value="q5_option2"><?php echo $test->q5_option2; ?></option>
          <option value="q5_option3"><?php echo $test->q5_option3; ?></option>
          <option value="q5_option4"><?php echo $test->q5_option4; ?></option>
           </select>
           <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>6. <?php echo $test->q6_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q6-sel-opt" name="q6-response">
          <option value=""></option>
          <option value="q6_option1"><?php echo $test->q6_option1; ?></option>
          <option value="q6_option2"><?php echo $test->q6_option2; ?></option>
          <option value="q6_option3"><?php echo $test->q6_option3; ?></option>
          <option value="q6_option4"><?php echo $test->q6_option4; ?></option>
           </select>
           <span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>7. <?php echo $test->q7_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q7-sel-opt" name="q7-response">
          <option value=""></option>
          <option value="q7_option1"><?php echo $test->q7_option1; ?></option>
          <option value="q7_option2"><?php echo $test->q7_option2; ?></option>
          <option value="q7_option3"><?php echo $test->q7_option3; ?></option>
          <option value="q7_option4"><?php echo $test->q7_option4; ?></option>
           </select>
           <span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>8. <?php echo $test->q8_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q8-sel-opt" name="q8-response">
          <option value=""></option>
          <option value="q8_option1"><?php echo $test->q8_option1; ?></option>
          <option value="q8_option2"><?php echo $test->q8_option2; ?></option>
          <option value="q8_option3"><?php echo $test->q8_option3; ?></option>
          <option value="q8_option4"><?php echo $test->q8_option4; ?></option>
           </select>
           <span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
      </div>
    </div>
    
        <?php } ?>
    
    <?php if($testdetail->test_id==15){ 
      //echo "<pre>";print_r($test);
    ?>
    
    <div class="otw-row ls-part6 ls-part6-screen-1">
      <div class="otw-twentyfour otw-columns">
        <h1> Instructions: </h1>
        <p> <?php echo $test->conversation_audio_title; ?></p>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    
    <div class="otw-row ls-part6 ls-part6-screen-2" style="display:none">
      <div class="otw-twentyfour otw-columns">
        <h1> Listen to the following report. You will hear the report only once. It is about 3 minutes long. </h1>
        <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
        
        <?php echo $test->conversation_audio_title; ?>
        <p align="center">
        <audio controls>
          <source src="<?php echo base_url('uploads/part6_listening/').$test->conversation_1_audio; ?>" type="audio/mpeg">
        </audio></p>
        <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
        <p align="center">This playbar will not appear in the official test.</p></div>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    
    <div class="otw-row ls-part6 ls-part6-screen-3" style="display:none">
      <div class="otw-twentyfour otw-columns">
        <h2>Choose the best way to complete each statement from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>)</h2>
        
        <p>1. <?php echo $test->q1_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
           <option value=""></option>
           <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
           <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
           <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
           <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
           </select> 
           <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>2. <?php echo $test->q2_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q2-sel-opt" name="q2-response">
           <option value=""></option>
           <option value="q2_option1"><?php echo $test->q2_option1; ?></option>
           <option value="q2_option2"><?php echo $test->q2_option2; ?></option>
           <option value="q2_option3"><?php echo $test->q2_option3; ?></option>
           <option value="q2_option4"><?php echo $test->q2_option4; ?></option>
           </select>
           <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>3. <?php echo $test->q3_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q3-sel-opt" name="q3-response">
          <option value=""></option>
          <option value="q3_option1"><?php echo $test->q3_option1; ?></option>
          <option value="q3_option2"><?php echo $test->q3_option2; ?></option>
          <option value="q3_option3"><?php echo $test->q3_option3; ?></option>
          <option value="q3_option4"><?php echo $test->q3_option4; ?></option>
           </select>
           <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>4. <?php echo $test->q4_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q4-sel-opt" name="q4-response">
          <option value=""></option>
          <option value="q4_option1"><?php echo $test->q4_option1; ?></option>
          <option value="q4_option2"><?php echo $test->q4_option2; ?></option>
          <option value="q4_option3"><?php echo $test->q4_option3; ?></option>
          <option value="q4_option4"><?php echo $test->q4_option4; ?></option>
           </select>
           <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>5. <?php echo $test->q5_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q5-sel-opt" name="q5-response">
          <option value=""></option>
          <option value="q5_option1"><?php echo $test->q5_option1; ?></option>
          <option value="q5_option2"><?php echo $test->q5_option2; ?></option>
          <option value="q5_option3"><?php echo $test->q5_option3; ?></option>
          <option value="q5_option4"><?php echo $test->q5_option4; ?></option>
           </select>
           <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
        <p>6. <?php echo $test->q6_question; ?>
           <select type="drop-down" style="width: 150px;" class="searchform q6-sel-opt" name="q6-response">
          <option value=""></option>
          <option value="q6_option1"><?php echo $test->q6_option1; ?></option>
          <option value="q6_option2"><?php echo $test->q6_option2; ?></option>
          <option value="q6_option3"><?php echo $test->q6_option3; ?></option>
          <option value="q6_option4"><?php echo $test->q6_option4; ?></option>
           </select> 
           <span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
        </p>
        
      </div>
    </div>
    
        <?php } ?>
        
        
          <?php if($testdetail->test_id==52){ 
      //echo "<pre>";print_r($attempt);
    ?>  
    <div class="col-md-12">
      <a href="<?php echo base_url("teacher/reviewQuestions/52"); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Go back</a>
    </div>
    <br><br>
    <div class="otw-row" style="margin-bottom: -80px;">

        <div class="otw-ten otw-columns">
          <div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
            <h2>Read the following information. </h2>
            		 <p>1. <?php echo $test->passage; ?> </p>
				    		 <p>1. <?php echo $test->q1_question; ?> </p>
            <hr>
            <div class="row">
              <div class="col-md-12">
              <b>Assign marks</b><br><br>
              </div>
              
              <?php echo form_open_multipart('teacher/answerDetails/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>
              <!-- <input type="hidden" name="form" value="Fwriting_part"> -->
              <input type="hidden" name="test_type" value="Celpip Part Test">   
              <input type="hidden" name="test_type_id" value="<?php echo $attempt->testid; ?>">
              <input type="hidden" name="test_code" value="<?php echo $attempt->questionid; ?>">
              <input type="hidden" name="test_part_id" value="<?php echo $attempt->subtypeid; ?>">
              <input type="hidden" name="member_id" value="<?php echo $attempt->memberid; ?>">

              <div class="col-md-12">
                <div class="form-group">
                  <label>Enter Marks</label>
                  <input type="text" class="form-control" placeholder="marks" name="marks" value="<?php echo set_value('marks',$marksAssigned[0]->marks); ?>" required>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Your Remarks</label>
                  <textarea class="form-control" placeholder="remarks" name="remarks" required><?php echo set_value('remarks',$marksAssigned[0]->remarks); ?> </textarea>
                </div>
              </div>
              
              <div class="col-md-12">
                <div class="form-group">
                  <?php  if(empty($marksAssigned)){?>
                    <button type="submit" class="">Save</button>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?php echo form_close(); ?>

          </div>

          <div class="otw-sc-hr"></div>
        </div>

        <div class="otw-thirteen otw-columns">
          <div id="wrapper">
            <div class="scrollbar1" id="style-default">
              <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">
              <form>
              <table>
                <div>
                  <p><?php echo $test->email_title; ?>
                </div>
                <div>
                <hr>
                  <p>
                    <label><b>Student Answer</b></label>
                      <span class="student_ans_dtail"><?php 
                      foreach ($attempt_data['response_data'] as $key => $attemptArray) { 
                        echo trim($attemptArray['q_response_email_content']);
						$wordCountt = str_word_count(trim($attemptArray['q_response_email_content']));
                      } 
                      ?></span>
					  <br><br>
					  <span>Total <?php echo $wordCountt; ?></span> words
                  </p>
                  <p>
                </div>
              </table>
            </form>
          </div>
        </div>
      </div>
      <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==51){ 
      //echo "<pre>";print_r($test);
    ?>  
    <div class="col-md-12">
      <a href="<?php echo base_url("teacher/reviewQuestions/52"); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Go back</a>
    </div>
    <br><br>
    <div class="otw-row" style="margin-bottom: -80px;">
      <div class="otw-ten otw-columns">

        <div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
          <h2>Read the following information. </h2>
        	 <p>1. <?php echo $test->passage; ?> </p>
				    		 <p>1. <?php echo $test->q1_question; ?> </p>
				</b>    		 <p>1. <?php echo $test->instruction; ?> </p>

          <hr>
          <div class="row">
            <?php echo form_open_multipart('teacher/answerDetails/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>
              <!-- <input type="hidden" name="form" value="Fwriting_part"> -->
              <input type="hidden" name="test_type" value="Celpip Part Test">
              <input type="hidden" name="test_type_id" value="<?php echo $attempt->testid; ?>">
              <input type="hidden" name="test_code" value="<?php echo $attempt->questionid; ?>">
              <input type="hidden" name="test_part_id" value="<?php echo $attempt->subtypeid; ?>">
              <input type="hidden" name="member_id" value="<?php echo $attempt->memberid; ?>">

              <div class="col-md-12">
                <div class="form-group">
                  <label>Enter Marks</label>
                  <input type="text" class="form-control" placeholder="marks" name="marks" value="<?php echo set_value('marks',$marksAssigned[0]->marks); ?>" required>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Your Remarks</label>
                  <textarea class="form-control" placeholder="remarks" name="remarks" required><?php echo set_value('remarks',$marksAssigned[0]->remarks); ?> </textarea>
                </div>
              </div>
              
              <div class="col-md-12">
                <div class="form-group">
                  <?php  if(empty($marksAssigned)){?>
                    <button type="submit" class="">Save</button>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?php echo form_close(); ?>

        </div>

        <div class="otw-sc-hr"></div>
      </div>
      <div class="otw-thirteen otw-columns">
        <div id="wrapper">
          <div class="scrollbar1" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">

            
              <hr>
              <div id="area">
                <label><b>Student Answer</b></label>
                <div style="white-space: pre-line;margin-top: -10px;">
                      <?php 
                      foreach ($attempt_data['response_data'] as $key => $attemptArray) { 
                        echo $attemptArray['q_response_email_content'];
						$wordCountt = str_word_count(trim($attemptArray['q_response_email_content']));
                      } 
                      ?>
					  
					  <br><br>
					  <span>Total <?php echo $wordCountt; ?></span> words
              </div>
            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==42){ 
      //echo "<pre>";print_r($attempt);
    ?>  
    <div class="col-md-12">
      <a href="<?php echo base_url("teacher/reviewQuestions/47"); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Go back</a>
    </div>
    <br><br>
    <div class="otw-row" style="margin-bottom: -80px;">

        <div class="otw-ten otw-columns">
          <div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
            <h2>Read the following information. </h2>
            	 <p>1. <?php echo $test->passage; ?> </p>
				    		 <p>1. <?php echo $test->q1_question; ?> </p>
            <hr>
            <div class="row">
              <div class="col-md-12">
              <b>Assign marks</b><br><br>
              </div>
              
              <?php echo form_open_multipart('teacher/answerDetails/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>
              <!-- <input type="hidden" name="form" value="Fwriting_part"> -->
              <input type="hidden" name="test_type" value="Celpip Part Test">   
              <input type="hidden" name="test_type_id" value="<?php echo $attempt->testid; ?>">
              <input type="hidden" name="test_code" value="<?php echo $attempt->questionid; ?>">
              <input type="hidden" name="test_part_id" value="<?php echo $attempt->subtypeid; ?>">
              <input type="hidden" name="member_id" value="<?php echo $attempt->memberid; ?>">

              <div class="col-md-12">
                <div class="form-group">
                  <label>Enter Marks</label>
                  <input type="text" class="form-control" placeholder="marks" name="marks" value="<?php echo set_value('marks',$marksAssigned[0]->marks); ?>" required>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Your Remarks</label>
                  <textarea class="form-control" placeholder="remarks" name="remarks" required><?php echo set_value('remarks',$marksAssigned[0]->remarks); ?> </textarea>
                </div>
              </div>
              
              <div class="col-md-12">
                <div class="form-group">
                  <?php  if(empty($marksAssigned)){?>
                    <button type="submit" class="">Save</button>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?php echo form_close(); ?>

          </div>

          <div class="otw-sc-hr"></div>
        </div>

        <div class="otw-thirteen otw-columns">
          <div id="wrapper">
            <div class="scrollbar1" id="style-default">
              <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">
              <form>
              <table>
                <div>
                </div>
                <div>
                <hr>
                  <p>
                    <label><b>Student Answer</b></label>
                      <span class="student_ans_dtail"><?php 
                      foreach ($attempt_data['response_data'] as $key => $attemptArray) { 
                        echo trim($attemptArray['q_response_email_content']);
						$wordCountt = str_word_count(trim($attemptArray['q_response_email_content']));
                      } 
                      ?></span>
					  <br><br>
					  <span>Total <?php echo $wordCountt; ?></span> words
                  </p>
                  <p>
                </div>
              </table>
            </form>
          </div>
        </div>
      </div>
      <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==41){ 
      //echo "<pre>";print_r($test);
    ?>  
    <div class="col-md-12">
      <a href="<?php echo base_url("teacher/reviewQuestions/41"); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Go back</a>
    </div>
    <br><br>
    <div class="otw-row" style="margin-bottom: -80px;">
      <div class="otw-ten otw-columns">

        <div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
          <h2>Read the following information. </h2>
        <p>1. <?php echo $test->q1_question; ?> </p>
				    <img src="<?php echo base_url('uploads/part4_SAWPA/').$test->q1_image; ?>">

          <hr>
          <div class="row">
            <?php echo form_open_multipart('teacher/answerDetails/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>
              <!-- <input type="hidden" name="form" value="Fwriting_part"> -->
              <input type="hidden" name="test_type" value="Celpip Part Test">
              <input type="hidden" name="test_type_id" value="<?php echo $attempt->testid; ?>">
              <input type="hidden" name="test_code" value="<?php echo $attempt->questionid; ?>">
              <input type="hidden" name="test_part_id" value="<?php echo $attempt->subtypeid; ?>">
              <input type="hidden" name="member_id" value="<?php echo $attempt->memberid; ?>">

              <div class="col-md-12">
                <div class="form-group">
                  <label>Enter Marks</label>
                  <input type="text" class="form-control" placeholder="marks" name="marks" value="<?php echo set_value('marks',$marksAssigned[0]->marks); ?>" required>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Your Remarks</label>
                  <textarea class="form-control" placeholder="remarks" name="remarks" required><?php echo set_value('remarks',$marksAssigned[0]->remarks); ?> </textarea>
                </div>
              </div>
              
              <div class="col-md-12">
                <div class="form-group">
                  <?php  if(empty($marksAssigned)){?>
                    <button type="submit" class="">Save</button>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?php echo form_close(); ?>

        </div>

        <div class="otw-sc-hr"></div>
      </div>
      <div class="otw-thirteen otw-columns">
        <div id="wrapper">
          <div class="scrollbar1" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">

            
              <hr>
              <div id="area">
                <label><b>Student Answer</b></label>
                <div style="white-space: pre-line;margin-top: -10px;">
                      <?php 
                      foreach ($attempt_data['response_data'] as $key => $attemptArray) { 
                        echo $attemptArray['q_response_email_content'];
						$wordCountt = str_word_count(trim($attemptArray['q_response_email_content']));
                      } 
                      ?>
					  
					  <br><br>
					  <span>Total <?php echo $wordCountt; ?></span> words
              </div>
            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==62){ 
      //echo "<pre>";print_r($test);
    ?>

    <div class="col-md-12">
      <a href="<?php echo base_url("teacher/reviewQuestions/62"); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Go back</a>
    </div>
    <br><br>

    <input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
      <div class="otw-twentyfour otw-columns">
        <div style="background-color: #eee;border-radius: 10px;"><p>Q1.<?php echo $test->q1_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio1'];?>" type="audio/ogg">
              
            </audio>
            <div style="background-color: #eee;border-radius: 10px;"><p>Q2.<?php echo $test->q2_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio2'];?>" type="audio/ogg">
              
            </audio>
            <div style="background-color: #eee;border-radius: 10px;"><p>Q3.<?php echo $test->q3_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio3'];?>" type="audio/ogg">
              
            </audio>
    <div style="background-color: #eee;border-radius: 10px;"><p>Q4.<?php echo $test->q4_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio4'];?>" type="audio/ogg">
              
            </audio>
    <div style="background-color: #eee;border-radius: 10px;"><p>Q5.<?php echo $test->q5_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio5'];?>" type="audio/ogg">
              
            </audio>
    



           <hr>

          <div class="row">
            <?php echo form_open_multipart('teacher/answerDetails/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>
              <!-- <input type="hidden" name="form" value="Fwriting_part"> -->
              <input type="hidden" name="test_type" value="Celpip Part Test">
              <input type="hidden" name="test_type_id" value="<?php echo $attempt->testid; ?>">
              <input type="hidden" name="test_code" value="<?php echo $attempt->questionid; ?>">
              <input type="hidden" name="test_part_id" value="<?php echo $attempt->subtypeid; ?>">
              <input type="hidden" name="member_id" value="<?php echo $attempt->memberid; ?>">

              <div class="col-md-12">
                <div class="form-group">
                  <label>Enter Marks</label>
                  <input type="text" class="form-control" placeholder="marks" name="marks" value="<?php echo set_value('marks',$marksAssigned[0]->marks); ?>" required>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Your Remarks</label>
                  <div style="white-space: pre-line;margin-top: -10px;">
                  <textarea class="form-control" placeholder="remarks" name="remarks" required><?php echo set_value('remarks',$marksAssigned[0]->remarks); ?> </textarea>
                </div>
              </div>
              
              <div class="col-md-12">
                <div class="form-group">
                  <?php  if(empty($marksAssigned)){?>
                    <button type="submit" class="">Save</button>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?php echo form_close(); ?>
        <div class="otw-sc-hr"></div>
      </div>
    <?php } ?>
    
    
        <?php if($testdetail->test_id==63){ 
      //echo "<pre>";print_r($test);
    ?>

    <div class="col-md-12">
      <a href="<?php echo base_url("teacher/reviewQuestions/63"); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Go back</a>
    </div>
    <br><br>

    <input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
      <div class="otw-twentyfour otw-columns">
       <div style="background-color: #eee;border-radius: 10px;"><p>Q1.<?php echo $test->q1_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio1'];?>" type="audio/ogg">
              
            </audio>
            <div style="background-color: #eee;border-radius: 10px;"><p>Q2.<?php echo $test->q2_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio2'];?>" type="audio/ogg">
              
            </audio>
            </div>

           <hr>

          <div class="row">
            <?php echo form_open_multipart('teacher/answerDetails/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>
              <!-- <input type="hidden" name="form" value="Fwriting_part"> -->
              <input type="hidden" name="test_type" value="Celpip Part Test">
              <input type="hidden" name="test_type_id" value="<?php echo $attempt->testid; ?>">
              <input type="hidden" name="test_code" value="<?php echo $attempt->questionid; ?>">
              <input type="hidden" name="test_part_id" value="<?php echo $attempt->subtypeid; ?>">
              <input type="hidden" name="member_id" value="<?php echo $attempt->memberid; ?>">

              <div class="col-md-12">
                <div class="form-group">
                  <label>Enter Marks</label>
                  <input type="text" class="form-control" placeholder="marks" name="marks" value="<?php echo set_value('marks',$marksAssigned[0]->marks); ?>" required>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Your Remarks</label>
                  <div style="white-space: pre-line;margin-top: -10px;">
                  <textarea class="form-control" placeholder="remarks" name="remarks" required><?php echo set_value('remarks',$marksAssigned[0]->remarks); ?> </textarea>
                </div>
              </div>
              
              <div class="col-md-12">
                <div class="form-group">
                  <?php  if(empty($marksAssigned)){?>
                    <button type="submit" class="">Save</button>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?php echo form_close(); ?>
        <div class="otw-sc-hr"></div>
      </div>
    <?php } ?>
    
        <?php if($testdetail->test_id==64){ 
      //echo "<pre>";print_r($test);
    ?>

    <div class="col-md-12">
      <a href="<?php echo base_url("teacher/reviewQuestions/64"); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Go back</a>
    </div>
    <br><br>

    <input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
    <div class="otw-row sp-part6 sp-part6-screen-1">
      <div class="otw-twentyfour otw-columns">
        <div style="background-color: #eee;border-radius: 10px;"><p>Q1.<?php echo $test->q1_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio1'];?>" type="audio/ogg">
              
            </audio>
            <div style="background-color: #eee;border-radius: 10px;"><p>Q2.<?php echo $test->q2_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio2'];?>" type="audio/ogg">
              
            </audio>
            <div style="background-color: #eee;border-radius: 10px;"><p>Q3.<?php echo $test->q3_question; ?></p></div>
        
       <audio controls>
              <source src="<?php echo  $this->data['s3audio3'];?>" type="audio/ogg">
              
            </audio>

           <hr>

          <div class="row">
            <?php echo form_open_multipart('teacher/answerDetails/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>
              <!-- <input type="hidden" name="form" value="Fwriting_part"> -->
              <input type="hidden" name="test_type" value="Celpip Part Test">
              <input type="hidden" name="test_type_id" value="<?php echo $attempt->testid; ?>">
              <input type="hidden" name="test_code" value="<?php echo $attempt->questionid; ?>">
              <input type="hidden" name="test_part_id" value="<?php echo $attempt->subtypeid; ?>">
              <input type="hidden" name="member_id" value="<?php echo $attempt->memberid; ?>">

              <div class="col-md-12">
                <div class="form-group">
                  <label>Enter Marks</label>
                  <input type="text" class="form-control" placeholder="marks" name="marks" value="<?php echo set_value('marks',$marksAssigned[0]->marks); ?>" required>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Your Remarks</label>
                  <div style="white-space: pre-line;margin-top: -10px;">
                  <textarea class="form-control" placeholder="remarks" name="remarks" required><?php echo set_value('remarks',$marksAssigned[0]->remarks); ?> </textarea>
                </div>
              </div>
              
              <div class="col-md-12">
                <div class="form-group">
                  <?php  if(empty($marksAssigned)){?>
                    <button type="submit" class="">Save</button>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?php echo form_close(); ?>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    
    
   
    <?php if($testdetail->test_id==40){ //echo "<pre>";print_r($test);?>
      <div class="otw-row" style="margin-bottom: -80px;">
            <div class="otw-ten otw-columns" style="border-right: 2px solid #c5c5c5;height: 300px;">
              <h2>Read the following message. </h2>
              <p><?php echo $test->question_title; ?> </p>
              <div class="otw-sc-hr"></div>
            </div>
             <div class="otw-thirteen otw-columns"> Using the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>), choose the best option according to the information given in the message.</h2><br>
              <form>
                <table><br>
                <div><?php echo $test->question; ?>
                  <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
                    <option value=""></option>
                    <option value="option1"><?php echo $test->option1; ?></option>
                    <option value="option2"><?php echo $test->option2; ?></option>
                    <option value="option3"><?php echo $test->option3; ?></option>
                    <option value="option4"><?php echo $test->option4; ?></option>
                  </select>
          <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                </div>
                </table>
              </form>
              
              <div class="otw-sc-hr"></div>
            </div>
          </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==37){ //echo "<pre>";print_r($test);?>
    <div class="otw-row" style="margin-bottom: -80px;">
      <div class="otw-ten otw-columns">
        <div id="wrapper">
          <div class="scrollbar" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius:10px;padding: 15px">
              <h2>Read the following message. </h2>
              <p><?php echo $test->passages_1; ?></p>
              <p><?php echo $test->passages_2; ?></p>
              <p><?php echo $test->passages_3; ?></p>
              <p><?php echo $test->passages_4; ?> </p>
              <p><strong>E. Not given in any of the above paragraphs.</strong></p>

            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
      <div class="otw-thirteen otw-columns">
        <div id="wrapper">
          <div class="scrollbar1" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
              <h2>Decide which paragraph, A to D, has the information given in each statement below. Select E if the information is not given in any of the paragraphs.</h2>
              <form>
                <table>
                  <div>
                    <p>
                      <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
                        <option value=""></option>
                        <option value="A">A&nbsp;&nbsp;</option>
                        <option value="B">B&nbsp;&nbsp;</option>
                        <option value="C">C&nbsp;&nbsp;</option>
                        <option value="D">D&nbsp;&nbsp;</option>
                        <option value="E">E&nbsp;&nbsp;</option>
                      </select><?php echo $test->q1_question; ?> 
                      <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
                    <p>
                      <select type="drop-down" style="width: 150px;" class="searchform q2-sel-opt"name="q2-response">
                        <option value=""></option>
                        <option value="A">A&nbsp;&nbsp;</option>
                        <option value="B">B&nbsp;&nbsp;</option>
                        <option value="C">C&nbsp;&nbsp;</option>
                        <option value="D">D&nbsp;&nbsp;</option>
                        <option value="E">E&nbsp;&nbsp;</option>
                      </select><?php echo $test->q2_question; ?>
                      <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
                    <p>
                      <select type="drop-down" style="width: 150px;" class="searchform q3-sel-opt" name="q3-response">
                        <option value=""></option>
                        <option value="A">A&nbsp;&nbsp;</option>
                        <option value="B">B&nbsp;&nbsp;</option>
                        <option value="C">C&nbsp;&nbsp;</option>
                        <option value="D">D&nbsp;&nbsp;</option>
                        <option value="E">E&nbsp;&nbsp;</option>
                      </select><?php echo $test->q3_question; ?>
                      <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
                    <p>
                      <select type="drop-down" style="width: 150px;" class="searchform q4-sel-opt" name="q4-response">
                        <option value=""></option>
                        <option value="A">A&nbsp;&nbsp;</option>
                        <option value="B">B&nbsp;&nbsp;</option>
                        <option value="C">C&nbsp;&nbsp;</option>
                        <option value="D">D&nbsp;&nbsp;</option>
                        <option value="E">E&nbsp;&nbsp;</option>
                      </select><?php echo $test->q4_question; ?> 
                      <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
                    <p>
                      <select type="drop-down" style="width: 150px;" class="searchform q5-sel-opt" name="q5-response">
                        <option value=""></option>
                        <option value="A">A&nbsp;&nbsp;</option>
                        <option value="B">B&nbsp;&nbsp;</option>
                        <option value="C">C&nbsp;&nbsp;</option>
                        <option value="D">D&nbsp;&nbsp;</option>
                        <option value="E">E&nbsp;&nbsp;</option>
                      </select><?php echo $test->q5_question; ?> 
                      <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
                    <p>
                      <select type="drop-down" style="width: 150px;" class="searchform q6-sel-opt" name="q6-response">
                        <option value=""></option>
                        <option value="A">A&nbsp;&nbsp;</option>
                        <option value="B">B&nbsp;&nbsp;</option>
                        <option value="C">C&nbsp;&nbsp;</option>
                        <option value="D">D&nbsp;&nbsp;</option>
                        <option value="E">E&nbsp;&nbsp;</option>
                      </select><?php echo $test->q6_question; ?> 
                      <span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
                    <p>
                      <select type="drop-down" style="width: 150px;" class="searchform q7-sel-opt" name="q7-response">
                        <option value=""></option>
                        <option value="A">A&nbsp;&nbsp;</option>
                        <option value="B">B&nbsp;&nbsp;</option>
                        <option value="C">C&nbsp;&nbsp;</option>
                        <option value="D">D&nbsp;&nbsp;</option>
                        <option value="E">E&nbsp;&nbsp;</option>
                      </select><?php echo $test->q7_question; ?> 
                      <span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
                    <p>
                      <select type="drop-down" style="width: 150px;" class="searchform q8-sel-opt" name="q8-response">
                        <option value=""></option>
                        <option value="A">A&nbsp;&nbsp;</option>
                        <option value="B">B&nbsp;&nbsp;</option>
                        <option value="C">C&nbsp;&nbsp;</option>
                        <option value="D">D&nbsp;&nbsp;</option>
                        <option value="E">E&nbsp;&nbsp;</option>
                      </select><?php echo $test->q8_question; ?>
                      <span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
                    <p>
                      <select type="drop-down" style="width: 150px;" class="searchform q9-sel-opt" name="q9-response">
                        <option value=""></option>
                        <option value="A">A&nbsp;&nbsp;</option>
                        <option value="B">B&nbsp;&nbsp;</option>
                        <option value="C">C&nbsp;&nbsp;</option>
                        <option value="D">D&nbsp;&nbsp;</option>
                        <option value="E">E&nbsp;&nbsp;</option>
                      </select><?php echo $test->q9_question; ?> 
                      <span class="q9-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
                  </div>
                </table>
              </form>

            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    
    <?php } ?>
    
    <?php if($testdetail->test_id==39){ 
      //echo "<pre>";print_r($test);
    ?>
    <div class="otw-row" style="margin-bottom: -80px;">
      <div class="otw-ten otw-columns">
        <div id="wrapper">
          <div class="scrollbar" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
              <h2>Read the following message. </h2>
              <p><?php echo $test->passages; ?></p>

            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
      <div class="otw-thirteen otw-columns">
        <div id="wrapper">
          <div class="scrollbar1" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
              <h2> Using the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>), choose the best option according to the information given in the message.</h2>
              <form>
                <table>
                  <div>&nbsp;&nbsp;<?php echo $test->q1_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q1-sel-opt searchform" name="q1-response">
                      <option value=""></option>
                      <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
                      <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
                      <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
                      <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
                    </select>
                    <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                  </div>
                  <div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q2_question; ?>
                    <select type="drop-down" style="width: 140px;" class="q2-sel-opt searchform" name="q2-response">
                      <option value=""></option>
                      <option value="q2_option1"><?php echo $test->q2_option1; ?></option>
                      <option value="q2_option2"><?php echo $test->q2_option2; ?></option>
                      <option value="q2_option3"><?php echo $test->q2_option3; ?></option>
                      <option value="q2_option4"><?php echo $test->q2_option4; ?></option>
                    </select>
                    <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                  </div>
                  <div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q3_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q3-sel-opt searchform" name="q3-response">
                      <option value=""></option>
                      <option value="q3_option1"><?php echo $test->q3_option1; ?></option>
                      <option value="q3_option2"><?php echo $test->q3_option2; ?></option>
                      <option value="q3_option3"><?php echo $test->q3_option3; ?></option>
                      <option value="q3_option4"><?php echo $test->q3_option4; ?></option>
                    </select>
                    <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                  </div>
                  <div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q4_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q4-sel-opt searchform" name="q4-response">
                      <option value=""></option>
                      <option value="q4_option1"><?php echo $test->q4_option1; ?></option>
                      <option value="q4_option2"><?php echo $test->q4_option2; ?></option>
                      <option value="q4_option3"><?php echo $test->q4_option3; ?></option>
                      <option value="q4_option4"><?php echo $test->q4_option4; ?></option>
                    </select>
                    <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                  </div>
                  <div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q5_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q5-sel-opt searchform" name="q5-response">
                      <option value=""></option>
                      <option value="q5_option1"><?php echo $test->q5_option1; ?></option>
                      <option value="q5_option2"><?php echo $test->q5_option2; ?></option>
                      <option value="q5_option3"><?php echo $test->q5_option3; ?></option>
                      <option value="q5_option4"><?php echo $test->q5_option4; ?></option>
                    </select>
                    <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                  </div>
                  <div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q6_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q6-sel-opt searchform" name="q6-response">
                      <option value=""></option>
                      <option value="q6_option1"><?php echo $test->q6_option1; ?></option>
                      <option value="q6_option2"><?php echo $test->q6_option2; ?></option>
                      <option value="q6_option3"><?php echo $test->q6_option3; ?></option>
                      <option value="q6_option4"><?php echo $test->q6_option4; ?></option>
                    </select>
                    <span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                  </div>
                </table>
              </form>

              <h2><!-- <img src="images/1.png"> --> Here is a response to the message. Complete the response by filling in the blanks. Select the best choice for each blank from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>). </h2>
              <form>
                <table>
                  <p><?php echo $test->hi_message; ?></p>
                  <p><?php echo $test->q7_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q7-sel-opt searchform" name="q7-response">
                      <option value=""></option>
                      <option value="q7_option1"><?php echo $test->q7_option1; ?></option>
                      <option value="q7_option2"><?php echo $test->q7_option2; ?></option>
                      <option value="q7_option3"><?php echo $test->q7_option3; ?></option>
                      <option value="q7_option4"><?php echo $test->q7_option4; ?></option>
                    </select>
                    <span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    <?php echo $test->q8_question; ?>
                    <select type="drop-down" style="width: 110px;" class="q8-sel-opt searchform" name="q8-response">
                      <option value=""></option>
                      <option value="q8_option1"><?php echo $test->q8_option1; ?></option>
                      <option value="q8_option2"><?php echo $test->q8_option2; ?></option>
                      <option value="q8_option3"><?php echo $test->q8_option3; ?></option>
                      <option value="q8_option4"><?php echo $test->q8_option4; ?></option>
                    </select>
                    <span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    <?php echo $test->q9_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q9-sel-opt searchform" name="q9-response">
                      <option value=""></option>
                      <option value="q9_option1"><?php echo $test->q9_option1; ?></option>
                      <option value="q9_option2"><?php echo $test->q9_option2; ?></option>
                      <option value="q9_option3"><?php echo $test->q9_option3; ?></option>
                      <option value="q9_option4"><?php echo $test->q9_option4; ?></option>
                    </select>
                    <span class="q9-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                  </p>
                  <p><?php echo $test->q10_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q10-sel-opt searchform" name="q10-response">
                      <option value=""></option>
                      <option value="q10_option1"><?php echo $test->q10_option1; ?></option>
                      <option value="q10_option2"> <?php echo $test->q10_option2; ?></option>
                      <option value="q10_option3"><?php echo $test->q10_option3; ?></option>
                      <option value="q10_option4"><?php echo $test->q10_option4; ?></option>
                    </select>
                    <span class="q10-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    <?php echo $test->q11_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q11-sel-opt searchform" name="q11-response">
                      <option value=""></option>
                      <option value="q11_option1"><?php echo $test->q11_option1; ?></option>
                      <option value="q11_option2"><?php echo $test->q11_option2; ?></option>
                      <option value="q11_option3"><?php echo $test->q11_option3; ?></option>
                      <option value="q11_option4"><?php echo $test->q11_option4; ?></option>
                    </select>
                    <span class="q11-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    <?php echo $test->thank_message; ?>
                </table>
              </form>
            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    <?php if($testdetail->test_id==38){ 
      //echo "<pre>";print_r($test);
    ?>
    <div class="otw-row" style="margin-bottom: -80px;">
      <div class="otw-ten otw-columns">
        <div id="wrapper">
          <div class="scrollbar" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;width: 570px;">
              <div class="container" style="margin: 10px;">
                <div class="otw-row">
                  <div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_1; ?>"></div>
                </div>
                <div class="otw-row">
                  <div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_2; ?>"></div>
                </div>
                <div class="otw-row">
                  <div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_3; ?>"></div>
                </div>
                <div class="otw-row">
                  <div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_4; ?>"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
      <div class="otw-thirteen otw-columns">
        <div id="wrapper">
          <div class="scrollbar1" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
              <h2>Read the following email message about the diagram on the left. Complete the email by filling in the blanks. Select the best choice for each blank from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>). </h2>
              <form>
                <table>
                  <div>
                    <p><?php echo $test->q1_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q1-sel-opt searchform" name="q1-response">
                      <option value=""></option>
                      <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
                      <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
                      <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
                      <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
                    </select>
                    <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    &nbsp;&nbsp;<?php echo $test->q2_question; ?>
                    <select type="drop-down" style="width: 140px;" class="q2-sel-opt searchform" name="q2-response">
                      <option value=""></option>
                      <option value="q2_option1"><?php echo $test->q2_option1; ?></option>
                      <option value="q2_option2"><?php echo $test->q2_option2; ?></option>
                      <option value="q2_option3"><?php echo $test->q2_option3; ?></option>
                      <option value="q2_option4"><?php echo $test->q2_option4; ?></option>
                    </select><span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    &nbsp;&nbsp;<?php echo $test->q3_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q3-sel-opt searchform" name="q3-response">
                      <option value=""></option>
                      <option value="q3_option1"><?php echo $test->q3_option1; ?></option>
                      <option value="q3_option2"><?php echo $test->q3_option2; ?></option>
                      <option value="q3_option3"><?php echo $test->q3_option3; ?></option>
                      <option value="q3_option4"><?php echo $test->q3_option4; ?></option>
                    </select>
                    <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    <?php echo $test->q4_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q4-sel-opt searchform" name="q4-response">
                      <option value=""></option>
                      <option value="q4_option1"><?php echo $test->q4_option1; ?></option>
                      <option value="q4_option2"><?php echo $test->q4_option2; ?></option>
                      <option value="q4_option3"><?php echo $test->q4_option3; ?></option>
                      <option value="q4_option4"><?php echo $test->q4_option4; ?></option>
                    </select>
                    <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    &nbsp;&nbsp;<?php echo $test->q5_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q5-sel-opt searchform" name="q5-response">
                      <option value=""></option>
                      <option value="q5_option1"><?php echo $test->q5_option1; ?></option>
                      <option value="q5_option2"><?php echo $test->q5_option2; ?></option>
                      <option value="q5_option3"><?php echo $test->q5_option3; ?></option>
                      <option value="q5_option4"><?php echo $test->q5_option4; ?></option>
                    </select>
                    <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    <?php echo $test->paragraph_6; ?>
                  </div>
                </table>
              </form>

              <h2><!-- <img src="images/1.png"> --> Using the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>), choose the best option.</h2>
              <form>
                <table>
                  <div>
                    <p><?php echo $test->q6_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q6-sel-opt searchform" name="q6-response">
                      <option value=""></option>
                      <option value="q6_option1"><?php echo $test->q6_option1; ?></option>
                      <option value="q6_option2"><?php echo $test->q6_option2; ?></option>
                      <option value="q6_option3"><?php echo $test->q6_option3; ?></option>
                      <option value="q6_option4"><?php echo $test->q6_option4; ?></option>
                    </select>
                    <span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    </p>
                    <p><?php echo $test->q7_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q7-sel-opt searchform" name="q7-response">
                      <option value=""></option>
                      <option value="q7_option1"><?php echo $test->q7_option1; ?></option>
                      <option value="q7_option2"><?php echo $test->q7_option2; ?></option>
                      <option value="q7_option3"><?php echo $test->q7_option3; ?></option>
                      <option value="q7_option4"><?php echo $test->q7_option4; ?></option>
                    </select><span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    </p>
                    <p><?php echo $test->q8_question; ?>
                    <select type="drop-down" style="width: 110px;" class="q8-sel-opt searchform" name="q8-response">
                      <option value=""></option>
                      <option value="q8_option1"><?php echo $test->q8_option1; ?></option>
                      <option value="q8_option2"><?php echo $test->q8_option2; ?></option>
                      <option value="q8_option3"><?php echo $test->q8_option3; ?></option>
                      <option value="q8_option4"><?php echo $test->q8_option4; ?></option>
                    </select>
                    <span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    </p>
                  </div>
                </table>
              </form>
            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==36){ 
      //echo "<pre>";print_r($test);
    ?>
    <div class="otw-row" style="margin-bottom: -80px;">
      <div class="otw-ten otw-columns">
        <div id="wrapper">
          <div class="scrollbar" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px">
              <h2>Read the following article from a website. </h2>
              <p><?php echo $test->passages; ?></p>
            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
      <div class="otw-thirteen otw-columns">
        <div id="wrapper">
          <div class="scrollbar1" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px">
              <h2>Using the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>), choose the best option according to the information given on the website.</h2>
              <form>
                <table>
                  <div>
                    <p><?php echo $test->q1_question; ?>
                      <select type="drop-down" style="width: 150px;" class="q1-sel-opt searchform" name="q1-response">
                        <option value=""></option>
                        <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
                        <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
                        <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
                        <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
                      </select>
                      <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    </p>
                    <p><?php echo $test->q2_question; ?>
                    <select type="drop-down" style="width: 140px;" class="q2-sel-opt searchform" name="q2-response">
                      <option value=""></option>
                      <option value="q2_option1"><?php echo $test->q2_option1; ?></option>
                      <option value="q2_option2"><?php echo $test->q2_option2; ?></option>
                      <option value="q2_option3"><?php echo $test->q2_option3; ?></option>
                      <option value="q2_option4"><?php echo $test->q2_option4; ?></option>
                    </select><span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    </p>
                    <p><?php echo $test->q3_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q3-sel-opt searchform" name="q3-response">
                      <option value=""></option>
                      <option value="q3_option1"><?php echo $test->q3_option1; ?></option>
                      <option value="q3_option2"><?php echo $test->q3_option2; ?></option>
                      <option value="q3_option3"><?php echo $test->q3_option3; ?></option>
                      <option value="q3_option4"><?php echo $test->q3_option4; ?></option>
                    </select>
                    <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    </p>
                    <p>
                    <?php echo $test->q4_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q4-sel-opt searchform" name="q4-response">
                      <option value=""></option>
                      <option value="q4_option1"><?php echo $test->q4_option1; ?></option>
                      <option value="q4_option2"><?php echo $test->q4_option2; ?></option>
                      <option value="q4_option3"><?php echo $test->q4_option3; ?></option>
                      <option value="q4_option4"><?php echo $test->q4_option4; ?></option>
                    </select>
                    <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    </p>
                    <p><?php echo $test->q5_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q5-sel-opt searchform" name="q5-response">
                      <option value=""></option>
                      <option value="q5_option1"><?php echo $test->q5_option1; ?></option>
                      <option value="q5_option2"><?php echo $test->q5_option2; ?></option>
                      <option value="q5_option3"><?php echo $test->q5_option3; ?></option>
                      <option value="q5_option4"><?php echo $test->q5_option4; ?></option>
                    </select>
                    <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    </p>

                  </div>
                  <h2>The following is a comment by a visitor to the website page. Complete the comment by choosing the best option to fill in each blank.</h2>
                  <div>
                    <p><?php echo $test->q6_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q6-sel-opt searchform" name="q6-response">
                      <option value=""></option>
                      <option value="q6_option1"><?php echo $test->q6_option1; ?></option>
                      <option value="q6_option2"><?php echo $test->q6_option2; ?></option>
                      <option value="q6_option3"><?php echo $test->q6_option3; ?></option>
                      <option value="q6_option4"><?php echo $test->q6_option4; ?></option>
                    </select>
                    <span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    <?php echo $test->q7_question; ?>
                    <select type="drop-down" style="width: 150px;" class="q7-sel-opt searchform" name="q7-response">
                      <option value=""></option>
                      <option value="q7_option1"><?php echo $test->q7_option1; ?></option>
                      <option value="q7_option2"><?php echo $test->q7_option2; ?></option>
                      <option value="q7_option3"><?php echo $test->q7_option3; ?></option>
                      <option value="q7_option4"><?php echo $test->q7_option4; ?></option>
                    </select><span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    
                    <?php echo $test->q8_question; ?>
                    <select type="drop-down" style="width: 110px;" class="q8-sel-opt searchform" name="q8-response">
                      <option value=""></option>
                      <option value="q8_option1"><?php echo $test->q8_option1; ?></option>
                      <option value="q8_option2"><?php echo $test->q8_option2; ?></option>
                      <option value="q8_option3"><?php echo $test->q8_option3; ?></option>
                      <option value="q8_option4"><?php echo $test->q8_option4; ?></option>
                    </select>
                    <span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    
                    <?php echo $test->q9_question; ?>
                    <select type="drop-down" style="width: 110px;" class="q9-sel-opt searchform" name="q9-response">
                      <option value=""></option>
                      <option value="q9_option1"><?php echo $test->q9_option1; ?></option>
                      <option value="q9_option2"><?php echo $test->q9_option2; ?></option>
                      <option value="q9_option3"><?php echo $test->q9_option3; ?></option>
                      <option value="q9_option4"><?php echo $test->q9_option4; ?></option>
                    </select>
                    <span class="q9-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    
                    <?php echo $test->q10_question; ?>
                    <select type="drop-down" style="width: 110px;" class="q10-sel-opt searchform" name="q10-response">
                      <option value=""></option>
                      <option value="q10_option1"><?php echo $test->q10_option1; ?></option>
                      <option value="q10_option2"><?php echo $test->q10_option2; ?></option>
                      <option value="q10_option3"><?php echo $test->q10_option3; ?></option>
                      <option value="q10_option4"><?php echo $test->q10_option4; ?></option>
                    </select>
                    <span class="q10-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                    
                    </p>
                  </div>
                </table>
              </form>
            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    
    <?php } ?>
    <input type="hidden" name="token" value="<?php echo $this->uri->segment(3); ?>"/>
      
    </div>
      </div>

    </div>

     <footer id="page-footer">
      
      <div class="otw-row copyright">
        <div class="otw-twelve otw-columns">
          
        </div>
        <div class="otw-twelve otw-columns text-right">
          <a href="#"><!--img src="images/logo-celpip-footer.png" title="celpip" alt=""/--></a>
           &copy; 2018-2019 All rights reserved.
        </div>
      </div>
    </footer>
  </div>
<script type="text/javascript">
  function show() { document.getElementById('area').style.display = 'block'; }
  function hide() { document.getElementById('area').style.display = 'none'; }
</script>
  <?php include_once('common/scripts.php'); ?>
  
  
</body>
</html>