<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?></h1>
    </section>

      <?php
        /*
        Load Template As per PTE test subtype: question/subid.php  

        PTE Types SPEAKING (Id:1)  READING(ID:2) LISTENING (ID:3) WRITING (ID:4)

        PTE SubID   PTE TestSubType               Type
        ---------   ----------------              ------

          28        Summarize spoken text          3
          29        Multiple-choice: Single        3
          30        Multiple-choice: Multiple      3
          31        Fill in the blanks             3
          32        Highlight correct summary      3
          33        Select missing word            3
          34        Highlight incorrect words      3
          35        Write from dictation           3

          36        Multiple Fill in the blanks    2
          37        Fill in the blanks             2
          38        Re-order paragraphs            2
          39        Multiple-Choice: Multiple      2
          40        Multiple-choice: Single        2

          41        Read Aloud                     1
          42        Repeat Sentence                1
          43        Describe Image                 1
          44        Re-tell lecture                1
          45        Answer short question          1

          46        Summarize written text         4
          47        Write Essey                    4

        */ 
      ?>

    <section class="content">
        <div class="row">
        

                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('teacher/addgeneralwritingsample/'.$this->uri->rsegment(3), array('subtypeid' => $this->uri->rsegment(3), 'class' => 'clearfix' )); ?>
                      <hr />
						
							<div class="row">
						    <div class="col-md-12">
								<div class="form-group">
									<label>Question id</label>
									<input type="text" class="form-control" placeholder="Question id" name="questionid" required="">
								</div>
						</div>
						
							<div class="col-md-12">
								<div class="form-group">
									<label>Seo Title</label>
									<input type="text" class="form-control" placeholder="seo_title" name="seo_title" required="">
								</div>
							</div>
							
								<div class="col-md-12">
								<div class="form-group">
									<label>Seo Discription</label>
									<textarea class="form-control" rows="5" name="seo_discription" placeholder="Seo Discription" required=""></textarea>
								</div>
							</div>

					
							
							<div class="col-md-12">
								<div class="form-group">
									<label>Title</label>
									<input type="text" class="form-control" placeholder="title" name="title" required="">
								</div>
								</div>
							
							<div class="col-md-12">
								<div class="form-group">
									<label>Question</label>
									<textarea class="form-control" rows="5" name="question" placeholder="Place some text here" required=""></textarea>
								</div>
						</div>	  
							
						<div class="col-md-12">
								<div class="form-group">
									<label>Answer</label>
									<textarea class="form-control" rows="5" name="answer" placeholder="Answer" required=""></textarea>
								</div>
							</div>
							
						  


 <button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
                         <div class="clearfix"></div> 
                      </form>

                  </div>


              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>