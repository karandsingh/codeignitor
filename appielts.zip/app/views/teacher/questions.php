<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?>  
        <small> <?php echo $pagetitle; ?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>

  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-body">

              <div class="row">

                <div class="col-md-3">
                  <div class="box box-widget widget-user">
                    <div class="widget-user-header bg-purple">
                      <h3 class="widget-user-username"><STRONG> <p class="fa fa-microphone"></p> SPEAKING</STRONG></h3>
                      <h5 class="widget-user-desc">Practice Task + 8 Tasks</h5>
                    </div>
                    <div class="box-footer no-padding">
                      <ul class="nav nav-stacked">
                      <?php
                      
                      //PTE Speaking Type id 1

                      $where="PTEtypeid ='6' AND active = 'Yes' ";
                      $subtypes = $this->my_model->getWhereRecords($this->tb_subtype, $where);
                      
                      if($subtypes!=NULL)
                      {
                      foreach ($subtypes as $key => $subtype) { ?>
                   
                        <?php if($subtype->id==62){ ?>

                        <li><a href="<?php echo base_url('teacher/reviewQuestions/62'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-eye"></p></span></a></li>

                        <?php }else if($subtype->id==63){  ?>
                                <li>
                                  <a href="<?php echo base_url('teacher/reviewQuestions/63'); ?>"><?=$subtype->PTEsubtype?>
                                    <span class="pull-right "><p class="fa fa-eye"></p></span>
                                  </a>
                                </li>

                                <?php }else if($subtype->id==64){  ?>
                                <li>
                                  <a href="<?php echo base_url('teacher/reviewQuestions/64'); ?>"><?=$subtype->PTEsubtype?>
                                    <span class="pull-right "><p class="fa fa-eye"></p></span>
                                  </a>
                                </li>

                                <?php }}} ?>

                      </ul>
                    </div>
                  </div>
                </div>

                <div class="col-md-3">
                  <div class="box box-widget widget-user">
                    <div class="widget-user-header bg-red">
                    
                      <h3 class="widget-user-username"><STRONG> <p class="fa fa-edit"></p>Academic WRITING</STRONG></h3>
                      <h5 class="widget-user-desc">2 Tasks</h5>
                      <!-- <h5 class="widget-user-desc">Time : 53(27+26) Minutes </h5> -->
                    </div>
                    <div class="box-footer no-padding">
                      <ul class="nav nav-stacked">
                        
                        <?php
                          //Writing Type id 4

                          $where="PTEtypeid ='4' AND active = 'Yes' ";
                          $subtypes = $this->my_model->getWhereRecords($this->tb_subtype, $where);
                          ?>
                            <?php 
                              if($subtypes!=NULL)
                              {
                              foreach ($subtypes as $key => $subtype) { ?>
                                <?php if($subtype->id==41){ ?>

                                <li>
                                  <a href="<?php echo base_url('teacher/reviewQuestions/41'); ?>"><?=$subtype->PTEsubtype?>
                                    <span class="pull-right "><p class="fa fa-eye"></p></span>
                                  </a>
                                </li>

                                <?php }else if($subtype->id==42){  ?>
                                <li>
                                  <a href="<?php echo base_url('teacher/reviewQuestions/42'); ?>"><?=$subtype->PTEsubtype?>
                                    <span class="pull-right "><p class="fa fa-eye"></p></span>
                                  </a>
                                </li>

                                <?php }}}?>

                      </ul>
                    </div>
                  </div>
                </div>
                
                <div class="col-md-3">
                  <div class="box box-widget widget-user">
                    <div class="widget-user-header bg-red">
                    
                      <h3 class="widget-user-username"><STRONG> <p class="fa fa-edit"></p>Academic WRITING</STRONG></h3>
                      <h5 class="widget-user-desc">2 Tasks</h5>
                      <!-- <h5 class="widget-user-desc">Time : 53(27+26) Minutes </h5> -->
                    </div>
                    <div class="box-footer no-padding">
                      <ul class="nav nav-stacked">
                        
                        <?php
                          //Writing Type id 4

                          $where="PTEtypeid ='5' AND active = 'Yes' ";
                          $subtypes = $this->my_model->getWhereRecords($this->tb_subtype, $where);
                          ?>
                            <?php 
                              if($subtypes!=NULL)
                              {
                              foreach ($subtypes as $key => $subtype) { ?>
                                <?php if($subtype->id==51){ ?>

                                <li>
                                  <a href="<?php echo base_url('teacher/reviewQuestions/51'); ?>"><?=$subtype->PTEsubtype?>
                                    <span class="pull-right "><p class="fa fa-eye"></p></span>
                                  </a>
                                </li>

                                <?php }else if($subtype->id==52){  ?>
                                <li>
                                  <a href="<?php echo base_url('teacher/reviewQuestions/52'); ?>"><?=$subtype->PTEsubtype?>
                                    <span class="pull-right "><p class="fa fa-eye"></p></span>
                                  </a>
                                </li>

                                <?php }}}?>

                      </ul>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>

  <?php include_once('common/scripts.php'); ?>
</body>
</html>
