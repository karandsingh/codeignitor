<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

        <style type="text/css">
    .widget-user .widget-user-header {
    padding: 15px;
    height: 90px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
}
  </style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
    <h1 style="text-align:center;color:#000">    
    <?php 
				if($Subtypeid->Subtypeid==51){
					echo "General Writing Part 1 Samples" ;
				}elseif($Subtypeid->Subtypeid==52){
					echo "General Writing Part 2 Samples";
		}else {
		    echo "General Writing Sample";
		}
			?></h1>
			
		
     
    </section>

    <!-- Main content -->

          <div class="box"
          >            <div class="box-header">
  <h3 class="box-title" stle="text-align:center">Sample Questions</h3>
              <?php if($Subtypeid->Subtypeid==51){
                                  ?>
                                       <a href="<?php echo base_url(); ?>teacher/addgeneralwritingsample/51" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                  <?php }else{ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addgeneralwritingsample/52" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php } ?>
                                 </div></div>
              <div class="box-body" style="overflow:scroll;">	
              <table id="example1" class="table table-bordered table-striped">
                              <thead>
                                 <tr>         
                                 <th>Id</th>

                                  <th>Test Title</th>
                                <th></th>
                                </tr>
                              </thead>

                              <tbody>
   <?php if($Subtypeid->Subtypeid==51){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editgeneralwritingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     
     <?php if($Subtypeid->Subtypeid==52){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>

                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editgeneralwritingsample/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  
	<div id="section-writing-instructions" class="modal fade">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-body">
			
		  </div>
		</div>
	  </div>
	</div>

  <?php include_once('common/scripts.php'); ?>
  
</body>
</html>