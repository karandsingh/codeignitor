<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?></h1>
     
    </section>

    

    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <h1><?php if($test->Subtypeid==31){$this->data['pagetitle'] = 'Sample General Reading Part 1: Matching Information';}
                    elseif($test->Subtypeid==32){$this->data['pagetitle'] = 'Sample General Reading Part 2: True/False/Not Given';}
                    elseif($test->Subtypeid==33){$this->data['pagetitle'] = 'Sample General Reading Part 3: Note Completion';}
                    elseif($test->Subtypeid==34){$this->data['pagetitle'] = 'Sample General Reading Part 4: Sentence Completion';} 
                    elseif($test->Subtypeid==35){$this->data['pagetitle'] = 'Sample General Reading Part 5: Matching Features';} 
                    elseif($test->Subtypeid==36){$this->data['pagetitle'] = 'Sample General Reading Part 6: Multiple Choice';} 
                    elseif($test->Subtypeid==37){$this->data['pagetitle'] = 'Sample General Reading Part 7: Summary Completion';}
              ?></h1>
         </div>
         </div>

                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('teacher/editgeneralreadingsample/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(3), 'class' => 'clearfix' )); ?>
                      <hr />
						
						<div class="row">
						    	<div class="col-md-12">
								<div class="form-group">
									<label>Seo Title</label>
									<input type="text" class="form-control" placeholder="Seo title" name="seo_title" value="<?php echo set_value('seo_title',$test->seo_title); ?>" required>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label>Seo Discription</label>
									<textarea class="form-control" rows="5" name="seo_discription" placeholder="Place some text here" required=""><?php echo $test->seo_discription; ?></textarea>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<label>Question Title</label>
									<input type="text" class="form-control" placeholder="Question title" name="title" value="<?php echo set_value('title',$test->title); ?>" required>
								</div>
							</div>
							
							 
						  
						  <div class="col-md-12">
								<div class="form-group">
									<label>Youtube Embed</label>
									<textarea class="form-control" rows="5" name="youtubelink" placeholder="Paste youtube url here" required=""><?php echo $test->video_url; ?></textarea>
								</div>
							</div>
							
						
						</div>	  
						 <button type="submit" class="btn btn-info btn-fill pull-right">Edit</button>
                         <div class="clearfix"></div> 

                      </form>

                  </div>


              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>