<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

        <style type="text/css">
    .widget-user .widget-user-header {
    padding: 15px;
    height: 90px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
}
  </style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
    <h1 style="text-align:center;color:#000">    
    <?php 
				if($Subtypeid->Subtypeid==11){
					echo "Listening Part 1: Multiple Choice with one answer";
				}elseif($Subtypeid->Subtypeid==12){
					echo "Listening Part 2: Multiple choice with more than one answer";
					}elseif($Subtypeid->Subtypeid==13){
					echo "Listening Part 3: Matching";
					}elseif($Subtypeid->Subtypeid==14){
					echo "Listening Part 4: Labelling on a Map";
					}elseif($Subtypeid->Subtypeid==15){
					echo "Listening Part 5: Fill in the Blanks";
					}elseif($Subtypeid->Subtypeid==16){
					echo "Listening Part 6: Fill in the Blanks : Short Answer";
					}
					else 
					{
		    echo "Listening Sample Test";
		}
			?></h1>
			
		
     
    </section>

    <!-- Main content -->

          <div class="box"
          >            <div class="box-header">
  <h3 class="box-title" stle="text-align:center">Sample Questions</h3>
              <?php if($Subtypeid->Subtypeid==11){
                                  ?>
                                       <a href="<?php echo base_url(); ?>teacher/addsamplelistening/11" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                  <?php }elseif($Subtypeid->Subtypeid==12){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addsamplelistening/12" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==13){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addsamplelistening/13" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==14){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addsamplelistening/14" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==15){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addsamplelistening/15" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php }elseif($Subtypeid->Subtypeid==16){ ?>
                                 <a href="<?php echo base_url(); ?>teacher/addsamplelistening/16" style="float:right" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
                                 <?php } ?>
                                 </div></div>
              <div class="box-body" style="overflow:scroll;">	
              <table id="example1" class="table table-bordered table-striped">
                              <thead>
                                 <tr>         
                                 <th>Id</th>
                                  <th>Test Title</th>
                                <th></th>
                                </tr>
                              </thead>

                              <tbody>
   <?php if($Subtypeid->Subtypeid==11){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editsamplelistening/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     
     <?php if($Subtypeid->Subtypeid==12){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editsamplelistening/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     <?php if($Subtypeid->Subtypeid==13){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editsamplelistening/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     <?php if($Subtypeid->Subtypeid==14){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editsamplelistening/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     <?php if($Subtypeid->Subtypeid==15){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editsamplelistening/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>
     <?php if($Subtypeid->Subtypeid==16){ 
			//echo "<pre>";print_r($test);
		?>
                <?php $count=1;
                     foreach ($question_list as $key => $question) { ?>
                    <tr>
                        <td><?php echo $count++;?></td>
                      <td><span class="online"><?php echo $question->title; ?></span></td>    
                               						<td>
          						  <a href="<?php echo base_url(); ?>teacher/editsamplelistening/<?=$question->id?>" class="btn btn-default btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i> Edit</a>
          						</td>                         
                    </tr>


                <?php } ?>
     <?php } ?>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  
	<div id="section-writing-instructions" class="modal fade">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-body">
			
		  </div>
		</div>
	  </div>
	</div>

  <?php include_once('common/scripts.php'); ?>
  
</body>
</html>
