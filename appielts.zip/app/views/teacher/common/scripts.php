<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {

    var weburl = '<?php echo site_url(); ?>';

    // Token protection for ajax request
    $.ajaxSetup({ data: {
      '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
    }});

    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
	
	$('.reseller_add_coins').click(function(){
		if (confirm('Are you sure?')) {
		   $("#resellet_addCoinModal").modal('show');
		   $(".student_id").val($(this).data('id'));
		}	
	});
	
	
    $('.reseller_add_coins_btn').click(function(){
		   
		   $(this).prop('disabled', true);
		   $(this).html('Please wait ...');
		   var coins = $('.add_coin_no').val();
		   var description = $('.add_coin_desc').val();
		   var student_id = $('.student_id').val();
		   $.ajax({
				type: "POST",
				url: weburl + "business/addCoins",
				data: {
				  coins: coins,
				  description: description,
				  student_id: student_id,
				},
				dataType:"json",
				cache:false,
				success:
				function(data) {
				  console.log(data);
				  //return false;
				  if( data.result == "success") {
					 window.location.reload();
				   }else{
					  $('.get_error_msg').html(data.message);
				   }
				},
				error:
				function(data) {
				  console.log(data);
				  $(this).prop('disabled', false);
				  $(this).html('Submit');
				}
			  });
		
	});
  });
</script>