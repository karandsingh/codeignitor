  <section class="sidebar">

      <ul class="sidebar-menu">

        <li class="header"> </li>

		    <li <?php if (in_array($this->uri->segment(2), array('dashboard'))) { ?> class="active"<?php } ?>>
			    <a href="<?php echo base_url($currentPath.'/dashboard'); ?>">
			      <i class="fa fa-dashboard"></i> <span>Dashboard</span>
		      </a>
        </li>

    <!---    <li class="<?php if (in_array($this->uri->segment(2), array('questionType','addQuestion','editQuestion','wtTaskList','wtTask2List','wtTask','wtTask2','wtTask_edit','wtTask2_edit','spPracticeList','spPractice','spPractice_edit','spPart1List','spPart1','spPart2List','spPart2','spPart2_edit','spPart3List','spPart3','spPart3_edit','spPart4List','spPart4','spPart5List','spPart5','spPart5_edit','spPart6List','spPart6','spPart6_edit','spPart7List','spPart7','spPart7_edit','spPart8List','spPart8_edit','spPart8'))) { ?>active <?php } ?>treeview">
          <a>
            <i class="fa fa-tasks"></i> <span>Manage Questions</span>
            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
          </a>
          <ul class="treeview-menu">
            <li <?php if (in_array($this->uri->segment(2), array('addQuestion','questionType'))) { ?> class="active"<?php } ?>>
              <a href="<?php echo base_url($currentPath."/questionType"); ?>"><i class="fa fa-plus-square"></i> Add Question
            </a>
            </li>
          </ul>
        </li>--->

        <li class="<?php if (in_array($this->uri->segment(2), array('reviewQuestions','questions','reviewedQuestions'))) { ?>active <?php } ?>treeview">
          <a>
            <i class="fa fa-tasks"></i> <span>Review Questions</span>
            <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
          </a>
          <ul class="treeview-menu">
            <li <?php if (in_array($this->uri->segment(2), array('questions'))) { ?> class="active"<?php } ?>>
              <a href="<?php echo base_url($currentPath."/questions"); ?>">
                <i class="fa fa-eye"></i>  Review New Questions
              </a>
            </li>
            <li <?php if (in_array($this->uri->segment(2), array('reviewedQuestions'))) { ?> class="active"<?php } ?>>
              <a href="<?php echo base_url($currentPath."/reviewedQuestions"); ?>"><i class="fa fa-check-circle-o"></i> Reviewed Questions
            </a>
            </li>
          </ul>
        </li>
      <!--    <ul class="treeview-menu">
              <li><?php if ($this->uri->segment(5)) ?><a href="<?php echo base_url($currentPath."/Samplewriting/47"); ?>"><i class="fa fa-book"></i> Task 1 </a></li>
               <li><?php if ($this->uri->segment(5)) ?><a href="<?php echo base_url($currentPath."/Samplewriting/46"); ?>"><i class="fa fa-book"></i> Task 2 </a></li>
            </ul>
        </li>--->
        
        
    <!---        <li <?php if (in_array($this->uri->segment(2), array('reviewedQuestions'))) { ?> class="active"<?php } ?>>
              <a href="<?php echo base_url($currentPath."/reviewedQuestions"); ?>"><i class="fa fa-check-circle-o"></i> Reviewed Questions
            </a>
            </li>
          </ul>
        </li>--->
           
           
           <li class="<?php if (in_array($this->uri->segment(5), array('SampleQuestions','questions','reviewedQuestions'))) { ?>active <?php } ?>">
          <a>
             <i class="glyphicon glyphicon-bullhorn"></i> <span>General Writing </span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
           </a>
           <ul class="treeview-menu">
              <li><?php if ($this->uri->segment(5)) ?><a href="<?php echo base_url($currentPath."/generalwritingsample/51"); ?>"><i class="fa fa-book"></i> Task 1 </a></li>
               <li><?php if ($this->uri->segment(5)) ?><a href="<?php echo base_url($currentPath."/generalwritingsample/52"); ?>"><i class="fa fa-book"></i> Task 2 </a></li>
            </ul>
        </li>
        
        
         <li class="<?php if (in_array($this->uri->segment(4), array('SampleQuestions','questions','reviewedQuestions'))) { ?>active <?php } ?>">
          <a>
             <i class="glyphicon glyphicon-bullhorn"></i> <span>Academic Writing </span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
           </a>
           <ul class="treeview-menu">
              <li><?php if ($this->uri->segment(5)) ?><a href="<?php echo base_url($currentPath."/academicwritingsample/41"); ?>"><i class="fa fa-book"></i> Task 1 </a></li>
               <li><?php if ($this->uri->segment(5)) ?><a href="<?php echo base_url($currentPath."/academicwritingsample/42"); ?>"><i class="fa fa-book"></i> Task 2 </a></li>
            </ul>
        </li>
        
          <li class="<?php if (in_array($this->uri->segment(4), array('SampleQuestions','questions','reviewedQuestions'))) { ?>active <?php } ?>">
          <a>
             <i class="glyphicon glyphicon-bullhorn"></i> <span>Listening Sample </span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
           </a>
           <ul class="treeview-menu">
              <li><?php if ($this->uri->segment(6)) ?><a href="<?php echo base_url($currentPath."/samplelistening/1"); ?>"><i class="fa fa-book"></i> Part 1 </a></li>
               <li><?php if ($this->uri->segment(6)) ?><a href="<?php echo base_url($currentPath."/samplelistening/12"); ?>"><i class="fa fa-book"></i> Part 2 </a></li>
               <li><?php if ($this->uri->segment(6)) ?><a href="<?php echo base_url($currentPath."/samplelistening/13"); ?>"><i class="fa fa-book"></i> Part 3 </a></li>
               <li><?php if ($this->uri->segment(6)) ?><a href="<?php echo base_url($currentPath."/Samplelistening/14"); ?>"><i class="fa fa-book"></i> Part 4 </a></li>
               <li><?php if ($this->uri->segment(6)) ?><a href="<?php echo base_url($currentPath."/Samplelistening/15"); ?>"><i class="fa fa-book"></i> Part 5 </a></li>
               <li><?php if ($this->uri->segment(6)) ?><a href="<?php echo base_url($currentPath."/Samplelistening/16"); ?>"><i class="fa fa-book"></i> Part 6 </a></li>
               <li><?php if ($this->uri->segment(6)) ?><a href="<?php echo base_url($currentPath."/Samplelistening/17"); ?>"><i class="fa fa-book"></i> Part 7 </a></li>
            </ul>
        </li>
        
        
        
        
        <li class="<?php if (in_array($this->uri->segment(4), array('SampleQuestions','questions','reviewedQuestions'))) { ?>active <?php } ?>">
          <a>
             <i class="glyphicon glyphicon-bullhorn"></i> <span>Academic Reading </span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
           </a>
           <ul class="treeview-menu">
              <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/21"); ?>"><i class="fa fa-book"></i> Part 1 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/22"); ?>"><i class="fa fa-book"></i> Part 2 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/23"); ?>"><i class="fa fa-book"></i> Part 3 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/24"); ?>"><i class="fa fa-book"></i> Part 4 </a></li>
                <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/25"); ?>"><i class="fa fa-book"></i> Part 5 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/26"); ?>"><i class="fa fa-book"></i> Part 6 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/27"); ?>"><i class="fa fa-book"></i> Part 7 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/28"); ?>"><i class="fa fa-book"></i> Part 8 </a></li>
                <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/29"); ?>"><i class="fa fa-book"></i> Part 9 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/academicreadingsample/30"); ?>"><i class="fa fa-book"></i> Part 10 </a></li>



       <?php /* <li <?php if (in_array($this->uri->segment(2), array('member','editMember'))) { ?> class="active"<?php } ?>>
          <a href="<?php echo base_url('business/member'); ?>">
            <i class="fa fa-list"></i> <span>Manage Students</span>
          </a>
        </li>*/ ?>
    
      </ul>
      </li>
      
      
          <li class="<?php if (in_array($this->uri->segment(4), array('SampleQuestions','questions','reviewedQuestions'))) { ?>active <?php } ?>">
          <a>
             <i class="glyphicon glyphicon-bullhorn"></i> <span>General Reading </span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
           </a>
           <ul class="treeview-menu">
              <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/generalreadingsample/31"); ?>"><i class="fa fa-book"></i> Part 1 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/generalreadingsample/32"); ?>"><i class="fa fa-book"></i> Part 2 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/generalreadingsample/33"); ?>"><i class="fa fa-book"></i> Part 3 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/generalreadingsample/34"); ?>"><i class="fa fa-book"></i> Part 4 </a></li>
                <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/generalreadingsample/35"); ?>"><i class="fa fa-book"></i> Part 5 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/generalreadingsample/36"); ?>"><i class="fa fa-book"></i> Part 6 </a></li>
               <li><?php if ($this->uri->segment(7)) ?><a href="<?php echo base_url($currentPath."/generalreadingsample/37"); ?>"><i class="fa fa-book"></i> Part 7 </a></li>



       <?php /* <li <?php if (in_array($this->uri->segment(2), array('member','editMember'))) { ?> class="active"<?php } ?>>
          <a href="<?php echo base_url('business/member'); ?>">
            <i class="fa fa-list"></i> <span>Manage Students</span>
          </a>
        </li>*/ ?>
    
      </ul>
      </li>
        <li class="<?php if (in_array($this->uri->segment(4), array('SampleQuestions','questions','reviewedQuestions'))) { ?>active <?php } ?>">
          <a>
             <i class="glyphicon glyphicon-bullhorn"></i> <span>Speaking Sample </span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
           </a>
           <ul class="treeview-menu">
               <li><?php if ($this->uri->segment(8)) ?><a href="<?php echo base_url($currentPath."/Samplespeaking/61"); ?>"><i class="fa fa-book"></i> Speaking Part 1 </a></li>
            </ul>
        </li>


       <?php /* <li <?php if (in_array($this->uri->segment(2), array('member','editMember'))) { ?> class="active"<?php } ?>>
          <a href="<?php echo base_url('business/member'); ?>">
            <i class="fa fa-list"></i> <span>Manage Students</span>
          </a>
        </li>*/ ?>
    
      </ul>
      
    </section>