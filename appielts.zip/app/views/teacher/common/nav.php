
    <a href="<?php echo base_url('teacher/dashboard'); ?>" class="logo">
      <span class="logo-mini"><?php echo $this->logo_mini; ?></span>
      <span class="logo-lg"><?php echo $this->logo_large; ?></span>
    </a>

    <nav class="navbar navbar-static-top">

      <a class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
      

          <li class="dropdown user user-menu">
            <a class="dropdown-toggle" data-toggle="dropdown">
			  <span>Balance Coins: <?php if($user->coins){ echo $user->coins; }else{ echo 0; } ?> </span> |
              <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs">Welcome, <?php echo strtoupper($user->username); ?> </span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                <p>
                  <?php echo strtoupper($user->username); ?>
                  <small><?php echo $user->name; ?></small>
                </p>
              </li>
            
              <li class="user-footer">
                <div class="pull-left">
                  <a class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="<?php echo base_url('teacher/logout'); ?>" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>

          <li>
            <a href="<?php echo base_url('teacher/logout'); ?>" ><i class="fa fa-sign-out"></i> </a>
          </li>
        </ul>
      </div>
    </nav>
