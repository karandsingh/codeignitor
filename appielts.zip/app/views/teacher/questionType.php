<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> Manager 
        <small>Select <?php echo $pagetitle; ?> Type To Add New Question</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>

  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-body">

              <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
                <strong>NOTE : </strong> Select category to add new question.
              </div>
              <hr />

              <div class="row">
                <div class="col-md-3">
                  <div class="box box-widget widget-user">
                    <div class="widget-user-header bg-blue">
                      <h3 class="widget-user-username"><b><p class="fa fa-headphones"></p> LISTENING</b></h3>
                      <h5 class="widget-user-desc">Practice Task + 6 Parts</h5>
                      <h5 class="widget-user-desc">Time : 50 Minutes </h5>
                    </div>
                    <div class="box-footer no-padding">
                      <ul class="nav nav-stacked">
                        <?php
                          //LISTENING Type id 3

                          $where="PTEtypeid ='3' AND active = 'Yes' ";
                          $subtypes = $this->my_model->getWhereRecords($this->tb_subtype, $where);
                          ?>
                            <?php 
                              if($subtypes!=NULL)
                              {
                              foreach ($subtypes as $key => $subtype) { ?>
                         <?php if($subtype->id==20){ ?>
						  <li><a href="<?php echo base_url('teacher/lspart1Listing'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }elseif($subtype->id==19){?>
						<li><a href="<?php echo base_url('teacher/lspart2Listing'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }elseif($subtype->id==18){?>
						<li><a href="<?php echo base_url('teacher/lspart3Listing'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }elseif($subtype->id==17){?>
						<li><a href="<?php echo base_url('teacher/lspart4Listing'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }elseif($subtype->id==16){?>
						<li><a href="<?php echo base_url('teacher/lspart5Listing'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }elseif($subtype->id==15){?>
						<li><a href="<?php echo base_url('teacher/lspart6Listing'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }elseif($subtype->id==29){?>
						<li><a href="<?php echo base_url('teacher/lsPracticeList'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }else{ ?>
                        <li><a href="<?php echo base_url('teacher/addQuestion/'); ?><?=$subtype->id?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php } }} ?>

                      </ul>
                    </div>
                  </div>
                </div>
				
				<div class="col-md-3">
                  <div class="box box-widget widget-user">
                    <div class="widget-user-header bg-aqua">
                    
                      <h3 class="widget-user-username"><STRONG> <p class="fa fa-book"></p> READING</STRONG></h3>
                      <h5 class="widget-user-desc">Practice Task + 4 Parts</h5>
                      <h5 class="widget-user-desc">Time : 55 Minutes </h5>
                    </div>
                    <div class="box-footer no-padding">
                      <ul class="nav nav-stacked">

                      <?php
                          //PTE Reading Type id 2

                          $where="PTEtypeid ='2' AND active = 'Yes' ";
                          $subtypes = $this->my_model->getWhereRecords($this->tb_subtype, $where);
                          ?>
                            <?php 
                              if($subtypes!=NULL)
                              {
                              foreach ($subtypes as $key => $subtype) { ?>
							  
							  <?php if($subtype->id==40){ ?>
							  <li><a href="<?php echo base_url('teacher/rdPracticeList'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
							  <?php }else if($subtype->id==39){ ?>
							  <li><a href="<?php echo base_url('teacher/rdPart1List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
							  
							 <?php }else if($subtype->id==38){ ?>
							  <li><a href="<?php echo base_url('teacher/rdPart2List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
							  <?php }else if($subtype->id==37){ ?>
							  <li><a href="<?php echo base_url('teacher/rdPart3List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
							  
							<?php }else if($subtype->id==36){ ?>
							  <li><a href="<?php echo base_url('teacher/rdPart4List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
							<?php }else{?>
                            <li><a href="<?php echo base_url($currentPath.'/addQuestion/'); ?><?=$subtype->id?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }}} ?>

                      </ul>
                    </div>
                  </div>
                </div>
				
				<div class="col-md-3">
                  <div class="box box-widget widget-user">
                    <div class="widget-user-header bg-purple">
                    
                      <h3 class="widget-user-username"><STRONG> <p class="fa fa-microphone"></p> SPEAKING</STRONG></h3>
                      <h5 class="widget-user-desc">Practice Task + 8 Tasks</h5>
                      <h5 class="widget-user-desc">Time : 20 Minutes </h5>
                    </div>
                    <div class="box-footer no-padding">
                      <ul class="nav nav-stacked">
                      <?php
                      
                          //PTE Speaking Type id 1

                          $where="PTEtypeid ='1' AND active = 'Yes' ";
                          $subtypes = $this->my_model->getWhereRecords($this->tb_subtype, $where);
                          ?>
                            <?php 
                              if($subtypes!=NULL)
                              {
                              foreach ($subtypes as $key => $subtype) { ?>
                         
						       <?php if($subtype->id==59){ ?>
						  <li><a href="<?php echo base_url('teacher/spPracticeList'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }elseif($subtype->id==58){?>
						<li><a href="<?php echo base_url('teacher/spPart1List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }elseif($subtype->id==57){?>
						<li><a href="<?php echo base_url('teacher/spPart2List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						
						<?php }elseif($subtype->id==56){?>
						<li><a href="<?php echo base_url('teacher/spPart3List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						
						<?php }elseif($subtype->id==55){?>
						<li><a href="<?php echo base_url('teacher/spPart4List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						
						<?php }elseif($subtype->id==54){?>
						<li><a href="<?php echo base_url('teacher/spPart5List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						
						<?php }elseif($subtype->id==53){?>
						<li><a href="<?php echo base_url('teacher/spPart6List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						
						<?php }elseif($subtype->id==52){?>
						<li><a href="<?php echo base_url('teacher/spPart7List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						
						<?php }elseif($subtype->id==51){?>
						<li><a href="<?php echo base_url('teacher/spPart8List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
						<?php }else{?>
                        <li><a href="<?php echo base_url($currentPath.'/addQuestion/'); ?><?=$subtype->id?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
                               
                      <?php }}} ?>

                      </ul>
                    </div>
                  </div>
                </div>
				
                <div class="col-md-3">
                  <div class="box box-widget widget-user">
                    <div class="widget-user-header bg-red">
                    
                      <h3 class="widget-user-username"><STRONG> <p class="fa fa-edit"></p> WRITING</STRONG></h3>
                      <h5 class="widget-user-desc">2 Tasks</h5>
                      <h5 class="widget-user-desc">Time : 53(27+26) Minutes </h5>
                    </div>
                    <div class="box-footer no-padding">
                      <ul class="nav nav-stacked">
                        
                        <?php
                          //Writing Type id 4

                          $where="PTEtypeid ='4' AND active = 'Yes' ";
                          $subtypes = $this->my_model->getWhereRecords($this->tb_subtype, $where);
                          ?>
                            <?php 
                              if($subtypes!=NULL)
                              {
                              foreach ($subtypes as $key => $subtype) { ?>
                                <?php if($subtype->id==47){?>
								<li><a href="<?php echo base_url('teacher/wtTaskList'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
								<?php }else if($subtype->id==46){?>
								<li><a href="<?php echo base_url('teacher/wtTask2List'); ?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
							   <?php }else{ ?>
                        <li><a href="<?php echo base_url($currentPath.'/addQuestion/'); ?><?=$subtype->id?>"><?=$subtype->PTEsubtype?><span class="pull-right "><p class="fa fa-plus-square"></p></span></a></li>
                               
                      <?php }}}?>

                      </ul>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>

  <?php include_once('common/scripts.php'); ?>
</body>
</html>
