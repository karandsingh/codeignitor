<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> 
      </h1>
    </section>
<!-- <b>Buy 5000 coins for $10</b>   <BR><BR>
   <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="7T735DXVZWJ74">
<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>-->
<!--  
     
     
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="3SWHFA7Q5H378">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

-->
    <!-- <div class="col-md-12" >
      <a href="<?php echo base_url('member/buyCoins'); ?>" class="btn btn-danger"> BUY COINS</a>
    </div> -->
    
    <?php $member_id = $this->logged['id']; ?>
	<div class="col-md-12" >
    <!--
      <form target="paypal" action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">
      <input type="hidden" name="item_name" value="<?php echo $this->logged['id']; ?>">
      <input type="hidden" name="item_number" value="1">
      <input type="hidden" name="cmd" value="_s-xclick">
      <input type="hidden" name="hosted_button_id" value="QQ5ZDEN5UXJNY">
      <table>
      <tr><td><input type="hidden" name="on0" value="Buy Coins">Buy Coins</td></tr><tr><td><select name="os0">
        <option value="5000 coins">5000 coins $10.00 USD</option>
        <option value="25000 coins">25000 coins $35.00 USD</option>
        <option value="150000 coins">150000 coins $150.00 USD</option>
      </select> </td></tr>
      </table> -->
      <!-- <input type="hidden" name="currency_code" value="<?php echo $member_id; ?>"> -->
     <!--<input type='hidden' name='notify_url' value='http://online.celpip.biz/member/payment'>
      <input type='hidden' name='cancel_return' value='http://online.celpip.biz/member/cancel'>
      <input type='hidden' name='return' value='http://online.celpip.biz/member/coinManage'>

      <input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_cart_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
      <img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
      </form> 
     --><form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="BAL22RBXVQYKW">
<table>
<tr><td><input type="hidden" name="on0" value="Buy Coins">Buy Coins</td></tr><tr><td><select name="os0">
	<option value="coins 5k">coins 5k $10.00 USD</option>
	<option value="coins 25k">coins 25k $35.00 USD</option>
	<option value="coins 150k">coins 150k $150.00 USD</option>
</select> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>
 
      <!-- actual form with original paypal nettycoons account button -->
     <!-- <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="48R4DNVHHHHR6">
<table>
<tr><td><input type="hidden" name="on0" value="Buy Coins">Buy Coins</td></tr><tr><td><select name="os0">
	<option value="5000 coins">5000 coins $10.00 USD</option>
	<option value="25000 coins">25000 coins $35.00 USD</option>
	<option value="150000 coins">150000 coins $150.00 USD</option>
</select> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>-->

<!-- actual form with original paypal allumez  account button -->

<!--<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="ALCAEMQY34V26">
<table>
<tr><td><input type="hidden" name="on0" value="Buy Coins">Buy Coins</td></tr><tr><td><select name="os0">
	<option value="5000 coins">5000 coins $10.00 USD</option>
	<option value="25000 coins">25000 coins $35.00 USD</option>
	<option value="150000 coins">150000 coins $150.00 USD</option>
</select> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_cart_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>

    --></div> 

    <br><br>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-body">

              <div class="card">
			  <?php if($this->session->flashdata('global_msg')){ ?>
					 <div class="alert alert-success">
					  <button class="close" type="button" data-dismiss="alert">
						<span aria-hidden="true">&times;</span>
					  </button>
					  <?=$this->session->flashdata('global_msg')?>
					</div>
				<?php } ?>
				<div class="table-responsive">
                <table class="table table-hover table-bordered table-stripedx" id="example1">
                  <thead>
                    <tr>
                      <th>S.no.</th>
                      <th>Date</th>
                      <th>Description</th>
                      <th>Credit</th>
                      <th>Debit</th>
                      <th>Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
						$serialno = 0; 
						//echo "<pre>";print_r($history);die;
						foreach ($history as $objHistory) {
						$serialno++;
                    ?>
        					<tr>
        						<td><?php echo $serialno;?></td>
        						<td><?php echo $objHistory->created_date;?></td>
        						<td><?php echo $objHistory->description;?></td>
        						<td><?php echo $objHistory->credit_coin;?></td>
        						<td><?php echo $objHistory->debit_coin;?></td>
        						<td><?php echo $objHistory->balance_coin;?></td>
        					</tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
</body>
</html>
