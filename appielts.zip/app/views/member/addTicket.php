<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add New Ticket
        <small>Ticket details</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add New Ticket</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
            </div>




      


            <!-- /.box-header -->
            <div class="box-body">


                                   <?php if($success) { ?>
                                  <div class="alert alert-success">
                                    Ticket has been added successfully.</br></br>

                                    Have a great day!
                                  </div>
                                  <?php } else { ?>

                                    <?php echo validation_errors(); ?>
                                    
                                    <?php 

                                    //Form syntex echo form_open('form/data_submitted'); 

                                   echo form_open_multipart('member/addTicket', array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>


                                   

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Title</label>
                                                <input type="text" class="form-control" placeholder="Write Ticket title here" name="title" required value="<?php echo set_value('title'); ?>">
                                            </div>
                                        </div>


       
                                  <div class="col-md-6">
                                      <div class="form-group ">
                                      <label >Department</label>
                                      <select class="form-control" name="type" required>
                                      <option value="">Select Department</option>
                                      <option value="Technical">Technical</option>
                                      <option value="Billing">Billing</option>
                                      <option value="General">General query</option>
                                      </select>
                                      </div>
                                  </div>
                              </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Details</label>
                                                <p><textarea class="form-control" placeholder="Please enter details " value="" name="details" required value="<?php echo set_value('details'); ?>" rows="7"></textarea></p>
                                            </div>
                                        </div>
                                    </div>

                                   

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
                                    <div class="clearfix"></div>
                                </form>
                            
                              <?php } ?>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

 
  <?php include_once('common/scripts.php'); ?>
</body>
</html>
