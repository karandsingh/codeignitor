<!doctype html>
<html lang="en">
<head>
    <title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>
</head>
<body>

<div class="wrapper">
    <?php include_once('common/sidebar.php'); ?>

    <div class="main-panel">
        <?php include_once('common/nav.php'); ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">


                            <table class="table table-striped">
                                <tr>
                                  <th>ID</th>
                                  <td><?php echo $user->id; ?></td>
                                </tr>

                                <tr>
                                  <th>Role</th>
                                  <td><span class="online"><?php echo $role->name; ?></span></td>
                                </tr>

                                <tr>
                                  <th>Full Name</th>
                                  <td><?php echo $user->name; ?></td>
                                </tr>

                                <tr>
                                  <th>E-mail</th>
                                  <td><?php echo $user->email; ?></td>
                                </tr>

                                <tr>
                                  <th>Username</th>
                                  <td><?php echo $user->username; ?></td>
                                </tr>

                                <tr>
                                  <th>Mobile</th>
                                  <td><?php echo $user->mobile; ?></td>
                                </tr>

                                <tr>
                                  <th>Street Address</th>
                                  <td><?php echo $user->street_address; ?></td>
                                </tr>

                                <tr>
                                  <th>Postal Code</th>
                                  <td><?php echo $user->postal_code; ?></td>
                                </tr>

                                <?php /*
                                  <tr>
                                    <th>City</th>
                                    <td><?php echo $user->city; ?></td>
                                  </tr>

                                  <tr>
                                    <th>Region</th>
                                    <td><?php echo $user->region; ?></td>
                                  </tr>

                                  <tr>
                                    <th>Country</th>
                                    <td><?php echo $user->country; ?></td>
                                  </tr>
                                */ ?>

                                <tr>
                                  <th>Status</th>
                                  <td>
                                    <?php
                                      if($user->confirm == 'yes') {
                                        $status = '<span class="label label-success">Active</span>';
                                      } else {
                                        $status = '<span class="label label-danger">Inactive</span>';
                                      }
                                      echo $status;
                                    ?>
                                  </td>
                                </tr>  

                            </table>
                              
                        </div>
                    </div>

                </div>

            </div>
        </div>



        <?php include_once('common/footer.php'); ?>
    </div>
</div>


</body>

    <?php include_once('common/scripts.php'); ?>
</html>