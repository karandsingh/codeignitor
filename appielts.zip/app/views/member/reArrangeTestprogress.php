<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>
    <style type="text/css">
      .widget-user .widget-user-header {
        padding: 15px;
        height: 90px;
        border-top-right-radius: 3px;
        border-top-left-radius: 3px;
      }
      #player {

        width: 100%;
      }​
      .clickmediv {
        display: block;padding: 10px;border:#000 1px solid;margin-bottom: 20px;cursor: pointer;
      }
      video::-internal-media-controls-download-button,
      audio::-internal-media-controls-download-button {
        display:none;
      }
    </style>
</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

  <div class="content-wrapper">
    
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
              <div class="box box-widget widget-user">
                <div class="widget-user-header bg-purple">
                  <!--<p>
                    <span class="pull-right" >
                    <a href="<?php echo base_url($currentPath.'/reArrangeTestdetails'); ?>" class="btn btn-danger btn-md"><i class="glyphicon glyphicon-collapse-up "></i> Quit</a></span>
                  </p>-->

                  <h3 class="widget-user-username">
                    <strong><?php echo  $test->name; ?></strong>
                  </h3>
                  <p>Total Questions : <strong><?php echo $total; ?></strong>
                  <span class="pull-right" >
                     <a class="btn btn-danger btn-md rearrange-quit">
                       <i class="glyphicon glyphicon-collapse-up "></i> Quit
                     </a>
                   </span>
                  </p>
                </div>
              </div>
            </div>

            
            <div class="box box-solid">
            <?php //echo "<pre>";print_r($test);?>

              <?php foreach ($allQuestions as $objQuestion) {

                  //$type = $this->my_model->getARecord($this->tb_type, $objQuestion->PTEtypeid);
                  //$subtype = $this->my_model->getARecord($this->tb_subtype, $objQuestion->PTEsubtypeid);

                  //$myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                  //$qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);


                  // check if member already attempt is question
                  $attempted = false;

                  $where = "questionid = '". $objQuestion->id ."' AND memberid = '".$user->id ."' AND testdetail_id = '".$testdetail->id ."' ";
                  $alreadyAttempt = $this->my_model->getWhereOrderRecords('system_reArrange_attempt_code', $where, 'id', 'ASC', true);
                  if( is_object($alreadyAttempt)) {
                    $attempted = true;
                  }


                  // options
                  //$where = "dictation_id = '".$objQuestion->id."' ";
                  //$options = $this->my_model->getWhereOrderRecords('system_dictation_option_code', $where, 'id', 'asc');
				  
				  //echo "<pre>";print_r($options);die;
                ?>

                <div class="box-body mystyle">

                  <div class="alert alert-warning" style="font-size: 18px;">
                    <?php echo $objQuestion->passage; ?>
                  </div>

                  <?php
                    if($attempted) {
                     
                        include('reArrangetestresponse.php');
                    } else {

                  ?>



                    <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                    <hr>
                    
                    <div class="row">
                       
                      <div class="col-md-12">

                        <div class="text-center" id="myloading">
                          <i class="fa fa-spinner fa-spin"></i> Please wait ...
                        </div>

                        <div class="text-center" id="timeblock" style="display: none;">
                          <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                        </div>

                        <div id="contentblock" style="display: none;">
                          <table class="table" style="font-size: 14px;">
						    <?php
								$options = array('1'=>$objQuestion->q1_option1,'2'=>$objQuestion->q1_option2,'3'=>$objQuestion->q1_option3,'4'=>$objQuestion->q1_option4);
							?>
							<?php foreach ($options as $key=>$objOption) { ?>
                              <tr>
                                <td>
                                  <input type="radio" name="my-response" value="<?php echo $key; ?>">
                                  <?php echo $objOption; ?>
                                </td>
                              </tr>
                            <?php } ?>

                            <tr>
                              <td>
                                <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                              </td>
                            </tr>
                          </table>
                        </div>

                        <div class="text-center" id="success-json" style="display: none;"></div>
                      </div>
                    </div>

                  <?php } ?>

                </div>
              <?php } ?>
          </div>
        </div>

        <div class="text-center"><?php echo $pagination; ?></div>

          </div>
        </div>
      </div>
    </section>

  </div>
  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>
  <input type="hidden" name="token-name" id="token-name" value="<?php echo $this->security->get_csrf_token_name(); ?>">
  <input type="hidden" name="token-hash" id="token-hash" value="<?php echo $this->security->get_csrf_hash(); ?>">
  <input type="hidden" name="mid" id="mid" value="<?php echo $user->id; ?>">
  <input type="hidden" name="reporturl" id="reporturl" value="<?php echo $reporturl; ?>">
  <input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($user->id) ?>">
  <input type="hidden" id="testdetail_id" value="<?php echo $testdetail->id; ?>">

  <?php include_once('vmodals.php'); ?>
  
  <?php include_once('common/scripts.php'); ?>

  <script type="text/javascript">
    $(document).ready(function () {

      <?php if(!$attempted) { ?>

        // Run code after 2 seconds,
        // Before this code user will read a message
        setTimeout(function() {
          
          $('#myloading').hide();
          $("#timeblock").delay(1000).fadeIn();
          $("#contentblock").delay(1000).fadeIn();
          mycounter('counter', 60); // Start Time , 300 seconds = 5 minutes (60 x 5)


          setTimeout(function() {
            $('#timeblock').hide();
            $('#submit-answer').hide();
            $('#submit-answer').prop('disabled', true);
            alert('Time is over, Please reload page to attempt question again.');
          }, 300000); // 300 seconds (300 x 1000)


          // submit,
          $('#submit-answer').click(function() {
            console.log('submitted');

            $('#submit-answer').prop('disabled', true);
            $(this).html('Please wait ...');

            // upload user response

            // token protection
            var token_name = $("#token-name").val();
            var token_hash = $("#token-hash").val();
            var mid = $("#mid").val();
            //var testid = $("#testid").val();
            var questionid = $("#questionid").val();
            var subtypeid = $("#subtypeid").val();
            var reporturl = $("#reporturl").val();

            var myresponse = $("input[name='my-response']:checked").val();
            var testdetail_id = $("#testdetail_id").val();

            // console.log(myresponse);

            if(myresponse) {
              var dataString ='myresponse='+myresponse+'&mid='+mid+'&questionid='+questionid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;

              
              var weburl = '<?php echo site_url(); ?>';

              $.ajax({
                type: "POST",
                url: weburl + "member/reArrange_uploadjson/",
                data: dataString,
                cache:false,
                success: function(data) {
                  console.log(data);
                  if( data.result == "success") {
                    console.log('done ...');
                  }

                  $('#myloading').hide();
                  $('#timeblock').hide();
                  $('#contentblock').hide();

                  console.log('Your Response is saved.');
                  $('#success-json').show();
                  $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');

                },
                error : function(data) {
                  console.log(data);
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }
              });
            } else {
              $('#submit-answer').prop('disabled', false);
              $(this).html('Submit');
            }

          });
        }, 2000);

      <?php } ?>


      /*
      * Method to handle counter
      *
      * elementId {string} - id of counter element
      * seconds {integer} - maximum seconds of counter
      */
      function mycounter(elementId, seconds) {

        var counter = seconds;
        setInterval(function() {
          counter--;
          if (counter >= 0) {
            span = document.getElementById(elementId);
            span.innerHTML = counter;
          } else {
            document.getElementById(elementId).style.display = "none";
          }
          // Display 'counter' wherever you want to display it.
          if (counter === 0) {
              clearInterval(counter);
          }
        }, 1000);
      }
    });
  </script>
</body>
</html>
