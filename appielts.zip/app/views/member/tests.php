<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Complete TESTS
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Tests</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <h3 class="box-title"></h3>

                <?php
                  if (!empty($tests)) {
                    $myCounter = 0;
                    foreach ($tests as $key => $test) {
                      $myCounter++;

                      $where = "testid = '".$test->id."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');
                      $total_questions = count($allQuestions);

                      if($total_questions) {

                        $start_btn = '<a href="'.base_url($currentPath.'/testdetails/'.$test->id.'/'.$test->id_md5).'" class="btn btn-block btn-info">START TEST</a>';

                      } else {

                        $start_btn = '<button class="btn btn-block btn-danger" type="button" disabled="disabled">START TEST</button>';
                      }

                      ?>
                      <div class="col-md-4">
                        <div class="box box-widget widget-user">
                          <div class="widget-user-header bg-purplex">
                            <h3 class="widget-user-username"><?php echo $test->test_name; ?></h3>
                            <h5 class="widget-user-desc">
                              <strong>Questions</strong> : <?php echo $total_questions; ?>
                            </h5>
                            <h5 class="widget-user-desc">
                              <strong>Time</strong> : <?php echo $test->total_time; ?>
                            </h5>
                          </div>
                          <div class="box-footer no-padding">
                            <?php echo $start_btn; ?>
                          </div>
                        </div>
                      </div>
                <?php }} ?>

          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
</body>
</html>
