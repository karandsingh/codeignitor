<!DOCTYPE html>
<html>
<head>
	<title>celpip : Canadian English Language Proficiency Index Program</title>
	  <?php include_once('common/head.php'); ?>
<style type="text/css">
  .scrollbar
{
  margin-left: -10px;
  float: left;
  height: 500px;
  width: 100%;
  background: #F5F5F5;
  overflow-y: scroll;
  margin-bottom: 25px;
}
.scrollbar1
{
  margin-left: 10px;
  float: left;
  height: 500px;
  width: 100%;
  background: #F5F5F5;
  overflow-y: scroll;
  margin-bottom: 25px;
}
.force-overflow
{
  min-height: 450px;
}
#wrapper
{
  text-align: left;
  width: 500px;
  margin: auto;
}
p {
  padding: 15px;
}
h2 {
  padding: 15px;
}
@media only screen and (max-width: 600px) {
  .scrollbar1 {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 600px) {
  .scrollbar {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
}
}
.otw-row .b {
border: 1px solid #eee;
padding-top: 5px;
padding-bottom: 5px;
}
</style>
</head>
<body class="inner">
<div class="page-wrapper">
    <div id="page-content">
      <header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip</h1>
              <a href="<?php echo base_url('member/dashboard'); ?>"><!--font size="20px"><strong>CELPIP</strong></font--><img src="images/logo-celpip.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            <?php
				      $attempt_data = json_decode($attempt->json_result, true);
				      //echo "<pre>";print_r($attempt_data);die;
			      ?>
          </div>
        </div>
      </header>

      <div class="page-title-wrapper fixed-width">
        <div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1>
              <?php 
              if($testdetail->test_id==41){
                echo 'Academic Writing Part 1';
              }elseif($testdetail->test_id==42){
                echo 'Academic Writing Part 2';
              }elseif($testdetail->test_id==51){
                echo 'General Writing Part 1';
              }elseif($testdetail->test_id==52){
                echo 'General Writing Part 2';
              }else{
                echo '';
              } ?>
            </h1>
            
          </div>
        </div>

       
      </div>
            
      <!---Writing Report--> 

      <?php if($testdetail->test_id==41){ 
      //echo "<pre>";print_r($attempt);
    ?>  
    <!-- <div class="col-md-12">
      <a href="<?php echo base_url("member/reviewQuestions/47"); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Go back</a>
    </div>
    <br><br> -->
    <div class="otw-row" style="margin-bottom: -80px;">

        <div class="otw-ten otw-columns">
          <div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
          
 <p>1. <?php echo $test->q1_question; ?> </p>
				    <img src="<?php echo base_url('uploads/part4_SAWPA/').$test->q1_image; ?>"></p>
			            <hr>
            <div class="row">
              
              <div class="col-md-12">
                <div class="form-group">
                  <label>Marks</label>
                  <?php echo $marksAssigned[0]->marks; ?>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Remarks</label>
                 <?php echo $marksAssigned[0]->remarks; ?>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  Marks assigned by : <label class="label label-success"><?php echo $teacher_name->name; ?></label>
                </div>
              </div>
              
            </div>
          </div>

          <div class="otw-sc-hr"></div>
        </div>

        <div class="otw-thirteen otw-columns">
          <div id="wrapper">
            <div class="scrollbar1" id="style-default">
              <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">
              <form>
              <table>
                <div>
                </div>
                <div>
                <hr>
                  <p>
                    <label><b>Student Answer</b></label>
                    <div style="white-space: pre-line;margin-top: -40px;">
                      <?php 
                      foreach ($attempt_data['response_data'] as $key => $attemptArray) { 
                        echo $attemptArray['q_response_email_content'];
                      } 
                      ?>
                      </div>
                  </p>
                  <p>
                </div>
              </table>
            </form>
          </div>
        </div>
      </div>
      <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==42){ ?>  

    <div class="otw-row" style="margin-bottom: -80px;">
      <div class="otw-ten otw-columns">
        <div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
          <h2>Read the following information. </h2>
          <p>1. <?php echo $test->passage; ?> </p>
				    		 <p>1. <?php echo $test->q1_question; ?> </p>
				              <hr>
          <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label>Marks</label>
                  <?php echo $marksAssigned[0]->marks; ?>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Remarks</label>
                 <?php echo $marksAssigned[0]->remarks; ?>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  Marks assigned by : <label class="label label-success"><?php echo $teacher_name->name; ?></label>
                </div>
              </div>
            </div>
        </div>

        <div class="otw-sc-hr"></div>
      </div>
      <div class="otw-thirteen otw-columns">
        <div id="wrapper">
          <div class="scrollbar1" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">

              <hr>
              <div id="area">
                <label><b>Student Answer</b></label><br>
                     <div style="white-space: pre-line;margin-top: -10px;">
                      <?php 
                      foreach ($attempt_data['response_data'] as $key => $attemptArray) { 
                        echo $attemptArray['q_response_email_content'];
                     $wordCountt = str_word_count(trim($attemptArray['q_response_email_content']));
                      } 
                      ?>
					  
					  <br><br>
					  <span>Total <?php echo $wordCountt; ?></span> words
              </div>
            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>

<?php if($testdetail->test_id==51){ 
      //echo "<pre>";print_r($attempt);
    ?>  
    <!-- <div class="col-md-12">
      <a href="<?php echo base_url("member/reviewQuestions/47"); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Go back</a>
    </div>
    <br><br> -->
    <div class="otw-row" style="margin-bottom: -80px;">

        <div class="otw-ten otw-columns">
          <div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
          	    		 <p>1. <?php echo $test->passage; ?> </p>
				    		 <p>1. <?php echo $test->q1_question; ?> </p>
				</b>    		 <p>1. <?php echo $test->instruction; ?> </p>

				            <hr>
            <div class="row">
              
              <div class="col-md-12">
                <div class="form-group">
                  <label>Marks</label>
                  <?php echo $marksAssigned[0]->marks; ?>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Remarks</label>
                 <?php echo $marksAssigned[0]->remarks; ?>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  Marks assigned by : <label class="label label-success"><?php echo $teacher_name->name; ?></label>
                </div>
              </div>
              
            </div>
          </div>

          <div class="otw-sc-hr"></div>
        </div>

        <div class="otw-thirteen otw-columns">
          <div id="wrapper">
            <div class="scrollbar1" id="style-default">
              <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">
              <form>
              <table>
                <div>
                </div>
                <div>
                <hr>
                  <p>
                    <label><b>Student Answer</b></label>
                    <div style="white-space: pre-line;margin-top: -40px;">
                      <?php 
                      foreach ($attempt_data['response_data'] as $key => $attemptArray) { 
                        echo $attemptArray['q_response_email_content'];
                      } 
                      ?>
                      </div>
                  </p>
                  <p>
                </div>
              </table>
            </form>
          </div>
        </div>
      </div>
      <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    
    <?php if($testdetail->test_id==52){ ?>  

    <div class="otw-row" style="margin-bottom: -80px;">
      <div class="otw-ten otw-columns">
        <div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
          <h2>Read the following information. </h2>
         	 <p>1. <?php echo $test->passage; ?> </p>
				    		 <p>1. <?php echo $test->q1_question; ?> </p>
				              <hr>
          <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label>Marks</label>
                  <?php echo $marksAssigned[0]->marks; ?>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Remarks</label>
                 <?php echo $marksAssigned[0]->remarks; ?>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  Marks assigned by : <label class="label label-success"><?php echo $teacher_name->name; ?></label>
                </div>
              </div>
            </div>
        </div>

        <div class="otw-sc-hr"></div>
      </div>
      <div class="otw-thirteen otw-columns">
        <div id="wrapper">
          <div class="scrollbar1" id="style-default">
            <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">

              <hr>
              <div id="area">
                <label><b>Student Answer</b></label><br>
                     <div style="white-space: pre-line;margin-top: -10px;">
                      <?php 
                      foreach ($attempt_data['response_data'] as $key => $attemptArray) { 
                        echo $attemptArray['q_response_email_content'];
                     $wordCountt = str_word_count(trim($attemptArray['q_response_email_content']));
                      } 
                      ?>
					  
					  <br><br>
					  <span>Total <?php echo $wordCountt; ?></span> words
              </div>
            </div>
          </div>
        </div>
        <div class="otw-sc-hr"></div>
      </div>
    </div>
    <?php } ?>
    </div>

     <footer id="page-footer">
      
      <div class="otw-row copyright">
        <div class="otw-twelve otw-columns">
          
        </div>
        <div class="otw-twelve otw-columns text-right">
          <a href="#">       &copy; 2020 All rights reserved.
        </div>
      </div>
    </footer>
</div>
</body>
</html>