<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        SUPPORT
        <small>View Tickets</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Support</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
            </div>

                      <?php if (@$_GET['trash']) { ?>
                      <div class="alert alert-success">
                      <button class="close" type="button" data-dismiss="alert">
                      <span aria-hidden="true">&times;</span>
                      </button>
                      Ticket information deleted.
                      </div>
                      <?php } ?>



                      <?php if (@$_GET['close']) { ?>
                      <div class="alert alert-success">
                      <button class="close" type="button" data-dismiss="alert">
                      <span aria-hidden="true">&times;</span>
                      </button>
                      Ticket successfuly closed.
                      </div>
                      <?php } ?>
      


            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                      <thead>
                                 <tr>
                                  <th>Ticket Id</th>
                                  <th>Ticket</th>
                                  <th>Type</th>
                                  <th>Date</th>
                                  <th>Status</th>
                                  <th>Action</th>
                                </tr>
                              </thead>

                              <tbody>

     

                         <?php
                         


                if (!empty($supports)) {
                foreach ($supports as $key => $support) { ?>

                  <?php if($support->status=="open"){$tstatus='<span class="label label-success">Open</span>';}else{
                    $tstatus='<span class="label label-info">Resoloved</span>';
                  }
                  ?>

                     <tr>
                          <td><span class="online"><?=$support->id?></span></td>
                          <td><span class="online"><?=$support->title?></span></td>
                          <td><span class="online"><?=$support->type?></span></td>
                          <td><span class="online"><?=date("d-m-Y",$support->time)?></span></td>
                          <td><?=$tstatus?></td>



                      <td>


                    
                      <a href="<?php echo base_url($currentPath.'/ticket/'.$support->id); ?>" class="btn btn-default btn-xs btn-info" title="Ticket details" data-toggle="tooltip"><i class="fa fa-eye"></i></a>

                    <!--   <?php $_onClick = "onclick=\"return confirm('Are you sure you want to delete ".$support->title." ? This action will delete all data.')\"";?>
                      <a href="<?php echo base_url($currentPath.'/deleteTicket/'.$support->id); ?>" class="btn btn-default btn-xs btn-danger" title="Delete" <?php echo $_onClick; ?> data-toggle="tooltip" data-placement="left"><i class="fa fa-trash-o"></i> </a> -->
                      
                    </td>

                         
                        </tr>


                <?php }} ?>
     


                          </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

 
  <?php include_once('common/scripts.php'); ?>
</body>
</html>
