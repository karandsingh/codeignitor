
          <?php if($subtype->id == '20') { ?>

            // Run code after 10 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              $(".my_audio").trigger('play'); // already loaded, just play audio

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                var myresponse = $("input[name='my-response']:checked").val();

                // console.log(myresponse);

                if(myresponse) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 10000);
          <?php } ?>