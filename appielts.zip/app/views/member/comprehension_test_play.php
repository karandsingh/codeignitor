<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
  <style type="text/css">
    .widget-user .widget-user-header {
      padding: 15px;
      height: 90px;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
    }
    @media only screen and (max-width: 600px) {
  .scrollbar1 {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 600px) {
  .scrollbar {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
}
}
@media only screen and (max-width: 600px) {
.page-title-wrapper {
  margin-bottom: 30px !important;
  border-top: 1px solid #fff;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  -ms-border-radius: 3px;
  -o-border-radius: 3px;
  border-radius: 3px;
  margin-top: 100px !important;
  margin-left: 10px !important;
  margin-right: 10px !important;
}
}
.radio-gap {
    margin-top: 35px;
}
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="page-wrapper">
    <div id="page-content">
		<header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip</h1>
              <a href="<?php echo base_url('member/dashboard'); ?>"><!--font size="20px"><strong>CELPIP</strong></font--><img src="images/logo-celpip.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            
          </div>
        </div>
      </header>

	  <div class="page-title-wrapper fixed-width">
	    <div style="background-color: #9700ad;float: right;padding: 11px;margin-top: -50px;margin-right: 51px;">	
        <a style="color: #fff;" class="comprehension-quit">Quit</a>
        </div>
        <div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1>Comprehension Test
			</h1>
            
          </div>
          <div class="otw-five otw-columns">
           
          </div>
        </div>
       
      </div>


      </div>
      <div class="otw-row main-content">
        <div class="otw-twentyfour otw-columns otw-content-section">
			<?php if($test){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-ten otw-columns">
				<div id="wrapper">
					<div class="scrollbar" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
							<h2>Read the following message. </h2>
							<p><?php echo $test->comprehension_passage; ?></p>

						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
			<div class="otw-thirteen otw-columns">
				<div id="wrapper">
					<div class="scrollbar1" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
							<h2> Using the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>), choose the best option according to the information given in the message.</h2>
							<form>
								<table>
									<div>&nbsp;&nbsp;<?php echo $test->q1_question; ?>
										<select type="drop-down" style="width: 150px;" class="q1-sel-opt searchform" name="q1-response">
											<option value=""></option>
											<option value="q1_option1"><?php echo $test->q1_option1; ?></option>
											<option value="q1_option2"><?php echo $test->q1_option2; ?></option>
											<option value="q1_option3"><?php echo $test->q1_option3; ?></option>
											<option value="q1_option4"><?php echo $test->q1_option4; ?></option>
										</select>
										<span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
									<div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q2_question; ?>
										<select type="drop-down" style="width: 140px;" class="q2-sel-opt searchform" name="q2-response">
											<option value=""></option>
											<option value="q2_option1"><?php echo $test->q2_option1; ?></option>
											<option value="q2_option2"><?php echo $test->q2_option2; ?></option>
											<option value="q2_option3"><?php echo $test->q2_option3; ?></option>
											<option value="q2_option4"><?php echo $test->q2_option4; ?></option>
										</select>
										<span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
									<div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q3_question; ?>
										<select type="drop-down" style="width: 150px;" class="q3-sel-opt searchform" name="q3-response">
											<option value=""></option>
											<option value="q3_option1"><?php echo $test->q3_option1; ?></option>
											<option value="q3_option2"><?php echo $test->q3_option2; ?></option>
											<option value="q3_option3"><?php echo $test->q3_option3; ?></option>
											<option value="q3_option4"><?php echo $test->q3_option4; ?></option>
										</select>
										<span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
									<div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q4_question; ?>
										<select type="drop-down" style="width: 150px;" class="q4-sel-opt searchform" name="q4-response">
											<option value=""></option>
											<option value="q4_option1"><?php echo $test->q4_option1; ?></option>
											<option value="q4_option2"><?php echo $test->q4_option2; ?></option>
											<option value="q4_option3"><?php echo $test->q4_option3; ?></option>
											<option value="q4_option4"><?php echo $test->q4_option4; ?></option>
										</select>
										<span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
									<div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q5_question; ?>
										<select type="drop-down" style="width: 150px;" class="q5-sel-opt searchform" name="q5-response">
											<option value=""></option>
											<option value="q5_option1"><?php echo $test->q5_option1; ?></option>
											<option value="q5_option2"><?php echo $test->q5_option2; ?></option>
											<option value="q5_option3"><?php echo $test->q5_option3; ?></option>
											<option value="q5_option4"><?php echo $test->q5_option4; ?></option>
										</select>
										<span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
								</table>
							</form>
						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		<input type="hidden" name="token" value="<?php echo $this->uri->segment(3); ?>"/>
       <div class="page-title-wrapper fixed-width">
        <div class="otw-row page-title">
            <div class="otw-ten otw-columns"></div>		
        <div class="otw-four otw-columns">
			<a href="javascript:void(0);" style="color:#fff" class="comprehension_submit_btn"><div class="submit" align="center">Submit</div></a>
		</div>
        <div class="otw-ten otw-columns"></div>
          <!--<div class="otw-nineteen otw-columns">-->
           
                <!--input type="submit" title="Answer Key" name="submit" value="Answer Key"-->
            
          <!--</div>-->
         <!-- <div class="otw-five otw-columns">-->
            <!--<form action="#" method="get" role="search" class="searchform">
                <input type="submit" title="Back" name="submit" value="Back">
            </form>-->
          <!--</div>-->
        </div>
        
      </div>
    </div>
      </div>

    </div>

     <footer id="page-footer">
      
      <div class="otw-row copyright">
        <div class="otw-twelve otw-columns">
          
        </div>
        <div class="otw-twelve otw-columns text-right">
          <a href="#"><!--img src="images/logo-celpip-footer.png" title="celpip" alt=""/--></a>
           &copy; 2018-2019 All rights reserved.
        </div>
      </div>
    </footer>
  </div>
<script type="text/javascript">
	function show() { document.getElementById('area').style.display = 'block'; }
	function hide() { document.getElementById('area').style.display = 'none'; }
</script>
  
  <?php include_once('vmodals.php'); ?>
  
  <?php include_once('common/scripts.php'); ?>
  
  
<?php if($testdetail->test_id==59 || $testdetail->test_id==58 || $testdetail->test_id==57 || $testdetail->test_id==56 || $testdetail->test_id==55 || $testdetail->test_id==54 || $testdetail->test_id==53 || $testdetail->test_id==52 || $testdetail->test_id==51){ ?>

<?php if($testdetail->test_id==58){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 90;
</script>
<?php } ?>

<?php if($testdetail->test_id==57){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==56){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==55){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==54){?>
<script type="text/javascript">
	var preparationTime = 60;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==53){?>
<script type="text/javascript">
	var preparationTime = 60;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==52){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 90;
</script>
<?php } ?>

<?php if($testdetail->test_id==51){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==59){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>
<script src="../../uploads/mic/js/justmicrec_lib.js"></script>
<script type="text/javascript">
        $(document).ready(function () {
			var weburl = '<?php echo site_url(); ?>';
			//alert(recordingTime);

            // INITIALIZATION
            //$('#recn').val(new Date().getTime()); // unique id

              justMicRec.configure({
                //hostPath : '../../uploads/mic/micrecajax.php?f=' + $('#recn').val(),
				hostPath : '/micrecajax.php?f=' + $('#recn').val(),
                workerPath: '../../uploads/mic/js/justmicrecworker.js',

                // Callback functions
                recordingActivity: function(analyserNode, seconds) { activity(analyserNode, seconds); },
                recordingError: function(e) { console.log('[ERR] ' + e) },
                //recordingStopped: recordingStopped,
                WAVsendingFinished: sendingFinished,
                uploadingProcess: function(current, total){
                        uploading(Math.round(current / total * 100)); }
              });
			  
			  function sendingFinished()
              {
                console.log('!! Recording has been sent to server successfully!');
                // DONE :- save attempt row
                
                var fname = $("#recn").val()+'.wav';
				$(".response_file").html('<input type="hidden" id="sp_response_file" value="'+fname+'"/><audio controls><source src="'+ weburl +'uploads/attempt/'+fname+'" type="audio/mpeg"></audio>');
				$("#success-recording").hide();
                // change unique id and reconfigure path to new wav file
                //$('#recn').val(new Date().getTime());
                /* justMicRec.configure({
                  //hostPath : '../../uploads/mic/micrecajax.php?f=' + $('#recn').val()
                  hostPath : '/micrecajax.php?f=' + $('#recn').val()
                }); */
              }

              var canvas = document.getElementById('levelbar'),
                  canvasWidth = canvas.width,
                  canvasHeight = canvas.height,
                  analyserContext = canvas.getContext('2d');


              // analyserNode - node to recording data, time - seconds
              function activity(analyserNode, time)
              {
                // maxTime - global var
                // var time = maxTime - time;
                if (time < 0) time = 0;
                var min = Math.floor(time / 60),
                    sec = Math.floor(time % 60);

                $('#time').text((min < 10 ? "0" : "") + min + ":" + (sec < 10 ? "0" : "") + sec);
                
                // $('#level').text(level);

                updateAnalysers(analyserNode);
                updateAnalysers2(analyserNode); // second variant
              }

              function uploading(percent)
              {
                $('#levelbar2').width(percent + '%');
              }

              function updateAnalysers(analyserNode) {
                var SPACING = 3,
                    BAR_WIDTH = 1,
                    numBars = Math.round(canvasWidth / SPACING),
                    freqByteData = new Uint8Array(analyserNode.frequencyBinCount);

                analyserNode.getByteFrequencyData(freqByteData); 

                analyserContext.clearRect(0, 0, canvasWidth, canvasHeight);
                analyserContext.fillStyle = '#F6D565';
                analyserContext.lineCap = 'round';
                var multiplier = analyserNode.frequencyBinCount / numBars;

                  // Draw rectangle for each frequency bin.
                  for (var i = 0; i < numBars; ++i) {
                  var magnitude = 0;
                  var offset = Math.floor( i * multiplier );
                  // gotta sum/average the block, or we miss narrow-bandwidth spikes
                  for (var j = 0; j < multiplier; j++)
                     magnitude += freqByteData[offset + j];
                  magnitude = magnitude / multiplier;
                  var magnitude2 = freqByteData[i * multiplier];
                  analyserContext.fillStyle = "hsl( " + Math.round((i*360)/numBars) + ", 100%, 50%)";
                  analyserContext.fillRect(i * SPACING, canvasHeight, BAR_WIDTH, -magnitude);
                  }
              }

              function updateAnalysers2(analyserNode) {
                // OLED 
                var array = new Uint8Array(analyserNode.frequencyBinCount);
                analyserNode.getByteFrequencyData(array);
                var values = 0;

                var length = array.length;
                for (var i = 0; i < length; i++) {
                  values += array[i];
                }

                var average = values / length;
                $('#levelbar2').width(Math.min(parseInt(average * 2), 100) + '%');
              }
		});
		
	</script>
	
	  <script type="text/javascript">
		var audio_data;
        window.onload = function init() {
          try  {
            // Webkit shim
            window.AudioContext = window.AudioContext || window.webkitAudioContext;
            navigator.getUserMedia = ( navigator.getUserMedia ||
                             navigator.webkitGetUserMedia ||
                             navigator.mozGetUserMedia ||
                             navigator.msGetUserMedia);
            window.URL = window.URL || window.webkitURL;
            
            audio_data = new AudioContext;
            console.log('Audio context set up.');
            console.log('navigator.getUserMedia ' + (navigator.getUserMedia ? 'available.' : 'not present!'));
          
          } catch (e) {
            //alert('No web audio support in this browser!');
          }
          
          navigator.getUserMedia({audio: true}, initUserMedia, function(e) {
            console.log('No live audio input: ' + e);
            //alert('Your browser does not support the audio.');
          });
        };

        function initUserMedia(stream) {
          var input = audio_data.createMediaStreamSource(stream);
          //console.log('Media stream created.' );
          //console.log("input sample rate " +input.context.sampleRate);

          input.connect(audio_data.destination);
          console.log('Input connected to audio context destination.');

          $("#recordButton").removeClass("recordOff").addClass("recordOn");
          $("#recordHelp").fadeOut("slow");
          console.log('Recorder initialised.');
        }
	  
    $(document).ready(function () {
			setTimeout(function() {

			  // Check if browser support audio
			  if($('#recordButton').hasClass('recordOn')) {
				  
				$("#recording-message").show(); // Show recording alert
				mycounter('count', preparationTime); // Handle counter
				$("#recording-message").delay(preparationTime+'000').fadeOut(); // Hide message after 40s
				var playerTime = parseInt(preparationTime+'000') + parseInt(1000);
				//alert(playerTime);
				// Show the player after 41s
				// Start recording after 41s, for 40 seconds
				$("#player-block").delay(playerTime).fadeIn();

				setTimeout(function() {

				  // Show buffer message
				  $("#buffermsg").show();

				  setTimeout(function() { // 5 second buffer before recording

					// Hide buffer message
					$("#buffermsg").hide();
					var recordwaitInervaltime = parseInt(recordingTime+'000') + parseInt(1000);
					var maxTime = recordingTime;
					mycounter('countresult', maxTime); // Start Time
					//startRecording();
					//alert(recordwaitInervaltime);
					console.log('*log: recording started (' + maxTime + ')');
					justMicRec.start(maxTime);

					setTimeout(function() {
					  // stop recording
					  // hide player block
					  // show success recording block
					  //stopRecording();
					  console.log('log: recording stopped');
					  $('#level').text('');
					  justMicRec.sendWAV();

					  $("#player-block").hide();
					  $("#success-recording").show();

					}, recordwaitInervaltime);

				  }, 5000);

				}, playerTime);



			  } else {

				// Show message to user , that your browser not support audio
				$("#audio-block").delay(1000).fadeIn();
			  }

		}, 2000);
		
		function mycounter(elementId, seconds) {

			var counter = seconds;
			setInterval(function() {
			  counter--;
			  if (counter >= 0) {
				span = document.getElementById(elementId);
				span.innerHTML = counter;
			  } else {
				document.getElementById(elementId).style.display = "none";
			  }
			  // Display 'counter' wherever you want to display it.
			  if (counter === 0) {
				  clearInterval(counter);
			  }
			}, 1000);
        }
	});
</script>
<?php } ?>
</body>
</html>