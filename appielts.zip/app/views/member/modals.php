<div id="instructions" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">

        <div class="box box-solid">
          <div class="box-body">

            <div class="alert alert-warning alert-dismissible" >
              <i class="glyphicon glyphicon-warning-sign"></i>
              Please Read all instructions carefully before you begin . 
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>

            <h3>Speaking</h3>
            <ul>
              <li>The Speaking section mainly timed between 35 to 50 minutes &amp; each question is timed Separately.</li>
              <li>In the Real test of Pearson (PTE Academic), Test taker should face Personal Introduction which is without scores. In our test, there is no Personal Introduction section.</li>
              <li>Before attempting the tests, one must ensure that headset with microphone is functioning properly.</li>
            </ul>

            <h3>Reading</h3>
            <ul>
              <li>Reading section is of 32-41 minutes duration. So, target your answers under the given time.</li>
              <li>Every instruction pertaining to set of questions must be read carefully and answer as expected. There are 5 types of questions and instructions for all vary.</li>
              <li>You will only find the result , if you "SUBMIT TEST" at the end of reading section.</li>
              <li>Before submitting the test in the end, any answer can be changed any number of times. There is a secondary option of "SAVE &amp; EXIT".</li>
            </ul>

            <h3>Writing</h3>
            <ul>
              <li>In the Writing task, the answer has to strictly stick to the given word limit.It consists of 40 minute.</li>
              <li>Two Summary of 10-10 minutes and 1 Essay of 20 minutes or 2 Essay of 20-20 minutes and 1 summary of 10 Minutes.</li>
            </ul>

            <h3>Listening</h3>
            <ul>
              <li>The Listening section is of 40 minutes duration. The section comprises some purely listening assignments whereas, some integrated assignments that involve speaking and listening.</li>
              <li>PTE test of English is a time bound test ,so target your answers under the given time.</li>
              <li>There is no re-recording or re-listening of the audio facility, hence complete concentration must be practiced. One can take notes while listening to the audio and for each question there is a facility of volume adjustment.</li>
            </ul>
          </div>
        </div>

        <div class="text-center">
          <button type="button" class="btn btn-primary" id="test-submit" data-testid="<?php echo $test->id; ?>" data-memberid="<?php echo $user->id; ?>">Start Test Now</button>
        </div>

      </div>
    </div>
  </div>
</div>