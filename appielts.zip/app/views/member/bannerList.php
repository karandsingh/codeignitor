<!DOCTYPE html>
<html>
<head>
    <title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>
<style>
    img, .school-banner {
    max-width: 100%;
    height: 90px;
}
</style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

 
    <?php include_once('common/nav.php'); ?>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">


    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Banners 
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Banners</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
           <h3 style="margin-left: 15px;"><b>Banners</b></h3>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="info-box">
              
			<?php
			 foreach($banner_data as $banner_list)
			 {
			  ?>
			  <a rel="nofollow" href="<?php echo $banner_list->banner_url; ?>"><img class="school-banner" src="<?php echo $banner_list->banner_img_first; ?>" width="100%" height="150"></a>
			  <br><br>
			  <a rel="nofollow" href="<?php echo $banner_list->banner_url; ?>"><img class="school-banner" src="<?php echo $banner_list->banner_img_second; ?>" width="100%" height="150"></a>
			  <?php
			 }
			?>
          </div>
          <!-- /.info-box -->
        </div>
      </div>
	


    </section>
  </div>

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

   <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>



</div>
<!-- ./wrapper -->

  <?php include_once('common/scripts.php'); ?>
</body>
</html>
