<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

        <style type="text/css">
    .widget-user .widget-user-header {
    padding: 15px;
    height: 90px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
}
  </style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> Details 
        <small> To Improve Your Skills</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
		<?php if($this->session->flashdata('global_msg')){ ?>
			 <div class="alert alert-success">
			  <button class="close" type="button" data-dismiss="alert">
				<span aria-hidden="true">&times;</span>
			  </button>
			  <?=$this->session->flashdata('global_msg')?>
			</div>
		<?php } ?>

        <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
          <strong>NOTE : </strong>
          If you are new to take this test please Click on <strong>Start it </strong> button to start new test.
        </div>
         
          <div class="box">

            <div class="box-body">

			  	<?php //echo "<pre>hiih";print_r($tests);die; ?>
				<div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Test Number</th>
                      <th>Start</th>
                    </tr>
                  </thead>
                  <tbody>
				    <?php foreach($tests as $test){?>
            <tr>
              <td>
                <?php echo $test->id; ?>
              </td>
              <td>Test <?php echo $test->id; ?></td>
						<td> 
						<?php /*<button type="button" class="btn btn-danger allow-comprehension-test-submit" data-testid="<?php echo $test->id; ?>" data-memberid="<?php echo $member_id; ?>"><i class="fa fa-hand-o-right"></i> Start It</button> */ ?>
						
						<?php
                        $where="member_id = '$member_id' AND test_id = '$test->id' AND is_attempt = '1'";
                        $getData = $this->my_model->getWhereLastRecords('system_comprehension_testdetails_code',$where);
                         //print_r($getData);
                        if(!empty($getData)){  
                        if($getData->test_check_status == '1') { ?>
            			<button type="button" class="btn btn-danger allow-comprehension-test-submit" data-testid="<?php echo $test->id; ?>" data-memberid="<?php echo $member_id; ?>"><i class="fa fa-hand-o-right"></i>Start It</button>
                          <?php 
                            $report_link = base_url('member/viewComprehensionReport/').$getData->id_md5;
                          ?>

                          <a class="btn btn-danger"style="color:#fff;" href="<?php echo $report_link; ?>"><i class="fa fa-hand-o-right"></i>  View Report

                        <?php }else{ ?>
                          <button type="button" class="btn btn-danger"> Reviewing</button>
                        <?php } ?>
                        <?php }else{ ?>
                          <button type="button" class="btn btn-danger allow-comprehension-test-submit" data-testid="<?php echo $test->id; ?>" data-memberid="<?php echo $member_id; ?>"><i class="fa fa-hand-o-right"></i>Start It</button>
                        <?php } ?>
						
						</td>
                      </tr> 
					<?php } ?>

                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
  <?php include_once('parts_modals.php'); ?>
</body>
</html>
