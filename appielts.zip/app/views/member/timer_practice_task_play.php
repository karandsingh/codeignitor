<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
  <style type="text/css">
    .widget-user .widget-user-header {
      padding: 15px;
      height: 90px;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
    }
    @media only screen and (max-width: 600px) {
  .scrollbar1 {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 65%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 600px) {
  .scrollbar {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
}
}
@media only screen and (max-width: 600px) {
.page-title-wrapper {
  margin-bottom: 30px !important;
  border-top: 1px solid #fff;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  -ms-border-radius: 3px;
  -o-border-radius: 3px;
  border-radius: 3px;
  margin-top: 100px !important;
  margin-left: 10px !important;
  margin-right: 10px !important;
}
}
.radio-gap {
    margin-top: 35px;
}
@media only screen and (max-width: 600px) {
.image_size {
        width: 100% !important;
        margin-top: 15px;
        margin-bottom: 15px;
    }}
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="page-wrapper">
    <div id="page-content">
		<header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip</h1>
              <a href="<?php echo base_url('member/dashboard'); ?>"><!--font size="20px"><strong>CELPIP</strong></font--><img src="images/logo-celpip.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            
          </div>
        </div>
      </header>

	  <div class="page-title-wrapper fixed-width">
        <div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1><?php 
				if($testdetail->test_id==20){
					echo 'Listening Part 1: Listening to Problem Solving';
				}elseif($testdetail->test_id==29){
					echo 'Listening Practice Task Questions:';
				}elseif($testdetail->test_id==19){
					echo 'Listening Part 2: Listening to Daily Life Conversation:';
				}elseif($testdetail->test_id==18){
					echo 'Listening Part 3: Listening for Information:';
				}elseif($testdetail->test_id==17){
					echo 'Listening Part 4: Listening to a News Item';
				}elseif($testdetail->test_id==16){
					echo 'Listening Part 5: Listening to a Discussion';
				}elseif($testdetail->test_id==15){
					echo 'Listening Part 6: Listening to Viewpoints';
				}elseif($testdetail->test_id==47){
					echo 'Writing Task 1: Writing an Email Details';
				}elseif($testdetail->test_id==46){
					echo 'Writing Task 2: Responding to Survey Questions';
				}elseif($testdetail->test_id==59){
					echo 'Speaking: Practice Task';
				}elseif($testdetail->test_id==58){
					echo 'Speaking Task 1: Giving Advice ';
				}elseif($testdetail->test_id==57){
					echo 'Speaking Task 2: Talking about a Personal Experience';
				}elseif($testdetail->test_id==56){
					echo 'Speaking Task 3: Describing a Scene';
				}elseif($testdetail->test_id==55){
					echo 'Speaking Task 4: Making Predictions';
				}elseif($testdetail->test_id==54){
					echo 'Speaking Task 5: Comparing and Persuading';
				}elseif($testdetail->test_id==53){
					echo 'Speaking Task 6: Dealing with a Difficult Situation';
				}elseif($testdetail->test_id==52){
					echo 'Speaking Task 7: Expressing Opinions';
				}elseif($testdetail->test_id==51){
					echo 'Speaking Task 8: Describing an Unusual Situation';
				}elseif($testdetail->test_id==40){
					echo 'Reading Practice Task';
				}elseif($testdetail->test_id==39){
					echo 'Reading Part 1: Reading Correspondence';
				}elseif($testdetail->test_id==38){
					echo 'Reading Part 2: Reading to Apply a Diagram';
				}elseif($testdetail->test_id==37){
					echo 'Reading Part 3: Reading for Information';
				}elseif($testdetail->test_id==36){
					echo 'Reading Part 4: Reading for Viewpoints';
				}else{
					echo '';
				} ?>
			</h1>
            
          </div>
          <div class="otw-five otw-columns">
		    <?php if($testdetail->test_id==29){ ?>
				<div id="timer_div" style="color:#fff"></div>	
			<?php } ?>
			<?php if($testdetail->test_id==20){ ?>
				<div id="timer_div" style="color:#fff"></div>	
			<?php } ?>
          </div>
        </div>
       
      </div>
	  
      <!--header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip Practice Test</h1>
              <a href="<?php //echo base_url(); ?>"><img src="images/logo-celpip.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            
          </div>
        </div>
      </header-->

      
        <?php /*<div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1><?php 
				if($testdetail->test_id==20){
					echo 'Part 1: Listening to Problem Solving';
				}elseif($testdetail->test_id==29){
					echo 'Listening Practice Task Questions:';
				}elseif($testdetail->test_id==19){
					echo 'Part 2: Listening to Daily Life Conversation:';
				}elseif($testdetail->test_id==18){
					echo 'Part 3: Listening for Information:';
				}elseif($testdetail->test_id==17){
					echo 'Part 4: Listening to a News Item';
				}else{
					echo '';
				} ?>
			</h1>
          </div>
          <div class="otw-five otw-columns">
            <form name="submit_ptest" enctype="multipart/form-data" id="submit_ptest" action="<?php echo base_url('member/PracticeTaskSubmit')?>" method="get" class="searchform">
                <!--button type="button" class="btn btn-danger"><i class="fa fa-hand-o-right"></i>Submit</button-->
				
				<?php if($testdetail->test_id==29){ ?>
                <input type="submit" title="Next" name="submit" value="Submit">
				<?php } ?>
				
				<?php if($testdetail->test_id==20){ ?>
					<button type="button" class="btn ls1_next_btn" data-screenid="2">Next</button>
				<?php } ?>
				
				<?php if($testdetail->test_id==19){ ?>
					<button type="button" class="btn ls2_next_btn" data-screenid="2">Next</button>
				<?php } ?>
				
				<?php if($testdetail->test_id==18){ ?>
					<button type="button" class="btn ls3_next_btn" data-screenid="2">Next</button>
				<?php } ?>
				
				<?php if($testdetail->test_id==17){ ?>
					<button type="button" class="btn ls4_next_btn" data-screenid="2">Next</button>
				<?php } ?>
            
          </div>
        </div>*/ ?>

      </div>
      <div class="otw-row main-content">
        <div class="otw-twentyfour otw-columns otw-content-section">
		<?php if($testdetail->test_id==29){ ?>
          <div class="otw-row">
            <div class="otw-ten otw-columns">
                <div class="border-sec">
              <h2> Listen to a short statement. In actual test You will hear it only once.</h2>
              <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
               <p align="center">
               <audio controls>
                   <source src="<?php echo base_url(); ?>uploads/listening_practiceTask/<?php echo $test->mp3URL;?>" type="audio/ogg">
                    <source src="<?php echo base_url(); ?>uploads/listening_practiceTask/<?php echo $test->mp3URL;?>" type="audio/mpeg">
               </audio></p>
               <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
               <p align="center">This playbar will not appear in the official test.</p></div>
              <div class="otw-sc-hr"></div>
              <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
            </div></div>
             <div class="otw-thirteen otw-columns">
              <h2> Choose the sentence that is closest in meaning to the statement.</h2>
              
                <table>
                  <div><input type="radio" checked name="q1-response" value="option1">&nbsp;&nbsp;&nbsp;<?php echo $test->option1;?></div><br>
                  <div><input type="radio" name="q1-response" value="option2">&nbsp;&nbsp;&nbsp;<?php echo $test->option2;?></div><Br>
                  <div><input type="radio" name="q1-response" value="option3">&nbsp;&nbsp;&nbsp;<?php echo $test->option3;?></div><Br>
                  <div><input type="radio" name="q1-response" value="option4">&nbsp;&nbsp;&nbsp;<?php echo $test->option4;?></div><br>
                </table>
              
              
            </div>
          </div>
		<?php } ?>
		
		<?php if($testdetail->test_id==20){ 
			//echo "<pre>";print_r($test);
		?>
			<div class="otw-row ls-part1 ls-part1-screen-1">
				<div class="otw-twentyfour otw-columns">
				  <p><div><font style="font-size: 30px;"> Instructions:</font>
				  &nbsp; <?php echo $test->l1_practice_01_text; ?></div></p>
				 
				  <img src="<?php echo base_url('uploads/part1_listening/').$test->l1_practice_01_img; ?>" class="test-img">
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-2" style="display:none">
				<div class="otw-twentyfour otw-columns">
				  <h1> Listen to the conversation. You will hear the conversation only once. It is about 1 to 1.5 minutes long. </h1>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				  <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_conversation_1_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			
			<div class="otw-row ls-part1 ls-part1-screen-3" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border">
				  <h2><!--<img src="images/1.png">--> Listen to a short statement.<br>&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 1 of 8</p>
				  <h2> Choose the best answer to each question.</h2>
				  <form>
					<table>
					  <div><input type="radio" name="q1-response" checked value="l1_q1_option1">&nbsp;&nbsp;&nbsp;<img width="100" height="100" src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_option1; ?>"></div>&nbsp;
					  <div><input type="radio" name="q1-response" value="l1_q1_option2">&nbsp;&nbsp;&nbsp;<img width="100" height="100" src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_option2; ?>"></div>&nbsp;
					  <div><input type="radio" name="q1-response" value="l1_q1_option3">&nbsp;&nbsp;&nbsp;<img width="100" height="100" src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_option3; ?>"></div>&nbsp;
					  <div><input type="radio" name="q1-response" value="l1_q1_option4">&nbsp;&nbsp;&nbsp;<img width="100" height="100" src="<?php echo base_url('uploads/part1_listening/').$test->l1_q1_option4; ?>"></div>&nbsp;
					</table>
				  </form>
				  
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-4" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q2_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 2 of 8</p>
				  <h2><!--<img src="images/1.png">--> Choose the best answer to each question.</h2>
				  <form>
					<table>
					  <div><input type="radio" name="q2-response" checked value="l1_q2_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q2_option1; ?></div>
					  <div><input type="radio" name="q2-response" value="l1_q2_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q2_option2; ?></div>
					  <div><input type="radio" name="q2-response" value="l1_q2_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q2_option3; ?></div>
					  <div><input type="radio" name="q2-response" value="l1_q2_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q2_option4; ?></div>
					</table>
				  </form>
				  
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-5" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q3_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 3 of 8</p>
				  <h2> Choose the best answer to each question.</h2>
				  <form>
					<table>
					  <div><input type="radio" name="q3-response" checked value="l1_q3_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q3_option1; ?></div>
					  <div><input type="radio" name="q3-response" value="l1_q3_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q3_option2; ?></div>
					  <div><input type="radio" name="q3-response" value="l1_q3_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q3_option3; ?></div>
					  <div><input type="radio" name="q3-response" value="l1_q3_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q3_option4; ?></div>
					</table>
				  </form>
				  
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-6" style="display:none">
				<div class="otw-twentyfour otw-columns">
				  <h1> Listen to the conversation. You will hear the conversation only once. It is about 1 to 1.5 minutes long. </h1>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				  <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_conversation_2_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-7" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q4_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 4 of 8</p>
				  <h2> Choose the best answer to each question.</h2>
				  <form>
					<table>
					  <div><input type="radio" name="q4-response" checked value="l1_q4_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q4_option1; ?></div>
					  <div><input type="radio" name="q4-response" value="l1_q4_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q4_option2; ?></div>
					  <div><input type="radio" name="q4-response" value="l1_q4_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q4_option3; ?></div>
					  <div><input type="radio" name="q4-response" value="l1_q4_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q4_option4; ?></div>
					</table>
				  </form>
				  
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-8" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q5_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 5 of 8</p>
				  <h2> Choose the best answer to each question.</h2>
				  <form>
					<table>
					  <div><input type="radio" name="q5-response" value="l1_q5_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q5_option1; ?></div>
					  <div><input type="radio" name="q5-response" checked value="l1_q5_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q5_option2; ?></div>
					  <div><input type="radio" name="q5-response" value="l1_q5_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q5_option3; ?></div>
					  <div><input type="radio" name="q5-response" value="l1_q5_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q5_option4; ?></div>
					</table>
				  </form>
				  
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-9" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q6_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 6 of 8</p>
				  <h2> Choose the best answer to each question.</h2>
				  <form>
					<table>
					  <div><input type="radio" name="q6-response" checked value="l1_q6_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q6_option1; ?></div>
					  <div><input type="radio" name="q6-response" value="l1_q6_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q6_option2; ?></div>
					  <div><input type="radio" name="q6-response" value="l1_q6_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q6_option3; ?></div>
					  <div><input type="radio" name="q6-response" value="l1_q6_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q6_option4; ?></div>
					</table>
				  </form>
				  
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-10" style="display:none">
				<div class="otw-twentyfour otw-columns">
				  <h1> Listen to the conversation. You will hear the conversation only once. It is about 1 to 1.5 minutes long. </h1>
				  <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>
				  <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_conversation_3_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-11" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q7_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 7 of 8</p>
				  <h2> Choose the best answer to each question.</h2>
				  <form>
					<table>
					  <div><input type="radio" name="q7-response" checked value="l1_q7_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q7_option1; ?></div>
					  <div><input type="radio" name="q7-response" value="l1_q7_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q7_option2; ?></div>
					  <div><input type="radio" name="q7-response" value="l1_q7_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q7_option3; ?></div>
					  <div><input type="radio" name="q7-response" value="l1_q7_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q7_option4; ?></div>
					</table>
				  </form>
				  
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part1 ls-part1-screen-12" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part1_listening/').$test->l1_q8_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 8 of 8</p>
				  <h2> Choose the best answer to each question.</h2>
				  <form>
					<table>
					  <div><input type="radio" name="q8-response" checked value="l1_q8_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q8_option1; ?></div>
					  <div><input type="radio" name="q8-response" value="l1_q8_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q8_option2; ?></div>
					  <div><input type="radio" name="q8-response" value="l1_q8_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q8_option3; ?></div>
					  <div><input type="radio" name="q8-response" value="l1_q8_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->l1_q8_option4; ?></div>
					</table>
				  </form>
				  
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==19){ 
			//echo "<pre>";print_r($test);
		?>
		
			<div class="otw-row ls-part2 ls-part2-screen-1">
				<div class="otw-twentyfour otw-columns">
				  <h1> Listen to the conversation. You will hear the conversation only once. It is about 1.5 to 2  minutes long. </h1>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				  <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part2_listening/').$test->conversation_1_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part2 ls-part2-screen-2" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part2_listening/').$test->q1_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
					<p>Question 1 of 5</p>
					<h2> Choose the best answer to each question.</h2>
					<div><input type="radio" name="q1-response" checked value="q1_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option1; ?></div>
					<div><input type="radio" name="q1-response" value="q1_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option2; ?></div>
					<div><input type="radio" name="q1-response" value="q1_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option3; ?></div>
					<div><input type="radio" name="q1-response" value="q1_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option4; ?></div>
					<div class="otw-sc-hr"></div>
				</div>
			</div>
			
			
			<div class="otw-row ls-part2 ls-part2-screen-3" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part2_listening/').$test->q2_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
					<p>Question 2 of 5</p>
					<h2> Choose the best answer to each question.</h2>
					<div><input type="radio" name="q2-response" checked value="q2_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option1; ?></div>
					<div><input type="radio" name="q2-response" value="q2_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option2; ?></div>
					<div><input type="radio" name="q2-response" value="q2_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option3; ?></div>
					<div><input type="radio" name="q2-response" value="q2_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option4; ?></div>
					<div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part2 ls-part2-screen-4" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part2_listening/').$test->q3_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
					<p>Question 3 of 5</p>
					<h2> Choose the best answer to each question.</h2>
					<div><input type="radio" name="q3-response" checked value="q3_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option1; ?></div>
					<div><input type="radio" name="q3-response" value="q3_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option2; ?></div>
					<div><input type="radio" name="q3-response" value="q3_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option3; ?></div>
					<div><input type="radio" name="q3-response" value="q3_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option4; ?></div>
				<div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part2 ls-part2-screen-5" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part2_listening/').$test->q4_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
					<p>Question 4 of 5</p>
					<h2> Choose the best answer to each question.</h2>
					<div><input type="radio" name="q4-response" checked value="q4_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option1; ?></div>
					<div><input type="radio" name="q4-response" value="q4_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option2; ?></div>
					<div><input type="radio" name="q4-response" value="q4_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option3; ?></div>
					<div><input type="radio" name="q4-response" value="q4_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option4; ?></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
		
			<div class="otw-row ls-part2 ls-part2-screen-6" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part2_listening/').$test->q5_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
					<p>Question 5 of 5</p>
					<h2> Choose the best answer to each question.</h2>
					<div><input type="radio" name="q5-response" checked value="q5_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option1; ?></div>
					<div><input type="radio" name="q5-response" value="q5_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option2; ?></div>
					<div><input type="radio" name="q5-response" value="q5_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option3; ?></div>
					<div><input type="radio" name="q5-response" value="q5_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option4; ?></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
		<?php } ?>
		<?php if($testdetail->test_id==18){ 
			//echo "<pre>";print_r($test);
		?>
			<div class="otw-row ls-part3 ls-part3-screen-1">
				<div class="otw-twentyfour otw-columns">
					<h1> Listen to the conversation. You will hear the conversation only once. It is about 2 to 2.5 minutes long. </h1>
					<!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
					<p align="center">
				    <audio controls>
						<source src="<?php echo base_url('uploads/part3_listening/').$test->conversation_1_audio; ?>" type="audio/mpeg">
				    </audio></p>
					<div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
					<p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part3 ls-part3-screen-2" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				 <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part3_listening/').$test->q1_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 1 of 6</p>
				  <h2> Choose the best answer to each question.</h2>
					  <div><input type="radio" name="q1-response" checked value="q1_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option1; ?></div>
					  <div><input type="radio" name="q1-response" value="q1_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option2; ?></div>
					  <div><input type="radio" name="q1-response" value="q1_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option3; ?></div>
					  <div><input type="radio" name="q1-response" value="q1_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q1_option4; ?></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part3 ls-part3-screen-3" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part3_listening/').$test->q2_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 2 of 6</p>
				  <h2> Choose the best answer to each question.</h2>
					  <div><input type="radio" name="q2-response" checked value="q2_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option1; ?></div>
					  <div><input type="radio" name="q2-response" value="q2_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option2; ?></div>
					  <div><input type="radio" name="q2-response" value="q2_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option3; ?></div>
					  <div><input type="radio" name="q2-response" value="q2_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q2_option4; ?></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part3 ls-part3-screen-4" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part3_listening/').$test->q3_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 3 of 6</p>
				  <h2>Choose the best answer to each question.</h2>
					  <div><input type="radio" name="q3-response" checked value="q3_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option1; ?></div>
					  <div><input type="radio" name="q3-response" value="q3_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option2; ?></div>
					  <div><input type="radio" name="q3-response" value="q3_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option3; ?></div>
					  <div><input type="radio" name="q3-response" value="q3_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q3_option4; ?></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part3 ls-part3-screen-5" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp;&nbsp;&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part3_listening/').$test->q4_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 4 of 6</p>
				  <h2> Choose the best answer to each question.</h2>
					  <div><input type="radio" name="q4-response" checked value="q4_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option1; ?></div>
					  <div><input type="radio" name="q4-response" value="q4_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option2; ?></div>
					  <div><input type="radio" name="q4-response" value="q4_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option3; ?></div>
					  <div><input type="radio" name="q4-response" value="q4_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q4_option4; ?></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part3 ls-part3-screen-6" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part3_listening/').$test->q5_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 5 of 6</p>
				  <h2> Choose the best answer to each question.</h2>
					<div><input type="radio" name="q5-response" checked value="q5_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option1; ?></div>
					<div><input type="radio" name="q5-response" value="q5_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option2; ?></div>
					<div><input type="radio" name="q5-response" value="q5_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option3; ?></div>
					<div><input type="radio" name="q5-response" value="q5_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q5_option4; ?></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part3 ls-part3-screen-7" style="display:none">
				<div class="otw-ten otw-columns">
				    <div class="border-sec">
				  <h2> Listen to a short statement.<br>&nbsp; You will hear it only once.</h2>
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				   <audio controls>
						<source src="<?php echo base_url('uploads/part3_listening/').$test->q6_audio; ?>" type="audio/mpeg">
				   </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div></div>
				<div class="otw-thirteen otw-columns">
				 <p>Question 6 of 6</p>
				  <h2> Choose the best answer to each question.</h2>
					<div><input type="radio" name="q6-response" checked value="q6_option1">&nbsp;&nbsp;&nbsp;<?php echo $test->q6_option1; ?></div>
					<div><input type="radio" name="q6-response" value="q6_option2">&nbsp;&nbsp;&nbsp;<?php echo $test->q6_option2; ?></div>
					<div><input type="radio" name="q6-response" value="q6_option3">&nbsp;&nbsp;&nbsp;<?php echo $test->q6_option3; ?></div>
					<div><input type="radio" name="q6-response" value="q6_option4">&nbsp;&nbsp;&nbsp;<?php echo $test->q6_option4; ?></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==17){ 
			//echo "<pre>";print_r($test);
		?>
			<div class="otw-row ls-part4 ls-part4-screen-1">
				<div class="otw-twentyfour otw-columns">
				  <h1> Listen to the following news item. You will hear the news item only once. It is about 1.5 minutes long. </h1>
				 <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				  <p align="center">
				    <audio controls>
						<source src="<?php echo base_url('uploads/part4_listening/').$test->conversation_1_audio; ?>" type="audio/mpeg">
				    </audio></p>
				   <div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				   <p align="center">This playbar will not appear in the official test.</p></div>
				  <div class="otw-sc-hr"></div>
				</div>
			</div>
			
			<div class="otw-row ls-part4 ls-part4-screen-2" style="display:none">
				<div class="otw-twentyfour otw-columns">
					<h2>Choose the best way to complete each statement from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>)</h2>
					
					<p>1. <?php echo $test->q1_question; ?>
					   <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
					   <option value=""></option>
						 <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
						 <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
						 <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
						 <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
					   </select>
					   <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					
					<p>2. <?php echo $test->q2_question; ?>
					   <select type="drop-down" style="width: 150px;" class="searchform q2-sel-opt" name="q2-response">
					   <option value=""></option>
						 <option value="q2_option1"><?php echo $test->q2_option1; ?></option>
						 <option value="q2_option2"><?php echo $test->q2_option2; ?></option>
						 <option value="q2_option3"><?php echo $test->q2_option3; ?></option>
						 <option value="q2_option4"><?php echo $test->q2_option4; ?></option>
					   </select>
					   <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					
					<p>3. <?php echo $test->q3_question; ?>
					   <select type="drop-down" style="width: 150px;" class="searchform q3-sel-opt" name="q3-response">
					    <option value=""></option>
						<option value="q3_option1"><?php echo $test->q3_option1; ?></option>
						<option value="q3_option2"><?php echo $test->q3_option2; ?></option>
						<option value="q3_option3"><?php echo $test->q3_option3; ?></option>
						<option value="q3_option4"><?php echo $test->q3_option4; ?></option>
					   </select>
					   <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					
					<p>4. <?php echo $test->q4_question; ?>
					   <select type="drop-down" style="width: 150px;" class="searchform q4-sel-opt" name="q4-response">
					    <option value=""></option>
						<option value="q4_option1"><?php echo $test->q4_option1; ?></option>
						<option value="q4_option2"><?php echo $test->q4_option2; ?></option>
						<option value="q4_option3"><?php echo $test->q4_option3; ?></option>
						<option value="q4_option4"><?php echo $test->q4_option4; ?></option>
					   </select>
					   <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					
					<p>5. <?php echo $test->q5_question; ?>
					   <select type="drop-down" style="width: 150px;" class="searchform q5-sel-opt" name="q5-response">
					    <option value=""></option>
						<option value="q5_option1"><?php echo $test->q5_option1; ?></option>
						<option value="q5_option2"><?php echo $test->q5_option2; ?></option>
						<option value="q5_option3"><?php echo $test->q5_option3; ?></option>
						<option value="q5_option4"><?php echo $test->q5_option4; ?></option>
					   </select>
					   <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
				</div>
			</div>
		
		<?php } ?>
		
		
		<?php if($testdetail->test_id==16){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="otw-row ls-part5 ls-part5-screen-1" style="margin-bottom: -80px;">
			<div class="otw-twentyfour otw-columns">
			  <h1><!-- <img src="images/1.png"> --> Watch the discussion. You will watch the discussion only once. It is about 1.5 to 2 minutes long.  </h1>
			  <p align="center">
			   <video width="100%" height="100%" controls>
				  <source src="<?php echo base_url('uploads/part5_listening/').$test->conversation_1_video; ?>" type="video/mp4">
			   </video> 
				</p>
			  <div class="otw-sc-hr"></div>
			</div>
		</div>
		
		<div class="otw-row ls-part5 ls-part5-screen-2" style="display:none">
			<div class="otw-twentyfour otw-columns">
				<h2>Choose the best way to complete each statement from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>)</h2>
				
				<p>1. <?php echo $test->q1_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
				   <option value=""></option>
					 <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
					 <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
					 <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
					 <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
				   </select>
				   <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>2. <?php echo $test->q2_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q2-sel-opt" name="q2-response">
				   <option value=""></option>
					 <option value="q2_option1"><?php echo $test->q2_option1; ?></option>
					 <option value="q2_option2"><?php echo $test->q2_option2; ?></option>
					 <option value="q2_option3"><?php echo $test->q2_option3; ?></option>
					 <option value="q2_option4"><?php echo $test->q2_option4; ?></option>
				   </select>
				   <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>3. <?php echo $test->q3_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q3-sel-opt" name="q3-response">
					<option value=""></option>
					<option value="q3_option1"><?php echo $test->q3_option1; ?></option>
					<option value="q3_option2"><?php echo $test->q3_option2; ?></option>
					<option value="q3_option3"><?php echo $test->q3_option3; ?></option>
					<option value="q3_option4"><?php echo $test->q3_option4; ?></option>
				   </select>
				   <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>4. <?php echo $test->q4_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q4-sel-opt" name="q4-response">
					<option value=""></option>
					<option value="q4_option1"><?php echo $test->q4_option1; ?></option>
					<option value="q4_option2"><?php echo $test->q4_option2; ?></option>
					<option value="q4_option3"><?php echo $test->q4_option3; ?></option>
					<option value="q4_option4"><?php echo $test->q4_option4; ?></option>
				   </select>
				   <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>5. <?php echo $test->q5_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q5-sel-opt" name="q5-response">
					<option value=""></option>
					<option value="q5_option1"><?php echo $test->q5_option1; ?></option>
					<option value="q5_option2"><?php echo $test->q5_option2; ?></option>
					<option value="q5_option3"><?php echo $test->q5_option3; ?></option>
					<option value="q5_option4"><?php echo $test->q5_option4; ?></option>
				   </select>
				   <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>6. <?php echo $test->q6_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q6-sel-opt" name="q6-response">
					<option value=""></option>
					<option value="q6_option1"><?php echo $test->q6_option1; ?></option>
					<option value="q6_option2"><?php echo $test->q6_option2; ?></option>
					<option value="q6_option3"><?php echo $test->q6_option3; ?></option>
					<option value="q6_option4"><?php echo $test->q6_option4; ?></option>
				   </select>
				   <span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>7. <?php echo $test->q7_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q7-sel-opt" name="q7-response">
					<option value=""></option>
					<option value="q7_option1"><?php echo $test->q7_option1; ?></option>
					<option value="q7_option2"><?php echo $test->q7_option2; ?></option>
					<option value="q7_option3"><?php echo $test->q7_option3; ?></option>
					<option value="q7_option4"><?php echo $test->q7_option4; ?></option>
				   </select>
				   <span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>8. <?php echo $test->q8_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q8-sel-opt" name="q8-response">
					<option value=""></option>
					<option value="q8_option1"><?php echo $test->q8_option1; ?></option>
					<option value="q8_option2"><?php echo $test->q8_option2; ?></option>
					<option value="q8_option3"><?php echo $test->q8_option3; ?></option>
					<option value="q8_option4"><?php echo $test->q8_option4; ?></option>
				   </select>
				   <span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
			</div>
		</div>
		
        <?php } ?>
		
		<?php if($testdetail->test_id==15){ 
			//echo "<pre>";print_r($test);
		?>
		
		<div class="otw-row ls-part6 ls-part6-screen-1">
			<div class="otw-twentyfour otw-columns">
				<h1> Instructions: </h1>
				<p> <?php echo $test->conversation_audio_title; ?></p>
			  <div class="otw-sc-hr"></div>
			</div>
		</div>
		
		<div class="otw-row ls-part6 ls-part6-screen-2" style="display:none">
			<div class="otw-twentyfour otw-columns">
				<h1> Listen to the following report. You will hear the report only once. It is about 3 minutes long. </h1>
				<!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				
				<?php echo $test->conversation_audio_title; ?>
				<p align="center">
				<audio controls>
					<source src="<?php echo base_url('uploads/part6_listening/').$test->conversation_1_audio; ?>" type="audio/mpeg">
				</audio></p>
				<div style="border: 2px solid #eee;padding-top: 15px;margin-top: 20px;">
				<p align="center">This playbar will not appear in the official test.</p></div>
			  <div class="otw-sc-hr"></div>
			</div>
		</div>
		
		<div class="otw-row ls-part6 ls-part6-screen-3" style="display:none">
			<div class="otw-twentyfour otw-columns">
				<h2>Choose the best way to complete each statement from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>)</h2>
				
				<p>1. <?php echo $test->q1_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
				   <option value=""></option>
					 <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
					 <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
					 <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
					 <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
				   </select> 
				   <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>2. <?php echo $test->q2_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q2-sel-opt" name="q2-response">
				   <option value=""></option>
					 <option value="q2_option1"><?php echo $test->q2_option1; ?></option>
					 <option value="q2_option2"><?php echo $test->q2_option2; ?></option>
					 <option value="q2_option3"><?php echo $test->q2_option3; ?></option>
					 <option value="q2_option4"><?php echo $test->q2_option4; ?></option>
				   </select>
				   <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>3. <?php echo $test->q3_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q3-sel-opt" name="q3-response">
					<option value=""></option>
					<option value="q3_option1"><?php echo $test->q3_option1; ?></option>
					<option value="q3_option2"><?php echo $test->q3_option2; ?></option>
					<option value="q3_option3"><?php echo $test->q3_option3; ?></option>
					<option value="q3_option4"><?php echo $test->q3_option4; ?></option>
				   </select>
				   <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>4. <?php echo $test->q4_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q4-sel-opt" name="q4-response">
					<option value=""></option>
					<option value="q4_option1"><?php echo $test->q4_option1; ?></option>
					<option value="q4_option2"><?php echo $test->q4_option2; ?></option>
					<option value="q4_option3"><?php echo $test->q4_option3; ?></option>
					<option value="q4_option4"><?php echo $test->q4_option4; ?></option>
				   </select>
				   <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>5. <?php echo $test->q5_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q5-sel-opt" name="q5-response">
					<option value=""></option>
					<option value="q5_option1"><?php echo $test->q5_option1; ?></option>
					<option value="q5_option2"><?php echo $test->q5_option2; ?></option>
					<option value="q5_option3"><?php echo $test->q5_option3; ?></option>
					<option value="q5_option4"><?php echo $test->q5_option4; ?></option>
				   </select>
				   <span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
				<p>6. <?php echo $test->q6_question; ?>
				   <select type="drop-down" style="width: 150px;" class="searchform q6-sel-opt" name="q6-response">
					<option value=""></option>
					<option value="q6_option1"><?php echo $test->q6_option1; ?></option>
					<option value="q6_option2"><?php echo $test->q6_option2; ?></option>
					<option value="q6_option3"><?php echo $test->q6_option3; ?></option>
					<option value="q6_option4"><?php echo $test->q6_option4; ?></option>
				   </select> 
				   <span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
				</p>
				
			</div>
		</div>
		
        <?php } ?>
		
		<?php if($testdetail->test_id==47){ 
			//echo "<pre>";print_r($test);
		?>	
		<div class="otw-row" style="margin-bottom: -80px;">
				<div class="otw-ten otw-columns">

					<div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
						<h2>Read the following information. </h2>
						  <p><?php echo $test->question_title; ?>
						   </p>
						   </div>

						  <div class="otw-sc-hr"></div>
				</div>
						 <div class="otw-thirteen otw-columns">
						 <div id="wrapper">
				<div class="scrollbar1" id="style-default">
				  <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">
						<form>
							<table>
								<div>
									<p><?php echo $test->email_title; ?>
								</div>
								<div>
									<p>
										<textarea type="text" id="wt_q1_response" name="q1_response" placeholder="Place some text here" required="" style="height: 250px;font-size:18px;font-weight:normal;color:#1d1d1d;"></textarea>
										<span id="display_count">0</span> words
									</p>
									<p>
								</div>
							</table>
						</form>

					</div>
				</div>
			</div>
			<div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==46){ 
			//echo "<pre>";print_r($test);
		?>	
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-ten otw-columns">

				<div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
					<h2>Read the following information. </h2>
					<?php echo $test->question_title; ?>
				</div>

				<div class="otw-sc-hr"></div>
			</div>
			<div class="otw-thirteen otw-columns">
				<div id="wrapper">
					<div class="scrollbar1" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">
							<h2>Choose the option that you prefer. Why do you prefer your choice? Explain the reasons for your choice. Write about 150-200 words.</h2>
							<div class="radio-gap">
								<input type="radio" name="q1_response" value="option_1" checked onclick="show();" /> 
									<?php echo $test->option_1; ?>
								</div>
							<div class="radio-gap">
								<input type="radio" name="q1_response" value="option_2" onclick="show();" /> 
									<?php echo $test->option_2; ?> 
								</div>
							<div id="area" style="display: none">
								<h2>Explain the reasons for your choice. Write about 150-200 words.</h2>
								<textarea id="wt_q2_response" name="q2_response" placeholder="Place some text here" required="" style="font-weight: normal;color: #1d1d1d;font-size:18px;width: 345px !important;height:250px;margin-left: 0px;margin-top: 30px;"></textarea>
								<span id="display_count">0</span> words
							</div>
						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==59){ 
			//echo "<pre>";print_r($test);
		?>
		<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
		<div class="otw-row sp-part6 sp-part6-screen-1">
			<div class="otw-twentyfour otw-columns">
				<div style="background-color: #eee;border-radius: 10px;"><p align="center"><?php echo $test->q1_question; ?></p></div>
				
				<p align="center"><div class="response_file"></div>
				</p>
				
				<?php
				  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
				?>
				<?php echo $bufferMessage; ?>
				<div class="alert alert-danger text-center" id="recording-message" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">30</strong> seconds
				</div>

				<div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
				  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page &nbsp;<button class="btn-sm btn-success" value="Refresh Page" onClick="window.location.reload()"> Reload </button>
				</div>

				<div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
				  
				  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
				  <span id="recordHelp">Allow your microphone and reload page</span>
					  Recording started .... <strong style="display: none;" id="countresult">60</strong><span id="time">00:00</span> seconds
				</div>

				<div class="text-center" id="success-recording" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
				</div>
				
				<div class="clearfix"></div>
				<span id="level"></span>
				<div style="display: none;">
				  <div id="levelbase">
					<canvas id="levelbar"></canvas>
				  </div>
				  <div id="levelbase2">
					<div id="levelbar2"></div>
				  </div>
				</div>
			  <div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==58){ 
			//echo "<pre>";print_r($test);
		?>
		<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
		<div class="otw-row sp-part6 sp-part6-screen-1">
			<div class="otw-twentyfour otw-columns">
				<h2><?php echo $test->q1_question; ?> </h2>
				<p align="center"><div class="response_file"></div>
				</p>
				
				<?php
				  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
				?>
				<?php echo $bufferMessage; ?>
				<div class="alert alert-danger text-center" id="recording-message" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">30</strong> seconds
				</div>

				<div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
				  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page &nbsp;<button class="btn-sm btn-success" value="Refresh Page" onClick="window.location.reload()"> Reload </button>
				</div>

				<div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
				  
				  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
				  <span id="recordHelp">Allow your microphone and reload page</span>
					  Recording started .... <strong style="display: none;" id="countresult">60</strong><span id="time">00:00</span> seconds
				</div>

				<div class="text-center" id="success-recording" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
				</div>
				
				<div class="clearfix"></div>
				<span id="level"></span>
				<div style="display: none;">
				  <div id="levelbase">
					<canvas id="levelbar"></canvas>
				  </div>
				  <div id="levelbase2">
					<div id="levelbar2"></div>
				  </div>
				</div>
			  <div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==57){ 
			//echo "<pre>";print_r($test);
		?>
		<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
		<div class="otw-row sp-part6 sp-part6-screen-1">
			<div class="otw-twentyfour otw-columns">
				<h2><?php echo $test->q1_question; ?> </h2>
				<p align="center"><div class="response_file"></div>
				</p>
				
				<?php
				  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
				?>
				<?php echo $bufferMessage; ?>
				<div class="alert alert-danger text-center" id="recording-message" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">30</strong> seconds
				</div>

				<div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
				  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page &nbsp;<button class="btn-sm btn-success" value="Refresh Page" onClick="window.location.reload()"> Reload </button>
				</div>

				<div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
				  
				  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
				  <span id="recordHelp">Allow your microphone and reload page</span>
					  Recording started .... <strong style="display: none;" id="countresult">60</strong><span id="time">00:00</span> seconds
				</div>

				<div class="text-center" id="success-recording" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
				</div>
				
				<div class="clearfix"></div>
				<span id="level"></span>
				<div style="display: none;">
				  <div id="levelbase">
					<canvas id="levelbar"></canvas>
				  </div>
				  <div id="levelbase2">
					<div id="levelbar2"></div>
				  </div>
				</div>
			  <div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==56){ 
			//echo "<pre>";print_r($test);
		?>
		<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
		<div class="otw-row sp-part6 sp-part6-screen-1">
			<div class="otw-twentyfour otw-columns">
				<h2><?php echo $test->q1_question; ?> </h2>
				<div><img src="<?php echo base_url('uploads/speaking_part3/').$test->q1_image; ?>" style="height: 320px;"></div>
				<p align="center"><div class="response_file"></div>
				</p>
				
				<?php
				  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
				?>
				<?php echo $bufferMessage; ?>
				<div class="alert alert-danger text-center" id="recording-message" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">30</strong> seconds
				</div>

				<div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
				  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page &nbsp;<button class="btn-sm btn-success" value="Refresh Page" onClick="window.location.reload()"> Reload </button>
				</div>

				<div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
				  
				  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
				  <span id="recordHelp">Allow your microphone and reload page</span>
					  Recording started .... <strong style="display: none;" id="countresult">60</strong><span id="time">00:00</span> seconds
				</div>

				<div class="text-center" id="success-recording" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
				</div>
				
				<div class="clearfix"></div>
				<span id="level"></span>
				<div style="display: none;">
				  <div id="levelbase">
					<canvas id="levelbar"></canvas>
				  </div>
				  <div id="levelbase2">
					<div id="levelbar2"></div>
				  </div>
				</div>
			  <div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==55){ //echo "<pre>";print_r($test); ?>
		<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
			<div class="otw-row" style="margin-bottom: -80px;">
				<div class="otw-twentyfour otw-columns">
				  <h2><?php echo $test->q1_question; ?> </h2>
				  <div><img src="<?php echo base_url('uploads/speaking_part4/').$test->q1_image; ?>" style="height: 320px;"></div>
				   
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div>
				<div class="otw-thirteen otw-columns">
					<p align="center"><div class="response_file"></div>
					</p>
					
					<?php
					  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
					?>
					<?php echo $bufferMessage; ?>
					<div class="alert alert-danger text-center" id="recording-message" style="display: none;">
					  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">30</strong> seconds
					</div>

					<div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
					  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page &nbsp;<button class="btn-sm btn-success" value="Refresh Page" onClick="window.location.reload()"> Reload </button>
					</div>

					<div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
					  
					  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
					  <span id="recordHelp">Allow your microphone and reload page</span>
						  Recording started .... <strong style="display: none;" id="countresult">60</strong><span id="time">00:00</span> seconds
					</div>

					<div class="text-center" id="success-recording" style="display: none;">
					  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
					</div>
					
					<div class="clearfix"></div>
					<span id="level"></span>
					<div style="display: none;">
					  <div id="levelbase">
						<canvas id="levelbar"></canvas>
					  </div>
					  <div id="levelbase2">
						<div id="levelbar2"></div>
					  </div>
					</div>
				  
				  
				<div class="otw-sc-hr"></div>
				</div>
           </div>
		
		<?php } ?>
		
		<?php if($testdetail->test_id==54){ //echo "<pre>";print_r($test); ?>
		<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
			<div class="otw-row" style="margin-bottom: -80px;">
				<div class="otw-twentyfour otw-columns">
				  <h2><?php echo $test->q1_question; ?> </h2>
				
				  <div class="container-fluid">
					<div class="otw-row">
					  <div class="otw-ten otw-columns image_size" ><img src="<?php echo base_url('uploads/speaking_part5/').$test->q1_image; ?>"></div>
					  <div class="otw-ten otw-columns image_size" ><img src="<?php echo base_url('uploads/speaking_part5/').$test->q1_image2; ?>"></div>
					</div>
				  </div>
				  
				  
				  <p align="center"><div class="response_file"></div>
					</p>
					
					<?php
					  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
					?>
					<?php echo $bufferMessage; ?>
					<div class="alert alert-danger text-center" id="recording-message" style="display: none;">
					  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">30</strong> seconds
					</div>

					<div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
					  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page &nbsp;<button class="btn-sm btn-success" value="Refresh Page" onClick="window.location.reload()"> Reload </button>
					</div>

					<div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
					  
					  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
					  <span id="recordHelp">Allow your microphone and reload page</span>
						  Recording started .... <strong style="display: none;" id="countresult">60</strong><span id="time">00:00</span> seconds
					</div>

					<div class="text-center" id="success-recording" style="display: none;">
					  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
					</div>
					
					<div class="clearfix"></div>
					<span id="level"></span>
					<div style="display: none;">
					  <div id="levelbase">
						<canvas id="levelbar"></canvas>
					  </div>
					  <div id="levelbase2">
						<div id="levelbar2"></div>
					  </div>
					</div>
				    <p><strong>*NOTE:</strong> This sample test is not recording your response. </p>

				
				   
				  <div class="otw-sc-hr"></div>
				  <!-- <div style="border-right: 1px solid #c5c5c5;height: 400px;"></div> -->
				</div>
				 <div class="otw-thirteen otw-columns">
				 
				  
				  
				  <div class="otw-sc-hr"></div>
				</div>
            </div>
		<?php } ?>
		
		<?php if($testdetail->test_id==53){ //echo "<pre>";print_r($test); ?>
		<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twentyfour otw-columns">
				<h2><?php echo $test->q1_question; ?> </h2>
				<p align="center"><div class="response_file"></div>
				</p>
				
				<?php
				  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
				?>
				<?php echo $bufferMessage; ?>
				<div class="alert alert-danger text-center" id="recording-message" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">30</strong> seconds
				</div>

				<div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
				  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page &nbsp;<button class="btn-sm btn-success" value="Refresh Page" onClick="window.location.reload()"> Reload </button>
				</div>

				<div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
				  
				  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
				  <span id="recordHelp">Allow your microphone and reload page</span>
					  Recording started .... <strong style="display: none;" id="countresult">60</strong><span id="time">00:00</span> seconds
				</div>

				<div class="text-center" id="success-recording" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
				</div>
				
				<div class="clearfix"></div>
				<span id="level"></span>
				<div style="display: none;">
				  <div id="levelbase">
					<canvas id="levelbar"></canvas>
				  </div>
				  <div id="levelbase2">
					<div id="levelbar2"></div>
				  </div>
				</div>
			  <div class="otw-sc-hr"></div>
			</div>
		</div>	
		<?php } ?>
		
		<?php if($testdetail->test_id==52){ //echo "<pre>";print_r($test); ?>
		<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twentyfour otw-columns">
				<h2><?php echo $test->q1_question; ?> </h2>
				<p align="center"><div class="response_file"></div>
				</p>
				
				<?php
				  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
				?>
				<?php echo $bufferMessage; ?>
				<div class="alert alert-danger text-center" id="recording-message" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">30</strong> seconds
				</div>

				<div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
				  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page &nbsp;<button class="btn-sm btn-success" value="Refresh Page" onClick="window.location.reload()"> Reload </button>
				</div>

				<div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
				  
				  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
				  <span id="recordHelp">Allow your microphone and reload page</span>
					  Recording started .... <strong style="display: none;" id="countresult">60</strong><span id="time">00:00</span> seconds
				</div>

				<div class="text-center" id="success-recording" style="display: none;">
				  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
				</div>
				
				<div class="clearfix"></div>
				<span id="level"></span>
				<div style="display: none;">
				  <div id="levelbase">
					<canvas id="levelbar"></canvas>
				  </div>
				  <div id="levelbase2">
					<div id="levelbar2"></div>
				  </div>
				</div>
			  <div class="otw-sc-hr"></div>
			</div>
		</div>	
		<?php } ?>
		
		<?php if($testdetail->test_id==51){ //echo "<pre>";print_r($test); ?>
		<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($testdetail->test_id) ?>">
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twentyfour otw-columns">
				<h2><?php echo $test->q1_question; ?> </h2>
				
				<div class="container">
					<div class="otw-row">
						<div class="otw-ten otw-columns"><img src="<?php echo base_url('uploads/speaking_part8/').$test->q1_image; ?>"></div>
						<div class="otw-ten otw-columns" style="float:left">
						
							<p align="center"><div class="response_file"></div></p>
				
							<?php
							  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
							?>
							<?php echo $bufferMessage; ?>
							<div class="alert alert-danger text-center" id="recording-message" style="display: none;">
							  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">30</strong> seconds
							</div>

							<div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
							  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page &nbsp;<button class="btn-sm btn-success" value="Refresh Page" onClick="window.location.reload()"> Reload </button>
							</div>

							<div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
							  
							  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
							  <span id="recordHelp">Allow your microphone and reload page</span>
								  Recording started .... <strong style="display: none;" id="countresult">60</strong><span id="time">00:00</span> seconds
							</div>

							<div class="text-center" id="success-recording" style="display: none;">
							  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
							</div>
							
							<div class="clearfix"></div>
							<span id="level"></span>
							<div style="display: none;">
							  <div id="levelbase">
								<canvas id="levelbar"></canvas>
							  </div>
							  <div id="levelbase2">
								<div id="levelbar2"></div>
							  </div>
							</div>
							
						</div>
					</div>
				</div>
				
				
				
				
			  <div class="otw-sc-hr"></div>
			</div>
		</div>	
		<?php } ?>
		<?php if($testdetail->test_id==40){ //echo "<pre>";print_r($test);?>
			<div class="otw-row" style="margin-bottom: -80px;">
            <div class="otw-ten otw-columns" style="border-right: 2px solid #c5c5c5;height: 300px;">
              <h2>Read the following message. </h2>
              <p><?php echo $test->question_title; ?> </p>
              <div class="otw-sc-hr"></div>
            </div>
             <div class="otw-thirteen otw-columns"> Using the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>), choose the best option according to the information given in the message.</h2><br>
              <form>
                <table><br>
                <div><?php echo $test->question; ?>
                  <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
                    <option value=""></option>
                    <option value="option1"><?php echo $test->option1; ?></option>
                    <option value="option2"><?php echo $test->option2; ?></option>
                    <option value="option3"><?php echo $test->option3; ?></option>
                    <option value="option4"><?php echo $test->option4; ?></option>
                  </select>
				  <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
                </div>
                </table>
              </form>
              
              <div class="otw-sc-hr"></div>
            </div>
          </div>
		<?php } ?>
		
		<?php if($testdetail->test_id==37){ //echo "<pre>";print_r($test);?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-ten otw-columns">
				<div id="wrapper">
					<div class="scrollbar" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius:10px;padding: 15px">
							<h2>Read the following message. </h2>
							<p><?php echo $test->passages_1; ?></p>
							<p><?php echo $test->passages_2; ?></p>
							<p><?php echo $test->passages_3; ?></p>
							<p><?php echo $test->passages_4; ?> </p>
							<p><strong>E. Not given in any of the above paragraphs.</strong></p>

						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
			<div class="otw-thirteen otw-columns">
				<div id="wrapper">
					<div class="scrollbar1" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
							<h2>Decide which paragraph, A to D, has the information given in each statement below. Select E if the information is not given in any of the paragraphs.</h2>
							<form>
								<table>
									<div>
										<p>
											<select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
												<option value=""></option>
												<option value="A">A&nbsp;&nbsp;</option>
												<option value="B">B&nbsp;&nbsp;</option>
												<option value="C">C&nbsp;&nbsp;</option>
												<option value="D">D&nbsp;&nbsp;</option>
												<option value="E">E&nbsp;&nbsp;</option>
											</select><?php echo $test->q1_question; ?> 
											<span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
										<p>
											<select type="drop-down" style="width: 150px;" class="searchform q2-sel-opt"name="q2-response">
												<option value=""></option>
												<option value="A">A&nbsp;&nbsp;</option>
												<option value="B">B&nbsp;&nbsp;</option>
												<option value="C">C&nbsp;&nbsp;</option>
												<option value="D">D&nbsp;&nbsp;</option>
												<option value="E">E&nbsp;&nbsp;</option>
											</select><?php echo $test->q2_question; ?>
											<span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
										<p>
											<select type="drop-down" style="width: 150px;" class="searchform q3-sel-opt" name="q3-response">
												<option value=""></option>
												<option value="A">A&nbsp;&nbsp;</option>
												<option value="B">B&nbsp;&nbsp;</option>
												<option value="C">C&nbsp;&nbsp;</option>
												<option value="D">D&nbsp;&nbsp;</option>
												<option value="E">E&nbsp;&nbsp;</option>
											</select><?php echo $test->q3_question; ?>
											<span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
										<p>
											<select type="drop-down" style="width: 150px;" class="searchform q4-sel-opt" name="q4-response">
												<option value=""></option>
												<option value="A">A&nbsp;&nbsp;</option>
												<option value="B">B&nbsp;&nbsp;</option>
												<option value="C">C&nbsp;&nbsp;</option>
												<option value="D">D&nbsp;&nbsp;</option>
												<option value="E">E&nbsp;&nbsp;</option>
											</select><?php echo $test->q4_question; ?> 
											<span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
										<p>
											<select type="drop-down" style="width: 150px;" class="searchform q5-sel-opt" name="q5-response">
												<option value=""></option>
												<option value="A">A&nbsp;&nbsp;</option>
												<option value="B">B&nbsp;&nbsp;</option>
												<option value="C">C&nbsp;&nbsp;</option>
												<option value="D">D&nbsp;&nbsp;</option>
												<option value="E">E&nbsp;&nbsp;</option>
											</select><?php echo $test->q5_question; ?> 
											<span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
										<p>
											<select type="drop-down" style="width: 150px;" class="searchform q6-sel-opt" name="q6-response">
												<option value=""></option>
												<option value="A">A&nbsp;&nbsp;</option>
												<option value="B">B&nbsp;&nbsp;</option>
												<option value="C">C&nbsp;&nbsp;</option>
												<option value="D">D&nbsp;&nbsp;</option>
												<option value="E">E&nbsp;&nbsp;</option>
											</select><?php echo $test->q6_question; ?> 
											<span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
										<p>
											<select type="drop-down" style="width: 150px;" class="searchform q7-sel-opt" name="q7-response">
												<option value=""></option>
												<option value="A">A&nbsp;&nbsp;</option>
												<option value="B">B&nbsp;&nbsp;</option>
												<option value="C">C&nbsp;&nbsp;</option>
												<option value="D">D&nbsp;&nbsp;</option>
												<option value="E">E&nbsp;&nbsp;</option>
											</select><?php echo $test->q7_question; ?> 
											<span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
										<p>
											<select type="drop-down" style="width: 150px;" class="searchform q8-sel-opt" name="q8-response">
												<option value=""></option>
												<option value="A">A&nbsp;&nbsp;</option>
												<option value="B">B&nbsp;&nbsp;</option>
												<option value="C">C&nbsp;&nbsp;</option>
												<option value="D">D&nbsp;&nbsp;</option>
												<option value="E">E&nbsp;&nbsp;</option>
											</select><?php echo $test->q8_question; ?>
											<span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
										<p>
											<select type="drop-down" style="width: 150px;" class="searchform q9-sel-opt" name="q9-response">
												<option value=""></option>
												<option value="A">A&nbsp;&nbsp;</option>
												<option value="B">B&nbsp;&nbsp;</option>
												<option value="C">C&nbsp;&nbsp;</option>
												<option value="D">D&nbsp;&nbsp;</option>
												<option value="E">E&nbsp;&nbsp;</option>
											</select><?php echo $test->q9_question; ?> 
											<span class="q9-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000;float: left;"></span></p>
									</div>
								</table>
							</form>

						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
		</div>
		
		<?php } ?>
		
		<?php if($testdetail->test_id==39){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-ten otw-columns">
				<div id="wrapper">
					<div class="scrollbar" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
							<h2>Read the following message. </h2>
							<p><?php echo $test->passages; ?></p>

						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
			<div class="otw-thirteen otw-columns">
				<div id="wrapper">
					<div class="scrollbar1" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
							<h2> Using the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>), choose the best option according to the information given in the message.</h2>
							<form>
								<table>
									<div>&nbsp;&nbsp;<?php echo $test->q1_question; ?>
										<select type="drop-down" style="width: 150px;" class="q1-sel-opt searchform" name="q1-response">
											<option value=""></option>
											<option value="q1_option1"><?php echo $test->q1_option1; ?></option>
											<option value="q1_option2"><?php echo $test->q1_option2; ?></option>
											<option value="q1_option3"><?php echo $test->q1_option3; ?></option>
											<option value="q1_option4"><?php echo $test->q1_option4; ?></option>
										</select>
										<span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
									<div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q2_question; ?>
										<select type="drop-down" style="width: 140px;" class="q2-sel-opt searchform" name="q2-response">
											<option value=""></option>
											<option value="q2_option1"><?php echo $test->q2_option1; ?></option>
											<option value="q2_option2"><?php echo $test->q2_option2; ?></option>
											<option value="q2_option3"><?php echo $test->q2_option3; ?></option>
											<option value="q2_option4"><?php echo $test->q2_option4; ?></option>
										</select>
										<span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
									<div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q3_question; ?>
										<select type="drop-down" style="width: 150px;" class="q3-sel-opt searchform" name="q3-response">
											<option value=""></option>
											<option value="q3_option1"><?php echo $test->q3_option1; ?></option>
											<option value="q3_option2"><?php echo $test->q3_option2; ?></option>
											<option value="q3_option3"><?php echo $test->q3_option3; ?></option>
											<option value="q3_option4"><?php echo $test->q3_option4; ?></option>
										</select>
										<span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
									<div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q4_question; ?>
										<select type="drop-down" style="width: 150px;" class="q4-sel-opt searchform" name="q4-response">
											<option value=""></option>
											<option value="q4_option1"><?php echo $test->q4_option1; ?></option>
											<option value="q4_option2"><?php echo $test->q4_option2; ?></option>
											<option value="q4_option3"><?php echo $test->q4_option3; ?></option>
											<option value="q4_option4"><?php echo $test->q4_option4; ?></option>
										</select>
										<span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
									<div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q5_question; ?>
										<select type="drop-down" style="width: 150px;" class="q5-sel-opt searchform" name="q5-response">
											<option value=""></option>
											<option value="q5_option1"><?php echo $test->q5_option1; ?></option>
											<option value="q5_option2"><?php echo $test->q5_option2; ?></option>
											<option value="q5_option3"><?php echo $test->q5_option3; ?></option>
											<option value="q5_option4"><?php echo $test->q5_option4; ?></option>
										</select>
										<span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
									<div style="margin-top: 30px;">&nbsp;&nbsp;<?php echo $test->q6_question; ?>
										<select type="drop-down" style="width: 150px;" class="q6-sel-opt searchform" name="q6-response">
											<option value=""></option>
											<option value="q6_option1"><?php echo $test->q6_option1; ?></option>
											<option value="q6_option2"><?php echo $test->q6_option2; ?></option>
											<option value="q6_option3"><?php echo $test->q6_option3; ?></option>
											<option value="q6_option4"><?php echo $test->q6_option4; ?></option>
										</select>
										<span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</div>
								</table>
							</form>

							<h2><!-- <img src="images/1.png"> --> Here is a response to the message. Complete the response by filling in the blanks. Select the best choice for each blank from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>). </h2>
							<form>
								<table>
									<p><?php echo $test->hi_message; ?></p>
									<p><?php echo $test->q7_question; ?>
										<select type="drop-down" style="width: 150px;" class="q7-sel-opt searchform" name="q7-response">
											<option value=""></option>
											<option value="q7_option1"><?php echo $test->q7_option1; ?></option>
											<option value="q7_option2"><?php echo $test->q7_option2; ?></option>
											<option value="q7_option3"><?php echo $test->q7_option3; ?></option>
											<option value="q7_option4"><?php echo $test->q7_option4; ?></option>
										</select>
										<span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										<?php echo $test->q8_question; ?>
										<select type="drop-down" style="width: 110px;" class="q8-sel-opt searchform" name="q8-response">
											<option value=""></option>
											<option value="q8_option1"><?php echo $test->q8_option1; ?></option>
											<option value="q8_option2"><?php echo $test->q8_option2; ?></option>
											<option value="q8_option3"><?php echo $test->q8_option3; ?></option>
											<option value="q8_option4"><?php echo $test->q8_option4; ?></option>
										</select>
										<span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										<?php echo $test->q9_question; ?>
										<select type="drop-down" style="width: 150px;" class="q9-sel-opt searchform" name="q9-response">
											<option value=""></option>
											<option value="q9_option1"><?php echo $test->q9_option1; ?></option>
											<option value="q9_option2"><?php echo $test->q9_option2; ?></option>
											<option value="q9_option3"><?php echo $test->q9_option3; ?></option>
											<option value="q9_option4"><?php echo $test->q9_option4; ?></option>
										</select>
										<span class="q9-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
									</p>
									<p><?php echo $test->q10_question; ?>
										<select type="drop-down" style="width: 150px;" class="q10-sel-opt searchform" name="q10-response">
											<option value=""></option>
											<option value="q10_option1"><?php echo $test->q10_option1; ?></option>
											<option value="q10_option2"> <?php echo $test->q10_option2; ?></option>
											<option value="q10_option3"><?php echo $test->q10_option3; ?></option>
											<option value="q10_option4"><?php echo $test->q10_option4; ?></option>
										</select>
										<span class="q10-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										<?php echo $test->q11_question; ?>
										<select type="drop-down" style="width: 150px;" class="q11-sel-opt searchform" name="q11-response">
											<option value=""></option>
											<option value="q11_option1"><?php echo $test->q11_option1; ?></option>
											<option value="q11_option2"><?php echo $test->q11_option2; ?></option>
											<option value="q11_option3"><?php echo $test->q11_option3; ?></option>
											<option value="q11_option4"><?php echo $test->q11_option4; ?></option>
										</select>
										<span class="q11-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										<?php echo $test->thank_message; ?>
								</table>
							</form>
						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		<?php if($testdetail->test_id==38){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="otw-row" style="margin-bottom: -80px;">
		    <div class="otw-twelveth otw-columns">
				<div id="wrapper">
					<div class="scrollbar1" id="style-default" style="width: 100% !important;">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;">
							<div class="container" >
								<div class="otw-row">
									<div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_1; ?>"></div>
								</div>
								<div class="otw-row">
									<div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_2; ?>"></div>
								</div>
								<div class="otw-row">
									<div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_3; ?>"></div>
								</div>
								<div class="otw-row">
									<div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_4; ?>"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
			<!--<div class="otw-ten otw-columns">
				<div id="wrapper">
					<div class="scrollbar" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;width: 570px;">
							<div class="container" style="margin: 10px;">
								<div class="otw-row">
									<div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_1; ?>"></div>
								</div>
								<div class="otw-row">
									<div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_2; ?>"></div>
								</div>
								<div class="otw-row">
									<div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_3; ?>"></div>
								</div>
								<div class="otw-row">
									<div class="otw-columns"><img src="<?php echo base_url('uploads/reading_part2/').$test->image_4; ?>"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>-->
			<div class="otw-ten otw-columns">
				<div id="wrapper">
					<div class="scrollbar1" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px;">
							<h2>Read the following email message about the diagram on the left. Complete the email by filling in the blanks. Select the best choice for each blank from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>). </h2>
							<form>
								<table>
									<div>
										<p><?php echo $test->q1_question; ?>
										<select type="drop-down" style="width: 150px;" class="q1-sel-opt searchform" name="q1-response">
											<option value=""></option>
											<option value="q1_option1"><?php echo $test->q1_option1; ?></option>
											<option value="q1_option2"><?php echo $test->q1_option2; ?></option>
											<option value="q1_option3"><?php echo $test->q1_option3; ?></option>
											<option value="q1_option4"><?php echo $test->q1_option4; ?></option>
										</select>
										<span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										&nbsp;&nbsp;<?php echo $test->q2_question; ?>
										<select type="drop-down" style="width: 140px;" class="q2-sel-opt searchform" name="q2-response">
											<option value=""></option>
											<option value="q2_option1"><?php echo $test->q2_option1; ?></option>
											<option value="q2_option2"><?php echo $test->q2_option2; ?></option>
											<option value="q2_option3"><?php echo $test->q2_option3; ?></option>
											<option value="q2_option4"><?php echo $test->q2_option4; ?></option>
										</select><span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										&nbsp;&nbsp;<?php echo $test->q3_question; ?>
										<select type="drop-down" style="width: 150px;" class="q3-sel-opt searchform" name="q3-response">
											<option value=""></option>
											<option value="q3_option1"><?php echo $test->q3_option1; ?></option>
											<option value="q3_option2"><?php echo $test->q3_option2; ?></option>
											<option value="q3_option3"><?php echo $test->q3_option3; ?></option>
											<option value="q3_option4"><?php echo $test->q3_option4; ?></option>
										</select>
										<span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										<?php echo $test->q4_question; ?>
										<select type="drop-down" style="width: 150px;" class="q4-sel-opt searchform" name="q4-response">
											<option value=""></option>
											<option value="q4_option1"><?php echo $test->q4_option1; ?></option>
											<option value="q4_option2"><?php echo $test->q4_option2; ?></option>
											<option value="q4_option3"><?php echo $test->q4_option3; ?></option>
											<option value="q4_option4"><?php echo $test->q4_option4; ?></option>
										</select>
										<span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										&nbsp;&nbsp;<?php echo $test->q5_question; ?>
										<select type="drop-down" style="width: 150px;" class="q5-sel-opt searchform" name="q5-response">
											<option value=""></option>
											<option value="q5_option1"><?php echo $test->q5_option1; ?></option>
											<option value="q5_option2"><?php echo $test->q5_option2; ?></option>
											<option value="q5_option3"><?php echo $test->q5_option3; ?></option>
											<option value="q5_option4"><?php echo $test->q5_option4; ?></option>
										</select>
										<span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										<?php echo $test->paragraph_6; ?>
									</div>
								</table>
							</form>

							<h2><!-- <img src="images/1.png"> --> Using the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>), choose the best option.</h2>
							<form>
								<table>
									<div>
										<p><?php echo $test->q6_question; ?>
										<select type="drop-down" style="width: 150px;" class="q6-sel-opt searchform" name="q6-response">
											<option value=""></option>
											<option value="q6_option1"><?php echo $test->q6_option1; ?></option>
											<option value="q6_option2"><?php echo $test->q6_option2; ?></option>
											<option value="q6_option3"><?php echo $test->q6_option3; ?></option>
											<option value="q6_option4"><?php echo $test->q6_option4; ?></option>
										</select>
										<span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										</p>
										<p><?php echo $test->q7_question; ?>
										<select type="drop-down" style="width: 150px;" class="q7-sel-opt searchform" name="q7-response">
											<option value=""></option>
											<option value="q7_option1"><?php echo $test->q7_option1; ?></option>
											<option value="q7_option2"><?php echo $test->q7_option2; ?></option>
											<option value="q7_option3"><?php echo $test->q7_option3; ?></option>
											<option value="q7_option4"><?php echo $test->q7_option4; ?></option>
										</select><span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										</p>
										<p><?php echo $test->q8_question; ?>
										<select type="drop-down" style="width: 110px;" class="q8-sel-opt searchform" name="q8-response">
											<option value=""></option>
											<option value="q8_option1"><?php echo $test->q8_option1; ?></option>
											<option value="q8_option2"><?php echo $test->q8_option2; ?></option>
											<option value="q8_option3"><?php echo $test->q8_option3; ?></option>
											<option value="q8_option4"><?php echo $test->q8_option4; ?></option>
										</select>
										<span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										</p>
									</div>
								</table>
							</form>
						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==36){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-ten otw-columns">
				<div id="wrapper">
					<div class="scrollbar" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px">
							<h2>Read the following article from a website. </h2>
							<p><?php echo $test->passages; ?></p>
						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
			<div class="otw-thirteen otw-columns">
				<div id="wrapper">
					<div class="scrollbar1" id="style-default">
						<div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:15px">
							<h2>Using the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>), choose the best option according to the information given on the website.</h2>
							<form>
								<table>
									<div>
										<p><?php echo $test->q1_question; ?>
											<select type="drop-down" style="width: 150px;" class="q1-sel-opt searchform" name="q1-response">
												<option value=""></option>
												<option value="q1_option1"><?php echo $test->q1_option1; ?></option>
												<option value="q1_option2"><?php echo $test->q1_option2; ?></option>
												<option value="q1_option3"><?php echo $test->q1_option3; ?></option>
												<option value="q1_option4"><?php echo $test->q1_option4; ?></option>
											</select>
											<span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										</p>
										<p><?php echo $test->q2_question; ?>
										<select type="drop-down" style="width: 140px;" class="q2-sel-opt searchform" name="q2-response">
											<option value=""></option>
											<option value="q2_option1"><?php echo $test->q2_option1; ?></option>
											<option value="q2_option2"><?php echo $test->q2_option2; ?></option>
											<option value="q2_option3"><?php echo $test->q2_option3; ?></option>
											<option value="q2_option4"><?php echo $test->q2_option4; ?></option>
										</select><span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										</p>
										<p><?php echo $test->q3_question; ?>
										<select type="drop-down" style="width: 150px;" class="q3-sel-opt searchform" name="q3-response">
											<option value=""></option>
											<option value="q3_option1"><?php echo $test->q3_option1; ?></option>
											<option value="q3_option2"><?php echo $test->q3_option2; ?></option>
											<option value="q3_option3"><?php echo $test->q3_option3; ?></option>
											<option value="q3_option4"><?php echo $test->q3_option4; ?></option>
										</select>
										<span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										</p>
										<p>
										<?php echo $test->q4_question; ?>
										<select type="drop-down" style="width: 150px;" class="q4-sel-opt searchform" name="q4-response">
											<option value=""></option>
											<option value="q4_option1"><?php echo $test->q4_option1; ?></option>
											<option value="q4_option2"><?php echo $test->q4_option2; ?></option>
											<option value="q4_option3"><?php echo $test->q4_option3; ?></option>
											<option value="q4_option4"><?php echo $test->q4_option4; ?></option>
										</select>
										<span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										</p>
										<p><?php echo $test->q5_question; ?>
										<select type="drop-down" style="width: 150px;" class="q5-sel-opt searchform" name="q5-response">
											<option value=""></option>
											<option value="q5_option1"><?php echo $test->q5_option1; ?></option>
											<option value="q5_option2"><?php echo $test->q5_option2; ?></option>
											<option value="q5_option3"><?php echo $test->q5_option3; ?></option>
											<option value="q5_option4"><?php echo $test->q5_option4; ?></option>
										</select>
										<span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										</p>

									</div>
									<h2>The following is a comment by a visitor to the website page. Complete the comment by choosing the best option to fill in each blank.</h2>
									<div>
										<p><?php echo $test->q6_question; ?>
										<select type="drop-down" style="width: 150px;" class="q6-sel-opt searchform" name="q6-response">
											<option value=""></option>
											<option value="q6_option1"><?php echo $test->q6_option1; ?></option>
											<option value="q6_option2"><?php echo $test->q6_option2; ?></option>
											<option value="q6_option3"><?php echo $test->q6_option3; ?></option>
											<option value="q6_option4"><?php echo $test->q6_option4; ?></option>
										</select>
										<span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										<?php echo $test->q7_question; ?>
										<select type="drop-down" style="width: 150px;" class="q7-sel-opt searchform" name="q7-response">
											<option value=""></option>
											<option value="q7_option1"><?php echo $test->q7_option1; ?></option>
											<option value="q7_option2"><?php echo $test->q7_option2; ?></option>
											<option value="q7_option3"><?php echo $test->q7_option3; ?></option>
											<option value="q7_option4"><?php echo $test->q7_option4; ?></option>
										</select><span class="q7-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										
										<?php echo $test->q8_question; ?>
										<select type="drop-down" style="width: 110px;" class="q8-sel-opt searchform" name="q8-response">
											<option value=""></option>
											<option value="q8_option1"><?php echo $test->q8_option1; ?></option>
											<option value="q8_option2"><?php echo $test->q8_option2; ?></option>
											<option value="q8_option3"><?php echo $test->q8_option3; ?></option>
											<option value="q8_option4"><?php echo $test->q8_option4; ?></option>
										</select>
										<span class="q8-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										
										<?php echo $test->q9_question; ?>
										<select type="drop-down" style="width: 110px;" class="q9-sel-opt searchform" name="q9-response">
											<option value=""></option>
											<option value="q9_option1"><?php echo $test->q9_option1; ?></option>
											<option value="q9_option2"><?php echo $test->q9_option2; ?></option>
											<option value="q9_option3"><?php echo $test->q9_option3; ?></option>
											<option value="q9_option4"><?php echo $test->q9_option4; ?></option>
										</select>
										<span class="q9-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										
										<?php echo $test->q10_question; ?>
										<select type="drop-down" style="width: 110px;" class="q10-sel-opt searchform" name="q10-response">
											<option value=""></option>
											<option value="q10_option1"><?php echo $test->q10_option1; ?></option>
											<option value="q10_option2"><?php echo $test->q10_option2; ?></option>
											<option value="q10_option3"><?php echo $test->q10_option3; ?></option>
											<option value="q10_option4"><?php echo $test->q10_option4; ?></option>
										</select>
										<span class="q10-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
										
										</p>
									</div>
								</table>
							</form>
						</div>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
		</div>
		
		<?php } ?>
		<input type="hidden" name="token" value="<?php echo $this->uri->segment(3); ?>"/>
       <div class="page-title-wrapper fixed-width">
        <div class="otw-row page-title">
            <div class="otw-ten otw-columns"></div>		
        <div class="otw-four otw-columns">
			<?php if($testdetail->test_id==20){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls1_next_btn" data-screenid="2"><div class="submit" align="center">Next</div></a>
			<?php } else if($testdetail->test_id==29){ ?>
				<a href="javascript:void(0);" style="color:#fff" id="ls_practice_submit"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==19){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls2_next_btn" data-screenid="2"><div class="submit" align="center">Next</div></a>
			<?php } else if($testdetail->test_id==18){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls3_next_btn" data-screenid="2"><div class="submit" align="center">Next</div></a>
			<?php } else if($testdetail->test_id==17){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls4_next_btn" data-screenid="2"><div class="submit" align="center">Next</div></a>
			<?php } else if($testdetail->test_id==16){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls5_next_btn" data-screenid="2"><div class="submit" align="center">Next</div></a>	
			<?php } else if($testdetail->test_id==15){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls6_next_btn" data-screenid="2"><div class="submit" align="center">Next</div></a>	
			<?php } else if($testdetail->test_id==40){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd_practice_submit"><div class="submit" align="center">Submit</div></a>	
			<?php } else if($testdetail->test_id==39){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd1_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==38){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd2_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==37){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd3_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==36){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd4_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==47){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="wt1_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==46){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="wt2_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==59){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp_practice_submit"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==58){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp1_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==57){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp2_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==56){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp3_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==55){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp4_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==54){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp5_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==53){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp6_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==52){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp7_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==51){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp8_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php }else{ ?> 
				<!--a href="#"><div align="center">submit</div></a-->
			<?php } ?>
		</div>
        <div class="otw-ten otw-columns"></div>
          <!--<div class="otw-nineteen otw-columns">-->
           
                <!--input type="submit" title="Answer Key" name="submit" value="Answer Key"-->
            
          <!--</div>-->
         <!-- <div class="otw-five otw-columns">-->
            <!--<form action="#" method="get" role="search" class="searchform">
                <input type="submit" title="Back" name="submit" value="Back">
            </form>-->
          <!--</div>-->
        </div>
        
      </div>
    </div>
      </div>

    </div>

     <footer id="page-footer">
      
      <div class="otw-row copyright">
        <div class="otw-twelve otw-columns">
          
        </div>
        <div class="otw-twelve otw-columns text-right">
          <a href="#"><!--img src="images/logo-celpip-footer.png" title="celpip" alt=""/--></a>
           &copy; 2018-2019 All rights reserved.
        </div>
      </div>
    </footer>
  </div>
<script type="text/javascript">
	function show() { document.getElementById('area').style.display = 'block'; }
	function hide() { document.getElementById('area').style.display = 'none'; }
</script>
  <?php include_once('common/scripts.php'); ?>
  
  
<?php if($testdetail->test_id==59 || $testdetail->test_id==58 || $testdetail->test_id==57 || $testdetail->test_id==56 || $testdetail->test_id==55 || $testdetail->test_id==54 || $testdetail->test_id==53 || $testdetail->test_id==52 || $testdetail->test_id==51){ ?>

<?php if($testdetail->test_id==58){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 90;
</script>
<?php } ?>

<?php if($testdetail->test_id==57){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==56){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==55){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==54){?>
<script type="text/javascript">
	var preparationTime = 60;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==53){?>
<script type="text/javascript">
	var preparationTime = 60;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==52){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 90;
</script>
<?php } ?>

<?php if($testdetail->test_id==51){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>

<?php if($testdetail->test_id==59){?>
<script type="text/javascript">
	var preparationTime = 30;
	var recordingTime = 60;
</script>
<?php } ?>
<script src="../../uploads/mic/js/justmicrec_lib.js"></script>
<script type="text/javascript">
        $(document).ready(function () {
			var weburl = '<?php echo site_url(); ?>';
			//alert(recordingTime);

            // INITIALIZATION
            //$('#recn').val(new Date().getTime()); // unique id

              justMicRec.configure({
                //hostPath : '../../uploads/mic/micrecajax.php?f=' + $('#recn').val(),
				hostPath : '/micrecajax.php?f=' + $('#recn').val(),
                workerPath: '../../uploads/mic/js/justmicrecworker.js',

                // Callback functions
                recordingActivity: function(analyserNode, seconds) { activity(analyserNode, seconds); },
                recordingError: function(e) { console.log('[ERR] ' + e) },
                //recordingStopped: recordingStopped,
                WAVsendingFinished: sendingFinished,
                uploadingProcess: function(current, total){
                        uploading(Math.round(current / total * 100)); }
              });
			  
			  function sendingFinished()
              {
                console.log('!! Recording has been sent to server successfully!');
                // DONE :- save attempt row
                
                var fname = $("#recn").val()+'.wav';
				$(".response_file").html('<input type="hidden" id="sp_response_file" value="'+fname+'"/><audio controls><source src="'+ weburl +'uploads/attempt/'+fname+'" type="audio/mpeg"></audio>');
				$("#success-recording").hide();
                // change unique id and reconfigure path to new wav file
                //$('#recn').val(new Date().getTime());
                /* justMicRec.configure({
                  //hostPath : '../../uploads/mic/micrecajax.php?f=' + $('#recn').val()
                  hostPath : '/micrecajax.php?f=' + $('#recn').val()
                }); */
              }

              var canvas = document.getElementById('levelbar'),
                  canvasWidth = canvas.width,
                  canvasHeight = canvas.height,
                  analyserContext = canvas.getContext('2d');


              // analyserNode - node to recording data, time - seconds
              function activity(analyserNode, time)
              {
                // maxTime - global var
                // var time = maxTime - time;
                if (time < 0) time = 0;
                var min = Math.floor(time / 60),
                    sec = Math.floor(time % 60);

                $('#time').text((min < 10 ? "0" : "") + min + ":" + (sec < 10 ? "0" : "") + sec);
                
                // $('#level').text(level);

                updateAnalysers(analyserNode);
                updateAnalysers2(analyserNode); // second variant
              }

              function uploading(percent)
              {
                $('#levelbar2').width(percent + '%');
              }

              function updateAnalysers(analyserNode) {
                var SPACING = 3,
                    BAR_WIDTH = 1,
                    numBars = Math.round(canvasWidth / SPACING),
                    freqByteData = new Uint8Array(analyserNode.frequencyBinCount);

                analyserNode.getByteFrequencyData(freqByteData); 

                analyserContext.clearRect(0, 0, canvasWidth, canvasHeight);
                analyserContext.fillStyle = '#F6D565';
                analyserContext.lineCap = 'round';
                var multiplier = analyserNode.frequencyBinCount / numBars;

                  // Draw rectangle for each frequency bin.
                  for (var i = 0; i < numBars; ++i) {
                  var magnitude = 0;
                  var offset = Math.floor( i * multiplier );
                  // gotta sum/average the block, or we miss narrow-bandwidth spikes
                  for (var j = 0; j < multiplier; j++)
                     magnitude += freqByteData[offset + j];
                  magnitude = magnitude / multiplier;
                  var magnitude2 = freqByteData[i * multiplier];
                  analyserContext.fillStyle = "hsl( " + Math.round((i*360)/numBars) + ", 100%, 50%)";
                  analyserContext.fillRect(i * SPACING, canvasHeight, BAR_WIDTH, -magnitude);
                  }
              }

              function updateAnalysers2(analyserNode) {
                // OLED 
                var array = new Uint8Array(analyserNode.frequencyBinCount);
                analyserNode.getByteFrequencyData(array);
                var values = 0;

                var length = array.length;
                for (var i = 0; i < length; i++) {
                  values += array[i];
                }

                var average = values / length;
                $('#levelbar2').width(Math.min(parseInt(average * 2), 100) + '%');
              }
		});
		
	</script>
	
	  <script type="text/javascript">
		var audio_data;
        window.onload = function init() {
          try  {
            // Webkit shim
            window.AudioContext = window.AudioContext || window.webkitAudioContext;
            navigator.getUserMedia = ( navigator.getUserMedia ||
                             navigator.webkitGetUserMedia ||
                             navigator.mozGetUserMedia ||
                             navigator.msGetUserMedia);
            window.URL = window.URL || window.webkitURL;
            
            audio_data = new AudioContext;
            console.log('Audio context set up.');
            console.log('navigator.getUserMedia ' + (navigator.getUserMedia ? 'available.' : 'not present!'));
          
          } catch (e) {
            //alert('No web audio support in this browser!');
          }
          
          navigator.getUserMedia({audio: true}, initUserMedia, function(e) {
            console.log('No live audio input: ' + e);
            //alert('Your browser does not support the audio.');
          });
        };

        function initUserMedia(stream) {
          var input = audio_data.createMediaStreamSource(stream);
          //console.log('Media stream created.' );
          //console.log("input sample rate " +input.context.sampleRate);

          input.connect(audio_data.destination);
          console.log('Input connected to audio context destination.');

          $("#recordButton").removeClass("recordOff").addClass("recordOn");
          $("#recordHelp").fadeOut("slow");
          console.log('Recorder initialised.');
        }
	  
    $(document).ready(function () {
			setTimeout(function() {

			  // Check if browser support audio
			  if($('#recordButton').hasClass('recordOn')) {
				  
				$("#recording-message").show(); // Show recording alert
				mycounter('count', preparationTime); // Handle counter
				$("#recording-message").delay(preparationTime+'000').fadeOut(); // Hide message after 40s
				var playerTime = parseInt(preparationTime+'000') + parseInt(1000);
				//alert(playerTime);
				// Show the player after 41s
				// Start recording after 41s, for 40 seconds
				$("#player-block").delay(playerTime).fadeIn();

				setTimeout(function() {

				  // Show buffer message
				  $("#buffermsg").show();

				  setTimeout(function() { // 5 second buffer before recording

					// Hide buffer message
					$("#buffermsg").hide();
					var recordwaitInervaltime = parseInt(recordingTime+'000') + parseInt(1000);
					var maxTime = recordingTime;
					mycounter('countresult', maxTime); // Start Time
					//startRecording();
					//alert(recordwaitInervaltime);
					console.log('*log: recording started (' + maxTime + ')');
					justMicRec.start(maxTime);

					setTimeout(function() {
					  // stop recording
					  // hide player block
					  // show success recording block
					  //stopRecording();
					  console.log('log: recording stopped');
					  $('#level').text('');
					  justMicRec.sendWAV();

					  $("#player-block").hide();
					  $("#success-recording").show();

					}, recordwaitInervaltime);

				  }, 5000);

				}, playerTime);



			  } else {

				// Show message to user , that your browser not support audio
				$("#audio-block").delay(1000).fadeIn();
			  }

		}, 2000);
		
		function mycounter(elementId, seconds) {

			var counter = seconds;
			setInterval(function() {
			  counter--;
			  if (counter >= 0) {
				span = document.getElementById(elementId);
				span.innerHTML = counter;
			  } else {
				document.getElementById(elementId).style.display = "none";
			  }
			  // Display 'counter' wherever you want to display it.
			  if (counter === 0) {
				  clearInterval(counter);
			  }
			}, 1000);
        }
	});
</script>
<?php } ?>

<?php if($testdetail->test_id==29){ ?>
<script type="text/javascript">
var timeLeft = 30;
var elem = document.getElementById('timer_div');
var timerId = setInterval(countdown, 1000);
function countdown() {
  if (timeLeft == 0) {
	clearTimeout(timerId);
	elem.innerHTML = timeLeft + ' seconds remaining';
	$("#ls_practice_submit").trigger("click");
  } else {
	elem.innerHTML = timeLeft + ' seconds remaining';
	timeLeft--;
  }
}
</script>
<?php } ?>

<script type="text/javascript">
function setTimer(val,button,is_submit){
	var timeLeft = val;
	var elem = document.getElementById('timer_div');
	var timerId = setInterval(countdown, 1000);
	function countdown() {
	  if (timeLeft == 0) {
		clearTimeout(timerId);
		elem.innerHTML = timeLeft + ' seconds remaining';
		if(is_submit==1){
			$("#"+button).trigger("click");
		}else{
			alert('Next tab');
		}
	  } else {
		elem.innerHTML = timeLeft + ' seconds remaining';
		timeLeft--;
	  }
	}
}

$(document).ready(function() {
	$("#wt_q2_response").on('keydown', function(e) {
        var words = $.trim(this.value).length ? this.value.match(/\S+/g).length : 0;
		$('#display_count').text(words);
    });
    $("#wt_q1_response").on('keydown', function(e) {
        var words = $.trim(this.value).length ? this.value.match(/\S+/g).length : 0;
		$('#display_count').text(words);
        /* if (words <= 200) {
            $('#display_count').text(words);
            //$('#word_left').text(200-words)
        }else{
            if (e.which !== 8) e.preventDefault();
        } */
    });
}); 
</script> 
</body>
</html>