<div class="row">
  <div class="col-md-12">
    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $alreadyAttempt->time); ?></span>
    <hr />
    <?php
      $opt = json_decode($alreadyAttempt->json_result, true);
      $yourOption = $opt['myresponse'];
    ?>

    <table class="table" style="font-size: 18px;">	  
	    <?php
			$options = array('1'=>$objQuestion->q1_option1,'2'=>$objQuestion->q1_option2,'3'=>$objQuestion->q1_option3,'4'=>$objQuestion->q1_option4);
	    ?>
        <?php $i=1; foreach ($options as $key=>$objOption) { ?>
		<tr>
            <td>

            <?php
              $rightOption = '';
              $iconStyle = '';

              if($objQuestion->q1_answere==$key) {

                $rightOption = 'style="color:green;font-weight:bold;"';

                if($yourOption == $key) {
                  $iconStyle = '<i class="fa fa-check" style="color:green;"></i>';
                }
              } else {

                if($yourOption == $key) {
                  $iconStyle = '<i class="fa fa-times" style="color:red;"></i>';
                }
              }
            ?>
            <span <?php echo $rightOption; ?>><?php echo $objOption; ?></span>
            <?php echo $iconStyle; ?>

          </td>
        </tr>

      <?php $i++; } ?>
    </table>
  </div>

</div>