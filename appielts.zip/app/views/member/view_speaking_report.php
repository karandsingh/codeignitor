<!DOCTYPE html>
<html>
<head>
	<title>celpip : Canadian English Language Proficiency Index Program</title>
	  <?php include_once('common/head.php'); ?>
<style type="text/css">
  .scrollbar
{
  margin-left: -10px;
  float: left;
  height: 500px;
  width: 100%;
  background: #F5F5F5;
  overflow-y: scroll;
  margin-bottom: 25px;
}
.scrollbar1
{
  margin-left: 10px;
  float: left;
  height: 500px;
  width: 100%;
  background: #F5F5F5;
  overflow-y: scroll;
  margin-bottom: 25px;
}
.force-overflow
{
  min-height: 450px;
}
#wrapper
{
  text-align: left;
  width: 500px;
  margin: auto;
}
p {
  padding: 15px;
}
h2 {
  padding: 15px;
}
@media only screen and (max-width: 600px) {
  .scrollbar1 {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 600px) {
  .scrollbar {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
}
}
.otw-row .b {
border: 1px solid #eee;
padding-top: 5px;
padding-bottom: 5px;
}
</style>
</head>
<body class="inner">
<div class="page-wrapper">
    <div id="page-content">
      <header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip</h1>
              <a href="<?php echo base_url('member/dashboard'); ?>"><!--font size="20px"><strong>CELPIP</strong></font--><img src="images/logo-celpip.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            <?php
				      $attempt_data = json_decode($attempt->json_result, true);
				      //echo "<pre>";print_r($attempt_data);die;
			      ?>
          </div>
        </div>
      </header>

      <div class="page-title-wrapper fixed-width">
        <div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1><?php 
        if($testdetail->test_id==61){
          echo 'Speaking Task 1: Talking about a Personal Experience';
        }else{
          echo '';
        } ?>
      </h1>
            
          </div>
        </div>
      </div>

      <div class="otw-row sp-part6 sp-part6-screen-1">
      <div class="otw-twentyfour otw-columns">
        <div style="background-color: #eee;border-radius: 10px;"><p align="center"><?php echo $test->q1_question; ?></p></div>
        
        <p align="center">
          <div class="response_file">
            <label><b>Student Answer</b></label>
            <?php
            foreach ($attempt_data['response_data'] as $key => $attemptArray) {  ?>
            <audio controls>
              <source src="<?php echo base_url(); ?>uploads/attempt/<?php echo $attemptArray['sp_response_file'];?>" type="audio/ogg">
            </audio>
            <?php } ?>
          </div>
        </p>
        <hr>
          <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label>Marks</label>
                  <input type="text" class="form-control" placeholder="marks" name="marks" value="<?php echo set_value('marks',$marksAssigned[0]->marks); ?>" required readonly>
                </div>
              </div>

              <div class="col-md-12">
                <div class="form-group">
                  <label>Teacher Remarks</label>
                  <textarea class="form-control" placeholder="remarks" name="remarks" required readonly><?php echo set_value('remarks',$marksAssigned[0]->remarks); ?> </textarea>
                </div>
              </div>
              
              <div class="col-md-12">
                <div class="form-group">
                  <?php  if(empty($marksAssigned)){?>
                    <button type="submit" class="">Save</button>
                  <?php } ?>
                </div>
              </div>
            </div>

        <div class="otw-sc-hr"></div>
      </div>
    </div>

    </div>

     <footer id="page-footer">
      
      <div class="otw-row copyright">
        <div class="otw-twelve otw-columns">
          
        </div>
        <div class="otw-twelve otw-columns text-right">
          <a href="#"></a>
           &copy; 2020 All rights reserved.
        </div>
      </div>
    </footer>
</div>
</body>
</html>