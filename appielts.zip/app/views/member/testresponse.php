
              <?php if($subtype->id == '41') { // Read Aloud ?>

                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <?php echo nl2br($qExtra->paragraph); ?>
                  </div>
                </div>






              <?php } elseif($subtype->id == '42') { // Repeat Sentence ?>

                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Your Response
                    <br />
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/pte/Speaking/'.$qExtra->mp3URL); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Original Sentence
                  </div>
                </div>




              <?php } elseif($subtype->id == '43') { // Describe Image ?>

                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <?php $imagefile = base_url('uploads/pte/Speaking/'.$qExtra->SDimage); ?>
                    <img src="<?php echo $imagefile; ?>" class="img-responsive" alt="photo">
                  </div>
                </div>



              <?php } elseif($subtype->id == '44') { // Re-tell lecture ?>


                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Your Response
                    <br />
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/pte/Speaking/'.$qExtra->mp3URL); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Original Lecture
                    <hr />
                    <?php $imagefile = base_url('uploads/pte/Speaking/'.$qExtra->imageURL); ?>
                    <img src="<?php echo $imagefile; ?>" class="img-responsive" alt="photo">
                  </div>
                </div>







              <?php } elseif($subtype->id == '45') { // Answer short question ?>

                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Your Response
                    <br />
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/pte/Speaking/'.$qExtra->mp3URL); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Original Sentence
                  </div>
                </div>







              <?php } elseif($subtype->id == '46') { // Summarize written text ?>

                <div class="row">
                  <div class="col-md-12">

                    <?php echo nl2br($qExtra->essay); ?>
                    <hr/>
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $lecture = json_decode($attempt->json_result, true);
                        echo nl2br($lecture['myresponse']);
                      ?>
                    <hr/>
                    
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>

                  </div>
                </div>



              <?php } elseif($subtype->id == '47') { // Write Essay ?>

                <div class="row">
                  <div class="col-md-12">

                    <?php echo nl2br($qExtra->essayTitle); ?>
                    <hr/>
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $lecture = json_decode($attempt->json_result, true);
                        echo nl2br($lecture['myresponse']);
                      ?>
                    <hr/>
                    
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>

                  </div>
                </div>





              <?php } elseif($subtype->id == '28') { // Summarize spoken text ?>


                <div class="row">
                  <div class="col-md-12">

                    <?php $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $lecture = json_decode($attempt->json_result, true);
                        echo nl2br($lecture['myresponse']);
                      ?>
                    <hr/>
                    
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>

                  </div>
                </div>





              <?php } elseif($subtype->id == '29') { // Multiple-choice: Single ?>


                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '20') { ?>

                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '19') { ?>

                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '18') { ?>

                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '17') { ?>

                <div class="row">
                  <div class="col-md-12 text-center">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>

              <?php } elseif($subtype->id == '16') { ?>

                <div class="row">
                  <div class="col-md-12 text-center">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>

              <?php } elseif($subtype->id == '15') { ?>

                <div class="row">
                  <div class="col-md-12 text-center">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>




              <?php } elseif($subtype->id == '30') { // Multiple-choice: Multiple ?>


                <div class="row">
                  <div class="col-md-6">

                    <?php $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr />
                    <?php /*
                    <h3><?php echo $qExtra->optiontitle; ?></h3>
                    */ ?>
                    <table class="table" style="font-size: 16px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>
                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <hr />

                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $optArr = explode(',', $youOpt);
                        foreach ($optArr as $optNumber) {
                          $myresponse = 'option'.$optNumber;
                          echo $qExtra->$myresponse;
                          echo '<hr />';
                        }
                      ?>

                      <strong>Correct Answer</strong> :
                      <hr />
                      <?php

                        $optArr = explode(',', $qExtra->answer);
                        foreach ($optArr as $optNumber) {
                          $rightOpt = 'option'.$optNumber;
                          echo $qExtra->$rightOpt;
                          echo '<hr />';
                        }
                      ?>

                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '31') { // Fill in the blanks ?>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="stextfield"></span>';
                          $totalBlanks = substr_count($qExtra->transcription, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->transcription));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANK'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANK'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="stextfield"></span>';
                          $totalBlanks = substr_count($qExtra->transcription, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->transcription));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANK'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANK'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>






              <?php } elseif($subtype->id == '32') { // Highlight correct summary ?>


                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>



              <?php } elseif($subtype->id == '33') { // Select missing word ?>


                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>


              <?php } elseif($subtype->id == '34') { // Highlight incorrect words ?>


                <div class="row">
                  <div class="col-md-12">
                    <?php $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                    <hr/>
                  </div>
                </div>


                <div class="row">
                  <div class="col-md-6">
                      <strong>Correct Answer</strong> :
                      <br />
                      <?php
                        echo nl2br($qExtra->transcription);
                      ?>
                      <style type="text/css">
                        .icorrectw {
                          background-color: green;
                          color: white;
                          padding: 2px;
                        }
                      </style>
                  </div>
                  <div class="col-md-6">
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $wordList = json_decode($attempt->json_result, true);
                        echo nl2br($wordList['myresponse']);
                      ?>
                      <style type="text/css">
                        .mySelected {
                          background-color: green;
                          color: white;
                          padding: 2px;
                        }
                      </style>
                  </div>
                </div>




              <?php } elseif($subtype->id == '35') { // Write from dictation ?>

                <div class="row">
                  <div class="col-md-12">

                    <?php $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $lecture = json_decode($attempt->json_result, true);
                        echo nl2br($lecture['myresponse']);
                      ?>
                    <hr/>
                    
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>

                  </div>
                </div>



              <?php } elseif($subtype->id == '36') { // Multiple Fill in the blanks ?>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>



              <?php } elseif($subtype->id == '37') { // Fill in the blanks ?>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="stextfield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANK'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANK'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="stextfield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANK'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANK'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>



              <?php } elseif($subtype->id == '38') { // Re-order paragraphs ?>

                <div class="row">
                  <div class="col-md-6">
                    <h3>Right Order</h3>

                    <hr/ ><?php echo nl2br($qExtra->option1); ?>
                    <hr/ ><?php echo nl2br($qExtra->option2); ?>
                    <hr/ ><?php echo nl2br($qExtra->option3); ?>
                    <hr/ ><?php echo nl2br($qExtra->option4); ?>
                    <hr/ ><?php echo nl2br($qExtra->option5); ?>

                  </div>

                  <div class="col-md-6">
                    <h3>Your Response</h3>

                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $optArr = explode(',', $youOpt);
                        foreach ($optArr as $optNumber) {
                          echo '<hr />';
                          $myresponse = 'option'.$optNumber;
                          echo $qExtra->$myresponse;
                        }
                      ?>


                  </div>

                </div>



              <?php } elseif($subtype->id == '39') { // Multiple-choice: Multiple ?>


                <div class="row">
                  <div class="col-md-6">
                    <?php echo nl2br($qExtra->paragraph); ?>
                  </div>
                  <div class="col-md-6">
                    <h3><?php echo $qExtra->optiontitle; ?></h3>
                    <table class="table" style="font-size: 16px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                    <br />
                    <hr/>
                      <strong>Your Response</strong> :
                      <hr />

                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $optArr = explode(',', $youOpt);
                        foreach ($optArr as $optNumber) {
                          $myresponse = 'option'.$optNumber;
                          echo $qExtra->$myresponse;
                          echo '<hr />';
                        }
                      ?>

                    <hr/>
                      <strong>Right Option</strong> :
                      <hr />
                      <?php

                        $optArr = explode(',', $qExtra->answer);
                        foreach ($optArr as $optNumber) {
                          $rightOpt = 'option'.$optNumber;
                          echo $qExtra->$rightOpt;
                          echo '<hr />';
                        }
                      ?>

                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>









              <?php } elseif($subtype->id == '40') { // Multiple-choice: Single ?>


                <div class="row">
                  <div class="col-md-6">
                    <?php echo nl2br($qExtra->paragraph); ?>
                  </div>
                  <div class="col-md-6">
                    <h3><?php echo $qExtra->optiontitle; ?></h3>
                    <table class="table" style="font-size: 16px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                    <br />
                    <hr/>
                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Right Option</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>



              <?php } ?>