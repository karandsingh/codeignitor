<!doctype html>
<html lang="en">
<head>
<title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
  <style type="text/css">
    .widget-user .widget-user-header {
      padding: 15px;
      height: 90px;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
    }
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">

    <section class="content-header">
      <h1>
        Spotting the Errors Tests
      </h1>
      <ol class="breadcrumb">
        <li><a><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <div class="alert alert-info alert-dismissible" >
            <strong>Note : </strong> If you are new to take this test please Click on <strong>Start it </strong> button to start new test . You can also Resume test , check your Results and re-attempt.   
          </div>

          <div class="box">
            <div class="box-header">
              <div class="box box-widget widget-user">
                <div class="widget-user-header bg-purple">

                    

                    <h3 class="widget-user-username"><STRONG> <p class="fa fa-desktop"></p> <?php echo $pagetitle; ?>  </STRONG></h3>
                    <span class="pull-right">
                      <a class="btn btn-danger btn-md spottingErrors-show-instructions"><i class="fa fa-hand-o-right" ></i> Start It</a>
                      <a id="" class="btn btn-default btn-md" href="<?php echo base_url($currentPath.'/tests'); ?>">Back</a>
                    </span>
                    <h5 class="widget-user-desc"> 
                    <strong>Questions</strong> : <?php echo $total_questions; ?>
                    </h5>
					<h5 class="widget-user-desc"> 
                    <strong>Coin Cost</strong> : <?php echo $coin_cost; ?>
                    </h5>

                </div>
              </div>
            </div>

            <div class="box-body">


                <h3>Test History</h3>
                <hr />
				<div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Taken Date</th>
                      <th>Attempted / Pending</th>
                      <th>Total Questions</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php
                      $ctrr = 0;
                      foreach ($history as $objTestdetail) {

                        $ctrr ++;

                        $where = "memberid = '".$user->id."' AND testdetail_id = '".$objTestdetail->id."' ";

                        $alreadyAttempt = $this->my_model->getWhereOrderRecords('system_spotting_errors_attempt_code', $where, 'id', 'ASC');

                        $attemptedQuestions = count($alreadyAttempt);
                        $pending = $total_questions - $attemptedQuestions;

                        $testLink = base_url('member/spottingErrorsTestprogress/'.$objTestdetail->id_md5.'/'.md5($test->id));

                        $btnText = '<a href="'.$testLink.'" class="btn btn-success">View Result</a>';
                        if($pending) {
                          $btnText = '<a href="'.$testLink.'" class="btn btn-primary">Resume Test </a>';
                        }
                      ?>
                      <tr>
                        <td><?php echo $ctrr; ?></td>
                        <td><?php echo date('M d,  Y h:i A', $objTestdetail->time); ?></td>
                        <td><?php echo $attemptedQuestions; ?> / <?php echo $pending; ?></td>
                        <td><?php echo $total_questions; ?></td>
                        <td>
                          <?php echo $btnText; ?>
                        </td>
                      </tr>

                    <?php } ?>

                  </tbody>
                </table>
				</div>




            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>

  <?php include_once('spottingErrorsmodals.php'); ?>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>