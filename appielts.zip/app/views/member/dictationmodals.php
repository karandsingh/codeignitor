<div id="dictation-instructions" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="box box-solid">
          <div class="box-body">
            <h3 class="text-center"><u>Instructions - Dictation Test</u></h3>
			<?php if($this->session->flashdata('global_msg')){ ?>
				 <div class="alert alert-success">
				  <button class="close" type="button" data-dismiss="alert">
					<span aria-hidden="true">&times;</span>
				  </button>
				  <?=$this->session->flashdata('global_msg')?>
				</div>
			<?php } ?>
			<div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
            <div class="alert alert-warning alert-dismissible" >
              <i class="glyphicon glyphicon-warning-sign"></i>
              Please Read all instructions carefully before you begin . 
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <ul>
              <li>Every instruction pertaining to set of questions must be read carefully and answer as expected.</li>
              <li>Dictation Test contains only MCQs.</li>
              <li>Each question of Dictation Test is of 60 seconds duration, so target your answers under the given time.</li>
              <li>You can see questions one by one.</li>
            </ul>
          </div>
        </div>
        <div class="text-center">
          <button type="button" class="btn btn-primary" id="dictation-test-submit" data-testid="<?php echo $test->id; ?>" data-memberid="<?php echo $user->id; ?>">Start Test Now</button>
        </div>
      </div>
    </div>
  </div>
</div>