<!DOCTYPE html>
<html>
<head>
	<title>celpip : Canadian English Language Proficiency Index Program</title>
	  <?php include_once('common/head.php'); ?>
<style type="text/css">
  .scrollbar
{
  margin-left: -10px;
  float: left;
  height: 500px;
  width: 100%;
  background: #F5F5F5;
  overflow-y: scroll;
  margin-bottom: 25px;
}
.scrollbar1
{
  margin-left: 10px;
  float: left;
  height: 500px;
  width: 100%;
  background: #F5F5F5;
  overflow-y: scroll;
  margin-bottom: 25px;
}
.force-overflow
{
  min-height: 450px;
}
#wrapper
{
  text-align: left;
  width: 500px;
  margin: auto;
}
p {
  padding: 15px;
}
h2 {
  padding: 15px;
}
@media only screen and (max-width: 600px) {
  .scrollbar1 {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 600px) {
  .scrollbar {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
}
}
.otw-row .b {
border: 1px solid #eee;
padding-top: 5px;
padding-bottom: 5px;
}
</style>
</head>
<body class="inner">
<div class="page-wrapper">
    <div id="page-content">
      <header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip</h1>
              <a href="<?php echo base_url('member/dashboard'); ?>"><!--font size="20px"><strong>CELPIP</strong></font--><img src="images/logo-celpip.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            <?php
				      $attempt_data = json_decode($attempt->json_result, true);
				      //echo "<pre>";print_r($attempt_data);die;
			      ?>
          </div>
        </div>
      </header>

      <div class="page-title-wrapper fixed-width">
        <div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1>Reading Section Wise Test</h1>
          </div>
        </div>
      </div>
      
      <!---Listening Report--> 
      <div class="otw-row main-content">
        <div class="otw-twentyfour otw-columns otw-content-section">
               <div class="container1">
                 <div class="otw-row">
                   <div class="otw-columns">
                     <font size="2px" color="#fff" style="background-color: red;border: 1px solid red;border-radius: 10px;">&nbsp;&nbsp; Note &nbsp;&nbsp;</font>
                   </div>
                   <div class="otw-columns">
                     <p>Use the back arrow in your browser to return to the page you just came from.<br> The back arrow is located at the top left of your screen, next to the address bar. </p>
                   </div>
                 </div>
				 <div class="table-responsive">
					<table class="table table-hover table-bordered table-stripedx" id="example1">
					  <thead>
						<tr>
						  <th>Question</th>
						  <th>Your Answer</th>
						  <th>Answer Key</th>
						</tr>
					  </thead>
					  <tbody>
					<?php 
          //echo "<pre>";print_r($attempt_data);die;
          foreach ($attempt_data as $key => $attempt_data_value) {
            
          foreach($attempt_data_value['response_data'] as $key=>$response_row){
						
					?>
					<tr>
						<td><?php echo $response_row['q_number']; ?></td> 
					    <?php if($response_row['q_response_type'] == 'image') { //uploads/part1_listening ?>
							<td><img width="100" height="100" style="border-radius:5px;" src="<?php echo base_url('uploads/part1_listening/').$response_row['q_response_val']; ?>"/></td>
							<td><img width="100" height="100" style="border-radius:5px;" src="<?php echo base_url('uploads/part1_listening/').$response_row['q_right_option_val']; ?>"/></td>
					   <?php }else{ ?>
							<td><?php echo $response_row['q_response_val']; ?></td>
							<td><?php echo $response_row['q_right_option_val']; ?></td>
					   <?php } ?>
					</tr>
					<?php }} ?>
						<tr>
							<td colspan="3"><a href="<?php echo base_url('member/getSectionReading/').$attempt_data['test_id']; ?>">Return to List</a></td>
						</tr>
					  </tbody>
					</table>
          </div>
          </div>
        </div>
      </div>
    </div>

     <footer id="page-footer">
      
      <div class="otw-row copyright">
        <div class="otw-twelve otw-columns">
          
        </div>
        <div class="otw-twelve otw-columns text-right">
          <a href="#"><img src="images/logo-celpip-footer.png" title="celpip" alt=""/></a>
           &copy; 2018 All rights reserved.
        </div>
      </div>
    </footer>
</div>
</body>
</html>