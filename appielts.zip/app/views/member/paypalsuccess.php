<!DOCTYPE html>
<html>
<head>
    <title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>
<style>
    img, .school-banner {
    max-width: 100%;
    height: 90px;
}
</style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

 
    <?php include_once('common/nav.php'); ?>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>
    <div class="content-wrapper"> 
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="col-lg-12">
    							<?php if($this->session->flashdata('global_msg')){ ?>
		    					    <div class="alert alert-success">
			     					  <button class="close" type="button" data-dismiss="alert">
			    						<span aria-hidden="true">&times;</span>
			  					  	  </button>
		  					  		  <?=$this->session->flashdata('global_msg')?>
		     					    </div>
    				            <?php } ?>
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>
    <?php include_once('common/scripts.php'); ?>
</body>
</html>>