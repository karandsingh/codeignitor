<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
	function sectionReadingInstructions(testId,memberId){
		//alert(testId+' '+memberId);
		$('#section-reading-instructions').modal('show');
		testName = 'Reading Section Wise Details';
		coinCost = '270';

		$("#section-reading-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions - '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>Please Read all instructions carefully before you begin .<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li>'+coinCost+' coins will be deducted from your account for this test Start test now!</li></ul></div></div><div style="font-size:15px;margin-bottom: 15px;">CELPIPSTORE aims to provide the students with real-exam experience for ultimate preparation, yet there may be certain ways in which the actual test may differ from our practice tests. However, we always welcome our users to give suggestions for improvement through Support.</div><div class="text-center"><button type="button" class="btn btn-danger allow-reading-section-wise-submit" data-testid="'+testId+'" data-memberid="'+memberId+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
	}

	function sectionListeningInstructions(testId,memberId){
		//alert(testId+' '+memberId);
		//return false;

		$('#section-listening-instructions').modal('show');
		testName = 'Listening Section Wise Details';
		coinCost = '310';

		$("#section-listening-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions - '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>Please Read all instructions carefully before you begin .<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li>'+coinCost+' coins will be deducted from your account for this test Start test now!</li></ul></div></div><div style="font-size: 15px;margin-bottom: 15px;text-align: justify;">CELPIPSTORE aims to provide the students with real-exam experience for ultimate preparation, yet there may be certain ways in which the actual test may differ from our practice tests. However, we always welcome our users to give suggestions for improvement through Support.</div><div class="text-center"><button type="button" class="btn btn-danger allow-section-wise-submit" data-testid="'+testId+'" data-memberid="'+memberId+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
	}

	function partInstructions(testId,memberId,testCode){

		$('#part-instructions').modal('show');
		if(testId==20){
			testName = 'Listening Part 1: Listening to Problem Solving';
			coinCost = '100';
		}else if(testId==29){
			testName = 'Listening Practice Task Questions:';
			coinCost = '15';
		}else if(testId==19){
			testName = 'Listening Part 2: Listening to Daily Life Conversation:';
			coinCost = '100';
		}else if(testId==18){
			testName = 'Listening Part 3: Listening for Information:';
			coinCost = '100';
		}else if(testId==17){
			testName = 'Listening Part 4: Listening to a News Item';
			coinCost = '100';
		}else if(testId==16){
			testName = 'Listening Part 5: Listening to a Discussion';
			coinCost = '100';
		}else if(testId==15){
			testName = 'Listening Part 6: Listening to Viewpoints';
			coinCost = '100';
		}else if(testId==47){
			testName = 'Writing Task 1: Writing an Email Details';
			coinCost = '300';
		}else if(testId==46){
			testName = 'Writing Task 2: Responding to Survey Questions';
			coinCost = '300';
		}else if(testId==59){
			testName = 'Speaking: Practice Task';
			coinCost = '200';
		}else if(testId==58){
			testName = 'Speaking Task 1: Giving Advice ';
			coinCost = '200';
		}else if(testId==57){
			testName = 'Speaking Task 2: Talking about a Personal Experience';
			coinCost = '200';
		}else if(testId==56){
			testName = 'Speaking Task 3: Describing a Scene';
			coinCost = '200';
		}else if(testId==55){
			testName = 'Speaking Task 4: Making Predictions';
			coinCost = '200';
		}else if(testId==54){
			testName = 'Speaking Task 5: Comparing and Persuading';
			coinCost = '200';
		}else if(testId==53){
			testName = 'Speaking Task 6: Dealing with a Difficult Situation';
			coinCost = '200';
		}else if(testId==52){
			testName = 'Speaking Task 7: Expressing Opinions';
			coinCost = '200';
		}else if(testId==51){
			testName = 'Speaking Task 8: Describing an Unusual Situation';
			coinCost = '200';
		}else if(testId==40){
			testName = 'Reading Practice Task';
			coinCost = '15';
		}else if(testId==39){
			testName = 'Reading Part 1: Reading Correspondence';
			coinCost = '150';
		}else if(testId==38){
			testName = 'Reading Part 2: Reading to Apply a Diagram';
			coinCost = '150';
		}else if(testId==37){
			testName = 'Reading Part 3: Reading for Information';
			coinCost = '150';
		}else if(testId==36){
			testName = 'Reading Part 4: Reading for Viewpoints';
			coinCost = '150';
		}else{
			testName = '';
			coinCost = '';
		}

		$("#part-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions - '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>Please Read all instructions carefully before you begin .<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li>'+coinCost+' coins will be deducted from your account for this test Start test now!</li></ul></div></div><div style="font-size: 15px;margin-bottom: 15px;">CELPIPSTORE aims to provide the students with real-exam experience for ultimate preparation, yet there may be certain ways in which the actual test may differ from our practice tests. However, we always welcome our users to give suggestions for improvement through Support.</div><div class="text-center"><button type="button" class="btn btn-danger allow-test-submit" data-testid="'+testId+'" data-memberid="'+memberId+'" data-testcode="'+testCode+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
	}
function partWithTimerInstructions(testId,memberId,testCode){
		$('#part-instructions').modal('show');
		if(testId==20){
			testName = 'Listening Part 1: Listening to Problem Solving';
			coinCost = '100';
		}else if(testId==29){
			testName = 'Listening Practice Task Questions:';
			coinCost = '15';
		}else if(testId==19){
			testName = 'Listening Part 2: Listening to Daily Life Conversation:';
			coinCost = '100';
		}else if(testId==18){
			testName = 'Listening Part 3: Listening for Information:';
			coinCost = '100';
		}else if(testId==17){
			testName = 'Listening Part 4: Listening to a News Item';
			coinCost = '100';
		}else if(testId==16){
			testName = 'Listening Part 5: Listening to a Discussion';
			coinCost = '100';
		}else if(testId==15){
			testName = 'Listening Part 6: Listening to Viewpoints';
			coinCost = '100';
		}else if(testId==47){
			testName = 'Writing Task 1: Writing an Email Details';
			coinCost = '300';
		}else if(testId==46){
			testName = 'Writing Task 2: Responding to Survey Questions';
			coinCost = '300';
		}else if(testId==59){
			testName = 'Speaking: Practice Task';
			coinCost = '200';
		}else if(testId==58){
			testName = 'Speaking Task 1: Giving Advice ';
			coinCost = '200';
		}else if(testId==57){
			testName = 'Speaking Task 2: Talking about a Personal Experience';
			coinCost = '200';
		}else if(testId==56){
			testName = 'Speaking Task 3: Describing a Scene';
			coinCost = '200';
		}else if(testId==55){
			testName = 'Speaking Task 4: Making Predictions';
			coinCost = '200';
		}else if(testId==54){
			testName = 'Speaking Task 5: Comparing and Persuading';
			coinCost = '200';
		}else if(testId==53){
			testName = 'Speaking Task 6: Dealing with a Difficult Situation';
			coinCost = '200';
		}else if(testId==52){
			testName = 'Speaking Task 7: Expressing Opinions';
			coinCost = '200';
		}else if(testId==51){
			testName = 'Speaking Task 8: Describing an Unusual Situation';
			coinCost = '200';
		}else if(testId==40){
			testName = 'Reading Practice Task';
			coinCost = '15';
		}else if(testId==39){
			testName = 'Reading Part 1: Reading Correspondence';
			coinCost = '150';
		}else if(testId==38){
			testName = 'Reading Part 2: Reading to Apply a Diagram';
			coinCost = '150';
		}else if(testId==37){
			testName = 'Reading Part 3: Reading for Information';
			coinCost = '150';
		}else if(testId==36){
			testName = 'Reading Part 4: Reading for Viewpoints';
			coinCost = '150';
		}else{
			testName = '';
			coinCost = '';
		}

		$("#part-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions - '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>&nbsp;&nbsp;Please Read all instructions carefully before you begin .<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li style="color:red;">The test will be Auto-submitted once the time is over</li><li>'+coinCost+' coins will be deducted from your account for this test Start test now!</li></ul></div></div></div><div style="font-size: 15px;margin-bottom: 15px;">CELPIPSTORE aims to provide the students with real-exam experience for ultimate preparation, yet there may be certain ways in which the actual test may differ from our practice tests. However, we always welcome our users to give suggestions for improvement through Support.</div><div class="text-center"><button type="button" class="btn btn-danger allow-timer-test-submit" data-testid="'+testId+'" data-memberid="'+memberId+'" data-testcode="'+testCode+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
	}
  $(function () {

  $('.q1-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
	  $(this).next(".q1-sel-opt-text").show();
	  $(this).next(".q1-sel-opt-text").html('<b>'+ optionsText+'</b>');
      $(this).hide();
  });

  $(".q1-sel-opt-text").on('click',function(){
    $(this).hide();
	$(this).prev().show();
  });

  $('.q2-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q2-sel-opt-text').show();
     $(this).next(".q2-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q2-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

  $('.q3-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q3-sel-opt-text').show();
     $(this).next(".q3-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q3-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

  $('.q4-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q4-sel-opt-text').show();
     $(this).next(".q4-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q4-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

  $('.q5-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q5-sel-opt-text').show();
     $(this).next(".q5-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q5-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

  $('.q6-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q6-sel-opt-text').show();
     $(this).next(".q6-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q6-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

  $('.q7-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q7-sel-opt-text').show();
     $(this).next(".q7-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q7-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

  $('.q8-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q8-sel-opt-text').show();
     $(this).next(".q8-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q8-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

  $('.q9-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q9-sel-opt-text').show();
     $(this).next(".q9-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q9-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

  $('.q10-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q10-sel-opt-text').show();
     $(this).next(".q10-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q10-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

  $('.q11-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q11-sel-opt-text').show();
     $(this).next(".q11-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });

  $(".q11-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });

    var weburl = '<?php echo site_url(); ?>';

    // Token protection for ajax request
    $.ajaxSetup({ data: {
      '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
    }});

    //$("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });

  $('.fillBlanks-show-instructions').click(function(){
      $('#fillBlanks-instructions').modal('show');
    });

  $('#fillBlanks-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var memberid = $(this).attr('data-memberid');
      $.ajax({
        type: "POST",
        url: weburl + "member/startfillBlankstest/",
        data: {
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/fillBlanksTestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#fillBlanks-test-submit').prop('disabled', false);
          $('#fillBlanks-test-submit').html('Start Test Now');
        }
      });
    });


  $('.spottingErrors-show-instructions').click(function(){
      $('#spottingErrors-instructions').modal('show');
    });

  $('#spottingErrors-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var memberid = $(this).attr('data-memberid');
      $.ajax({
        type: "POST",
        url: weburl + "member/startSpottingErrorstest/",
        data: {
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/spottingErrorsTestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#spottingErrors-test-submit').prop('disabled', false);
          $('#spottingErrors-test-submit').html('Start Test Now');
        }
      });
    });


    $('.v-show-instructions').click(function(){
      $('#v-instructions').modal('show');
    });

    $('#v-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/startnewvtest/",
        data: {
          testid: testid,
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/vtestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#v-test-submit').prop('disabled', false);
          $('#v-test-submit').html('Start Test Now');
        }
      });
    });

  $('.reArrange-show-instructions').click(function(){
    $('#reArrange-instructions').modal('show');
  });

  $('#reArrange-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var memberid = $(this).attr('data-memberid');
      $.ajax({
        type: "POST",
        url: weburl + "member/startreArrangetest/",
        data: {
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/reArrangeTestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#reArrange-test-submit').prop('disabled', false);
          $('#reArrange-test-submit').html('Start Test Now');
        }
      });
    });


  $('.dictation-show-instructions').click(function(){
    $('#dictation-instructions').modal('show');
  });

  $('#dictation-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/startDictationtest/",
        data: {
          testid: testid,
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/dictationTestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#dictation-test-submit').prop('disabled', false);
          $('#dictation-test-submit').html('Start Test Now');
        }
      });
    });



    $('.show-instructions').click(function(){
      $('#instructions').modal('show');
    });

    $('#test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/startnewtest/",
        data: {
          testid: testid,
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testprogress/' + data.tdcode + '/' + data.tcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#test-submit').prop('disabled', false);
          $('#test-submit').html('Start Test Now');
        }
      });
    });

    $('.parts-show-instructions').click(function(){
      $('#parts-instructions').modal('show');
    });


  $('body').on('click', '.allow-test-submit', function(){
  //$('.allow-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
    var testcode = $(this).attr('data-testcode');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/accessnewtest/",
        data: {
          testid: testid,
          memberid: memberid,
      testcode:testcode
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
      //return false;
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testnewprogress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });
  	$('body').on('click', '.allow-timer-test-submit', function(){
	//$('.allow-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
    var testcode = $(this).attr('data-testcode');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/accessnewtimertest/",
        data: {
          testid: testid,
          memberid: memberid,
      testcode:testcode
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
      //return false;
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/timertestnewprogress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });

  $('body').on('click', '.allow-section-wise-submit', function(){
  //$('.allow-section-wise-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');

      console.log('testid = ' +testid+ 'memberid = '+memberid);
    //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/accessSectionWisetest/",
        data: {
          testid: testid,
          memberid: memberid
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testSectionWiseprogress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });

	$('body').on('click', '.allow-reading-section-wise-submit', function(){
	//$('.allow-reading-section-wise-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');

      console.log('testid = ' +testid+ 'memberid = '+memberid);
    //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/accessReadingSectionWisetest/",
        data: {
          testid: testid,
          memberid: memberid
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testReadingSectionWiseprogress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });


  $('#ls_practice_submit').click(function(){
  //$( "#submit_ptest" ).submit(function( event ) {
  ///event.preventDefault();
  //console.log($('#submit_ptest').serialize());
  //showAjaxLoader();
  //var form_data = $(this).serializeArray();
  //var form_data = new FormData();
    //form_data.append( 'file', input.files[0] );

  //console.log(form_data);
  var q1_response = $('input[name=q1-response]:checked').val();
  var token = $('input[name=token]').val();
  //return false;
  $.ajax({
        type: "POST",
        url: weburl + "member/practiceTaskSubmit/",
        data: {
          q1_response: q1_response,
      token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/29';
            window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
          //$('#submit_ptest').prop('disabled', false);
          //$('#submit_ptest').html('Submit');
        }
      });

  /*$.ajax({
        url: weburl+'member/practiceTaskSubmit/',
        type: 'post',
    data: form_data,
    /* data: {
          testid: '11',
          memberid: '15',
        }, */
       /* dataType: 'json',
    cache:false,
        success: function(data) {
      alert();
      return false;
      //$.isLoading("hide");
      //var response = JSON.parse(data);
      console.log(data);
    //  console.log(data.status);
      /* if(data.status ==0){
        var errorhtml = "<div class='error_msg alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>"+data.error+"</div>";

        $('.form_error_data').html(errorhtml);
          $('html, body').animate({scrollTop:0}, 'slow');
        //$('.form_error_data').hide().delay(5000).fadeIn(400);
      }else{
        //location.reload();
        window.location.reload();
      }  */

        /*}
    });*/
});

  $('.rd_practice_submit').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var token = $('input[name=token]').val();
    if(q1_response!=''){
      $.ajax({
        type: "POST",
        url: weburl + "member/readingPracticeTaskSubmit/",
        data: {
          q1_response: q1_response,
          token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/40';
            window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
          //$('#submit_ptest').prop('disabled', false);
          //$('#submit_ptest').html('Submit');
        }
      });
    }
    });

  $('.wt1_submit_btn').click(function(){

    var q1_response = $('textarea#wt_q1_response').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/wtPart1Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/47';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.wt2_submit_btn').click(function(){

    var q1_response = $("input[name='q1_response']:checked").val();
    var q2_response = $('textarea#wt_q2_response').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/wtPart2Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/46';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.rd4_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var q6_response = $('select[name="q6-response"]').val();
    var q7_response = $('select[name="q7-response"]').val();
    var q8_response = $('select[name="q8-response"]').val();
    var q9_response = $('select[name="q9-response"]').val();
    var q10_response = $('select[name="q10-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!='' && q9_response!='' && q10_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart4Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        q7_response: q7_response,
        q8_response: q8_response,
        q9_response: q9_response,
        q10_response: q10_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/36';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.rd1_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var q6_response = $('select[name="q6-response"]').val();
    var q7_response = $('select[name="q7-response"]').val();
    var q8_response = $('select[name="q8-response"]').val();
    var q9_response = $('select[name="q9-response"]').val();
    var q10_response = $('select[name="q10-response"]').val();
    var q11_response = $('select[name="q11-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!='' && q9_response!='' && q10_response!='' && q11_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart1Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        q7_response: q7_response,
        q8_response: q8_response,
        q9_response: q9_response,
        q10_response: q10_response,
        q11_response: q11_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/39';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.rd3_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var q6_response = $('select[name="q6-response"]').val();
    var q7_response = $('select[name="q7-response"]').val();
    var q8_response = $('select[name="q8-response"]').val();
    var q9_response = $('select[name="q9-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!='' && q9_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart3Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        q7_response: q7_response,
        q8_response: q8_response,
        q9_response: q9_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/37';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.rd2_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var q6_response = $('select[name="q6-response"]').val();
    var q7_response = $('select[name="q7-response"]').val();
    var q8_response = $('select[name="q8-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart2Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        q7_response: q7_response,
        q8_response: q8_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/38';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    $('#ls_timer_practice_submit').click(function(){
  //$( "#submit_ptest" ).submit(function( event ) {
  ///event.preventDefault();
  //console.log($('#submit_ptest').serialize());
  //showAjaxLoader();
  //var form_data = $(this).serializeArray();
  //var form_data = new FormData();
    //form_data.append( 'file', input.files[0] );

  //console.log(form_data);
  var q1_response = $('input[name=q1-response]:checked').val();
  var token = $('input[name=token]').val();
  //return false;
  $.ajax({
        type: "POST",
        url: weburl + "member/practiceTaskSubmit/",
        data: {
          q1_response: q1_response,
      token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTimerTestList/29';
            window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
          //$('#submit_ptest').prop('disabled', false);
          //$('#submit_ptest').html('Submit');
        }
      });

  /*$.ajax({
        url: weburl+'member/practiceTaskSubmit/',
        type: 'post',
    data: form_data,
    /* data: {
          testid: '11',
          memberid: '15',
        }, */
       /* dataType: 'json',
    cache:false,
        success: function(data) {
      alert();
      return false;
      //$.isLoading("hide");
      //var response = JSON.parse(data);
      console.log(data);
    //  console.log(data.status);
      /* if(data.status ==0){
        var errorhtml = "<div class='error_msg alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>"+data.error+"</div>";

        $('.form_error_data').html(errorhtml);
          $('html, body').animate({scrollTop:0}, 'slow');
        //$('.form_error_data').hide().delay(5000).fadeIn(400);
      }else{
        //location.reload();
        window.location.reload();
      }  */

        /*}
    });*/
});

    $('.rd_timer_practice_submit').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response=='' ){
      $.ajax({
        type: "POST",
        url: weburl + "member/readingPracticeTaskSubmit/",
        data: {
          q1_response: q1_response,
          token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTimerTestList/40';
            window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
          //$('#submit_ptest').prop('disabled', false);
          //$('#submit_ptest').html('Submit');
        }
      });
    }
    });

  $('.wt1_timer_submit_btn').click(function(){

    var q1_response = $('textarea#wt_q1_response').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' || q1_response=='' ){
    $.ajax({
      type: "POST",
      url: weburl + "member/wtPart1Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/47';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.wt2_timer_submit_btn').click(function(){

    var q1_response = $("input[name='q1_response']:checked").val();
    var q2_response = $('textarea#wt_q2_response').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' || q1_response=='' ){
    $.ajax({
      type: "POST",
      url: weburl + "member/wtPart2Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/46';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.rd4_timer_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var q6_response = $('select[name="q6-response"]').val();
    var q7_response = $('select[name="q7-response"]').val();
    var q8_response = $('select[name="q8-response"]').val();
    var q9_response = $('select[name="q9-response"]').val();
    var q10_response = $('select[name="q10-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!='' && q9_response!='' && q10_response!='' || q1_response=='' && q2_response=='' && q3_response=='' && q4_response=='' && q5_response=='' && q6_response=='' && q7_response=='' && q8_response=='' && q9_response=='' && q10_response==''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart4Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        q7_response: q7_response,
        q8_response: q8_response,
        q9_response: q9_response,
        q10_response: q10_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/36';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.rd1_timer_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var q6_response = $('select[name="q6-response"]').val();
    var q7_response = $('select[name="q7-response"]').val();
    var q8_response = $('select[name="q8-response"]').val();
    var q9_response = $('select[name="q9-response"]').val();
    var q10_response = $('select[name="q10-response"]').val();
    var q11_response = $('select[name="q11-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!='' && q9_response!='' && q10_response!='' && q11_response!='' || q1_response=='' && q2_response=='' && q3_response=='' && q4_response=='' && q5_response=='' && q6_response=='' && q7_response=='' && q8_response=='' && q9_response=='' && q10_response=='' && q11_response==''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart1Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        q7_response: q7_response,
        q8_response: q8_response,
        q9_response: q9_response,
        q10_response: q10_response,
        q11_response: q11_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/39';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.rd3_timer_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var q6_response = $('select[name="q6-response"]').val();
    var q7_response = $('select[name="q7-response"]').val();
    var q8_response = $('select[name="q8-response"]').val();
    var q9_response = $('select[name="q9-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!='' && q9_response!='' || q1_response=='' && q2_response=='' && q3_response=='' && q4_response=='' && q5_response=='' && q6_response=='' && q7_response=='' && q8_response=='' && q9_response==''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart3Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        q7_response: q7_response,
        q8_response: q8_response,
        q9_response: q9_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/37';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $('.rd2_timer_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var q6_response = $('select[name="q6-response"]').val();
    var q7_response = $('select[name="q7-response"]').val();
    var q8_response = $('select[name="q8-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!='' || q1_response=='' && q2_response=='' && q3_response=='' && q4_response=='' && q5_response=='' && q6_response=='' && q7_response=='' && q8_response==''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart2Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        q7_response: q7_response,
        q8_response: q8_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/38';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });


$('.rd_sec_next_btn').click(function() {

    var screenid = $(this).attr('data-screenid');
    //alert(screenid);
    if (screenid == 2) {
        $(".sec-wise-test-title").html('Part 1: Reading Correspondence');
    }

	if (screenid == 3) {
        $(".sec-wise-test-title").html('Reading Part 2: Reading to Apply a Diagram');
    }

	if (screenid == 4) {
        $(".sec-wise-test-title").html('Reading Part 3: Reading for Information');
    }

	if (screenid == 5) {
        $(".sec-wise-test-title").html('Reading Part 4: Reading for Viewpoints');
    }

	 if (screenid <=5) {
        $(".ls-section-screen-" + screenid).show();
        $('.ls-section').not(".ls-section-screen-" + screenid).hide();

      if(screenid == 5){
        $('.submit').html('Submit');


      }

    }if(screenid == 6){
        $(".sec-wise-test-title").html('Submitting your answers please wait');


      }

	if (screenid == 6){
    var practice_q1_response = $('select[name="practice-q1-response"]').val();
    var p1_q1_response = $('select[name="p1-q1-response"]').val();
    var p1_q2_response = $('select[name="p1-q2-response"]').val();
    var p1_q3_response = $('select[name="p1-q3-response"]').val();
    var p1_q4_response = $('select[name="p1-q4-response"]').val();
    var p1_q5_response = $('select[name="p1-q5-response"]').val();
    var p1_q6_response = $('select[name="p1-q6-response"]').val();
    var p1_q7_response = $('select[name="p1-q7-response"]').val();
    var p1_q8_response = $('select[name="p1-q8-response"]').val();
    var p1_q9_response = $('select[name="p1-q9-response"]').val();
    var p1_q10_response = $('select[name="p1-q10-response"]').val();
    var p1_q11_response = $('select[name="p1-q11-response"]').val();

	var p2_q1_response = $('select[name="p2-q1-response"]').val();
    var p2_q2_response = $('select[name="p2-q2-response"]').val();
    var p2_q3_response = $('select[name="p2-q3-response"]').val();
    var p2_q4_response = $('select[name="p2-q4-response"]').val();
    var p2_q5_response = $('select[name="p2-q5-response"]').val();
    var p2_q6_response = $('select[name="p2-q6-response"]').val();
    var p2_q7_response = $('select[name="p2-q7-response"]').val();
    var p2_q8_response = $('select[name="p2-q8-response"]').val();

	var p3_q1_response = $('select[name="p3-q1-response"]').val();
    var p3_q2_response = $('select[name="p3-q2-response"]').val();
    var p3_q3_response = $('select[name="p3-q3-response"]').val();
    var p3_q4_response = $('select[name="p3-q4-response"]').val();
    var p3_q5_response = $('select[name="p3-q5-response"]').val();
    var p3_q6_response = $('select[name="p3-q6-response"]').val();
    var p3_q7_response = $('select[name="p3-q7-response"]').val();
    var p3_q8_response = $('select[name="p3-q8-response"]').val();
    var p3_q9_response = $('select[name="p3-q9-response"]').val();

	var p4_q1_response = $('select[name="p4-q1-response"]').val();
    var p4_q2_response = $('select[name="p4-q2-response"]').val();
    var p4_q3_response = $('select[name="p4-q3-response"]').val();
    var p4_q4_response = $('select[name="p4-q4-response"]').val();
    var p4_q5_response = $('select[name="p4-q5-response"]').val();
    var p4_q6_response = $('select[name="p4-q6-response"]').val();
    var p4_q7_response = $('select[name="p4-q7-response"]').val();
    var p4_q8_response = $('select[name="p4-q8-response"]').val();
    var p4_q9_response = $('select[name="p4-q9-response"]').val();
    var p4_q10_response = $('select[name="p4-q10-response"]').val();

    var token = $('input[name=token]').val();
    //return false;
	if(p4_q1_response!='' || p4_q1_response==''){
		$.ajax({
		  type: "POST",
		  url: weburl + "member/readingSectionSubmit/",
		  data: {
			p1_q1_response : p1_q1_response,
			p1_q2_response : p1_q2_response,
			p1_q3_response : p1_q3_response,
			p1_q4_response : p1_q4_response,
			p1_q5_response : p1_q5_response,
			p1_q6_response : p1_q6_response,
			p1_q7_response : p1_q7_response,
			p1_q8_response : p1_q8_response,
			p1_q9_response : p1_q9_response,
			p1_q10_response : p1_q10_response,
			p1_q11_response : p1_q11_response,

			p2_q1_response : p2_q1_response,
			p2_q2_response : p2_q2_response,
			p2_q3_response : p2_q3_response,
			p2_q4_response : p2_q4_response,
			p2_q5_response : p2_q5_response,
			p2_q6_response : p2_q6_response,
			p2_q7_response : p2_q7_response,
			p2_q8_response : p2_q8_response,

			p3_q1_response : p3_q1_response,
			p3_q2_response : p3_q2_response,
			p3_q3_response : p3_q3_response,
			p3_q4_response : p3_q4_response,
			p3_q5_response : p3_q5_response,
			p3_q6_response : p3_q6_response,
			p3_q7_response : p3_q7_response,
			p3_q8_response : p3_q8_response,
			p3_q9_response : p3_q9_response,

			p4_q1_response : p4_q1_response,
			p4_q2_response : p4_q2_response,
			p4_q3_response : p4_q3_response,
			p4_q4_response : p4_q4_response,
			p4_q5_response : p4_q5_response,
			p4_q6_response : p4_q6_response,
			p4_q7_response : p4_q7_response,
			p4_q8_response : p4_q8_response,
			p4_q9_response : p4_q9_response,
			p4_q10_response : p4_q10_response,

			token: token
		  },
		  dataType: "json",
		  cache: false,
		  success: function(data) {
			if (data.result == "success") {
			  //alert();
			  //return false;
			  var testprogressurl = weburl + 'member/getSectionReading';
			  window.location.href = testprogressurl;
			}
			console.log(data);
		  },
		  error: function(data) {
			console.log(data);
			//$('#submit_ptest').prop('disabled', false);
			//$('#submit_ptest').html('Submit');
		  }
		  //console.log(data);

		});
	}

   console.log(data);
	}
	
	if(screenid<6){
            $(this).attr("data-screenid", ++screenid);
	    
	}
});

$('.ls_sec_next_btn').click(function() {
    //$(this).prop('disabled', true);
    //$(this).html('Please wait ...');
    $('audio').each(function() {
        this.pause(); // Stop playing
        this.currentTime = 0; // Reset time
    });
    $('video').each(function() {
        this.pause(); // Stop playing
        this.currentTime = 0; // Reset time
    });
    var screenid = $(this).attr('data-screenid');
    //alert(screenid);
    if (screenid == 2) {
        $(".sec-wise-test-title").html('Listening Part 1: Listening to Problem Solving');
    }
    if (screenid == 14) {
        $(".sec-wise-test-title").html('Listening Part 2: Listening to Daily Life Conversation');
    }

    if (screenid == 20) {
        $(".sec-wise-test-title").html('Listening Part 3: Listening for Information');
    }

    if (screenid == 27) {
        $(".sec-wise-test-title").html('Listening Part 4: Listening to a News Item');
    }
    if (screenid == 29) {
        $(".sec-wise-test-title").html('Listening Part 5: Listening to a Discussion');
    }
    if (screenid == 31) {
        $(".sec-wise-test-title").html('Listening Part 6: Listening to Viewpoints');
    }
    if (screenid <= 33) {
        $(".ls-section-screen-" + screenid).show();
        $('.ls-section').not(".ls-section-screen-" + screenid).hide();

      if(screenid==33){
        $('.submit').html('Submit');
      }
    }
   

 if(screenid==34){
	//alert();
	var practice_q1_response = $('input[name=practice-q1-response]:checked').val();
    var p1_q1_response = $('input[name=p1-q1-response]:checked').val();
    var p1_q2_response = $('input[name=p1-q2-response]:checked').val();
    var p1_q3_response = $('input[name=p1-q3-response]:checked').val();
    var p1_q4_response = $('input[name=p1-q4-response]:checked').val();
    var p1_q5_response = $('input[name=p1-q5-response]:checked').val();
    var p1_q6_response = $('input[name=p1-q6-response]:checked').val();
    var p1_q7_response = $('input[name=p1-q7-response]:checked').val();
    var p1_q8_response = $('input[name=p1-q8-response]:checked').val();

    var p2_q1_response = $('input[name=p2-q1-response]:checked').val();
    var p2_q2_response = $('input[name=p2-q2-response]:checked').val();
    var p2_q3_response = $('input[name=p2-q3-response]:checked').val();
    var p2_q4_response = $('input[name=p2-q4-response]:checked').val();
    var p2_q5_response = $('input[name=p2-q5-response]:checked').val();

    var p3_q1_response = $('input[name=p3-q1-response]:checked').val();
    var p3_q2_response = $('input[name=p3-q2-response]:checked').val();
    var p3_q3_response = $('input[name=p3-q3-response]:checked').val();
    var p3_q4_response = $('input[name=p3-q4-response]:checked').val();
    var p3_q5_response = $('input[name=p3-q5-response]:checked').val();
    var p3_q6_response = $('input[name=p3-q6-response]:checked').val();

    var p4_q1_response = $('select[name="p4-q1-response"]').val();
    var p4_q2_response = $('select[name="p4-q2-response"]').val();
    var p4_q3_response = $('select[name="p4-q3-response"]').val();
    var p4_q4_response = $('select[name="p4-q4-response"]').val();
    var p4_q5_response = $('select[name="p4-q5-response"]').val();

    var p5_q1_response = $('select[name="p5-q1-response"]').val();
    var p5_q2_response = $('select[name="p5-q2-response"]').val();
    var p5_q3_response = $('select[name="p5-q3-response"]').val();
    var p5_q4_response = $('select[name="p5-q4-response"]').val();
    var p5_q5_response = $('select[name="p5-q5-response"]').val();
    var p5_q6_response = $('select[name="p5-q6-response"]').val();
    var p5_q7_response = $('select[name="p5-q7-response"]').val();
    var p5_q8_response = $('select[name="p5-q8-response"]').val();

    var p6_q1_response = $('select[name="p6-q1-response"]').val();
    var p6_q2_response = $('select[name="p6-q2-response"]').val();
    var p6_q3_response = $('select[name="p6-q3-response"]').val();
    var p6_q4_response = $('select[name="p6-q4-response"]').val();
    var p6_q5_response = $('select[name="p6-q5-response"]').val();
    var p6_q6_response = $('select[name="p6-q6-response"]').val();

    var token = $('input[name=token]').val();
    //return false;
	if(p6_q1_response!='' || p6_q1_response ==''){
		$.ajax({
		  type: "POST",
		  url: weburl + "member/listeningSectionSubmit/",
		  data: {
			practice_q1_response : practice_q1_response,
			p1_q1_response : p1_q1_response,
			p1_q2_response : p1_q2_response,
			p1_q3_response : p1_q3_response,
			p1_q4_response : p1_q4_response,
			p1_q5_response : p1_q5_response,
			p1_q6_response : p1_q6_response,
			p1_q7_response : p1_q7_response,
			p1_q8_response : p1_q8_response,

			p2_q1_response : p2_q1_response,
			p2_q2_response : p2_q2_response,
			p2_q3_response : p2_q3_response,
			p2_q4_response : p2_q4_response,
			p2_q5_response : p2_q5_response,

			p3_q1_response : p3_q1_response,
			p3_q2_response : p3_q2_response,
			p3_q3_response : p3_q3_response,
			p3_q4_response : p3_q4_response,
			p3_q5_response : p3_q5_response,
      p3_q6_response : p3_q6_response,

			p4_q1_response : p4_q1_response,
			p4_q2_response : p4_q2_response,
			p4_q3_response : p4_q3_response,
			p4_q4_response : p4_q4_response,
			p4_q5_response : p4_q5_response,

			p5_q1_response : p5_q1_response,
			p5_q2_response : p5_q2_response,
			p5_q3_response : p5_q3_response,
			p5_q4_response : p5_q4_response,
			p5_q5_response : p5_q5_response,
			p5_q6_response : p5_q6_response,
			p5_q7_response : p5_q7_response,
			p5_q8_response : p5_q8_response,

			p6_q1_response : p6_q1_response,
			p6_q2_response : p6_q2_response,
			p6_q3_response : p6_q3_response,
			p6_q4_response : p6_q4_response,
			p6_q5_response : p6_q5_response,
			p6_q6_response : p6_q6_response,

			token: token
		  },
		  dataType: "json",
		  cache: false,
		  success: function(data) {
			if (data.result == "success") {
			  //alert();
			  //return false;
			  var testprogressurl = weburl + 'member/getSectionListening';
			  window.location.href = testprogressurl;
			}
			console.log(data);
		  },
		  error: function(data) {
			console.log(data);
			//$('#submit_ptest').prop('disabled', false);
			//$('#submit_ptest').html('Submit');
		  }
		  //console.log(data);

		});
	}
   console.log(data);
}if(screenid<34){
            $(this).attr("data-screenid", ++screenid);

}
});


  $('.ls1_next_btn').click(function(){
    //$(this).prop('disabled', true);
    //$(this).html('Please wait ...');
    $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
    var screenid = $(this).attr('data-screenid');
    if(screenid <= 12){
    $(".ls-part1-screen-"+screenid).show();

    $('.ls-part1').not(".ls-part1-screen-" + screenid).hide();

     if(screenid==12){
        $('.submit').html('Submit')
      }

     }
    
    if(screenid==13){

  
      var q1_response = $('input[name=q1-response]:checked').val();
      var q2_response = $('input[name=q2-response]:checked').val();
      var q3_response = $('input[name=q3-response]:checked').val();
      var q4_response = $('input[name=q4-response]:checked').val();
      var q5_response = $('input[name=q5-response]:checked').val();
      var q6_response = $('input[name=q6-response]:checked').val();
      var q7_response = $('input[name=q7-response]:checked').val();
      var q8_response = $('input[name=q8-response]:checked').val();
      var token = $('input[name=token]').val();
      //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/lsPart1Submit/",
        data: {
          q1_response: q1_response,
          q2_response: q2_response,
          q3_response: q3_response,
          q4_response: q4_response,
          q5_response: q5_response,
          q6_response: q6_response,
          q7_response: q7_response,
          q8_response: q8_response,
          token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
          var testprogressurl = weburl + 'member/getTestList/20';
          window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
          //$('#submit_ptest').prop('disabled', false);
          //$('#submit_ptest').html('Submit');
        }
        });
    }    if(screenid<13){
      $(this).attr("data-screenid", ++screenid);
    }
    //alert(screenid);
    });

  $('.ls2_next_btn').click(function(){
    //$(this).prop('disabled', true);
    //$(this).html('Please wait ...');

    $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
    var screenid = $(this).attr('data-screenid');

    if(screenid<=6){
    $(".ls-part2-screen-"+screenid).show();

    $('.ls-part2').not(".ls-part2-screen-" + screenid).hide();
    
    
    
    }
    if(screenid==6){
      $('.submit').html('Submit')
    }

    if(screenid==7){

      var q1_response = $('input[name=q1-response]:checked').val();
      var q2_response = $('input[name=q2-response]:checked').val();
      var q3_response = $('input[name=q3-response]:checked').val();
      var q4_response = $('input[name=q4-response]:checked').val();
      var q5_response = $('input[name=q5-response]:checked').val();
      var token = $('input[name=token]').val();
      //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/lsPart2Submit/",
        data: {
          q1_response: q1_response,
          q2_response: q2_response,
          q3_response: q3_response,
          q4_response: q4_response,
          q5_response: q5_response,
          token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
          var testprogressurl = weburl + 'member/getTestList/19';
          window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
        }
        });
    }
    $(this).attr("data-screenid", ++screenid);
    //alert(screenid);
    });

  $('.ls3_next_btn').click(function(){
    $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
    var screenid = $(this).attr('data-screenid');
        
    if(screenid<=7){
      $(".ls-part3-screen-"+screenid).show();
      $('.ls-part3').not(".ls-part3-screen-" + screenid).hide();
       
    }
     if(screenid==7){
            $('.submit').html('Submit')
        }
    if(screenid==8){

      var q1_response = $('input[name=q1-response]:checked').val();
      var q2_response = $('input[name=q2-response]:checked').val();
      var q3_response = $('input[name=q3-response]:checked').val();
      var q4_response = $('input[name=q4-response]:checked').val();
      var q5_response = $('input[name=q5-response]:checked').val();
      var q6_response = $('input[name=q6-response]:checked').val();
      var token = $('input[name=token]').val();
      //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/lsPart3Submit/",
        data: {
          q1_response: q1_response,
          q2_response: q2_response,
          q3_response: q3_response,
          q4_response: q4_response,
          q5_response: q5_response,
		  q6_response: q6_response,
          token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
          var testprogressurl = weburl + 'member/getTestList/18';
          window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
        }
        });
    }
    $(this).attr("data-screenid", ++screenid);
    });

  $('.ls4_next_btn').click(function(){
		$('audio').each(function(){
	       this.pause(); // Stop playing
	       this.currentTime = 0; // Reset time
	     });
	     var screenid = $(this).attr('data-screenid');
	       if (screenid <= 2) {
	        $(".ls-part4-screen-"+screenid).show();
	       $('.ls-part4').not(".ls-part4-screen-" + screenid).hide();
	         	          $('.submit').html('Submit');


	     }


	  if(screenid==3){

      var q1_response = $('select[name="q1-response"]').val();
      var q2_response = $('select[name="q2-response"]').val();
      var q3_response = $('select[name="q3-response"]').val();
      var q4_response = $('select[name="q4-response"]').val();
      var q5_response = $('select[name="q5-response"]').val();
      var token = $('input[name=token]').val();

      if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!=''){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/lsPart4Submit/",
          data: {
            q1_response: q1_response,
            q2_response: q2_response,
            q3_response: q3_response,
            q4_response: q4_response,
            q5_response: q5_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/17';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      }
    }if(screenid<3){
      $(this).attr("data-screenid", ++screenid);
    }
    //alert($('select[name="q1-response"]').val());
    });

  $('.ls5_timer_next_btn').click(function(){
    $('video').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
    $('.submit').html('Submit');
    var screenid = $(this).attr('data-screenid');
      if (screenid <= 3) {
       $(".ls-part5-screen-"+screenid).show();
      $('.ls-part5').not(".ls-part5-screen-" + screenid).hide();
        $(this).attr("data-screenid", ++screenid);

      if(screenid==4){
        $(".sec-wise-test-title").html('Submitting your answers please wait');
      }
    }


 if(screenid==4){
      var q1_response = $('select[name="q1-response"]').val();
      var q2_response = $('select[name="q2-response"]').val();
      var q3_response = $('select[name="q3-response"]').val();
      var q4_response = $('select[name="q4-response"]').val();
      var q5_response = $('select[name="q5-response"]').val();
      var q6_response = $('select[name="q6-response"]').val();
      var q7_response = $('select[name="q7-response"]').val();
      var q8_response = $('select[name="q8-response"]').val();
      var token = $('input[name=token]').val();

      if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!='' || q1_response=='' && q2_response=='' && q3_response=='' && q4_response=='' && q5_response=='' && q6_response=='' && q7_response=='' && q8_response==''){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/lsPart5Submit/",
          data: {
            q1_response: q1_response,
            q2_response: q2_response,
            q3_response: q3_response,
            q4_response: q4_response,
            q5_response: q5_response,
            q6_response: q6_response,
            q7_response: q7_response,
            q8_response: q8_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTimerTestList/16';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      } if(screenid<4){
      $(this).attr("data-screenid", ++screenid);
    }
    }
    });

  $('.ls6_next_btn').click(function(){
		$('audio').each(function(){
		 this.pause(); // Stop playing
		 this.currentTime = 0; // Reset time
	 });
	 var screenid = $(this).attr('data-screenid');
	 if(screenid<=3){
		 $(".ls-part6-screen-"+screenid).show();
		 $('.ls-part6').not(".ls-part6-screen-" + screenid).hide();
		 if(screenid==3){
			 $('.submit').html('Submit')
		 }
	 }

	 
	 if(screenid==4){

      var q1_response = $('select[name="q1-response"]').val();
      var q2_response = $('select[name="q2-response"]').val();
      var q3_response = $('select[name="q3-response"]').val();
      var q4_response = $('select[name="q4-response"]').val();
      var q5_response = $('select[name="q5-response"]').val();
      var q6_response = $('select[name="q6-response"]').val();
      var token = $('input[name=token]').val();

      if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' ){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/lsPart6Submit/",
          data: {
            q1_response: q1_response,
            q2_response: q2_response,
            q3_response: q3_response,
            q4_response: q4_response,
            q5_response: q5_response,
            q6_response: q6_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/15';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      }
    }
    if(screenid<4){
      $(this).attr("data-screenid", ++screenid);
    }
    });

  $('.sp_practice_submit').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/speakingPracticeTaskSubmit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/59';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp1_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart1Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/58';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp2_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart2Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/57';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp3_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  
  
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart3Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/56';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp4_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart4Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/55';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp5_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart5Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/54';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp6_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart6Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/53';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp7_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart7Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/52';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp8_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart8Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/51';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.ls1_timer_next_btn').click(function(){
    //$(this).prop('disabled', true);
    //$(this).html('Please wait ...');
    $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
    var screenid = $(this).attr('data-screenid');
    if(screenid <= 12){
    $(".ls-part1-screen-"+screenid).show();

    $('.ls-part1').not(".ls-part1-screen-" + screenid).hide();

     if(screenid==12){
        $('.submit').html('Submit')
      }

     }
    
    if(screenid==13){

  
      var q1_response = $('input[name=q1-response]:checked').val();
      var q2_response = $('input[name=q2-response]:checked').val();
      var q3_response = $('input[name=q3-response]:checked').val();
      var q4_response = $('input[name=q4-response]:checked').val();
      var q5_response = $('input[name=q5-response]:checked').val();
      var q6_response = $('input[name=q6-response]:checked').val();
      var q7_response = $('input[name=q7-response]:checked').val();
      var q8_response = $('input[name=q8-response]:checked').val();
      var token = $('input[name=token]').val();
      //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/lsPart1Submit/",
        data: {
          q1_response: q1_response,
          q2_response: q2_response,
          q3_response: q3_response,
          q4_response: q4_response,
          q5_response: q5_response,
          q6_response: q6_response,
          q7_response: q7_response,
          q8_response: q8_response,
          token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
          var testprogressurl = weburl + 'member/getTimerTestList/20';
          window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
          //$('#submit_ptest').prop('disabled', false);
          //$('#submit_ptest').html('Submit');
        }
        });
    } if(screenid<13){
      $(this).attr("data-screenid", ++screenid);
    }
    //alert(screenid);
    });

  $('.ls2_timer_next_btn').click(function(){
    //$(this).prop('disabled', true);
    //$(this).html('Please wait ...');

    $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
    var screenid = $(this).attr('data-screenid');

    if(screenid<=6){
    $(".ls-part2-screen-"+screenid).show();

    $('.ls-part2').not(".ls-part2-screen-" + screenid).hide();
    if(screenid==6){
      $('.submit').html('Submit')
    }
    }

    if(screenid==7){

      var q1_response = $('input[name=q1-response]:checked').val();
      var q2_response = $('input[name=q2-response]:checked').val();
      var q3_response = $('input[name=q3-response]:checked').val();
      var q4_response = $('input[name=q4-response]:checked').val();
      var q5_response = $('input[name=q5-response]:checked').val();
      var token = $('input[name=token]').val();
      //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/lsPart2Submit/",
        data: {
          q1_response: q1_response,
          q2_response: q2_response,
          q3_response: q3_response,
          q4_response: q4_response,
          q5_response: q5_response,
          token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
          var testprogressurl = weburl + 'member/getTimerTestList/19';
          window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
        }
        });
    }
    $(this).attr("data-screenid", ++screenid);
    //alert(screenid);
    });

  $('.ls3_timer_next_btn').click(function(){
    $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
   var screenid = $(this).attr('data-screenid');
        
    if(screenid<=7){
      $(".ls-part3-screen-"+screenid).show();
      $('.ls-part3').not(".ls-part3-screen-" + screenid).hide();
       
    }
     if(screenid==7){
            $('.submit').html('Submit')
        }
    if(screenid==8){

      var q1_response = $('input[name=q1-response]:checked').val();
      var q2_response = $('input[name=q2-response]:checked').val();
      var q3_response = $('input[name=q3-response]:checked').val();
      var q4_response = $('input[name=q4-response]:checked').val();
      var q5_response = $('input[name=q5-response]:checked').val();
      var q6_response = $('input[name=q6-response]:checked').val();
      var token = $('input[name=token]').val();
      //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/lsPart3Submit/",
        data: {
          q1_response: q1_response,
          q2_response: q2_response,
          q3_response: q3_response,
          q4_response: q4_response,
          q5_response: q5_response,
		  q6_response: q6_response,
          token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
          var testprogressurl = weburl + 'member/getTimerTestList/18';
          window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
        }
        });
    }
    $(this).attr("data-screenid", ++screenid);
    });

  $('.ls4_timer_next_btn').click(function(){
    $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });

       var screenid = $(this).attr('data-screenid');
	       if (screenid <= 2) {
	        $(".ls-part4-screen-"+screenid).show();
	       $('.ls-part4').not(".ls-part4-screen-" + screenid).hide();
	         	          $('.submit').html('Submit');


	     }


	  if(screenid==3){
    var q1_response = $('select[name="q1-response"]').val();
      var q2_response = $('select[name="q2-response"]').val();
      var q3_response = $('select[name="q3-response"]').val();
      var q4_response = $('select[name="q4-response"]').val();
      var q5_response = $('select[name="q5-response"]').val();
      var token = $('input[name=token]').val();

      if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' || q1_response=='' && q2_response=='' && q3_response=='' && q4_response=='' && q5_response=='' ){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/lsPart4Submit/",
          data: {
            q1_response: q1_response,
            q2_response: q2_response,
            q3_response: q3_response,
            q4_response: q4_response,
            q5_response: q5_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTimerTestList/17';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      }
    }if(screenid<3){
      $(this).attr("data-screenid", ++screenid);
    }
    //alert($('select[name="q1-response"]').val());
    });

  $('.ls5_timer_next_btn').click(function(){
 	$('audio').each(function(){
	      this.pause(); // Stop playing
	      this.currentTime = 0; // Reset time
	    }); $('video').each(function(){
	      this.pause(); // Stop playing
	      this.currentTime = 0; // Reset time
	    });
	    var screenid = $(this).attr('data-screenid');
	      if (screenid <= 2) {
	       $(".ls-part5-screen-"+screenid).show();
	      $('.ls-part5').not(".ls-part5-screen-" + screenid).hide();
	   $('.submit').html('Submit');
}
	     

	 if(screenid==3){
     var q1_response = $('select[name="q1-response"]').val();
      var q2_response = $('select[name="q2-response"]').val();
      var q3_response = $('select[name="q3-response"]').val();
      var q4_response = $('select[name="q4-response"]').val();
      var q5_response = $('select[name="q5-response"]').val();
      var q6_response = $('select[name="q6-response"]').val();
      var q7_response = $('select[name="q7-response"]').val();
      var q8_response = $('select[name="q8-response"]').val();
      var token = $('input[name=token]').val();

      if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' && q7_response!='' && q8_response!='' || q1_response=='' && q2_response=='' && q3_response=='' && q4_response=='' && q5_response=='' && q6_response=='' && q7_response=='' && q8_response==''){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/lsPart5Submit/",
          data: {
            q1_response: q1_response,
            q2_response: q2_response,
            q3_response: q3_response,
            q4_response: q4_response,
            q5_response: q5_response,
            q6_response: q6_response,
            q7_response: q7_response,
            q8_response: q8_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTimerTestList/16';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      }
    }if(screenid<3){
      $(this).attr("data-screenid", ++screenid);
    }
    });

  $('.ls6_timer_next_btn').click(function(){
    $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
  var screenid = $(this).attr('data-screenid');
	 if(screenid<=3){
		 $(".ls-part6-screen-"+screenid).show();
		 $('.ls-part6').not(".ls-part6-screen-" + screenid).hide();
		 if(screenid==3){
			 $('.submit').html('Submit')
		 }
	 }

	 
	 if(screenid==4){

    
      var q1_response = $('select[name="q1-response"]').val();
      var q2_response = $('select[name="q2-response"]').val();
      var q3_response = $('select[name="q3-response"]').val();
      var q4_response = $('select[name="q4-response"]').val();
      var q5_response = $('select[name="q5-response"]').val();
      var q6_response = $('select[name="q6-response"]').val();
      var token = $('input[name=token]').val();

      if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' || q1_response=='' && q2_response=='' && q3_response=='' && q4_response=='' && q5_response=='' && q6_response==''){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/lsPart6Submit/",
          data: {
            q1_response: q1_response,
            q2_response: q2_response,
            q3_response: q3_response,
            q4_response: q4_response,
            q5_response: q5_response,
            q6_response: q6_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTimerTestList/15';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      }
    }
    if(screenid<4){
      $(this).attr("data-screenid", ++screenid);
    }
    });

  $('.sp_timer_practice_submit').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/speakingPracticeTaskSubmit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/59';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp1_timer_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart1Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/58';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp2_timer_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart2Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/57';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp3_timer_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart3Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/56';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp4_timer_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart4Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/55';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp5_timer_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart5Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/54';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp6_timer_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart6Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/53';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp7_timer_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart7Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/52';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  $('.sp8_timer_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart8Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTimerTestList/51';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });


  $('.allow-comprehension-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/accessComprehensionTest/",
        data: {
          testid: testid,
          memberid: memberid
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          //console.log(data);
          //return false;
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testComprehensionProgress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });

	$('.comprehension_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/comprehensionSubmit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/comprehensionTest';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

  $("#example1").DataTable();
  });
  
   function exitCompleteTest(){
    $('#complete-instructions').modal('show');
    $("#complete-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions</u></h3><div class="alert alert-warning alert-dismissible" >Are you sure you want to exit the test? If you exit now, your coins will be deducted and you will have to restart the test from beginning next time. No progress made so far will be saved.</div></div></div><div class="text-center"><button type="button" class="btn btn-danger"><a href="https://demo.celpip.biz/member/completeTest" style="color: #fff;">Yes, I want to exit</a></button><button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-left:10px;">No, I will continue</button></div>');  
   }
   
    function exitTest(type){
    if(type=='section_wise_reading')
    {
      var url = 'https://demo.celpip.biz/member/getSectionReading';
    }
    else if(type=='section_wise')
    {
      var url = 'https://demo.celpip.biz/member/getSectionListening';  
    }
        
    $('#test-instructions').modal('show');
    $("#test-instructions .modal-body").html("<div class='box box-solid'><div class='box-body'><h3 class='text-center'><u>Instructions</u></h3><div class='alert alert-warning alert-dismissible'>Even if you don't complete the section, your coins will be deducted, are you sure you want to exit?</div></div></div><div class='text-center'><button type='button' class='btn btn-danger'><a href='"+url+"' style='color: #fff;'>Yes, I want to exit</a></button><button type='button' class='btn btn-danger' data-dismiss='modal' style='margin-left:10px;'>No, I will continue</button></div>");  
   }
   
   
    function exitPartTest(type,testId){
    if(type=='testList')
    {
     var url = "https://demo.celpip.biz/member/getTestList/"+testId+"";   
    }
    else if(type=='timerTestList')
    {
     var url = "https://demo.celpip.biz/member/getTimerTestList/"+testId+"";   
    }
      
        
    $('#part-test-instructions').modal('show');
    $("#part-test-instructions .modal-body").html("<div class='box box-solid'><div class='box-body'><h3 class='text-center'><u>Instructions</u></h3><div class='alert alert-warning alert-dismissible'>Even if you don't complete the section, your coins will be deducted, are you sure you want to exit?</div></div></div><div class='text-center'><button type='button' class='btn btn-danger'><a href='"+url+"' style='color: #fff;'>Yes, I want to exit</a></button><button type='button' class='btn btn-danger' data-dismiss='modal' style='margin-left:10px;'>No, I will continue</button></div>");  
   }

  function completeInstructions(testId,memberId){
      $('#complete-instructions').modal('show');
      testName = 'Complete Test';
      coinCost = '500';

      $("#complete-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions - '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>Please Read all instructions carefully before you begin .<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li>'+coinCost+' coins will be deducted from your account for this test Start test now!</li></ul></div></div><div style="font-size: 15px;margin-bottom: 15px;text-align: justify;">CELPIPSTORE aims to provide the students with real-exam experience for ultimate preparation, yet there may be certain ways in which the actual test may differ from our practice tests. However, we always welcome our users to give suggestions for improvement through Support.</div><div class="text-center"><button type="button" class="btn btn-danger allow-complete-test-submit" data-testid="'+testId+'" data-memberid="'+memberId+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
  }
  
  function completeInProgress(testId,memberId,idmd5){
     
      $('#complete-instructions').modal('show');
      testName = 'Complete Test';
      coinCost = '500';

      $("#complete-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions - '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>Please Read all instructions carefully before you begin .<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li>'+coinCost+' coins will be deducted from your account for this test Start test now!</li></ul></div></div><div class="text-center"><button type="button" class="btn btn-danger allow-complete-test-submit-inprogress" data-testid="'+testId+'" data-memberid="'+memberId+'" data-idmd5="'+idmd5+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
  }
  $(function () {
    var weburl = '<?php echo site_url(); ?>';
    $('body').on('click', '.allow-complete-test-submit', function(){
        $(this).prop('disabled', true);
        $(this).html('Please wait ...');
        var testid = $(this).attr('data-testid');
        var memberid = $(this).attr('data-memberid');
        
        console.log('memberid = ' +memberid);
        $.ajax({
          type: "POST",
          url: weburl + "member/accesscompletetest/",
          data: {
            testid: testid,
            memberid: memberid
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
           if( data.result == "success") {
              var testprogressurl = weburl + 'member/testCompleteprogress/' + data.tdcode;
              window.location.href = testprogressurl;
            }else{
        $('.get_test_msg').html(data.message);
        }
          },
          error:
          function(data) {
            console.log(data);
            $('.allow-test-submit').prop('disabled', false);
            $('.allow-test-submit').html('Start Test Now');
          }
        });
      });
      
      
      
      $('body').on('click', '.complete_inProgress_screen', function(){
        $(this).prop('disabled', true);
        $(this).html('Please wait ...');
        var testid = $(this).attr('data-testid');
        var memberid = $(this).attr('data-memberid');
        
        console.log('memberid = ' +memberid);
        $.ajax({
          type: "POST",
          url: weburl + "member/accesscompletetest/",
          data: {
            testid: testid,
            memberid: memberid
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
           if( data.result == "success") {
              var testprogressurl = weburl + 'member/testCompleteprogress/' + data.tdcode;
             window.location.href = testprogressurl;
            }else{
        $('.get_test_msg').html(data.message);
        }
          },
          error:
          function(data) {
            console.log(data);
            $('.allow-test-submit').prop('disabled', false);
            $('.allow-test-submit').html('Start Test Now');
          }
        });
      });
      
    $('body').on('click', '.allow-complete-test-submit-inprogress', function(){
        $(this).prop('disabled', true);
        $(this).html('Please wait ...');
        var testid = $(this).attr('data-testid');
        var memberid = $(this).attr('data-memberid');
        var idmd5 = $(this).attr('data-idmd5');
        
        console.log('memberid = ' +memberid);
        
        var testprogressurl = weburl + 'member/testCompleteprogress/' + idmd5;
        
        window.location.href = testprogressurl;
      });
      
      
  
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      

      $('.complete_sec_next_btn').click(function() {
        //var this = $(this);
        var status = navigator.onLine;
        if (status) {
          //alert('Internet connected !!');
        } else {
            alert('No internet Connection !!');
            return false;
        }
        var screenid = $(this).attr('data-screenid');
        
        var token = $('input[name=token]').val();

        if(screenid==2){
          var practice_q1_response = $('input[name=practice-q1-response]:checked').val();
          var response = {'practice_q1_response':practice_q1_response};
        }

        if(screenid==5){
          var p1_q1_response = $('input[name=p1-q1-response]:checked').val();
          //alert(p1_q1_response);
          var response = {'p1_q1_response':p1_q1_response};
        }

        if(screenid==6){
          var p1_q2_response = $('input[name=p1-q2-response]:checked').val();
          //alert(p1_q2_response);
          var response = {'p1_q2_response':p1_q2_response};
        }

        if(screenid==7){
          var p1_q3_response = $('input[name=p1-q3-response]:checked').val();
          //alert(p1_q3_response);
          var response = {'p1_q3_response':p1_q3_response};
        }

        if(screenid==8){
          var p1_q4_response = $('input[name=p1-q4-response]:checked').val();
          //alert(p1_q4_response);
          var response = {'p1_q4_response':p1_q4_response};
        }

        if(screenid==10){
          var p1_q5_response = $('input[name=p1-q5-response]:checked').val();
          //alert(p1_q5_response);
          var response = {'p1_q5_response':p1_q5_response};
        }

        if(screenid==11){
          var p1_q6_response = $('input[name=p1-q6-response]:checked').val();
          var response = {'p1_q6_response':p1_q6_response};
        }
        
        
        
        
        /* complete test insert */
        if(screenid==50){
          var practice_q1_response = $('input[name=practice-q1-response]:checked').val();
          var practice_response = {'practice_q1_response':practice_q1_response};

          var p1_q1_response = $('input[name=p1-q1-response]:checked').val();
          //alert(p1_q1_response);
          var q1_response = {'p1_q1_response':p1_q1_response};

          var p1_q2_response = $('input[name=p1-q2-response]:checked').val();
          //alert(p1_q2_response);
          var q2_response = {'p1_q2_response':p1_q2_response};

          var p1_q3_response = $('input[name=p1-q3-response]:checked').val();
          //alert(p1_q3_response);
          var q3_response = {'p1_q3_response':p1_q3_response};

          var p1_q4_response = $('input[name=p1-q4-response]:checked').val();
          //alert(p1_q4_response);
          var q4_response = {'p1_q4_response':p1_q4_response};

          var p1_q5_response = $('input[name=p1-q5-response]:checked').val();
          //alert(p1_q5_response);
          var q5_response = {'p1_q5_response':p1_q5_response};

          var p1_q6_response = $('input[name=p1-q6-response]:checked').val();
          var q6_response = {'p1_q6_response':p1_q6_response};

          var token = $('input[name=token]').val();

          if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='')
          {
            
            $.ajax({
            type: "POST",
            url: weburl + "member/completeTestSetSubmit/",
            data: {
            q1_response: q1_response,
            q2_response: q2_response,
            q3_response: q3_response,
            q4_response: q4_response,
            q5_response: q5_response,
            q6_response: q6_response,
            token:token
            },
            dataType:"json",
            cache:false,
            success:
            function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/completeTest';
            window.location.href = testprogressurl;
            }
            },
            error:
            function(data) {
            //console.log(data);
            //$('#submit_ptest').prop('disabled', false);
            //$('#submit_ptest').html('Submit');
            }
            });
          }  
        }
        /* complete test insert */
        
        
        
        

        console.log(screenid);
        $.ajax({
          type: "POST",
          url: weburl + "member/completeTestSubmit/",
          data: {
            screenid:screenid,
            token:token,
            response:response
          },
          beforeSend: function(){
            $(".custom-loader").show();
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
              if( data.result == "success") {
                $(".otw-row .ls-section").html(data.data);
                $(".sec-wise-test-title").html(data.screen_data.test_title);
                $('.complete_sec_next_btn').attr('data-screenid',data.screen_data.screenid);
                $('.current_screenId').val(data.screen_data.screenid);
                
                var datascreenid = data.screen_data.screenid;
                
                /* set time for writing Test */
                if(datascreenid==40)
                {
                    $("#timer_div").hide();
                    $("#timer_writing_div").show();
                    
                    var min = 25;
                    var timeLeft = 59;
                    var elem = document.getElementById('timer_writing_div');
                    var timerId = setInterval(countdown, 1000);
                    function countdown() {
                    if (timeLeft < 0)
                    {         min--;
                    timeLeft = 59;
                    }
                    if(timeLeft < 10)
                    {
                    timeLeft = '0' + timeLeft;
                    }
                    
                    if(min == 0 && timeLeft == 0) {
                    clearTimeout(timerId);
                    elem.innerHTML = min +':' + timeLeft + ' mins remaining';
                    $(".wt1_timer_submit_btn").trigger("click");
                    } else {
                    elem.innerHTML = min +':' + timeLeft + ' mins remaining';
                    timeLeft--;
                    }
                    } 
                }
                else if(datascreenid==41)
                {
                  $("#timer_div").hide();
                  $("#timer_writing_div").show();  
                }
                else
                {
                  $("#timer_writing_div").hide();
                  $("#timer_div").show();
                }
                /* set time for writing Test */
                
                
              }
              $(".custom-loader").hide();

              if(screenid==39 || screenid==40){
                $("#p2-q2-response").on('keydown', function(e) {
                    var words = $.trim(this.value).length ? this.value.match(/\S+/g).length : 0;
                    $('#display_count1').text(words);
                });
                $("#p1-q1-response").on('keydown', function(e) {
                    var words = $.trim(this.value).length ? this.value.match(/\S+/g).length : 0;
                    $('#display_count').text(words);
                });
              }

              if(screenid==41 || screenid==42 || screenid==43 || screenid==44 || screenid==45 || screenid==46 || screenid==47 || screenid==48 || screenid==49){
                try  {
                    // Webkit shim
                    window.AudioContext = window.AudioContext || window.webkitAudioContext;
                    navigator.getUserMedia = ( navigator.getUserMedia ||
                                        navigator.webkitGetUserMedia ||
                                        navigator.mozGetUserMedia ||
                                        navigator.msGetUserMedia);
                    window.URL = window.URL || window.webkitURL;

                    audio_data = new AudioContext;
                    console.log('Audio context set up.');
                    console.log('navigator.getUserMedia ' + (navigator.getUserMedia ? 'available.' : 'not present!'));

                } catch (e) {
                    //alert('No web audio support in this browser!');
                }

                navigator.getUserMedia({audio: true}, initUserMedia, function(e) {
                    console.log('No live audio input: ' + e);
                    //alert('Your browser does not support the audio.');
                });

                function initUserMedia(stream) {
                    var input = audio_data.createMediaStreamSource(stream);
                    //console.log('Media stream created.' );
                    //console.log("input sample rate " +input.context.sampleRate);

                    input.connect(audio_data.destination);
                    console.log('Input connected to audio context destination.');

                    $("#recordButton").removeClass("recordOff").addClass("recordOn");
                    $("#recordHelp").fadeOut("slow");
                    console.log('Recorder initialised.');
                }

                setTimeout(function() {

                  // Check if browser support audio
                  if($('#recordButton').hasClass('recordOn')) {
                    var preparationTime = 30;
                    var recordingTime = 90;

                    $("#recording-message").show(); // Show recording alert
                    $("#recording-message").delay(preparationTime+'000').fadeOut(); // Hide message after 40s
                    var playerTime = parseInt(preparationTime+'000') + parseInt(1000);
                    //alert(playerTime);
                    // Show the player after 41s
                    // Start recording after 41s, for 40 seconds
                    $("#player-block").delay(playerTime).fadeIn();

                    setTimeout(function() {

                      // Show buffer message
                      $("#buffermsg").show();

                      setTimeout(function() { // 5 second buffer before recording

                        // Hide buffer message
                        $("#buffermsg").hide();
                        var recordwaitInervaltime = parseInt(recordingTime+'000') + parseInt(1000);
                        var maxTime = recordingTime;
                        //startRecording();
                        //alert(recordwaitInervaltime);
                        console.log('*log: recording started (' + maxTime + ')');
                        justMicRec.start(maxTime);

                        setTimeout(function() {
                          // stop recording
                          // hide player block
                          // show success recording block
                          //stopRecording();
                          console.log('log: recording stopped');
                          $('#level').text('');
                          justMicRec.sendWAV();

                          $("#player-block").hide();
                          $("#success-recording").show();

                        }, recordwaitInervaltime);

                      }, 5000);

                    }, playerTime);



                  } else {

                    // Show message to user , that your browser not support audio
                    $("#audio-block").delay(1000).fadeIn();
                  }

                }, 2000);
              }
              
              if(screenid==28 || screenid==30 || screenid==33 || screenid==34 || screenid==35 || screenid==36 || screenid==37 || screenid==38){
                $('.q1-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next(".q1-sel-opt-text").show();
                  $(this).next(".q1-sel-opt-text").html('<b>'+ optionsText+'</b>');
                    $(this).hide();
                });

                $(".q1-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q2-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q2-sel-opt-text').show();
                  $(this).next(".q2-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q2-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q3-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q3-sel-opt-text').show();
                  $(this).next(".q3-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q3-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q4-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q4-sel-opt-text').show();
                  $(this).next(".q4-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q4-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q5-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q5-sel-opt-text').show();
                  $(this).next(".q5-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q5-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q6-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q6-sel-opt-text').show();
                  $(this).next(".q6-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q6-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q7-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q7-sel-opt-text').show();
                  $(this).next(".q7-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q7-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q8-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q8-sel-opt-text').show();
                  $(this).next(".q8-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q8-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q9-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q9-sel-opt-text').show();
                  $(this).next(".q9-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q9-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q10-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q10-sel-opt-text').show();
                  $(this).next(".q10-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q10-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });

                $('.q11-sel-opt').on('change',function(){
                  var optionsText = this.options[this.selectedIndex].text;
                  $(this).next('.q11-sel-opt-text').show();
                  $(this).next(".q11-sel-opt-text").html('<b>'+ optionsText+'</b>');
                  $(this).hide();
                });

                $(".q11-sel-opt-text").on('click',function(){
                  $(this).hide();
                  $(this).prev().show();
                });
              }
              
          },
          error:
          function(data) {
              //console.log(data);
              //$('#submit_ptest').prop('disabled', false);
              //$('#submit_ptest').html('Submit');
          }
        });
        return false;
      });
  });
</script>
