<!-- jQuery 2.2.3 -->
<script src="/theme/default/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="/theme/default/bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="/theme/default/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="/theme/default/plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="/theme/default/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="/theme/default/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="/theme/default/dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="/theme/default/dist/js/demo.js"></script>
<!-- page script -->
<script>
	function sectionReadingInstructions(testId,memberId){
		//alert(testId+' '+memberId);
		$('#section-reading-instructions').modal('show');
		testName = 'Reading Section Wise Details';
		coinCost = '270';
		
		$("#section-reading-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions  '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>Please Read all instructions carefully before you begin .<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li>'+coinCost+' Coins will be deducted from your account for this test Start test now!</li></ul></div></div><div class="text-center"><button type="button" class="btn btn-danger allow-reading-section-wise-submit" data-testid="'+testId+'" data-memberid="'+memberId+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
	}

	function sectionListeningInstructions(testId,memberId){
		//alert(testId+' '+memberId);
		//return false;
		
		$('#section-listening-instructions').modal('show');
		testName = 'Listening Section Wise Details';
		coinCost = '310';
		
		$("#section-listening-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions - '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>Please Read all instructions carefully before you begin .<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li>'+coinCost+' coins will be deducted from your account for this test Start test now!</li></ul></div></div><div class="text-center"><button type="button" class="btn btn-danger allow-section-wise-submit" data-testid="'+testId+'" data-memberid="'+memberId+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
	}
	
	function partInstructions(testId,memberId,testCode){
		
		$('#part-instructions').modal('show');	
		if(testId==14){
			testName = 'Listening Part 4: Labellinh on a Map';
			coinCost = '200';
		}else if(testId==29){
			testName = 'Listening Practice Task Questions:';
			coinCost = '15';
		}else if(testId==19){
			testName = 'Listening Part 2: Listening to Daily Life Conversation:';
			coinCost = '100';
		}else if(testId==18){
			testName = 'Listening Part 3: Listening for Information:';
			coinCost = '100';
		}else if(testId==11){
			testName = 'Listening Part 1: Multiple Choice Question with one answer';
			coinCost = '300';
		}else if(testId==16){
			testName = 'Listening Part 5: Listening to a Discussion';
			coinCost = '100';
		}else if(testId==15){
			testName = 'Listening Part 6: Listening to Viewpoints';
			coinCost = '100';
		}else if(testId==47){
			testName = 'Writing Task 1: Writing an Email Details';
			coinCost = '300';
		}else if(testId==46){
			testName = 'Writing Task 2: Responding to Survey Questions';
			coinCost = '300';
		}else if(testId==59){
			testName = 'Speaking: Practice Task';
			coinCost = '50';
		}else if(testId==58){
			testName = 'Speaking Task 1: Giving Advice ';
			coinCost = '120';
		}else if(testId==21){
			testName = 'Academic Reading Task 1: Multiple choice question with one answer';
			coinCost = '120';
		}else if(testId==56){
			testName = 'Speaking Task 3: Describing a Scene';
			coinCost = '120';
		}else if(testId==55){
			testName = 'Speaking Task 4: Making Predictions';
			coinCost = '120';
		}else if(testId==54){
			testName = 'Speaking Task 5: Comparing and Persuading';
			coinCost = '120';
		}else if(testId==53){
			testName = 'Speaking Task 6: Dealing with a Difficult Situation';
			coinCost = '120';
		}else if(testId==52){
			testName = 'Speaking Task 7: Expressing Opinions';
			coinCost = '120';
		}else if(testId==51){
			testName = 'Speaking Task 8: Describing an Unusual Situation';
			coinCost = '120';
		}else if(testId==41){
			testName = 'Academic writing Part 1';
			coinCost = '150';
		}else if(testId==39){
			testName = 'Reading Part 1: Reading Correspondence';
			coinCost = '150';
		}else if(testId==38){
			testName = 'Reading Part 2: Reading to Apply a Diagram';
			coinCost = '150';
		}else if(testId==37){
			testName = 'Reading Part 3: Reading for Information';
			coinCost = '150';
		}else if(testId==36){
			testName = 'Reading Part 4: Reading for Viewpoints';
			coinCost = '150';
		}else if(testId==61){
			testName = 'Speaking Part 1: Talking about a personal experience';
			coinCost = '300';
		}else{
			testName = '';
			coinCost = '';
		}
		
		$("#part-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>    Please Read all instructions carefully before you begin.<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li>'+coinCost+' Coins will be deducted from your account for this test. If you wisth to proceed, click on "Start it" now. </li></ul></div></div><div class="text-center"><button type="button" class="btn btn-danger allow-test-submit" data-testid="'+testId+'" data-memberid="'+memberId+'" data-testcode="'+testCode+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
	}
	
	function partWithTimerInstructions(testId,memberId,testCode){
		$('#part-instructions').modal('show');	
		if(testId==14){
			testName = 'Labelling on a Map';
			coinCost = '200';
		}else if(testId==29){
			testName = 'Listening Practice Task Questions:';
			coinCost = '15';
		}else if(testId==19){
			testName = 'Listening Part 2: Listening to Daily Life Conversation:';
			coinCost = '100';
		}else if(testId==18){
			testName = 'Listening Part 3: Listening for Information:';
			coinCost = '100';
		}else if(testId==11){
			testName = 'Listening Part 1: Multiple Choice question with one answer';
			coinCost = '300';
		}else if(testId==16){
			testName = 'Listening Part 5: Listening to a Discussion';
			coinCost = '100';
		}else if(testId==15){
			testName = 'Listening Part 6: Listening to Viewpoints';
			coinCost = '100';
		}else if(testId==47){
			testName = 'Writing Task 1: Writing an Email Details';
			coinCost = '300';
		}else if(testId==46){
			testName = 'Writing Task 2: Responding to Survey Questions';
			coinCost = '300';
		}else if(testId==59){
			testName = 'Speaking: Practice Task';
			coinCost = '50';
		}else if(testId==58){
			testName = 'Speaking Task 1: Giving Advice ';
			coinCost = '120';
		}else if(testId==61){
			testName = 'Speaking Task 1: Talking about a Personal Experience';
			coinCost = '120';
		}else if(testId==56){
			testName = 'Speaking Task 3: Describing a Scene';
			coinCost = '120';
		}else if(testId==55){
			testName = 'Speaking Task 4: Making Predictions';
			coinCost = '120';
		}else if(testId==54){
			testName = 'Speaking Task 5: Comparing and Persuading';
			coinCost = '120';
		}else if(testId==53){
			testName = 'Speaking Task 6: Dealing with a Difficult Situation';
			coinCost = '120';
		}else if(testId==52){
			testName = 'Speaking Task 7: Expressing Opinions';
			coinCost = '120';
		}else if(testId==51){
			testName = 'Speaking Task 8: Describing an Unusual Situation';
			coinCost = '120';
		}else if(testId==40){
			testName = 'Reading Practice Task';
			coinCost = '15';
		}else if(testId==39){
			testName = 'Reading Part 1: Reading Correspondence';
			coinCost = '150';
		}else if(testId==38){
			testName = 'Reading Part 2: Reading to Apply a Diagram';
			coinCost = '150';
		}else if(testId==37){
			testName = 'Reading Part 3: Reading for Information';
			coinCost = '150';
		}else if(testId==36){
			testName = 'Reading Part 4: Reading for Viewpoints';
			coinCost = '150';
		}else{
			testName = '';
			coinCost = '';
		}
		
		$("#part-instructions .modal-body").html('<div class="box box-solid"><div class="box-body"><h3 class="text-center"><u>Instructions - '+testName+'</u></h3><div class="alert alert-warning alert-dismissible" ><i class="glyphicon glyphicon-warning-sign"></i>Please Read all instructions carefully before you begin .<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div><ul><li>'+coinCost+' coins will be deducted from your account for this test Start test now!</li></ul></div></div><div class="text-center"><button type="button" class="btn btn-danger allow-timer-test-submit" data-testid="'+testId+'" data-memberid="'+memberId+'" data-testcode="'+testCode+'"><i class="fa fa-hand-o-right"></i> Start It</button></div>');
	}

  $(function () {
    
  $('.q1-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
	  $(this).next(".q1-sel-opt-text").show();
	  $(this).next(".q1-sel-opt-text").html('<b>'+ optionsText+'</b>');
      $(this).hide();
  });
    
  $(".q1-sel-opt-text").on('click',function(){
    $(this).hide();
	$(this).prev().show();
  });
  
  $('.q2-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q2-sel-opt-text').show();
     $(this).next(".q2-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q2-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
  
  $('.q3-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q3-sel-opt-text').show();
     $(this).next(".q3-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q3-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
  
  $('.q4-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q4-sel-opt-text').show();
     $(this).next(".q4-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q4-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
  
  $('.q5-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q5-sel-opt-text').show();
     $(this).next(".q5-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q5-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
  
  $('.q6-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q6-sel-opt-text').show();
     $(this).next(".q6-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q6-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
  
  $('.q7-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q7-sel-opt-text').show();
     $(this).next(".q7-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q7-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
  
  $('.q8-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q8-sel-opt-text').show();
     $(this).next(".q8-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q8-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
  
  $('.q9-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q9-sel-opt-text').show();
     $(this).next(".q9-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q9-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
  
  $('.q10-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q10-sel-opt-text').show();
     $(this).next(".q10-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q10-sel-opt-text").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
  
  $('.q11-sel-opt').on('change',function(){
     var optionsText = this.options[this.selectedIndex].text;
     $(this).next('.q11-sel-opt-text').show();
     $(this).next(".q11-sel-opt-text").html('<b>'+ optionsText+'</b>');
     $(this).hide();
  });
    
  $(".q11-sel-opt").on('click',function(){
    $(this).hide();
    $(this).prev().show();
  });
    
    var weburl = '<?php echo site_url(); ?>';

    // Token protection for ajax request
    $.ajaxSetup({ data: {
      '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>'
    }});

    //$("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  
  $('.fillBlanks-show-instructions').click(function(){
      $('#fillBlanks-instructions').modal('show');
    });
  
  $('#fillBlanks-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var memberid = $(this).attr('data-memberid');
      $.ajax({
        type: "POST",
        url: weburl + "member/startfillBlankstest/",
        data: {
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/fillBlanksTestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#fillBlanks-test-submit').prop('disabled', false);
          $('#fillBlanks-test-submit').html('Start Test Now');
        }
      });
    });
  
  
  $('.spottingErrors-show-instructions').click(function(){
      $('#spottingErrors-instructions').modal('show');
    });
  
  $('#spottingErrors-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var memberid = $(this).attr('data-memberid');
      $.ajax({
        type: "POST",
        url: weburl + "member/startSpottingErrorstest/",
        data: {
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/spottingErrorsTestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#spottingErrors-test-submit').prop('disabled', false);
          $('#spottingErrors-test-submit').html('Start Test Now');
        }
      });
    });
  
  
    $('.v-show-instructions').click(function(){
      $('#v-instructions').modal('show');
    });

    $('#v-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/startnewvtest/",
        data: {
          testid: testid,
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/vtestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#v-test-submit').prop('disabled', false);
          $('#v-test-submit').html('Start Test Now');
        }
      });
    });
  
  $('.reArrange-show-instructions').click(function(){
    $('#reArrange-instructions').modal('show');
  });

  $('#reArrange-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var memberid = $(this).attr('data-memberid');
      $.ajax({
        type: "POST",
        url: weburl + "member/startreArrangetest/",
        data: {
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/reArrangeTestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#reArrange-test-submit').prop('disabled', false);
          $('#reArrange-test-submit').html('Start Test Now');
        }
      });
    });
  
  
  $('.dictation-show-instructions').click(function(){
    $('#dictation-instructions').modal('show');
  });
  
  $('#dictation-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/startDictationtest/",
        data: {
          testid: testid,
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/dictationTestprogress/' + data.tdcode + '/' + data.tcode;
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#dictation-test-submit').prop('disabled', false);
          $('#dictation-test-submit').html('Start Test Now');
        }
      });
    });



    $('.show-instructions').click(function(){
      $('#instructions').modal('show');
    });

    $('#test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/startnewtest/",
        data: {
          testid: testid,
          memberid: memberid,
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testprogress/' + data.tdcode + '/' + data.tcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('#test-submit').prop('disabled', false);
          $('#test-submit').html('Start Test Now');
        }
      });
    });

    $('.parts-show-instructions').click(function(){
      $('#parts-instructions').modal('show');
    });
  
  
  $('body').on('click', '.allow-test-submit', function(){
  //$('.allow-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
    var testcode = $(this).attr('data-testcode');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/accessnewtest/",
        data: {
          testid: testid,
          memberid: memberid,
      testcode:testcode
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
      //return false;
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testnewprogress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });
	
	$('body').on('click', '.allow-timer-test-submit', function(){
	//$('.allow-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
    var testcode = $(this).attr('data-testcode');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/accessnewtimertest/",
        data: {
          testid: testid,
          memberid: memberid,
      testcode:testcode
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
      //return false;
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/timertestnewprogress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });
  
  $('body').on('click', '.allow-section-wise-submit', function(){
  //$('.allow-section-wise-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
    
      console.log('testid = ' +testid+ 'memberid = '+memberid);
    //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/accessSectionWisetest/",
        data: {
          testid: testid,
          memberid: memberid
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testSectionWiseprogress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });
	
	$('body').on('click', '.allow-reading-section-wise-submit', function(){
	//$('.allow-reading-section-wise-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
    
      console.log('testid = ' +testid+ 'memberid = '+memberid);
    //return false;
      $.ajax({
        type: "POST",
        url: weburl + "member/accessReadingSectionWisetest/",
        data: {
          testid: testid,
          memberid: memberid
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testReadingSectionWiseprogress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });
  
  
  $('#ls_practice_submit').click(function(){
  //$( "#submit_ptest" ).submit(function( event ) {
  ///event.preventDefault();
  //console.log($('#submit_ptest').serialize());
  //showAjaxLoader();
  //var form_data = $(this).serializeArray();
  //var form_data = new FormData();    
    //form_data.append( 'file', input.files[0] );
  
  //console.log(form_data); 
  var q1_response = $('input[name=q1-response]:checked').val();
  var token = $('input[name=token]').val();
  //return false;
  $.ajax({
        type: "POST",
        url: weburl + "member/practiceTaskSubmit/",
        data: {
          q1_response: q1_response,
      token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/29';
            window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
          //$('#submit_ptest').prop('disabled', false);
          //$('#submit_ptest').html('Submit');
        }
      });
  
  /*$.ajax({
        url: weburl+'member/practiceTaskSubmit/',
        type: 'post',
    data: form_data,
    /* data: {
          testid: '11',
          memberid: '15',
        }, */
       /* dataType: 'json',
    cache:false,
        success: function(data) {
      alert();
      return false;
      //$.isLoading("hide");
      //var response = JSON.parse(data);  
      console.log(data);    
    //  console.log(data.status);
      /* if(data.status ==0){
        var errorhtml = "<div class='error_msg alert alert-danger'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>"+data.error+"</div>";
        
        $('.form_error_data').html(errorhtml);
          $('html, body').animate({scrollTop:0}, 'slow');
        //$('.form_error_data').hide().delay(5000).fadeIn(400);
      }else{
        //location.reload();
        window.location.reload();
      }  */
      
        /*}
    });*/
});

  $('.rd_practice_submit').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var token = $('input[name=token]').val();
    if(q1_response!=''){
      $.ajax({
        type: "POST",
        url: weburl + "member/readingPracticeTaskSubmit/",
        data: {
          q1_response: q1_response,
          token:token
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          console.log(data);
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/40';
            window.location.href = testprogressurl;
          }
        },
        error:
        function(data) {
          //console.log(data);
          //$('#submit_ptest').prop('disabled', false);
          //$('#submit_ptest').html('Submit');
        }
      });
    }
    });
  
  $('.wt1_submit_btn').click(function(){
    
    var q1_response = $('textarea#wt_q1_response').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/wtPart1Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/41';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
  
  $('.wt2_submit_btn').click(function(){
    
    var q1_response = $('textarea#wt_q1_response').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/wtPart2Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/42';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
   $('.gw2_submit_btn').click(function(){
    
    var q1_response = $('textarea#gw_q1_response').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/gwPart2Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/52';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
   $('.gw1_submit_btn').click(function(){
    
    var q1_response = $('textarea#gw_q1_response').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/gwPart1Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/51';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
  
  
    
  
  
  $('.rd4_submit_btn').click(function(){
    var q1_response = $('input[name=q1-response]').val();
    var q2_response = $('input[name=q2-response]').val();
    var q3_response = $('input[name=q3-response]').val();
    var q4_response = $('input[name=q4-response]').val();
    var q5_response = $('input[name=q5-response]').val();
    var q6_response = $('input[name=q6-response]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart4Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/24';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
       $('.rd5_submit_btn').click(function(){
    var q1_response = $("#q1_answer").text();
    var q2_response = $("#q2_answer").text();
    var q3_response = $("#q3_answer").text();
    var q4_response =  $("#q4_answer").text();

    var token = $('input[name=token]').val();
    
    
    //return false;
     if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' ){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart5Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/25';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
     $('.rd7_submit_btn').click(function(){
         var q1_response = $("#q1_answer1").text();
         var q2_response = $("#q1_answer2").text();
         var q3_response = $("#q1_answer3").text();
         var q4_response = $("#q2_answer").text();

     
      var token = $('input[name=token]').val();
      
      if(q1_response!='' && q2_response!=''&&q3_response!='' && q4_response!=''){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/rdPart7Submit/",
          data: {
            q1_response: q1_response,
            q2_response: q2_response,
            q3_response: q3_response,
            q4_response: q4_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/27';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      }
    
    });
    
    
    
         $('.rd6_submit_btn').click(function(){
    var counterSelected = 0;
    var totalBlanks = $('#totalBlanks').val();

     var responseArr = [];
                $.each($("input[name='q1-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
    var q1_response = responseArr.join(",");
     
      var token = $('input[name=token]').val();
      
      if(q1_response && counterSelected == totalBlanks ){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/rdPart6Submit/",
          data: {
            q1_response: q1_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/26';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      }
    
    });
    
      $('.rd8_submit_btn').click(function(){
    var q1_response = $('input[name=q1-response]').val();
    var q2_response = $('input[name=q2-response]').val();
    var q3_response = $('input[name=q3-response]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' ){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart8Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/28';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
    
  $('.rd1_submit_btn').click(function(){
      var q1_response = $('input[name=q1-response]:checked').val();
      var q2_response = $('input[name=q2-response]:checked').val();
      var q3_response = $('input[name=q3-response]:checked').val();
      var q4_response = $('input[name=q4-response]:checked').val();

    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart1Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,  
        q4_response: q4_response,

        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/21';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
     $('.rd9_submit_btn').click(function(){
    var q1_response = $('input[name=q1-response]').val();
    var q2_response = $('input[name=q2-response]').val();
    var q3_response = $('input[name=q3-response]').val();
    var q4_response = $('input[name=q4-response]').val();
    var q5_response = $('input[name=q5-response]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart9Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/29';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
           $('.rd10_submit_btn').click(function(){
    var q1_response = $("#q1_answer").text();
    var q2_response = $("#q2_answer").text();
    var q3_response = $("#q3_answer").text();

    var token = $('input[name=token]').val();
    
    
    //return false;
     if(q1_response!='' && q2_response!='' && q3_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart10Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/30';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
    
  $('.rd1_submit_btn').click(function(){
      var q1_response = $('input[name=q1-response]:checked').val();
      var q2_response = $('input[name=q2-response]:checked').val();
      var q3_response = $('input[name=q3-response]:checked').val();
      var q4_response = $('input[name=q4-response]:checked').val();

    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart1Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,  
        q4_response: q4_response,

        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/21';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
  $('.rd3_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart3Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/23';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

 $('.rd2_submit_btn').click(function(){
    var q1_response = $('input[name=q1_response]').val();
     var q2_response = $('input[name=q2_response]').val();


    var token = $('input[name=token]').val();
     var array = []
	 var checkboxes = document.querySelectorAll('input[name=q1_response]:checked');
	 var array2 = []
	 var checkboxes2 = document.querySelectorAll('input[name=q2_response]:checked');
	   /* alert (checkboxes.length); */
	 for (var i = 0; i < checkboxes.length; i++  ) 
	 { array.push(checkboxes[i].value)
	
	 }
	 for (var j = 0; j < checkboxes2.length; j++  ) 
	 { array2.push(checkboxes2[j].value)
	
	 }

    if(array!=""&&array2!=""){
    $.ajax({
      type: "POST",
      url: weburl + "member/rdPart2Submit/",
      data: {
        q1_response: array,
        q2_response: array2,

        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/22';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
  
$('.rd_sec_next_btn').click(function() {
    //$(this).prop('disabled', true);
    //$(this).html('Please wait ...');
    $('audio').each(function() {
        this.pause(); // Stop playing
        this.currentTime = 0; // Reset time
    });
    var screenid = $(this).attr('data-screenid');
    //alert(screenid);
    if (screenid == 2) {
        $(".sec-wise-test-title").html('Part 1: Reading Correspondence');
    }
	
	if (screenid == 3) {
        $(".sec-wise-test-title").html('Reading Part 2: Reading to Apply a Diagram');
    }
	
	if (screenid == 4) {
        $(".sec-wise-test-title").html('Reading Part 3: Reading for Information');
    }
	
	if (screenid == 5) {
		$('.submit').html('Submit');
        $(".sec-wise-test-title").html('Reading Part 4: Reading for Viewpoints');
		$( ".rd_sec_next_btn" ).addClass("rd_sec_submit_btn");
    }
	
	if (screenid <= 5) {
        $(".ls-section-screen-" + screenid).show();
        $('.ls-section').not(".ls-section-screen-" + screenid).hide();
        $(this).attr("data-screenid", ++screenid);
    }
});  

$('body').on('click', '.rd_sec_submit_btn', function(){
    var practice_q1_response = $('select[name="practice-q1-response"]').val();
    var p1_q1_response = $('select[name="p1-q1-response"]').val();
    var p1_q2_response = $('select[name="p1-q2-response"]').val();
    var p1_q3_response = $('select[name="p1-q3-response"]').val();
    var p1_q4_response = $('select[name="p1-q4-response"]').val();
    var p1_q5_response = $('select[name="p1-q5-response"]').val();
    var p1_q6_response = $('select[name="p1-q6-response"]').val();
    var p1_q7_response = $('select[name="p1-q7-response"]').val();
    var p1_q8_response = $('select[name="p1-q8-response"]').val();
    var p1_q9_response = $('select[name="p1-q9-response"]').val();
    var p1_q10_response = $('select[name="p1-q10-response"]').val();
    var p1_q11_response = $('select[name="p1-q11-response"]').val();
	
	var p2_q1_response = $('select[name="p2-q1-response"]').val();
    var p2_q2_response = $('select[name="p2-q2-response"]').val();
    var p2_q3_response = $('select[name="p2-q3-response"]').val();
    var p2_q4_response = $('select[name="p2-q4-response"]').val();
    var p2_q5_response = $('select[name="p2-q5-response"]').val();
    var p2_q6_response = $('select[name="p2-q6-response"]').val();
    var p2_q7_response = $('select[name="p2-q7-response"]').val();
    var p2_q8_response = $('select[name="p2-q8-response"]').val();
	
	var p3_q1_response = $('select[name="p3-q1-response"]').val();
    var p3_q2_response = $('select[name="p3-q2-response"]').val();
    var p3_q3_response = $('select[name="p3-q3-response"]').val();
    var p3_q4_response = $('select[name="p3-q4-response"]').val();
    var p3_q5_response = $('select[name="p3-q5-response"]').val();
    var p3_q6_response = $('select[name="p3-q6-response"]').val();
    var p3_q7_response = $('select[name="p3-q7-response"]').val();
    var p3_q8_response = $('select[name="p3-q8-response"]').val();
    var p3_q9_response = $('select[name="p3-q9-response"]').val();
	
	var p4_q1_response = $('select[name="p4-q1-response"]').val();
    var p4_q2_response = $('select[name="p4-q2-response"]').val();
    var p4_q3_response = $('select[name="p4-q3-response"]').val();
    var p4_q4_response = $('select[name="p4-q4-response"]').val();
    var p4_q5_response = $('select[name="p4-q5-response"]').val();
    var p4_q6_response = $('select[name="p4-q6-response"]').val();
    var p4_q7_response = $('select[name="p4-q7-response"]').val();
    var p4_q8_response = $('select[name="p4-q8-response"]').val();
    var p4_q9_response = $('select[name="p4-q9-response"]').val();
    var p4_q10_response = $('select[name="p4-q10-response"]').val();
    
    var token = $('input[name=token]').val();
    //return false;
	if(p4_q1_response!=''){
		$.ajax({
		  type: "POST",
		  url: weburl + "member/readingSectionSubmit/",
		  data: {
			p1_q1_response : p1_q1_response,
			p1_q2_response : p1_q2_response,
			p1_q3_response : p1_q3_response,
			p1_q4_response : p1_q4_response,
			p1_q5_response : p1_q5_response,
			p1_q6_response : p1_q6_response,
			p1_q7_response : p1_q7_response,
			p1_q8_response : p1_q8_response,
			p1_q9_response : p1_q9_response,
			p1_q10_response : p1_q10_response,
			p1_q11_response : p1_q11_response,
					 
			p2_q1_response : p2_q1_response,
			p2_q2_response : p2_q2_response,
			p2_q3_response : p2_q3_response,
			p2_q4_response : p2_q4_response,
			p2_q5_response : p2_q5_response,
			p2_q6_response : p2_q6_response,
			p2_q7_response : p2_q7_response,
			p2_q8_response : p2_q8_response,
					 
			p3_q1_response : p3_q1_response,
			p3_q2_response : p3_q2_response,
			p3_q3_response : p3_q3_response,
			p3_q4_response : p3_q4_response,
			p3_q5_response : p3_q5_response,
			p3_q6_response : p3_q6_response,
			p3_q7_response : p3_q7_response,
			p3_q8_response : p3_q8_response,
			p3_q9_response : p3_q9_response,
			
			p4_q1_response : p4_q1_response,
			p4_q2_response : p4_q2_response,
			p4_q3_response : p4_q3_response,
			p4_q4_response : p4_q4_response,
			p4_q5_response : p4_q5_response,
			p4_q6_response : p4_q6_response,
			p4_q7_response : p4_q7_response,
			p4_q8_response : p4_q8_response,
			p4_q9_response : p4_q9_response,
			p4_q10_response : p4_q10_response,
			
			token: token
		  },
		  dataType: "json",
		  cache: false,
		  success: function(data) {
			if (data.result == "success") {
			  //alert();
			  //return false;
			  var testprogressurl = weburl + 'member/getSectionReading';
			  window.location.href = testprogressurl;
			}
			console.log(data);
		  },
		  error: function(data) {
			console.log(data);
			//$('#submit_ptest').prop('disabled', false);
			//$('#submit_ptest').html('Submit');
		  }
		  //console.log(data);

		});
	}
   //console.log(data);
});

  
$('.ls_sec_next_btn').click(function() {
    //$(this).prop('disabled', true);
    //$(this).html('Please wait ...');
    $('audio').each(function() {
        this.pause(); // Stop playing
        this.currentTime = 0; // Reset time
    });
    var screenid = $(this).attr('data-screenid');
    //alert(screenid);
    if (screenid == 2) {
        $(".sec-wise-test-title").html('Listening Part 1: Listening to Problem Solving');
    }
    if (screenid == 14) {
        $(".sec-wise-test-title").html('Listening Part 2: Listening to Daily Life Conversation');
    }

    if (screenid == 14) {
        $(".sec-wise-test-title").html('Listening Part 4: Labelling on a Map');
    }

    if (screenid == 26) {
        $(".sec-wise-test-title").html('Listening Part 4: Listening to a News Item');
    }
    if (screenid == 28) {
        $(".sec-wise-test-title").html('Listening Part 5: Listening to a Discussion');
    }
    if (screenid == 30) {
        $(".sec-wise-test-title").html('Listening Part 6: Listening to Viewpoints');
    }
    if (screenid <= 32) {
        $(".ls-section-screen-" + screenid).show();
        $('.ls-section').not(".ls-section-screen-" + screenid).hide();
        $(this).attr("data-screenid", ++screenid);
    }
  
  if(screenid==33){
    $('.submit').html('Submit');
	$( ".ls_sec_next_btn" ).addClass("ls_sec_submit_btn");
  }
});

$('body').on('click', '.ls_sec_submit_btn', function(){
	//alert();
	var practice_q1_response = $('input[name=practice-q1-response]:checked').val();
    var p1_q1_response = $('input[name=p1-q1-response]:checked').val();
    var p1_q2_response = $('input[name=p1-q2-response]:checked').val();
    var p1_q3_response = $('input[name=p1-q3-response]:checked').val();
    var p1_q4_response = $('input[name=p1-q4-response]:checked').val();
    var p1_q5_response = $('input[name=p1-q5-response]:checked').val();
    var p1_q6_response = $('input[name=p1-q6-response]:checked').val();
    var p1_q7_response = $('input[name=p1-q7-response]:checked').val();
    var p1_q8_response = $('input[name=p1-q8-response]:checked').val();
    
    var p2_q1_response = $('input[name=p2-q1-response]:checked').val();
    var p2_q2_response = $('input[name=p2-q2-response]:checked').val();
    var p2_q3_response = $('input[name=p2-q3-response]:checked').val();
    var p2_q4_response = $('input[name=p2-q4-response]:checked').val();
    var p2_q5_response = $('input[name=p2-q5-response]:checked').val();
    
    var p3_q1_response = $('input[name=p3-q1-response]:checked').val();
    var p3_q2_response = $('input[name=p3-q2-response]:checked').val();
    var p3_q3_response = $('input[name=p3-q3-response]:checked').val();
    var p3_q4_response = $('input[name=p3-q4-response]:checked').val();
    var p3_q5_response = $('input[name=p3-q5-response]:checked').val();
    
    var p4_q1_response = $('select[name="p4-q1-response"]').val();
    var p4_q2_response = $('select[name="p4-q2-response"]').val();
    var p4_q3_response = $('select[name="p4-q3-response"]').val();
    var p4_q4_response = $('select[name="p4-q4-response"]').val();
    var p4_q5_response = $('select[name="p4-q5-response"]').val();
    
    var p5_q1_response = $('select[name="p5-q1-response"]').val();
    var p5_q2_response = $('select[name="p5-q2-response"]').val();
    var p5_q3_response = $('select[name="p5-q3-response"]').val();
    var p5_q4_response = $('select[name="p5-q4-response"]').val();
    var p5_q5_response = $('select[name="p5-q5-response"]').val();
    var p5_q6_response = $('select[name="p5-q6-response"]').val();
    var p5_q7_response = $('select[name="p5-q7-response"]').val();
    var p5_q8_response = $('select[name="p5-q8-response"]').val();

    var p6_q1_response = $('select[name="p6-q1-response"]').val();
    var p6_q2_response = $('select[name="p6-q2-response"]').val();
    var p6_q3_response = $('select[name="p6-q3-response"]').val();
    var p6_q4_response = $('select[name="p6-q4-response"]').val();
    var p6_q5_response = $('select[name="p6-q5-response"]').val();
    var p6_q6_response = $('select[name="p6-q6-response"]').val();
    
    var token = $('input[name=token]').val();
    //return false;
	if(p6_q1_response!=''){
		$.ajax({
		  type: "POST",
		  url: weburl + "member/listeningSectionSubmit/",
		  data: {
			practice_q1_response : practice_q1_response,
			p1_q1_response : p1_q1_response,
			p1_q2_response : p1_q2_response,
			p1_q3_response : p1_q3_response,
			p1_q4_response : p1_q4_response,
			p1_q5_response : p1_q5_response,
			p1_q6_response : p1_q6_response,
			p1_q7_response : p1_q7_response,
			p1_q8_response : p1_q8_response,
					 
			p2_q1_response : p2_q1_response,
			p2_q2_response : p2_q2_response,
			p2_q3_response : p2_q3_response,
			p2_q4_response : p2_q4_response,
			p2_q5_response : p2_q5_response,
					 
			p3_q1_response : p3_q1_response,
			p3_q2_response : p3_q2_response,
			p3_q3_response : p3_q3_response,
			p3_q4_response : p3_q4_response,
			p3_q5_response : p3_q5_response,
			
			p4_q1_response : p4_q1_response,
			p4_q2_response : p4_q2_response,
			p4_q3_response : p4_q3_response,
			p4_q4_response : p4_q4_response,
			p4_q5_response : p4_q5_response,
			
			p5_q1_response : p5_q1_response,
			p5_q2_response : p5_q2_response,
			p5_q3_response : p5_q3_response,
			p5_q4_response : p5_q4_response,
			p5_q5_response : p5_q5_response,
			p5_q6_response : p5_q6_response,
			p5_q7_response : p5_q7_response,
			p5_q8_response : p5_q8_response,

			p6_q1_response : p6_q1_response,
			p6_q2_response : p6_q2_response,
			p6_q3_response : p6_q3_response,
			p6_q4_response : p6_q4_response,
			p6_q5_response : p6_q5_response,
			p6_q6_response : p6_q6_response,
			
			token: token
		  },
		  dataType: "json",
		  cache: false,
		  success: function(data) {
			if (data.result == "success") {
			  //alert();
			  //return false;
			  var testprogressurl = weburl + 'member/getSectionListening';
			  window.location.href = testprogressurl;
			}
			console.log(data);
		  },
		  error: function(data) {
			console.log(data);
			//$('#submit_ptest').prop('disabled', false);
			//$('#submit_ptest').html('Submit');
		  }
		  //console.log(data);

		});
	}
   console.log(data);
});
  
  
  
   $('.ls1_submit_btn').click(function(){
      var q1_response = $('input[name=q1-response]:checked').val();
      var q2_response = $('input[name=q2-response]:checked').val();
      var q3_response = $('input[name=q3-response]:checked').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' ){
    $.ajax({
      type: "POST",
      url: weburl + "member/lsPart1Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/11';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
    $('.ls2_submit_btn').click(function(){
    var q1_response = $('input[name=q1response]').val();

    var token = $('input[name=token]').val();
     var array = []
	 var checkboxes = document.querySelectorAll('input[name=q1response]:checked');
	   /* alert (checkboxes.length); */
	 for (var i = 0; i < checkboxes.length; i++) 
	 { array.push(checkboxes[i].value)
	 }

    if(array!=""){
    $.ajax({
      type: "POST",
      url: weburl + "member/lsPart2Submit/",
      data: {
        q1_response: array,

        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/12';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
     $('.ls3_submit_btn').click(function(){
    var q1_response = $("#q1_answer").text();
    var q2_response = $("#q2_answer").text();
    var q3_response = $("#q3_answer").text();
    var q4_response =  $("#q4_answer").text();
    var q5_response =  $("#q5_answer").text();
    
    var token = $('input[name=token]').val();
    
    
    //return false;
     if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/lsPart3Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/13';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });

$('.ls4_submit_btn').click(function(){
    var q1_response = $('input[name=q1-response]:checked').val();
    var q2_response = $('input[name=q2-response]:checked').val();
    var q3_response = $('input[name=q3-response]:checked').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' ){
    $.ajax({
      type: "POST",
      url: weburl + "member/lsPart4Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/14';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
$('.gr1_submit_btn').click(function(){
    var q1_response = $('input[name=q1-response]:checked').val();
    var q2_response = $('input[name=q2-response]:checked').val();
    var q3_response = $('input[name=q3-response]:checked').val();
    var q4_response = $('input[name=q4-response]:checked').val();
    var q5_response = $('input[name=q5-response]:checked').val();
    var q6_response = $('input[name=q6-response]:checked').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' ){
    $.ajax({
      type: "POST",
      url: weburl + "member/grPart1Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/31';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
$('.gr2_submit_btn').click(function(){
   var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var q6_response = $('select[name="q6-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!='' && q6_response!='' ){
    $.ajax({
      type: "POST",
      url: weburl + "member/grPart2Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        q6_response: q6_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/32';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
      $('.gr3_submit_btn').click(function(){
    var q1_response = $('input[name=q1-response]').val();
    var q2_response = $('input[name=q2-response]').val();
    var q3_response = $('input[name=q3-response]').val();
    var q4_response = $('input[name=q4-response]').val();
    var q5_response = $('input[name=q5-response]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/grPart3Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/33';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
    
    $('.gr4_submit_btn').click(function(){
            
    var counterSelected = 0;
    var counterSelected2 = 0;
    var totalBlanks = $('#totalBlanks').val();
    var totalBlanks2 = $('#totalBlanks2').val();

     var responseArr = [];
                $.each($("input[name='q1-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
    var q1_response = responseArr.join(",");
     var responseArr2 = [];
                $.each($("input[name='q3-response']"), function(){
                  if($(this).val()){
                    responseArr2.push($(this).val());
                    counterSelected2++;
                  }
                });
    var q3_response = responseArr2.join(",");

    var q2_response = $('input[name=q2-response]').val();
    var q4_response = $('input[name=q4-response]').val();
    var token = $('input[name=token]').val();
    //return false;
    if( q2_response!='' && q4_response!='' && q1_response && counterSelected == totalBlanks && q3_response && counterSelected2 == totalBlanks2){
    $.ajax({
      type: "POST",
      url: weburl + "member/grPart4Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/34';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
    
    
    $('.gr5_submit_btn').click(function(){
    var q1_response = $('input[name=q1-response]:checked').val();
    var q2_response = $('input[name=q2-response]:checked').val();
    var q3_response = $('input[name=q3-response]:checked').val();
    var q4_response = $('input[name=q4-response]:checked').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' ){
    $.ajax({
      type: "POST",
      url: weburl + "member/grPart5Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/35';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
    $('.gr6_submit_btn').click(function(){
       var q1_response = $('input[name=q1response]').val();

    var token = $('input[name=token]').val();
     var array = []
	 var checkboxes = document.querySelectorAll('input[name=q1response]:checked');
	   /* alert (checkboxes.length); */
	 for (var i = 0; i < checkboxes.length; i++) 
	 { array.push(checkboxes[i].value)
	 }

    if(array!=""){
    $.ajax({
      type: "POST",
      url: weburl + "member/grPart6Submit/",
      data: {
        q1_response: array,

        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/36';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
    
      $('.gr7_submit_btn').click(function(){
    var counterSelected = 0;
    var totalBlanks = $('#totalBlanks').val();

     var responseArr = [];
                $.each($("input[name='q1-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
    var q1_response = responseArr.join(",");
     
      var token = $('input[name=token]').val();
      
      if(q1_response && counterSelected == totalBlanks ){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/grPart7Submit/",
          data: {
            q1_response: q1_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/37';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      }
    
    });
    
    
    
    
    
  $('.ls5_submit_btn').click(function(){
    $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
      
    var counterSelected = 0;
    var counterSelected2 = 0;
    var counterSelected3 = 0;
    var totalBlanks = $('#totalBlanks').val();
    var totalBlanks2 = $('#totalBlanks2').val();
    var totalBlanks3 = $('#totalBlanks3').val();

     var responseArr = [];
                $.each($("input[name='q1-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
    var q1_response = responseArr.join(",");
     var responseArr2 = [];
                $.each($("input[name='q2-response']"), function(){
                  if($(this).val()){
                    responseArr2.push($(this).val());
                    counterSelected2++;
                  }
                });
    var q2_response = responseArr2.join(",");
     var responseArr3 = [];
                $.each($("input[name='q3-response']"), function(){
                  if($(this).val()){
                    responseArr3.push($(this).val());
                    counterSelected3++;
                  }
                });
    var q3_response = responseArr3.join(",");
      var token = $('input[name=token]').val();
      
      if(q1_response && counterSelected == totalBlanks && q2_response && counterSelected2 == totalBlanks2 && q3_response && counterSelected3 == totalBlanks3 ){
        //return false;
        $.ajax({
          type: "POST",
          url: weburl + "member/lsPart5Submit/",
          data: {
            q1_response: q1_response,
            q2_response: q2_response,
            q3_response: q3_response,
            token:token
          },
          dataType:"json",
          cache:false,
          success:
          function(data) {
            console.log(data);
            if( data.result == "success") {
            var testprogressurl = weburl + 'member/getTestList/15';
            window.location.href = testprogressurl;
            }
          },
          error:
          function(data) {
            //console.log(data);
          }
          });
      }
    
    });
  
 $('.ls6_submit_btn').click(function(){
     $('audio').each(function(){
      this.pause(); // Stop playing
      this.currentTime = 0; // Reset time
    });
    var q1_response = $('textarea#q1-response').val();
    var q2_response = $('textarea#q2-response').val();
    var q3_response = $('textarea#q3-response').val();

    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/lsPart6Submit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/16';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
      
  $('.sp_practice_submit').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/speakingPracticeTaskSubmit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/59';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });
  
  $('.sp1_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart1Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/58';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });
  
   $('.sp2_next_btn').click(function(){
  var q1_response = $("input[name=audiofile]").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart2Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/62';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });



   $('.sp3_next_btn').click(function(){
  var q1_response = $("input[name=audiofile]").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart3Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/63';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

     $('.sp3_next_btn').click(function(){
  var q1_response = $("input[name=audiofile]").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart4Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/64';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });

  
  
  $('.sp2_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart2Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/61';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });
  
  $('.sp3_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart3Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/56';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });
  
  $('.sp4_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart4Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/55';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });
  
  $('.sp5_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart5Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/54';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });
  
  $('.sp6_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart6Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/53';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });
  
  $('.sp7_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart7Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/52';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });
  
  $('.sp8_submit_btn').click(function(){
  var q1_response = $("#sp_response_file").val();
  var token = $('input[name=token]').val();
    if(q1_response!='' || q1_response!=undefined){
    $.ajax({
      type: "POST",
      url: weburl + "member/spPart8Submit/",
      data: {
        q1_response: q1_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/getTestList/51';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
      });
    }
  });
  
  $('.allow-comprehension-test-submit').click(function(){
      $(this).prop('disabled', true);
      $(this).html('Please wait ...');
      var testid = $(this).attr('data-testid');
      var memberid = $(this).attr('data-memberid');
      console.log('testid = ' +testid);
      $.ajax({
        type: "POST",
        url: weburl + "member/accessComprehensionTest/",
        data: {
          testid: testid,
          memberid: memberid
        },
        dataType:"json",
        cache:false,
        success:
        function(data) {
          //console.log(data);
          //return false;
          if( data.result == "success") {
            var testprogressurl = weburl + 'member/testComprehensionProgress/' + data.tdcode;
            //console.log(testprogressurl);
            window.location.href = testprogressurl;
            //window.location.reload(true) = testprogressurl;
          }else{
      $('.get_test_msg').html(data.message);
      }
        },
        error:
        function(data) {
          console.log(data);
          $('.allow-test-submit').prop('disabled', false);
          $('.allow-test-submit').html('Start Test Now');
        }
      });
    });
	
	$('.comprehension_submit_btn').click(function(){
    var q1_response = $('select[name="q1-response"]').val();
    var q2_response = $('select[name="q2-response"]').val();
    var q3_response = $('select[name="q3-response"]').val();
    var q4_response = $('select[name="q4-response"]').val();
    var q5_response = $('select[name="q5-response"]').val();
    var token = $('input[name=token]').val();
    //return false;
    if(q1_response!='' && q2_response!='' && q3_response!='' && q4_response!='' && q5_response!=''){
    $.ajax({
      type: "POST",
      url: weburl + "member/comprehensionSubmit/",
      data: {
        q1_response: q1_response,
        q2_response: q2_response,
        q3_response: q3_response,
        q4_response: q4_response,
        q5_response: q5_response,
        token:token
      },
      dataType:"json",
      cache:false,
      success:
      function(data) {
        console.log(data);
        if( data.result == "success") {
        var testprogressurl = weburl + 'member/comprehensionTest';
        window.location.href = testprogressurl;
        }
      },
      error:
      function(data) {
        //console.log(data);
        //$('#submit_ptest').prop('disabled', false);
        //$('#submit_ptest').html('Submit');
      }
    });
    }
    });
  
  $("#example1").DataTable();
  });
</script>