
    <a href="<?php echo base_url($currentPath.'/dashboard'); ?>" class="logo" style="background-color:white;">
      <span class="logo-mini"><img src="images/ielts24x7.png" style="max-width: 100%;height: auto;"></span>
      <span class="logo-lg"><img src="images/ielts24x7.png" style="max-width: 100%;height: auto;"></span>
    </a>

    <nav class="navbar navbar-static-top">

      <a class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
      

          <li class="dropdown user user-menu">
            <a class="dropdown-toggle" data-toggle="dropdown">
			
			  <span>Balance Coins: <?php echo $user->coins; ?> </span> | 
            <!---  <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">--->
              <span class="hidden-xs">Welcome, <?php echo strtoupper($user->username); ?> </span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
               <!--- <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">---->
                <p>
                  <?php echo strtoupper($user->username); ?>
                  <small><?php echo $user->name; ?></small>
                </p>
              </li>
            
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?php echo base_url('member/editProfile') ?>" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="<?php echo base_url($currentPath.'/logout'); ?>" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>

          <li>
            <a href="<?php echo base_url($currentPath.'/logout'); ?>" ><i class="fa fa-sign-out"></i></a>
          </li>
        </ul>
      </div>
    </nav>
