<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>
<style>
    .timeline-body {
        white-space: pre-line;
        margin-top: -40px;
    }
</style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        TICKET
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Ticket</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
            </div>

                      <?php if (@$_GET['trash']) { ?>
                      <div class="alert alert-success">
                      <button class="close" type="button" data-dismiss="alert">
                      <span aria-hidden="true">&times;</span>
                      </button>
                      Ticket information deleted.
                      </div>
                      <?php } ?>

      


            <!-- /.box-header -->
            <div class="box-body">
              <table id="example10" class="table table-bordered table-striped">



                   <?php if($support->status=="open"){ ?>

                    <p class="pull-right">
                      <?php $_onClick = "onclick=\"return confirm('Are you sure you want to Close ".$support->title." ? This action will Close your ticket.')\"";?>
                        <a href="<?php echo base_url($currentPath.'/closeTicket/'.$support->id); ?>" class="btn  btn-danger" title="Resoloved " <?php echo $_onClick; ?> data-toggle="tooltip" data-placement="left"><i class="fa fa-trash-o"></i> Close This Ticket </a>
                   </p>

                  <?php }else{
                    echo '<span class="label label-success pull-right">Resoloved</span>';
                  }
                  ?>

                      

                      <div><h4><?php echo $support->title; ?></h4>
                      </div>
                      <div style="white-space: pre-wrap;"><?php echo $support->details; ?></div>

                      <br>
                      <thead>
                                 <tr>
                                  <th>Responce</th>
                                 
                                </tr>
                              </thead>

                              <tbody>

     

                         <?php
                         


                if (!empty($tickets)) {
                foreach ($tickets as $key => $ticket) { ?>

                  <?php
                    $now = time(); // or your date as well
                    $your_date = $ticket->time;
                    $datediff = $now - $your_date;
                    $olddays=round($datediff / (60 * 60 * 24));

                  ?>

                     <tr>
                          <td>

                              <ul class="timeline">

                              <!-- timeline time label -->
                              <li class="time-label">
                                  <span class="bg-red">
                                      <?=date("d M. Y",$ticket->time)?>

                                  </span>
                              </li>
                              <!-- /.timeline-label -->

                              <!-- timeline item -->
                              <li>
                                  <!-- timeline icon -->
                                  <i class="fa fa-envelope bg-blue"></i>
                                  <div class="timeline-item">
                                      <span class="time"><i class="fa fa-clock-o"></i> <?php echo $olddays;?> days</span>

                                      <h3 class="timeline-header">

                                     <?php if($ticket->member_id==$user->id){?> you<?php }else{?>Support Team <?php }?>

                                    </h3>

                                      <div class="timeline-body">
                                        
                                         <?=$ticket->details?>
                                      </div>

                                    
                                  </div>
                              </li>
                              <!-- END timeline item -->

                         

                          </ul>
                                  

                          </td>
                          

                         
                        </tr>


                <?php }} ?>
     


                          </tbody>
              </table>


               <?php if($support->status=="open"){?>

                 <?php 

                //Form syntex echo form_open('form/data_submitted'); 

                echo form_open_multipart('member/replyTicket/'.$support->id, array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>

                  <div class="row">
                      <div class="col-md-11">
                            <div class="form-group">
                            <!-- <label>Add new message</label> -->

                            <textarea class="form-control" rows="2" name="details" placeholder="Place some text here" required><?php echo set_value('details'); ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary btn-fill pull-right">Reply</button>
                      </div>
                            
                 </form>
                  </div>                     
                <div class="clearfix"></div>
              <?php }?>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->


  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

 
  <?php include_once('common/scripts.php'); ?>
</body>
</html>
