<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
  <style type="text/css">
    .widget-user .widget-user-header {
      padding: 15px;
      height: 90px;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
    }
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
  
  <div class="wrapper">

    <header class="main-header">
      <?php include_once('common/nav.php'); ?>
    </header>
    <aside class="main-sidebar">
      <?php include_once('common/sidebar.php'); ?>
    </aside>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?>  
        <small>Select <?php echo $pagetitle; ?> </small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
		
	  <?php if($typeid == '1') { ?>
      <div class="row">
        <div class="col-md-12">
                <?php if($listening) { ?>
                  <?php foreach ($listening as $key => $subtype) {

                      $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
    				  
					  //echo "<pre>";print_r($subtype);die;
                    ?>
					<div class="col-md-4">
                        <div class="box box-widget widget-user boxcustom">
                          <div class="widget-user-header bg-purplex">
                            <h3 class="widget-user-username text-center"><b><?php echo $subtype->PTEsubtype; ?></b></h3>
							<h5 class="widget-user-desc">
                              <strong>Coins </strong> : <?php echo $subtype->coin_cost; ?>
                            </h5>
                            <h5 class="widget-user-desc">
                              <strong>Total tests </strong> : 
                              <?php  
                             
                              if($subtype->total_test >= $number_of_visible_questions){
                                echo $number_of_visible_questions;
                              }else{
                                echo $subtype->total_test;
                              } 
                              ?>

                            </h5>
                          </div>
                         <div class="box-footer no-padding">
							<a href="<?php echo base_url($currentPath.'/getTestList/'.$subtype->id); ?>" class="btn btn-block btn-info">START TEST</a>
							 <?php //echo $start_btn; ?>
                          </div>
                        </div>
                      </div>
                  <?php } ?>
                <?php } ?>
        </div>
      </div>
      <?php } ?>
		
		
		
	<?php if($typeid == '4') { ?>
      <div class="row">
        <div class="col-md-12">
                <?php if($academicwriting) { ?>
                  <?php foreach ($academicwriting as $key => $subtype) {

                      $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
                    ?>
					<div class="col-md-4">
                        <div class="box box-widget widget-user boxcustom">
                          <div class="widget-user-header bg-purplex">
                            <h3 class="widget-user-username text-center"><b><?php echo $subtype->PTEsubtype; ?></b></h3>
							<h5 class="widget-user-desc">
                              <strong>Coins </strong> : <?php echo $subtype->coin_cost; ?>
                            </h5>
							<h5 class="widget-user-desc">
							  <strong>Total tests </strong> : <?php  
                             
                              if($subtype->total_test >= $number_of_visible_questions){
                                echo $number_of_visible_questions;
                              }else{
                                echo $subtype->total_test;
                              } 
                              ?>
							</h5>
                          </div>
                          <div class="box-footer no-padding">
							<a href="<?php echo base_url($currentPath.'/getTestList/'.$subtype->id); ?>" class="btn btn-block btn-info">START TEST</a>
                            <?php //echo $start_btn; ?>
                          </div>
                        </div>
                      </div>
                  <?php } ?>
                <?php } ?>
        </div>
      </div>
      <?php } ?>
	  
	  
	  <?php if($typeid == '2') { ?>
      <div class="row">
        <div class="col-md-12">
		<?php if($academicreading) { ?>
			<?php foreach ($academicreading as $key => $subtype) {

			  $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
			  $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
			?>
			<div class="col-md-4">
				<div class="box box-widget widget-user boxcustom">
				  <div class="widget-user-header bg-purplex">
					<h3 class="widget-user-username text-center"><b><?php echo $subtype->PTEsubtype; ?></b></h3>
					<h5 class="widget-user-desc">
					  <strong>Coins </strong> : <?php echo $subtype->coin_cost; ?>
					</h5>
					<h5 class="widget-user-desc">
					  <strong>Total tests </strong> : <?php  
                             
                              if($subtype->total_test >= $number_of_visible_questions){
                                echo $number_of_visible_questions;
                              }else{
                                echo $subtype->total_test;
                              } 
                              ?>
					</h5>
				  </div>
				  <div class="box-footer no-padding">
					<a href="<?php echo base_url($currentPath.'/getTestList/'.$subtype->id); ?>" class="btn btn-block btn-info">START TEST</a>
				  </div>
				</div>
			  </div>
		  <?php } ?>
		<?php } ?>
        </div>
      </div>
      <?php } ?>
	  
	  <?php if($typeid == '3') { ?>
      <div class="row">
        <div class="col-md-12">
	    <?php if($generalreading) { ?>
		  <?php foreach ($generalreading as $key => $subtype) {

			  $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
			  $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
			?>
			<div class="col-md-4">
				<div class="box box-widget widget-user boxcustom">
				  <div class="widget-user-header bg-purplex">
					<h3 class="widget-user-username text-center"><b><?php echo $subtype->PTEsubtype; ?></b></h3>
					<h5 class="widget-user-desc">
					  <strong>Coins </strong> : <?php echo $subtype->coin_cost; ?>
					</h5>
					<h5 class="widget-user-desc">
					  <strong>Total tests </strong> : <?php  
                             
                              if($subtype->total_test >= $number_of_visible_questions){
                                echo $number_of_visible_questions;
                              }else{
                                echo $subtype->total_test;
                              } 
                              ?>
					</h5>
				  </div>
				   <div class="box-footer no-padding">
							<a href="<?php echo base_url($currentPath.'/getTestList/'.$subtype->id); ?>" class="btn btn-block btn-info">START TEST</a>
							 <?php //echo $start_btn; ?>
				  </div>
				</div>
			  </div>
		  <?php } ?>
		<?php } ?>
        </div>
      </div>
      <?php } ?>
      <?php if($typeid == '5') { ?>
      <div class="row">
        <div class="col-md-12">
                <?php if($generalwriting) { ?>
                  <?php foreach ($generalwriting as $key => $subtype) {

                      $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
                    ?>
					<div class="col-md-4">
                        <div class="box box-widget widget-user boxcustom">
                          <div class="widget-user-header bg-purplex">
                            <h3 class="widget-user-username text-center"><b><?php echo $subtype->PTEsubtype; ?></b></h3>
							<h5 class="widget-user-desc">
                              <strong>Coins </strong> : <?php echo $subtype->coin_cost; ?>
                            </h5>
							<h5 class="widget-user-desc">
							  <strong>Total tests </strong> : <?php  
                             
                              if($subtype->total_test >= $number_of_visible_questions){
                                echo $number_of_visible_questions;
                              }else{
                                echo $subtype->total_test;
                              } 
                              ?>
							</h5>
                          </div>
                          <div class="box-footer no-padding">
							<a href="<?php echo base_url($currentPath.'/getTestList/'.$subtype->id); ?>" class="btn btn-block btn-info">START TEST</a>
                            <?php //echo $start_btn; ?>
                          </div>
                        </div>
                      </div>
                  <?php } ?>
                <?php } ?>
        </div>
      </div>
      <?php } ?>
		<?php if($typeid == '6') { ?>
      <div class="row">
        <div class="col-md-12">
                <?php if($speaking) { ?>
                  <?php foreach ($speaking as $key => $subtype) {

                      $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
                    ?>
					<div class="col-md-4">
                        <div class="box box-widget widget-user boxcustom">
                          <div class="widget-user-header bg-purplex">
                            <h3 class="widget-user-username text-center"><b><?php echo $subtype->PTEsubtype; ?></b></h3>
							<h5 class="widget-user-desc">
                              <strong>Coins </strong> : <?php echo $subtype->coin_cost; ?>
                            </h5>
							<h5 class="widget-user-desc">
							  <strong>Total tests </strong> : <?php  
                             
                              if($subtype->total_test >= $number_of_visible_questions){
                                echo $number_of_visible_questions;
                              }else{
                                echo $subtype->total_test;
                              } 
                              ?>
							</h5>
                          </div>
                          <div class="box-footer no-padding">
							<a href="<?php echo base_url($currentPath.'/getTestList/'.$subtype->id); ?>" class="btn btn-block btn-info">START TEST</a>
                            <?php //echo $start_btn; ?>
                          </div>
                        </div>
                      </div>
                  <?php } ?>
                <?php } ?>
        </div>
      </div>
      <?php } ?>
		
         
          <?php /*<div class="box">

            <!-- /.box-header -->
            <div class="box-body">

            	 <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
		              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
		              <h4><i class="fa fa-info"></i> Note:</h4>
		              Select Sample Question to start it
		             
                 </div>
                 <h2></h2>
          






      <?php if($typeid == '1') { ?>
      <div class="row">
        <div class="col-md-12">
          <div class="box box-widget widget-user">
            <div class="widget-user-header bg-purple">
              <span class="label pull-right"><?php echo count($speaking); ?></span>
              <h3 class="widget-user-username"><i class="fa fa-microphone"></i> <strong>SPEAKING</strong></h3>
              <h5 class="widget-user-desc">Speak and Practice</h5>
            </div>
            <div class="box-footer no-padding">
              <ul class="nav nav-stacked">
                <?php if($speaking) { ?>
                  <?php foreach ($speaking as $key => $subtype) {

                      $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
                      $test_urlkey = md5($test->id);
                    ?>
                    <li>
                      <a href="<?php echo base_url($currentPath.'/sampleQResult/'.$subtype->id.'/'.$test_urlkey); ?>">
                        <b><?php echo $subtype->PTEsubtype; ?></b> (<?php echo count($allQuestions); ?>)
                        <span class="btn pull-right text-purple">
                          Start It <i class="glyphicon glyphicon glyphicon-forward"></i>
                        </span>
                      </a>
                    </li>
                  <?php } ?>
                <?php } ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <?php } ?>


      <?php if($typeid == '4') { ?>
      <div class="row">
        <div class="col-md-12">
          <div class="box box-widget widget-user">
            <div class="widget-user-header bg-red">
              <span class="label pull-right"><?php echo count($writing); ?></span>
              <h3 class="widget-user-username"><i class="fa fa-edit"></i> <strong>WRITING</strong></h3>
              <h5 class="widget-user-desc">Practice Writing Tasks</h5>
            </div>
            <div class="box-footer no-padding">
              <ul class="nav nav-stacked">
                <?php if($writing) { ?>
                  <?php foreach ($writing as $key => $subtype) {

                      $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
                      $test_urlkey = md5($test->id);
                    ?>
                    <li>
                      <a href="<?php echo base_url($currentPath.'/sampleQResult/'.$subtype->id.'/'.$test_urlkey); ?>">
                        <b><?php echo $subtype->PTEsubtype; ?></b> (<?php echo count($allQuestions); ?>)
                        <span class="btn pull-right text-purple">
                          Start It <i class="glyphicon glyphicon glyphicon-forward"></i>
                        </span>
                      </a>
                    </li>
                  <?php } ?>
                <?php } ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <?php } ?>


      <?php if($typeid == '2') { ?>
      <div class="row">
        <div class="col-md-12">
          <div class="box box-widget widget-user">
            <div class="widget-user-header bg-aqua">
              <span class="label pull-right"><?php echo count($reading); ?></span>
              <h3 class="widget-user-username"><i class="fa fa-book"></i> <strong>READING</strong></h3>
              <h5 class="widget-user-desc">Improve Your Reading Skills</h5>
            </div>
            <div class="box-footer no-padding">
              <ul class="nav nav-stacked">
                <?php if($reading) { ?>
                  <?php foreach ($reading as $key => $subtype) {

                      $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
                      $test_urlkey = md5($test->id);
                    ?>
                    <li>
                      <a href="<?php echo base_url($currentPath.'/sampleQResult/'.$subtype->id.'/'.$test_urlkey); ?>">
                        <b><?php echo $subtype->PTEsubtype; ?></b> (<?php echo count($allQuestions); ?>)
                        <span class="btn pull-right text-purple">
                          Start It <i class="glyphicon glyphicon glyphicon-forward"></i>
                        </span>
                      </a>
                    </li>
                  <?php } ?>
                <?php } ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <?php } ?>







      <?php if($typeid == '3') { ?>
      <div class="row">
        <div class="col-md-12">
          <div class="box box-widget widget-user">
            <div class="widget-user-header bg-blue">
              <span class="label pull-right"><?php echo count($listening); ?></span>
              <h3 class="widget-user-username"><i class="fa fa-book"></i> <strong>LISTENING</strong></h3>
              <h5 class="widget-user-desc">Listen &amp; Answer</h5>
            </div>
            <div class="box-footer no-padding">
              <ul class="nav nav-stacked">
                <?php if($listening) { ?>
                  <?php foreach ($listening as $key => $subtype) {

                      $where = "testid = '".$test_id."' AND status = 'Active' AND Qtable = '".$subtype->tbname."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'desc');
                      $test_urlkey = md5($test->id);
                    ?>
                    <li>
                      <a href="<?php echo base_url($currentPath.'/sampleQResult/'.$subtype->id.'/'.$test_urlkey); ?>">
                        <b><?php echo $subtype->PTEsubtype; ?></b> (<?php echo count($allQuestions); ?>)
                        <span class="btn pull-right text-purple">
                          Start It <i class="glyphicon glyphicon glyphicon-forward"></i>
                        </span>
                      </a>
                    </li>
                  <?php } ?>
                <?php } ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <?php } ?>












            </div>
            <!-- /.box-body -->
          </div> */ ?>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>

  <?php include_once('common/scripts.php'); ?>
</body>
</html>