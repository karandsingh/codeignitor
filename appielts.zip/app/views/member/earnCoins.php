<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Earn Free Coins
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Earn Free Coins</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
            </div>


            <!-- /.box-header -->
            <div class="box-body">
				<table class="table table-bordered table-hover">
                  
                      <tr>
                        <th>By Promoting your online Coupon Code</th>
                        <td><?php echo $member->student_code; ?></td>
                      </tr>

                      <tr>
                        <th>By Promoting Url</th>
                        <td><?php echo base_url().'?coupon='.$member->student_code; ?></td>
                      </tr>
                      <tr>
                        <th>For every new member refererred </th>
                        <td>Get 100 to 500 Free coins</td>
                      </tr>

                      <tr>
                        <th>For each purchase by referred member</th>
                        <td>Get 5000 to 150,000 Free coins</td>
                      </tr>     
                </table><Br><br><h2>How to promote coupon code and link ?</h2>
                <font size=4 >
Dear member, <br><br>There are a number of ways to promote coupon code and the promotion link to earn free coins. Here is the list of the most successful ways suggested by our own members :
<br><br><b>1. Promote on LinkedIn: </b>As you, all know IELTS test is for Canadian PR and Canadian Citizenship. 
 On LinkedIn you will find a number of professionals with required experience and skills who are looking for a platform like IELTS24x7, to prepare for the test at home.                                                                                                                                       
<br><br><b>2. Send an email to your friends and colleagues:</b> You have a long contact list of your friends and known people. Simply send them an email and tell them about IELTS24x7, along with your promotion link
<br><br><b>3. Promote using Whatsapp:</b> Good thing about Whatsapp is promoting in groups. You post a single message that will be visible to all the members in that group.
<br><br><b>4. Promote using Twitter:</b> You may use Twitter to share your promotional link
<br><br><b>5. Promote using Facebook:</b> Facebook  is a popular free social networking website that allows members to create pages, groups, events. Using these features you may promote your link or coupon code.

<br><br><b>Sample message :</b><Br><br>
Hi (name),<br><br>
I know you are interested in Canadian PR, take the first step to fulfil your Canadian dreams. Join IELTS24x7. Click the link below :
                       <br> (Your promotional link)
</font>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

 
  <?php include_once('common/scripts.php'); ?>
</body>
</html>
