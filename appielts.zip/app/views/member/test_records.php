<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
  <style type="text/css">
    .widget-user .widget-user-header {
      padding: 15px;
      height: 90px;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
    }
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
  <?php
  $bufferMessage = '<div class="alertXXX alert-warningXXX text-center" id="buffermsg" style="display: none;"><img src="images/loading.gif" border="0" />Recording beginning in <strong>5</strong> seconds<img src="images/loading.gif" border="0" /></div>';
?>
<input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5('21') ?>">
  <div class="page-wrapper">
    <div class="alert alert-danger text-center" id="recording-message" style="display: none;">
                              <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">40</strong> seconds
                            </div>

                            <div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
                              <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page
                            </div>

                            <div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
                              
                              <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
                              <span id="recordHelp">Allow your microphone and reload page</span>
                                  Recording started .... <strong style="display: none;" id="countresult">40</strong><span id="time">00:00</span> seconds
                            </div>

                            <div class="text-center" id="success-recording" style="display: none;">
                              <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
                            </div>
							
							<div class="clearfix"></div>
                                <span id="level"></span>
                                <div style="display: none;">
                                  <div id="levelbase">
                                    <canvas id="levelbar"></canvas>
                                  </div>
                                  <div id="levelbase2">
                                    <div id="levelbar2"></div>
                                  </div>
                                </div>
  </div>
  <?php include_once('common/scripts.php'); ?>
  
  
  <script src="../../uploads/mic/js/justmicrec_lib.js"></script>
  <script type="text/javascript">
          $(document).ready(function () {

              // INITIALIZATION
              //$('#recn').val(new Date().getTime()); // unique id

              justMicRec.configure({
                //hostPath : '../../uploads/mic/micrecajax.php?f=' + $('#recn').val(),
				hostPath : '/micrecajax.php?f=' + $('#recn').val(),
                workerPath: '../../uploads/mic/js/justmicrecworker.js',

                // Callback functions
                recordingActivity: function(analyserNode, seconds) { activity(analyserNode, seconds); },
                recordingError: function(e) { console.log('[ERR] ' + e) },
                //recordingStopped: recordingStopped,
                WAVsendingFinished: sendingFinished,
                uploadingProcess: function(current, total){
                        uploading(Math.round(current / total * 100)); }
              });
			  
			  function sendingFinished()
              {
                console.log('!! Recording has been sent to server successfully!');
              
                // DONE :- save attempt row
                var token_name = $("#token-name").val(); // token protection
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();
                var fname = $("#recn").val()+'.wav';

                var testdetail_id = $("#testdetail_id").val();

                var dataString ='mid='+mid+'&fname='+fname+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;

                var weburl = '<?php echo site_url(); ?>';
                 $.ajax({
                  type: "POST",
                  url: weburl + "member/uploadattempt/",
                  data: dataString,
                  cache:false,
                  success: function(data) {
                    console.log(data);
                    if( data.result == "success") {
                      console.log('done ...');
                    }
                    $("#success-recording").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');
                  },
                  error : function(data) {
                    console.log(data);
                  }
                 });

                // change unique id and reconfigure path to new wav file
                //$('#recn').val(new Date().getTime());
                justMicRec.configure({
                  //hostPath : '../../uploads/mic/micrecajax.php?f=' + $('#recn').val()
                  hostPath : '/micrecajax.php?f=' + $('#recn').val()
                });
              }

              var canvas = document.getElementById('levelbar'),
                  canvasWidth = canvas.width,
                  canvasHeight = canvas.height,
                  analyserContext = canvas.getContext('2d');


              // analyserNode - node to recording data, time - seconds
              function activity(analyserNode, time)
              {
                // maxTime - global var
                // var time = maxTime - time;
                if (time < 0) time = 0;
                var min = Math.floor(time / 60),
                    sec = Math.floor(time % 60);

                $('#time').text((min < 10 ? "0" : "") + min + ":" + (sec < 10 ? "0" : "") + sec);
                
                // $('#level').text(level);

                updateAnalysers(analyserNode);
                updateAnalysers2(analyserNode); // second variant
              }

              function uploading(percent)
              {
                $('#levelbar2').width(percent + '%');
              }

              function updateAnalysers(analyserNode) {
                var SPACING = 3,
                    BAR_WIDTH = 1,
                    numBars = Math.round(canvasWidth / SPACING),
                    freqByteData = new Uint8Array(analyserNode.frequencyBinCount);

                analyserNode.getByteFrequencyData(freqByteData); 

                analyserContext.clearRect(0, 0, canvasWidth, canvasHeight);
                analyserContext.fillStyle = '#F6D565';
                analyserContext.lineCap = 'round';
                var multiplier = analyserNode.frequencyBinCount / numBars;

                  // Draw rectangle for each frequency bin.
                  for (var i = 0; i < numBars; ++i) {
                  var magnitude = 0;
                  var offset = Math.floor( i * multiplier );
                  // gotta sum/average the block, or we miss narrow-bandwidth spikes
                  for (var j = 0; j < multiplier; j++)
                     magnitude += freqByteData[offset + j];
                  magnitude = magnitude / multiplier;
                  var magnitude2 = freqByteData[i * multiplier];
                  analyserContext.fillStyle = "hsl( " + Math.round((i*360)/numBars) + ", 100%, 50%)";
                  analyserContext.fillRect(i * SPACING, canvasHeight, BAR_WIDTH, -magnitude);
                  }
              }

              function updateAnalysers2(analyserNode) {
                // OLED 
                var array = new Uint8Array(analyserNode.frequencyBinCount);
                analyserNode.getByteFrequencyData(array);
                var values = 0;

                var length = array.length;
                for (var i = 0; i < length; i++) {
                  values += array[i];
                }

                var average = values / length;
                $('#levelbar2').width(Math.min(parseInt(average * 2), 100) + '%');
              }
		});
		
	</script>
	
	  <script type="text/javascript">
		var audio_data;
        window.onload = function init() {
          try  {
            // Webkit shim
            window.AudioContext = window.AudioContext || window.webkitAudioContext;
            navigator.getUserMedia = ( navigator.getUserMedia ||
                             navigator.webkitGetUserMedia ||
                             navigator.mozGetUserMedia ||
                             navigator.msGetUserMedia);
            window.URL = window.URL || window.webkitURL;
            
            audio_data = new AudioContext;
            console.log('Audio context set up.');
            console.log('navigator.getUserMedia ' + (navigator.getUserMedia ? 'available.' : 'not present!'));
          
          } catch (e) {
            //alert('No web audio support in this browser!');
          }
          
          navigator.getUserMedia({audio: true}, initUserMedia, function(e) {
            console.log('No live audio input: ' + e);
            //alert('Your browser does not support the audio.');
          });
        };

        function initUserMedia(stream) {
          var input = audio_data.createMediaStreamSource(stream);
          //console.log('Media stream created.' );
          //console.log("input sample rate " +input.context.sampleRate);

          input.connect(audio_data.destination);
          console.log('Input connected to audio context destination.');

          $("#recordButton").removeClass("recordOff").addClass("recordOn");
          $("#recordHelp").fadeOut("slow");
          console.log('Recorder initialised.');
        }
	  
    $(document).ready(function () {
			setTimeout(function() {

			  // Check if browser support audio
			  if($('#recordButton').hasClass('recordOn')) {
				alert();

				$("#recording-message").show(); // Show recording alert
				mycounter('count', 40); // Handle counter
				$("#recording-message").delay(40000).fadeOut(); // Hide message after 40s

				// Show the player after 41s
				// Start recording after 41s, for 40 seconds
				$("#player-block").delay(41000).fadeIn();

				setTimeout(function() {

				  // Show buffer message
				  $("#buffermsg").show();

				  setTimeout(function() { // 5 second buffer before recording

					// Hide buffer message
					$("#buffermsg").hide();
					
					var maxTime = 40;
					mycounter('countresult', maxTime); // Start Time
					//startRecording();

					console.log('*log: recording started (' + maxTime + ')');
					justMicRec.start(maxTime);

					setTimeout(function() {
					  // stop recording
					  // hide player block
					  // show success recording block
					  //stopRecording();
					  console.log('log: recording stopped');
					  $('#level').text('');
					  justMicRec.sendWAV();

					  $("#player-block").hide();
					  $("#success-recording").show();

					}, 41000);

				  }, 5000);

				}, 41000);



			  } else {

				// Show message to user , that your browser not support audio
				$("#audio-block").delay(1000).fadeIn();
			  }

		}, 2000);
		
		function mycounter(elementId, seconds) {

			var counter = seconds;
			setInterval(function() {
			  counter--;
			  if (counter >= 0) {
				span = document.getElementById(elementId);
				span.innerHTML = counter;
			  } else {
				document.getElementById(elementId).style.display = "none";
			  }
			  // Display 'counter' wherever you want to display it.
			  if (counter === 0) {
				  clearInterval(counter);
			  }
			}, 1000);
        }
	});
  </script>
</body>
</html>