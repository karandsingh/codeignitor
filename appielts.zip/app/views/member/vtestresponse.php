<div class="row">
  <div class="col-md-12">
    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $alreadyAttempt->time); ?></span>
    <hr />
    <?php
      $opt = json_decode($alreadyAttempt->json_result, true);
      $yourOption = $opt['myresponse'];
    ?>

    <table class="table" style="font-size: 18px;">
      <?php foreach ($options as $objOption) { ?>

        <tr>
          <td>

            <?php
              $rightOption = '';
              $iconStyle = '';

              if($objOption->is_correct) {

                $rightOption = 'style="color:green;font-weight:bold;"';

                if($yourOption == $objOption->id) {
                  $iconStyle = '<i class="fa fa-check" style="color:green;"></i>';
                }
              } else {

                if($yourOption == $objOption->id) {
                  $iconStyle = '<i class="fa fa-times" style="color:red;"></i>';
                }
              }
            ?>

            <span <?php echo $rightOption; ?>><?php echo $objOption->title; ?></span>
            <?php echo $iconStyle; ?>

          </td>
        </tr>

      <?php } ?>
    </table>
  </div>

</div>