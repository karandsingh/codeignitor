<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

        <style type="text/css">
    .widget-user .widget-user-header {
    padding: 15px;
    height: 90px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
}

  </style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> 
        <small></small>
      </h1> 
      <ol class="breadcrumb">
        <li><a><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>



    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">


         
          <div class="box">
            <div class="box-body">

              <div class="row">
                <div class="col-md-12">
                  <div class="alert alert-info">

                    <h3>
                      <i class="fa fa-desktop"></i> <?=$type->PTEtype?> : <?=$subtype->PTEsubtype?>
                    </h3>
                    
                  </div>
                </div>
              </div>



              <?php if($subtype->id == '41') { // Read Aloud ?>

                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <?php echo nl2br($qExtra->paragraph); ?>
                  </div>
                </div>






              <?php } elseif($subtype->id == '42') { // Repeat Sentence ?>

                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Your Response
                    <br />
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/dir/Speaking/'.$qExtra->mp3URL); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Original Sentence
                  </div>
                </div>




              <?php } elseif($subtype->id == '43') { // Describe Image ?>

                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <?php $imagefile = base_url('uploads/dir/Speaking/'.$qExtra->SDimage); ?>
                    <img src="<?php echo $imagefile; ?>" class="img-responsive" alt="photo">
                  </div>
                </div>



              <?php } elseif($subtype->id == '44') { // Re-tell lecture ?>


                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Your Response
                    <br />
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/dir/Speaking/'.$qExtra->mp3URL); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Original Lecture
                    <hr />
                    <?php $imagefile = base_url('uploads/dir/Speaking/'.$qExtra->imageURL); ?>
                    <img src="<?php echo $imagefile; ?>" class="img-responsive" alt="photo">
                  </div>
                </div>







              <?php } elseif($subtype->id == '45') { // Answer short question ?>

                <div class="row">
                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/attempt/'.$attempt->fname); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Your Response
                    <br />
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>

                  <div class="col-md-6">
                    <hr/>
                      <?php $audiofile = base_url('uploads/dir/Speaking/'.$qExtra->mp3URL); ?>
                      <audio src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                    <hr/>
                    Original Sentence
                  </div>
                </div>







              <?php } elseif($subtype->id == '46') { // Summarize written text ?>

                <div class="row">
                  <div class="col-md-12">

                    <?php echo nl2br($qExtra->essay); ?>
                    <hr/>
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $lecture = json_decode($attempt->json_result, true);
                        echo nl2br($lecture['myresponse']);
                      ?>
                    <hr/>
                    
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>

                  </div>
                </div>



              <?php } elseif($subtype->id == '47') { // Write Essay ?>

                <div class="row">
                  <div class="col-md-12">

                    <?php echo nl2br($qExtra->essayTitle); ?>
                    <hr/>
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $lecture = json_decode($attempt->json_result, true);
                        echo nl2br($lecture['myresponse']);
                      ?>
                    <hr/>
                    
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>

                  </div>
                </div>





              <?php } elseif($subtype->id == '28') { // Summarize spoken text ?>


                <div class="row">
                  <div class="col-md-12">

                    <?php $audiofile = base_url('uploads/dir/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $lecture = json_decode($attempt->json_result, true);
                        echo nl2br($lecture['myresponse']);
                      ?>
                    <hr/>
                    
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>

                  </div>
                </div>





              <?php } elseif($subtype->id == '29') { // Multiple-choice: Single ?>

                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/dir/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '20') { ?>

                <div class="row">
                  <div class="col-md-6">
                    <?php //$audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <?php $audiofile = base_url('uploads/dir/Listening/horse.mp3'); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '19') { ?>

                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>


              <?php } elseif($subtype->id == '18') { ?>

                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '17') { ?>


                <div class="row">
                  <div class="col-md-12 text-center">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>

              <?php } elseif($subtype->id == '16') { ?>


                <div class="row">
                  <div class="col-md-12 text-center">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>


              <?php } elseif($subtype->id == '15') { ?>


                <div class="row">
                  <div class="col-md-12 text-center">
                    <?php $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>




              <?php } elseif($subtype->id == '30') { // Multiple-choice: Multiple ?>


                <div class="row">
                  <div class="col-md-6">

                    <?php $audiofile = base_url('uploads/dir/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr />
                    <?php /*
                    <h3><?php echo $qExtra->optiontitle; ?></h3>
                    */ ?>
                    <table class="table" style="font-size: 16px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>
                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <hr />

                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $optArr = explode(',', $youOpt);
                        foreach ($optArr as $optNumber) {
                          $myresponse = 'option'.$optNumber;
                          echo $qExtra->$myresponse;
                          echo '<hr />';
                        }
                      ?>

                      <strong>Correct Answer</strong> :
                      <hr />
                      <?php

                        $optArr = explode(',', $qExtra->answer);
                        foreach ($optArr as $optNumber) {
                          $rightOpt = 'option'.$optNumber;
                          echo $qExtra->$rightOpt;
                          echo '<hr />';
                        }
                      ?>

                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '31') { // Fill in the blanks ?>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="stextfield"></span>';
                          $totalBlanks = substr_count($qExtra->transcription, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->transcription));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANK'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANK'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="stextfield"></span>';
                          $totalBlanks = substr_count($qExtra->transcription, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->transcription));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANK'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANK'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>

              <?php } elseif($subtype->id == '32') { // Highlight correct summary ?>


                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/dir/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } elseif($subtype->id == '33') { // Select missing word ?>


                <div class="row">
                  <div class="col-md-6">
                    <?php $audiofile = base_url('uploads/dir/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <table class="table" style="font-size: 14px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                  </div>

                  <div class="col-md-6">

                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Correct Answer</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>


              <?php } elseif($subtype->id == '34') { // Highlight incorrect words ?>


                <div class="row">
                  <div class="col-md-12">
                    <?php $audiofile = base_url('uploads/dir/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                    <hr/>
                  </div>
                </div>


                <div class="row">
                  <div class="col-md-6">
                      <strong>Correct Answer</strong> :
                      <br />
                      <?php
                        echo nl2br($qExtra->transcription);
                      ?>
                      <style type="text/css">
                        .icorrectw {
                          background-color: green;
                          color: white;
                          padding: 2px;
                        }
                      </style>
                  </div>
                  <div class="col-md-6">
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $wordList = json_decode($attempt->json_result, true);
                        echo nl2br($wordList['myresponse']);
                      ?>
                      <style type="text/css">
                        .mySelected {
                          background-color: green;
                          color: white;
                          padding: 2px;
                        }
                      </style>
                  </div>
                </div>




              <?php } elseif($subtype->id == '35') { // Write from dictation ?>

                <div class="row">
                  <div class="col-md-12">

                    <?php $audiofile = base_url('uploads/dir/Listening/'.$qExtra->mp3URL); ?>
                    <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls autoplay>Your browser does not support the audio.</audio>
                    <hr/>
                      <strong>Your Response</strong> :
                      <br />
                      <?php
                        $lecture = json_decode($attempt->json_result, true);
                        echo nl2br($lecture['myresponse']);
                      ?>
                    <hr/>
                    
                    <strong>Submitted Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>

                  </div>
                </div>



              <?php } elseif($subtype->id == '36') { // Multiple Fill in the blanks ?>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>



              <?php } elseif($subtype->id == '37') { // Fill in the blanks ?>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="stextfield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANK'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANK'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="stextfield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANK'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANK'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>



              <?php } elseif($subtype->id == '38') { ?>

                <div class="row">
                  <div class="col-md-12">
                    <?php $imagefile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->diagram); ?>
                    <img src="<?php echo $imagefile; ?>" class="img-responsive" alt="photo">
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>






              <?php } elseif($subtype->id == '39') { ?>

                <div class="row">
                  <div class="col-md-6">
                      <h3>Correct Answer</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $correntwords = explode(',', $qExtra->words);
                          foreach ($correntwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>

                  <div class="col-md-6">
                      <h3>Your Response</h3>
                        <?php
                          $mysearch = '<span class="ofield"></span>';
                          $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                          $finalText = '';
                          $myctr = 1;
                          $txts = explode($mysearch, trim($qExtra->paragraph));
                          foreach ($txts as $text) {
                            $blank = '';
                            if($myctr <= $totalBlanks) {
                              $blank = 'FILLBLANKLIST'.$myctr;
                            }
                            $finalText .= $text . $blank;
                            $myctr++;
                          }
                          //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                          $search = array();
                          for ($i=1; $i <= $totalBlanks; $i++) { 
                            $search[] = 'FILLBLANKLIST'.$i;
                          }

                          $replace = array();
                          $result = json_decode($attempt->json_result, true);
                          $userwords = explode(',', $result['myresponse']);
                          foreach ($userwords as $word) {
                            $replace[] = '<u style="font-weight:bold;">'.$word.'</u>';
                          }
                          //echo '<pre>'; print_r($search); echo '</pre>';
                          //echo '<pre>'; print_r($replace); echo '</pre>';

                          $finalParagraph = str_replace($search, $replace, $finalText);
                          echo nl2br($finalParagraph);
                        ?>
                  </div>
                </div>







              <?php } elseif($subtype->id == '40') { // Multiple-choice: Single ?>


                <div class="row">
                  <div class="col-md-6">
                    <?php echo nl2br($qExtra->paragraph); ?>
                  </div>
                  <div class="col-md-6">
                    <h3><?php echo $qExtra->optiontitle; ?></h3>
                    <table class="table" style="font-size: 16px;">
                      <tr>
                        <td>
                          <?php echo $qExtra->option1; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option2; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option3; ?>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <?php echo $qExtra->option4; ?>
                        </td>
                      </tr>
                    </table>
                    <br />
                    <hr/>
                      <strong>Your Response</strong> :
                      <?php
                        $opt = json_decode($attempt->json_result, true);
                        $youOpt = $opt['myresponse']; // in numeric form

                        $myresponse = 'option'.$youOpt;
                        echo $qExtra->$myresponse;
                      ?>
                    <hr/>
                      <strong>Right Option</strong> :
                      <?php
                        $rightOpt = 'option'.$qExtra->answer;
                        echo $qExtra->$rightOpt;
                      ?>
                    <hr/>
                    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $attempt->time); ?></span>
                  </div>
                </div>

              <?php } else { ?>
                <p>Under Construction</p>
              <?php } ?>

            </div>
          </div>
        </div>
      </div>
    </section>

  </div>

  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>

  <?php include_once('common/scripts.php'); ?>

  <script type="text/javascript">
    $(document).ready(function () {

      /*
      var data = "<?php //echo $audiofile ; ?>";
 
      setTimeout(function() {
        
        var binary= convertDataURIToBinary(data);
        var blob = new Blob([binary], {type : 'audio/mp3'});
        var blobUrl = URL.createObjectURL(blob);

        $("#responseaudio").attr("src", blobUrl);

        $("#responseaudio")[0].pause();
        $("#responseaudio")[0].load(); //suspends and restores all audio element
        $("#responseaudio")[0].play();

      }, 2000);



      function convertDataURIToBinary(dataURI) {
        var BASE64_MARKER = ';base64,';
        var base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
        var base64 = dataURI.substring(base64Index);
        var raw = window.atob(base64);
        var rawLength = raw.length;
        var array = new Uint8Array(new ArrayBuffer(rawLength));

        for(let i = 0; i < rawLength; i++) {
          array[i] = raw.charCodeAt(i);
        }
        return array;
      }
      */




    });
  </script>








</body>
</html>
