<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> 
      </h1>
    </section>


    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="alert alert-info alert-dismissible" >
          <strong>Note :</strong> Pay $25 and get 4000 coins.   
        </div>
         
          <div class="box">
            <div class="box-body">

              <div class="box-footer no-padding">
              <ul class="nav nav-stacked">
                <li>
                <?php

                //Set useful variables for paypal form
                $paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
                $paypalID = 'billing-facilitator@website-welcome.com'; //Business Email

                ?>

                  <form action="<?php echo $paypalURL; ?>" method="post">
                    <!-- Identify your business so that you can collect the payments. -->
                    <input type="hidden" name="business" value="<?php echo $paypalID; ?>">
                    
                    <!-- Specify a Buy Now button. -->
                    <input type="hidden" name="cmd" value="_xclick">
                    
                    <!-- Specify details about the item that buyers will purchase. -->
                    <input type="hidden" name="item_name" value="Test item">
                    <input type="hidden" name="item_number" value="897">
                    <input type="hidden" name="amount" value="10">
                    <input type="hidden" name="currency_code" value="USD">
                    
                    <!-- Specify URLs -->
                    <input type='hidden' name='cancel_return' value="<?php echo base_url('/member/tests/?alert=cancel'); ?>">
                    <input type='hidden' name='return' value="<?php echo base_url('/member/tests/?alert=success'); ?>">
                    
                    <!-- Display the payment button. -->
                    <input type="image" name="submit" border="0"
                    src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" alt="PayPal - The safer, easier way to pay online">
                    <img alt="" border="0" width="1" height="1" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >
                  </form>


                </li>


              </ul>
              
            </div>

           

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
</body>
</html>
