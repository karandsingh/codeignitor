<div class="row">
  <div class="col-md-12">
    <strong>Taken Date</strong> : <span class="online"><?php echo date('M d,  Y h:i A', $alreadyAttempt->time); ?></span>
    <hr />
    <?php
      $opt = json_decode($alreadyAttempt->json_result, true);
	  //echo "<pre>";print_r($opt);die;
      $yourOption1 = $opt['myresponse1'];
      $yourOption2 = $opt['myresponse2'];
      $yourOption3 = $opt['myresponse3'];
      $yourOption4 = $opt['myresponse4'];
    ?>
	<div class="table-responsive">
    <table class="table" style="font-size: 18px;">	

		<?php
			$options = array('1'=>$objQuestion->q1_option1,'2'=>$objQuestion->q1_option2,'3'=>$objQuestion->q1_option3,'4'=>$objQuestion->q1_option4);
		?>
		<tr>
		<td>Question 1 <i class="fa fa-angle-double-right"></i> </td>
		<?php $i=1; foreach ($options as $key=>$objOption) { ?>
			<td>
			<?php
			$rightOption = '';
			$iconStyle = '';

			if($objQuestion->q1_answere==$key) {

				$rightOption = 'style="color:green;font-weight:bold;"';

				if($yourOption1 == $key) {
				  $iconStyle = '<i class="fa fa-check" style="color:green;"></i>';
				}
			} else {

				if($yourOption1 == $key) {
				  $iconStyle = '<i class="fa fa-times" style="color:red;"></i>';
				}
			}
			?>
			
			<span <?php echo $rightOption; ?>><?php echo $objOption; ?></span>
            <?php echo $iconStyle; ?>
			</td>  
		<?php $i++; } ?>
		</tr>
		<tr>
		<td>Question 2 <i class="fa fa-angle-double-right"></i> </td>
		<?php
			$options = array('1'=>$objQuestion->q2_option1,'2'=>$objQuestion->q2_option2,'3'=>$objQuestion->q2_option3,'4'=>$objQuestion->q2_option4);
		?>
		<?php $i=1; foreach ($options as $key=>$objOption) { ?> 
			<td>
				<?php
				$rightOption = '';
				$iconStyle = '';

				if($objQuestion->q2_answere==$key) {

					$rightOption = 'style="color:green;font-weight:bold;"';

					if($yourOption2 == $key) {
					  $iconStyle = '<i class="fa fa-check" style="color:green;"></i>';
					}
				} else {

					if($yourOption2 == $key) {
					  $iconStyle = '<i class="fa fa-times" style="color:red;"></i>';
					}
				}
				?>
				
				<span <?php echo $rightOption; ?>><?php echo $objOption; ?></span>
				<?php echo $iconStyle; ?>
			</td>
		<?php $i++; } ?>
		</tr>
		
		<tr>
		<td>Question 3 <i class="fa fa-angle-double-right"></i> </td>
		<?php
			$options = array('1'=>$objQuestion->q3_option1,'2'=>$objQuestion->q3_option2,'3'=>$objQuestion->q3_option3,'4'=>$objQuestion->q3_option4);
		?>
		<?php $i=1; foreach ($options as $key=>$objOption) { ?>
			<td>
				<?php
				$rightOption = '';
				$iconStyle = '';

				if($objQuestion->q3_answere==$key) {

					$rightOption = 'style="color:green;font-weight:bold;"';

					if($yourOption3 == $key) {
					  $iconStyle = '<i class="fa fa-check" style="color:green;"></i>';
					}
				} else {

					if($yourOption3 == $key) {
					  $iconStyle = '<i class="fa fa-times" style="color:red;"></i>';
					}
				}
				?>
				
				<span <?php echo $rightOption; ?>><?php echo $objOption; ?></span>
				<?php echo $iconStyle; ?>
			</td>
		<?php $i++; } ?>
		</tr>
		
		<tr>
		<td>Question 4 <i class="fa fa-angle-double-right"></i> </td>
		<?php
			$options = array('1'=>$objQuestion->q4_option1,'2'=>$objQuestion->q4_option2,'3'=>$objQuestion->q4_option3,'4'=>$objQuestion->q4_option4);
		?>
		<?php $i=1; foreach ($options as $key=>$objOption) { ?>
			<td>
				<?php
				$rightOption = '';
				$iconStyle = '';

				if($objQuestion->q4_answere==$key) {

					$rightOption = 'style="color:green;font-weight:bold;"';

					if($yourOption4 == $key) {
					  $iconStyle = '<i class="fa fa-check" style="color:green;"></i>';
					}
				} else {

					if($yourOption4 == $key) {
					  $iconStyle = '<i class="fa fa-times" style="color:red;"></i>';
					}
				}
				?>
				
				<span <?php echo $rightOption; ?>><?php echo $objOption; ?></span>
				<?php echo $iconStyle; ?>
			</td>
		<?php $i++; } ?>
		</tr>
		
		
	    <?php
			//$options = array('1'=>$objQuestion->q1_option1,'2'=>$objQuestion->q1_option2,'3'=>$objQuestion->q1_option3,'4'=>$objQuestion->q1_option4);
	    ?>
        <?php /*//$i=1; foreach ($options as $key=>$objOption) { ?>
		<tr>
            <td>

            <?php/*
              $rightOption = '';
              $iconStyle = '';

              if($objQuestion->q1_answere==$key) {

                $rightOption = 'style="color:green;font-weight:bold;"';

                if($yourOption == $key) {
                  $iconStyle = '<i class="fa fa-check" style="color:green;"></i>';
                }
              } else {

                if($yourOption == $key) {
                  $iconStyle = '<i class="fa fa-times" style="color:red;"></i>';
                }
              }
            <span <?php echo $rightOption; ?>><?php echo $objOption; ?></span>
            <?php echo $iconStyle; ?>

          </td>
        </tr> 

      <?php $i++; }*/ ?>
    </table>
	</div>
  </div>

</div>