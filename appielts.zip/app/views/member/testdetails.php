<!doctype html>
<html lang="en">
<head>
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>
    <style type="text/css">
      .widget-user .widget-user-header {
        padding: 15px;
        height: 90px;
        border-top-right-radius: 3px;
        border-top-left-radius: 3px;
      }
    </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> 
      </h1>
      <ol class="breadcrumb">
        <li><a><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-xs-12">

        <div class="alert alert-info alert-dismissible" >
          <strong>Note : </strong> If you are new to take this test please Click on <strong>Start it </strong> button to start new test . You can also Resume test , check your Results and re-attempt.   
        </div>

         
          <div class="box">

            <div class="box-header">
              <div class="box box-widget widget-user">
                <div class="widget-user-header bg-purple">

                  <span class="pull-right ">

                    <a class="btn btn-danger btn-md show-instructions"><i class="fa fa-hand-o-right" ></i> Start It</a>

                  <a id="" class="btn btn-default btn-md" href="<?php echo base_url($currentPath.'/tests'); ?>">Back</a> <p> </p></span>
                  <h3 class="widget-user-username"><STRONG> <p class="fa fa-desktop"></p> <?php echo $test->test_name; ?> </STRONG></h3>

                  <h5 class="widget-user-desc"> 
                    <strong>Time</strong> : <?php echo $test->total_time; ?>
                    <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
                    <strong>Questions</strong> : <?php echo $total_questions; ?>
                  </h5>

                </div>
              </div>
            </div>

            <div class="box-body">

                <h3>Test History</h3>
                <hr />

                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>Attempted Questions</th>
                      <th>Pending Questions</th>
                      <th>Taken Date</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php foreach ($history as $objTestdetail) {


                        $where = "testid = '".$test->id."' AND memberid = '".$user->id."' AND testdetail_id = '".$objTestdetail->id."' ";
                        $alreadyAttempt = $this->my_model->getWhereOrderRecords($this->tb_attempt, $where, 'id', 'ASC');

                        $attemptedQuestions = count($alreadyAttempt);
                        $pending = $total_questions - $attemptedQuestions;

                        $testLink = base_url('member/testprogress/'.$objTestdetail->id_md5.'/'.$test->id_md5);

                        $btnText = '<a href="'.$testLink.'" class="btn btn-success">Result</a>';
                        if($pending) {
                          $btnText = '<a href="'.$testLink.'" class="btn btn-primary">Resume</a>';
                        }



                      ?>


                      <tr>
                        <td><?php echo $attemptedQuestions; ?></td>
                        <td><?php echo $pending; ?></td>
                        <td><?php echo date('M d,  Y h:i A', $objTestdetail->time); ?></td>
                        <td>
                          <?php echo $btnText; ?>
                        </td>
                      </tr>


                    <?php } ?>

                  </tbody>
                </table>




            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>

  <?php include_once('modals.php'); ?>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>