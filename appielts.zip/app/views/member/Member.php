<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

/*
* Member controller
* this controller is related to specific user role
*/
class Member extends AKAAL_Controller {

    public function __construct() {
        parent::__construct();
 
        $this->data['currentAccount'] = 'logger_member';
        $this->data['currentPath'] = 'member';
        
        // table name of specific user role; which is related to this controller only
        $this->tb_name = $this->tb_member;
    }

    function index() {

        $this->login();
    }

    function login() {
        // check website session, if enabled
        if( $loggedUser = $this->session->userdata($this->data['currentAccount']) )
        {
            redirect($this->data['currentPath'].'/dashboard', 'refresh');
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $this->load->model('my_model');
            $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_isValidUser');
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                redirect($this->data['currentPath'].'/dashboard', 'refresh');
            }
        }

        $this->data['title'] = '<a href="'.base_url('/'.$this->data['currentPath'].'/login').'">Member Login</a>';

        //$this->data['custom_url'] = 'http://ielts24x7.com/NEW';
        //$this->data['custom_url'] = 'http://ielts24x7.com';
        $this->data['custom_url'] = 'https://ielts24x7.com';

        $window_title = 'Student Login - ' . $this->app_name;

        $this->data['meta'] = array(
            'title' => $window_title,
            'description' => '',
            'keywords' => '',
            'url' => current_url(),
            'type' => 'link',
        );
        $this->data['pagetitle'] = 'Student Login';

        $this->data['formAction'] = $this->uri->segment(1). '/' . $this->uri->segment(2);
        $this->load->view('shared/login', $this->data);
    }

    function isValidUser($password) {
        //Field validation succeeded.  Validate against database
        $username = $this->input->post('username');
        $result = $this->my_model->getUser($this->tb_name, $username, $password);

        if($result)
        {
            $session_array = array();
            foreach($result as $row)
            {
                $session_array = array(
                    'id' => $row->id,
                    'name' => $row->name,
                );

                $this->session->set_userdata($this->data['currentAccount'], $session_array);
            }
            return true;
        }
        else
        {
            $this->form_validation->set_message('isValidUser', 'Invalid username or password');
            return false;
        }
    }

    function logout() {
        // Make sure you destory website session as well.
        $this->session->unset_userdata($this->data['currentAccount']);
        $this->session->sess_destroy();
        // Finally redirect page to desire location
        redirect($this->data['currentPath']);
    }

    function verifyUser() {

        // check login
        $this->logged = is_user_logged_in(
            $this->data['currentAccount'],
            $this->data['currentPath']
        );

        $this->data['user'] = $this->my_model->getARecord($this->tb_name, $this->logged['id']);
        $this->data['role'] = $this->my_model->getARecord($this->tb_role, $this->data['user']->role_id);

        // checks for valid user get or not
        if( !is_object($this->data['user'])) { return false; }

        $this->data['country'] = $this->my_model->getARecord($this->tb_countries, $this->data['user']->country_id);
    }

    function account() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Profile';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function sampleQuestion($typeid = '') {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Sample Questions';
        $this->data['test_id'] = '7';

        $this->data['test'] = $this->my_model->getARecord($this->tb_test, '7');

        if( in_array($typeid, array('1','2','3','4')) ) {

            // Speaking
            $where = "PTEtypeid = '1' ";
            $this->data['speaking'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');

            // Writing
            $where = "PTEtypeid = '4' ";
            $this->data['writing'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');

            // Reading
            $where = "PTEtypeid = '2' ";
            $this->data['reading'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');

            // Listening
            $where = "PTEtypeid = '3' ";
            $this->data['listening'] = $this->my_model->getWhereOrderRecords($this->tb_subtype, $where, 'id', 'DESC');
        
        } else {

            exit($this->unauthorized_message);
        }

        $this->data['typeid'] = $typeid;

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function sampleQResult($id, $test_id_md5) {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // questions
        $where = "testid = '".$this->data['test']->id."' AND status = 'Active' AND PTEsubtypeid = '".$this->data['subtype']->id."' ";
        $this->data['allQuestions'] = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');


        /**********************************************
        * DONE - attempted question by logged students
        ***********************************************/

        $where = "subtypeid = '".$this->data['subtype']->id."' AND memberid = '".$this->data['user']->id."' ";
        $this->data['attemptedQuestions'] = $this->my_model->getWhereOrderRecords($this->tb_attempt, $where, 'id', 'asc');


        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'sample Questions';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function startTest($id, $test_id_md5) {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // questions
        $where = "testid = '".$this->data['test']->id."' AND status = 'Active' AND PTEsubtypeid = '".$this->data['subtype']->id."' ";
        $this->data['allQuestions'] = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'sample Questions';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function sampleTest($id, $test_id_md5, $page='1') {
        $this->verifyUser();

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $id);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $test_id_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }
        $this->data['type'] = $this->my_model->getARecord('system_PTEtype_code', $this->data['subtype']->PTEtypeid);

        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                'testid' => $this->data['test']->id,
                'status' => 'Active',
                'PTEsubtypeid' => $this->data['subtype']->id,
            );
            $this->sortby = 'id'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, $this->tb_question );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 5;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination

        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, $this->tb_question );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        $this->data['reporturl'] = base_url('member/sampleQResult/'.$id.'/'.$test_id_md5);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Sample Test';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function uploadrecording() {

        $audiosrc = $this->input->post('audiosrc');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $subtypeid = $this->input->post('subtypeid');
        $questionid = $this->input->post('questionid');

        // upload mp3 - DONE
        $time = time();
        $fname = md5($time).'-'.md5($memberId).'.record';

        write_file('./uploads/attempt/'.$fname, $audiosrc);

        $qryData = array(
            'time' => $time,
            'testid' => $testid,
            'questionid' => $questionid,
            'subtypeid' => $subtypeid,
            'memberid' => $memberId,
            'fname' => $fname
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Recording has been successfully uploaded.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    function uploadattempt() {

        $fname = $this->input->post('fname');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $subtypeid = $this->input->post('subtypeid');
        $questionid = $this->input->post('questionid');

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'testid' => $testid,
            'questionid' => $questionid,
            'subtypeid' => $subtypeid,
            'memberid' => $memberId,
            'fname' => $fname,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Recording has been successfully uploaded.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    function uploadjson() {

        $myresponse = $this->input->post('myresponse');
        $memberId = $this->input->post('mid');
        $testid = $this->input->post('testid');
        $subtypeid = $this->input->post('subtypeid');
        $questionid = $this->input->post('questionid');

        $result = array('myresponse' => $myresponse);
        $json_result = json_encode($result);

        $testdetail_id = $this->input->post('testdetail_id');
        if(!$testdetail_id) {
            $testdetail_id = '0';
        }

        $qryData = array(
            'time' => time(),
            'testid' => $testid,
            'questionid' => $questionid,
            'subtypeid' => $subtypeid,
            'memberid' => $memberId,
            'json_result' => $json_result,
            'testdetail_id' => $testdetail_id
        );

        if( $this->my_model->insertDataIntoTable($this->tb_attempt, $qryData) )
        {
            $last_added_id = $this->db->insert_id();

            $response = array(
                "result" => "success",
                "message" => "Data has been successfully submitted.",
            );
        } else {
            $response = array(
                "result" => "error",
                "message" => "Report to webmaster."
            );
        }

        // return ajax response as json
        echo json_encode ($response) ;
    }

    function response($id, $id_md5) {
        $this->verifyUser();

        $this->data['attempt'] = $this->my_model->getARecord($this->tb_attempt, $id);
        if( !is_object($this->data['attempt'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($id);
        if($getId != $id_md5) {
            exit($this->unauthorized_message);
        }

        $this->data['subtype'] = $this->my_model->getARecord($this->tb_subtype, $this->data['attempt']->subtypeid);
        if( !is_object($this->data['subtype'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id', $this->data['attempt']->testid);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }

        $this->data['type'] = $this->my_model->getARecord($this->tb_type, $this->data['subtype']->PTEtypeid);


        $this->data['question'] = $this->my_model->checkARecord($this->tb_question, 'id', $this->data['attempt']->questionid);
        if( !is_object($this->data['question'])) {
            exit($this->unauthorized_message);
        }

        $myTable = $this->tb_prefix.$this->data['subtype']->tbname.$this->tb_suffix;

        $this->data['qExtra'] = $this->my_model->checkARecord($myTable, 'questionid', $this->data['attempt']->questionid);
        if( !is_object($this->data['qExtra'])) {
            exit($this->unauthorized_message);
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Your Response';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function tests() {
        $this->verifyUser();
        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Tests';

        // Get all tests without - Sample Test = 7
        $where = "id != '7' ";
        $this->data['tests'] = $this->my_model->getWhereOrderRecords($this->tb_test, $where, 'id', 'ASC');

        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    function testdetails($id, $id_md5) {
        $this->verifyUser();

        $this->data['test'] = $this->my_model->getARecord($this->tb_test, $id);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }

        $getId = md5($id);
        if($getId != $id_md5) {
            exit($this->unauthorized_message);
        }

        // Should not be (Sample Test) = 7
        if($id == 7) {
            exit($this->unauthorized_message);
        }


        // Get all questions in test
        $where = "testid = '".$id."' ";
        $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');
        $this->data['total_questions'] = count($allQuestions);

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Test Details';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    /*
    * Test Progress
    * $tdId_md5 = testdetails table unique id
    * $testId_md5 = test table unique id
    */
    function testprogress($tdId_md5, $testId_md5, $page='1') {
        $this->verifyUser();

        $this->data['testdetail'] = $this->my_model->checkARecord($this->tb_testdetails, 'id_md5', $tdId_md5);
        if( !is_object($this->data['testdetail'])) {
            exit($this->unauthorized_message);
        }

        $this->data['test'] = $this->my_model->checkARecord($this->tb_test, 'id_md5', $testId_md5);
        if( !is_object($this->data['test'])) {
            exit($this->unauthorized_message);
        }



        // Questions with paging

            // Set preferences for pagination
            $perPage = 1;
            $offset = getOffset($page, $perPage); // Set offset value

            $mylink = base_url('/'.$this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4));

            $this->conditions = array(
                'testid' => $this->data['test']->id,
                'status' => 'Active',
                //'PTEsubtypeid' => $this->data['subtype']->id,
            );
            $this->sortby = 'PTEsubtypeid'; // required
            $this->orderby = 'ASC'; // required [ASC|DESC|RAND]

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, $this->tb_question );
            $config['base_url'] = $mylink;
            $config['uri_segment'] = 5;
            $config['num_links'] = 10;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['next_link'] = 'Next »';
            $config['prev_link'] = '« Previous';

            $this->pagination->initialize($config);
            // end pagination

        $this->data['allQuestions'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, $this->tb_question );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
        //$this->data['reporturl'] = base_url('member/sampleQResult/tests');
        $this->data['reporturl'] = current_url();




        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = $this->data['test']->test_name;
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }


    /*
    * Start a new test
    */
    function startnewtest() {

        $testid = $this->input->post('testid');
        $memberid = $this->input->post('memberid');
        $objTest = $this->my_model->getARecord($this->tb_test, $testid);

        if( is_object($objTest)) {

            $qryData = array(
                'test_id' => $testid,
                'member_id' => $memberid,
                'time' => time(),
            );

            if( $this->my_model->insertDataIntoTable($this->tb_testdetails, $qryData) )
            {
                $this->data['success'] = true;
                $last_added_id = $this->db->insert_id();

                $id_md5 = md5($last_added_id);

                $updateData = array(
                    'id_md5' => $id_md5,
                );
                $this->my_model->updateTable($this->tb_testdetails, $updateData, $last_added_id);

            }

            // Add entry here
            $response = array(
                'result' => 'success',
                'message' => 'Test Started',
                'tdcode' => $id_md5, // test details code
                'tcode' => $objTest->id_md5 // test code
            );

        } else {
            $response = array(
                'result' => 'error',
                'message' => $this->ajaxerror_message
            );
        }

        // Return ajax response as json
        echo json_encode ($response) ;
    }

    function support() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST")
        {

            $this->form_validation->set_rules('title', 'Title', 'trim');
            $this->form_validation->set_rules('type', 'Type', 'trim');
            $this->form_validation->set_rules('email', 'Email', 'trim');
            $this->form_validation->set_rules('details', 'details', 'trim');

            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button> <i class="fa fa-info-sign"></i>','</div>' );

            if($this->form_validation->run() == TRUE)
            {
                $qryData = array(
                    'title' => $this->input->post('title'),
                    'email' => $this->input->post('email'),
                    'type' => $this->input->post('type'),
                    'details' => $this->input->post('details'),
                    'member_id' => $this->logged['id'],
                    'time' => time(),
                );

                if( $this->my_model->insertDataIntoTable('system_support_code', $qryData) )
                {
                    $this->data['success'] = true;
                }
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Support';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    public function password() {
        $this->verifyUser();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $this->form_validation->set_rules('old', 'Current password', 'trim|required|xss_clean|min_length[3]|max_length[30]');
            $this->form_validation->set_rules('new', 'New password', 'trim|required|xss_clean|min_length[6]|max_length[30]');
            $this->form_validation->set_rules('confirm', 'Confirm password', 'trim|required|xss_clean|min_length[6]|max_length[30]|callback_checkPassword');
            
            $this->form_validation->set_error_delimiters( '<div class="alert alert-danger">','</div>' );
            if($this->form_validation->run() == TRUE) {
                $this->data['success'] = true;
            }
        }

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Change Password';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function checkPassword() {

        $newPassword = $this->input->post('new');
        $confirmPassword = $this->input->post('confirm');

        if($newPassword == $confirmPassword) {

            $result = $this->my_model->changePassword($confirmPassword, $this->data['user']->id, $this->tb_name);
            if(!$result) {

                $this->form_validation->set_message('checkPassword', 'Please enter correct Current Password.');
                return false;
            }
        
        } else {
            $this->form_validation->set_message('checkPassword', 'The New password field does not match the Confirm password field.');
            return false;
        }
        return true;
    }

    function dashboard() {
        $this->verifyUser();

        $this->data['window_title'] = $this->app_name;
        $this->data['pagetitle'] = 'Dashboard';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }

    function ComingSoon() {
        $this->verifyUser();

        $this->data['window_title']="Select Question Type";
        $this->data['window_title'] = $this->app_name." ->".$this->data['window_title'];
        $this->data['pagetitle'] = 'Question';
        $this->load->view($this->data['currentPath'].'/'.__FUNCTION__, $this->data);
    }
}