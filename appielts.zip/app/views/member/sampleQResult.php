<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

        <style type="text/css">
    .widget-user .widget-user-header {
    padding: 15px;
    height: 90px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
}
  </style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> Details 
        <small> <?php echo $pagetitle; ?> To Improve Your Skills</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">


        <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
          <strong>NOTE : </strong>
          If you are new to take this test please Click on <strong>Start it </strong> button to start new test.
        </div>
         
          <div class="box">
            <div class="box-header">
               <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-purple">
            
              <!-- /.widget-user-image -->
              <span class="pull-right "> <a class="btn btn-danger btn-md" href="<?php echo base_url($currentPath.'/startTest/'.$subtype->id.'/'.$test->id_md5); ?>" target="_blank"><i class="fa fa-hand-o-right" ></i> Start It</a>

              <?php /* <a id="" class="btn btn-default btn-md">Back</a> */ ?>
              
               <p> </p>
              </span>

              <h3 class="widget-user-username"><STRONG> <p class="fa fa-desktop"></p> <?=$type->PTEtype?> : <?=$subtype->PTEsubtype?> </STRONG></h3> 

              <h5 class="widget-user-desc"><?=$type->PTEtype?> Questions To Improve Your Skills (<?php echo count($allQuestions); ?> Questions )</h5>
            </div>
              </div>
            </div>

            <div class="box-body">

              <?php
                /*
                  Read Aloud
                  Repeat Sentence
                  Describe Image
                  Re-tell lecture
                  Answer short question 
                */
                if($subtype->id == '41' || $subtype->id == '42' || $subtype->id == '43' || $subtype->id == '44' || $subtype->id == '45') {
              ?>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>Your Answer</th>
                      <th>Taken Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($attemptedQuestions as $objAttempted) { ?>
                      <tr>
                        <td>
                          <a href="<?php echo base_url($currentPath.'/response/'.$objAttempted->id.'/'.md5($objAttempted->id)); ?>" class="btn btn-success" target="_blank">
                            <i class="fa fa-play"></i> Review
                          </a>
                        </td>
                        <td><span class="online"><?php echo date('M d,  Y h:i A', $objAttempted->time); ?></span></td>
                      </tr>
                    <?php } ?>

                  </tbody>
                </table>



              <?php
                /*
                  Summarize written text || Write Essay
                */
                } elseif($subtype->id == '46' || $subtype->id == '47') {
              ?>


                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>Your Answer</th>
                      <th>Taken Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($attemptedQuestions as $objAttempted) { ?>
                      <tr>
                        <td>
                          <a href="<?php echo base_url($currentPath.'/response/'.$objAttempted->id.'/'.md5($objAttempted->id)); ?>" class="btn btn-success" target="_blank">
                            <i class="fa fa-edit"></i> 
                            <?php if($subtype->id == '46') { ?>
                              Review
                            <?php } elseif($subtype->id == '47') { ?>
                              Review
                            <?php } ?>
                          </a>
                        </td>
                        <td><span class="online"><?php echo date('M d,  Y h:i A', $objAttempted->time); ?></span></td>
                      </tr>
                    <?php } ?>

                  </tbody>
                </table>





              <?php
                /*
                  Multiple Fill in the blanks
                  Fill in the blanks
                  Re-order paragraphs
                  Multiple-choice: Multiple
                  Multiple-choice: Single
                */
                } elseif(in_array($subtype->id, array('36','37','38','39','40'))) {
              ?>

                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>Your Answer</th>
                      <th>Taken Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($attemptedQuestions as $objAttempted) { ?>
                      <tr>
                        <td>
                          <a href="<?php echo base_url($currentPath.'/response/'.$objAttempted->id.'/'.md5($objAttempted->id)); ?>" class="btn btn-success" target="_blank">
                            <i class="fa fa-edit"></i> 

                            <?php if($subtype->id == '40') { ?>
                              Review

                            <?php } elseif($subtype->id == '39') { ?>
                              Review

                            <?php } elseif($subtype->id == '38') { ?>
                              Review

                            <?php } elseif($subtype->id == '37') { ?>
                              Review

                            <?php } elseif($subtype->id == '36') { ?>
                              Review

                            <?php } ?>

                          </a>
                        </td>
                        <td><span class="online"><?php echo date('M d,  Y h:i A', $objAttempted->time); ?></span></td>
                      </tr>
                    <?php } ?>

                  </tbody>
                </table>










              <?php
                /*
                  Summarize spoken text
                  Select missing word
                  Highlight correct summary
                  Write from dictation
                  Multiple-choice: Single
                  Multiple-choice: Multiple
                  Highlight incorrect words

                */
                //} elseif(in_array($subtype->id, array('28','29','30','31','32','33','34','35'))) {
                } elseif(in_array($subtype->id, array('28','29','20','19','18','17','16','15','30','31','32','33','34','35'))) {
              ?>

                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>Your Answer</th>
                      <th>Taken Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($attemptedQuestions as $objAttempted) { ?>
                      <tr>
                        <td>
                          <a href="<?php echo base_url($currentPath.'/response/'.$objAttempted->id.'/'.md5($objAttempted->id)); ?>" class="btn btn-success" target="_blank">
                            <i class="fa fa-edit"></i> 

                            Review

                          </a>
                        </td>
                        <td><span class="online"><?php echo date('M d,  Y h:i A', $objAttempted->time); ?></span></td>
                      </tr>
                    <?php } ?>

                  </tbody>
                </table>

















              <?php } else { ?>
                <p>Under Construction</p>
              <?php } ?>





            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
</body>
</html>
