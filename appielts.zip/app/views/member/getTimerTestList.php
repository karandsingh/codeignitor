<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

        <style type="text/css">
    .widget-user .widget-user-header {
    padding: 15px;
    height: 90px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
}
  </style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> Details 
        <small> To Improve Your Skills</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
		<?php if($this->session->flashdata('global_msg')){ ?>
			 <div class="alert alert-success">
			  <button class="close" type="button" data-dismiss="alert">
				<span aria-hidden="true">&times;</span>
			  </button>
			  <?=$this->session->flashdata('global_msg')?>
			</div>
		<?php } ?>

        <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
          <strong>NOTE : </strong>
          If you are new to take this test please Click on <strong>Start it </strong> button to start new test.
        </div>
         
          <div class="box">

            <div class="box-body">

			  	<?php //echo "<pre>hiih";print_r($gettest);die; ?>
				<div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Test Number</th>
                      <th>Start</th>
                    </tr>
                  </thead>
                  <tbody>
				    <?php foreach($gettest as $test){?>
            <tr>
              <td>
                <?php echo $test->id; ?>
              </td>
              <td>Test <?php echo $test->id; ?></td>
						<td> <?php /*<a class="btn btn-danger btn-md v-show-instructions" href="<?php echo base_url('member/practiceTask/'.$test->id); ?>"><i class="fa fa-hand-o-right"></i> Start It</a> */ ?>
						<?php
							
							$where="member_id = '$member_id' AND test_code = '$test->test_code' AND is_attempt = '1'";
							$getData = $this->my_model->getWhereLastRecords('system_testdetails_code',$where);
							//echo "<pre>";print_r($getData);
              
							if(!empty($getData)){
							
						?>
						<?php if($getData->test_check_status == '1') { ?>
						
						<a class="btn btn-danger btn-md part-test-show-instructions" onclick="partWithTimerInstructions(<?php echo $test_id; ?>,<?php echo $member_id; ?>,'<?php echo $test->test_code; ?>')"><i class="fa fa-hand-o-right"></i> Start It</a>
						
						<?php /* <button type="button" class="btn btn-danger allow-test-submit" data-testid="<?php echo $test_id; ?>" data-memberid="<?php echo $member_id; ?>" data-testcode="<?php echo $test->test_code; ?>"><i class="fa fa-hand-o-right"></i> Start It</button> */ ?>
					    
              <?php 

                /* 1 Speaking ,2 Reading ,3 Listening, 4 Writing */
                
                if($test_type_id == '1'){ 
                  $report_link = base_url('member/viewSpeakReport/').$getData->id_md5;
                }
                if($test_type_id == '2'){ 
                  $report_link = base_url('member/viewReadReport/').$getData->id_md5;
                }
                if($test_type_id == '3'){ 
                  $report_link = base_url('member/viewListenReport/').$getData->id_md5;
                }
                if($test_type_id == '4'){ 
                  $report_link = base_url('member/viewWriteReport/').$getData->id_md5;
                }

              ?>
              <a class="btn btn-danger"style="color:#fff;" href="<?php echo $report_link; ?>"><i class="fa fa-hand-o-right"></i>  View Report
              </a>
						<?php }else{ ?>
						<button type="button" class="btn btn-danger"> Reviewing</button>
						<?php } ?>
						
						
						<?php }else{ ?>
						<?php /*<button type="button" class="btn btn-danger allow-test-submit" data-testid="<?php echo $test_id; ?>" data-memberid="<?php echo $member_id; ?>" data-testcode="<?php echo $test->test_code; ?>"><i class="fa fa-hand-o-right"></i> Start It</button>*/?>
						
						<a class="btn btn-danger btn-md part-test-show-instructions" onclick="partWithTimerInstructions(<?php echo $test_id; ?>,<?php echo $member_id; ?>,'<?php echo $test->test_code; ?>')"><i class="fa fa-hand-o-right"></i> Start It</a>
						<?php } ?>
						</td>
                      </tr> 
					<?php } ?>

                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

	<div id="part-instructions" class="modal fade">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-body">
			
		  </div>
		</div>
	  </div>
	</div>

  <?php include_once('common/scripts.php'); ?>
  <?php include_once('parts_modals.php'); ?>
</body>
</html>
