<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		.alert_mess {
			font-size: 50px;
			font-family: sans-serif;
			text-align: center;
			padding-top: 150px;
			color: orange;
		}
		.alert_para {
			font-size: 25px;
			font-family: sans-serif;
			text-align: center;
			padding-top: 50px;
		}
	</style>
</head>
<body>
<div class="alert_mess"><i class="fa fa-check" aria-hidden="true"></i> Account has been created Successfully!!</div>
<div class="alert_para">Please Check Your Email</div>
<div class="alert_para" style="color:green;"><a href="<?php echo base_url('login'); ?>"> Click here to login </a></div>


</body>
</html>