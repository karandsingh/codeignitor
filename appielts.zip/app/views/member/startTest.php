<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

        <style type="text/css">
    .widget-user .widget-user-header {
    padding: 15px;
    height: 90px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
}


  </style>

</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">


        <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h4><i class="fa fa-info"></i> Note:</h4>
        Please read all instructions carefully before you begin .    

        </div>
         
          <div class="box">
            <div class="box-header">
               <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-purple">
            
              <!-- /.widget-user-image -->
              
              <h3 class="widget-user-username"><STRONG> <p class="fa fa-desktop"></p> <?=$type->PTEtype?> : <?=$subtype->PTEsubtype?> </STRONG></h3> 

              <h5 class="widget-user-desc"> Questions To Improve Your Skills (<?php echo count($allQuestions); ?> Questions )</h5>
            </div>
              </div>
            </div>





            <!-- /.box-header -->
            <div class="box-body">
             

            <p align="center">
              <span > <a id="" class="btn btn-danger btn-md" href="<?php echo base_url($currentPath.'/sampleTest/'.$subtype->id.'/'.$test->id_md5); ?>" ><i class="fa fa-hand-o-right" ></i> Start Test Now</a>
              <a id="" class="btn btn-default btn-md" href=""><i class="fa fa-close "></i>  Quit</a></span>
            </p>

        <div class="box box-solid">
            <div class="box-header with-border">
              <i class="glyphicon glyphicon-warning-sign"></i>

              <h3 class="box-title">Please Read all instructions carefully before you begin . </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <dl>
                <dt>Speaking</dt>
                <ul>
                 <li>
                  The Speaking section mainly timed between 35 to 50 minutes &amp; each question is timed Separately.
                  </li>

                  <li>
                  In the Real test of Pearson (PTE Academic), Test taker should face Personal Introduction which is without scores. In our test, there is no Personal Introduction section.
                  </li>
                  <li>
                  Before attempting the tests, one must ensure that headset with microphone is functioning properly.
                  </li>
                </ul>
                <dt>Reading</dt>

                <ul>
                 <li>
                  Reading section is of 32-41 minutes duration. So, target your answers under the given time.
                  </li>
                  <li>
                 Every instruction pertaining to set of questions must be read carefully and answer as expected. There are 5 types of questions and instructions for all vary.
                  </li>
                  <li>
                  You will only find the result , if you "SUBMIT TEST" at the end of reading section.

                  </li>

                  <li>
                  Before submitting the test in the end, any answer can be changed any number of times. There is a secondary option of "SAVE & EXIT".

                  </li>
                </ul>

                <dt>Writing</dt>
                <ul>
                    <li>
                    In the Writing task, the answer has to strictly stick to the given word limit.It consists of 40 minute.
                    </li>
                    <li>
                    Two Summary of 10-10 minutes and 1 Essay of 20 minutes or 2 Essay of 20-20 minutes and 1 summary of 10 Minutes.
                    </li>
                </ul>
              <dt>Listening</dt>
                              <ul>
                 <li>
                  The Listening section is of 40 minutes duration. The section comprises some purely listening assignments whereas, some integrated assignments that involve speaking and listening.
                  </li>

                  <li>

                       PTE test of English is a time bound test ,so target your answers under the given time.
                   </li>
                  <li>
                 
                There is no re-recording or re-listening of the audio facility, hence complete concentration must be practiced. One can take notes while listening to the audio and for each question there is a facility of volume adjustment.

                  </li>
                </ul>

              </dl>
            </div>
            <!-- /.box-body -->
          </div>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
</body>
</html>
