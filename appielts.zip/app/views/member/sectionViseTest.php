<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
  <style type="text/css">
    .widget-user .widget-user-header {
      padding: 15px;
      height: 90px;
      border-top-right-radius: 3px;
      border-top-left-radius: 3px;
    }
  </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
  
  <div class="wrapper">

    <header class="main-header">
      <?php include_once('common/nav.php'); ?>
    </header>
    <aside class="main-sidebar">
      <?php include_once('common/sidebar.php'); ?>
    </aside>


  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?>  
        <small>Select <?php echo $pagetitle; ?> </small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
		
      <div class="row">
        <div class="col-md-12">
                <?php if($PTEtypes) { ?>
                  <?php foreach ($PTEtypes as $key => $type) {
                    ?>
					<div class="col-md-4">
                        <div class="box box-widget widget-user boxcustom">
                          <div class="widget-user-header bg-purplex">
                            <h3 class="widget-user-username text-center"><?php echo $type->PTEtype; ?></h3>
                            
                          </div>
                          <div class="box-footer no-padding">
						  <?php /*<a href="<?php echo base_url($currentPath.'/sampleQResult/'.$subtype->id.'/'.$test_urlkey); ?>" class="btn btn-block btn-info">START TEST</a> */ ?>
                          </div>
                        </div>
                      </div>
                  <?php } ?>
                <?php } ?>
        </div>
      </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>

  <?php include_once('common/scripts.php'); ?>
</body>
</html>