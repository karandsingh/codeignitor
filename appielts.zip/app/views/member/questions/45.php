             <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
              Read the passage given below and summarize it using one sentence. Type your response in the box at the bottom of the screen. You have 10 minutes to finish this task. Your response will be judged on the quality of your writing and on how well your response presents the key points in the passage.
              </p>

              <audio controls width="420" height="315">
              <source src="<?php echo base_url('/uploads/speaking/mp3/demo.mp3'); ?>" type="audio/mpeg">
              Your browser does not support the audio element.
              </audio>

              <dl>
                <dt></dt>
                <dd></dd>
              </dl>
       
