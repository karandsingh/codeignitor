             <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
              Look at the text below .In 40 seconds, You must read this text aloud as naturally and clearly as possible. you have 40 seconds to read aloud. 
              </p>

              
              <p>Having audio playing automatically could be annoying in some instances, so keep this in mind before adding music to your website. Consider the user that is in a setting where they do not want or expect audio to be playing, such as work or a library.Having audio playing automatically could be annoying in some instances, so keep this in mind before adding music to your website. Consider the user that is in a setting where they do not want or expect audio to be playing, such as work or a library.</p> 


            <p align="center"><a id="" class="btn btn-danger btn-md" "><strong><i class="fa fa-spinner fa-spin"></i> Recording beginning in : 00:40 Sec</strong> </a></p>


       
