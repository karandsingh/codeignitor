             <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;"><strong>
              You will hear a sentence . Please repeat the sentence exactly as you hear it. You will hear the sentence only once . </strong>
              </p>

              
              <p class="text-muted well well-sm no-shadow audiobg" align="center" ><strong>AUDIO CLIP</strong><br>
                <img src="./images/soundwaves.png">
                <audio  id="player" controls >
                <source src="<?php echo base_url('/uploads/speaking/mp3/demo.mp3'); ?>" type="audio/mpeg">
                Your browser does not support the audio element.
                </audio>
             </p> 




            <p align="center"><a id="" class="btn btn-danger btn-md" "><strong><i class="fa fa-spinner fa-spin"></i> Recording beginning in : 00:40 Sec</strong> </a></p>


       
