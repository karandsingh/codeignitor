<div id="parts-instructions" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="box box-solid">
          <div class="box-body">
            <h3 class="text-center"><u>Instructions - Celpip Part Test</u></h3>
      			
			     <div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
            <div class="alert alert-warning alert-dismissible" >
              <i class="glyphicon glyphicon-warning-sign"></i>
              Please Read all instructions carefully before you begin. 
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <ul>
              <li>Every instruction pertaining to set of questions must be read carefully and answer as expected.</li>
              <li>Coins Required: <?php echo $coins->coin_cost; ?></li>
              <li>Balance Coins: <?php echo $user->coins; ?></li>
            </ul>
          </div>
        </div>
        <div class="text-center">
          <button type="button" class="btn btn-primary allow-test-submit"  data-testid="<?php echo $test_id; ?>" data-memberid="<?php echo $member_id; ?>" data-testcode="<?php echo $test->test_code; ?>">Start Test Now</button>
        </div>
      </div>
    </div>
  </div>
</div>