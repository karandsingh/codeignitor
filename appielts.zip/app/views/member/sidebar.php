  <section class="sidebar">
      <!-- Sidebar user panel -->
      <!-- <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Alexander Pierce</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div> -->
      <!-- search form -->
      <!-- <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form> -->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->



      <ul class="sidebar-menu">

        <li class="header"> </li>

                <li <?php if (in_array($this->uri->segment(2), array('dashboard'))) { ?> class="active"<?php } ?>>
                    <a href="<?php echo base_url($currentPath.'/dashboard'); ?>">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                   </a>
        </li>
		
		<li <?php if (in_array($this->uri->segment(2), array('earnCoins'))) { ?> class="active"<?php } ?>>
			<a href="<?php echo base_url($currentPath.'/earnCoins'); ?>">
			<i class="fa fa-dollar"></i> <span>Earn Free Coins</span>
		   </a>
		</li>
		
        <?php /* <li <?php if (in_array($this->uri->segment(2), array('vocabulary','vtestdetails'))) { ?> class="active"<?php } ?>>
          <a href="<?php echo base_url($currentPath.'/vocabulary'); ?>">
            <i class="fa fa-list"></i> <span>Vocabulary Tests</span>
          </a>
        </li>*/ ?>
		
		
		<li class="<?php if (in_array($this->uri->segment(2), array('vocabulary','vtestdetails','reArrangeTestdetails','dictation','dictationTestdetails'))) { ?>active  <?php } ?>treeview">
		  <a>
			<i class="fa fa-list"></i> <span>Competitive English</span>
			<span class="pull-right-container">
			  <i class="fa fa-angle-left pull-right"></i>
			</span>
		  </a>
		  <ul class="treeview-menu">
			<li <?php if (in_array($this->uri->segment(2), array('vocabulary','vtestdetails'))) { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath.'/vocabulary'); ?>"> <i class="fa fa-sticky-note-o"></i> Vocabulary Tests </a></li>
			
			<li class=""><a href="<?php echo base_url($currentPath.'/spottingErrors'); ?>"><i class="fa fa-sticky-note-o"></i> Spotting the Errors </a></li>
			
			<li <?php if (in_array($this->uri->segment(2), array('dictation','dictationTestdetails'))) { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath.'/dictation'); ?>"><i class="fa fa-sticky-note-o"></i> Dictation Tests </a></li>
			
			<li class=""><a href="<?php echo base_url($currentPath.'/comprehensionTest'); ?>"><i class="fa fa-sticky-note-o"></i> Comprehension tests </a></li>
			
			<li <?php if (in_array($this->uri->segment(2), array('reArrangeTestdetails'))) { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath.'/reArrangeTestdetails'); ?>"><i class="fa fa-sticky-note-o"></i> Re-arrange </a></li>
			
			<li class=""><a href="<?php echo base_url($currentPath.'/fillblanks'); ?>"><i class="fa fa-sticky-note-o"></i> Fill in the blanks </a></li>
		</ul>


        <?php /*<li <?php if (in_array($this->uri->segment(2), array('tests'))) { ?> class="active"<?php } ?>>
			<a href="<?php echo base_url($currentPath.'/tests'); ?>">
			<i class="fa fa-file-text-o"></i> <span> CELPIP Complete Tests </span>
		   </a>
        </li>
		
		<li <?php if (in_array($this->uri->segment(2), array('sectionViseTest'))) { ?> class="active"<?php } ?>>
          <a href="<?php echo base_url($currentPath.'/sectionViseTest'); ?>">
            <i class="fa fa-list"></i> <span>CELPIP Sections Tests</span>
          </a>
        </li>*/ ?>
      
        <?php /*
          <li<?php if (in_array($this->uri->segment(2), array('History'))) { ?> class="active"<?php } ?>>
            <a href="<?php echo base_url($currentPath.'/dashboard'); ?>">
              <i class="fa fa-area-chart"></i> <span>Test History</span>
            </a>
          </li>
        */ ?>
		
	<li class="<?php if (in_array($this->uri->segment(2), array('getSectionListening','xxx'))) { ?>active <?php } ?>treeview">
            <a>
            <i class="glyphicon glyphicon-bullhorn"></i> <span>CELPIP Sections Tests </span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
           </a>
            <ul class="treeview-menu">
				<li <?php if ($this->uri->segment(3) == '3') { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/getSectionListening"); ?>"><i class="fa  fa-headphones"></i> Listening</a></li>
				<li <?php if ($this->uri->segment(3) == '3') { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/getSectionReading"); ?>"><i class="fa fa-file-text-o"></i> Reading </a></li>
            </ul>
			
        </li>


       <!--  <li<?php if (in_array($this->uri->segment(2), array('Analysis'))) { ?> class="active"<?php } ?>>
                    <a href="<?php echo base_url($currentPath.'/dashboard'); ?>">
                    <i class="fa fa-line-chart"></i> <span>Test Analysis</span>
                   </a>
        </li>

 


        <li class="<?php if (in_array($this->uri->segment(2), array('Material','addMember','editMember'))) { ?>active <?php } ?>treeview">
            <a href="#">
            <i class="fa fa-suitcase"></i> <span>Free Material</span>
               <span class="pull-right-container">
              <span class="label label-primary pull-right">2</span>
            </span>
           </a>
            </a>
            <ul class="treeview-menu">

            <li<?php if (in_array($this->uri->segment(2), array('member'))) { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/member"); ?>"><i class="fa fa-file-video-o"></i> Videos</a></li>

            <li<?php if (in_array($this->uri->segment(2), array('addTest'))) { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/member"); ?>"><i class="fa fa-cloud-download"></i> Download</a></li>


            </ul>
        </li> -->


        <li class="<?php if (in_array($this->uri->segment(2), array('sampleQuestion','xxx','getTestList','testnewprogress'))) { ?>active <?php } ?>treeview">
            <a >
            <i class="glyphicon glyphicon-bullhorn"></i> <span>Celpip Parts Tests </span>
                   <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>

                </span>
           </a>
            <ul class="treeview-menu">

            <?php /*

            <li<?php if ($this->uri->segment(3) == '1') { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/sampleQuestion/1"); ?>"><i class="fa fa-microphone"></i> Speaking</a></li>

            */ ?>
			<li <?php if ($this->uri->segment(3) == '3') { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/sampleQuestion/3"); ?>"><i class="fa  fa-headphones"></i> Listening</a></li>

            <li <?php if ($this->uri->segment(3) == '2') { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/sampleQuestion/2"); ?>"><i class="fa fa-file-text-o  "></i> Reading</a></li>
			
			<li <?php if ($this->uri->segment(3) == '1') { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/sampleQuestion/1"); ?>"><i class="fa fa-microphone"></i> Speaking</a></li>
			
			<li <?php if ($this->uri->segment(3) == '4') { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/sampleQuestion/4"); ?>"><i class="fa fa-pencil-square-o"></i> Writing</a></li>

            </ul>
        </li>




         <li class="<?php if (in_array($this->uri->segment(2), array('support','addTestType'))) { ?>active  <?php } ?>treeview">
                <a href="#">
                <i class="fa fa-support"></i> <span>Support</span>
                   <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>

                </span>
                </a>
                <ul class="treeview-menu">

                <li<?php if (in_array($this->uri->segment(2), array('support'))) { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/support"); ?>"><i class="fa fa-sticky-note-o"></i>View Tickets</a></li>
                <li<?php if (in_array($this->uri->segment(2), array('addTicket'))) { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/addTicket"); ?>"><i class="fa fa-sticky-note-o"></i>Create New Ticket</a></li>
                 </ul>
            </li>


            <li class="<?php if (in_array($this->uri->segment(2), array('account','changePassword','editProfile'))) { ?>active  <?php } ?>treeview">
                <a href="#">
                <i class="fa fa-gear"></i> <span>Settings</span>
                   <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
                </a>
                <ul class="treeview-menu">
					<li <?php if (in_array($this->uri->segment(2), array('editProfile'))) { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/editProfile"); ?>"><i class="fa fa-sticky-note-o"></i> Update Profile</a></li>
					<li <?php if (in_array($this->uri->segment(2), array('changePassword'))) { ?> class="active"<?php } ?>><a href="<?php echo base_url($currentPath."/password"); ?>"><i class="fa fa-sticky-note-o"></i> Change Password</a></li>
                </ul>
            </li>		
			
			<li <?php if (in_array($this->uri->segment(2), array('coinManage'))) { ?> class="active"<?php } ?>>
				<a href="<?php echo base_url($currentPath.'/coinManage'); ?>">
				<i class="fa fa-dollar"></i> <span>Coin Management</span>
			   </a>
			</li>
    
      </ul>
    </section>