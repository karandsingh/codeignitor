<!doctype html>
<html lang="en">
<head>
  <title><?php echo $window_title; ?></title>
  <?php include_once('common/head.php'); ?>
</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Vocabulary TESTS
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Tests</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">

          <h3 class="box-title"></h3>

               <?php
                  if (!empty($levels)) {

                    $myCounter = 0;

                    foreach ($levels as $key => $test) {
                      $myCounter++;
                      if($test->total_questions) {
                        $start_btn = '<a href="'.base_url($currentPath.'/vtestdetails/'.$test->id.'/'.md5($test->id)).'" class="btn btn-block btn-info">TAKE TEST</a>';
                      } else {
                        $start_btn = '<a class="btn btn-block btn-danger">LOCKED</a>';
                      }
                    ?>
                      <div class="col-md-4">
                        <div class="box box-widget widget-user boxcustom">
                          <div class="widget-user-header bg-purplex">
                            <h3 class="widget-user-username text-center"><?php echo $test->name; ?></h3>
                            <h5 class="widget-user-desc text-center">
                              <strong>Questions</strong> : <?php echo $test->total_questions; ?>
                            </h5>
							<h5 class="widget-user-desc text-center">
                              <strong>Coin Cost</strong> : <?php echo $test->coin_cost; ?>
                            </h5>
                          </div>
                          <div class="box-footer no-padding">
                            <?php echo $start_btn; ?>
                          </div>
                        </div>
                      </div>
                <?php }} ?>

          </div>
        </div>
      </div>
    </section>
  </div>
  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>