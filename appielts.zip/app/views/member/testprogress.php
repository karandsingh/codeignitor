<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>
    <style type="text/css">
      .widget-user .widget-user-header {
        padding: 15px;
        height: 90px;
        border-top-right-radius: 3px;
        border-top-left-radius: 3px;
      }
      #player {

        width: 100%;
      }​
      .clickmediv {
        display: block;padding: 10px;border:#000 1px solid;margin-bottom: 20px;cursor: pointer;
      }
      video::-internal-media-controls-download-button,
      audio::-internal-media-controls-download-button {
        display:none;
      }
    </style>
</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

  <div class="content-wrapper">
    
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
              <div class="box box-widget widget-user">
                <div class="widget-user-header bg-purple">
                  <p>
                    <span class="pull-right" > <a href="<?php echo base_url($currentPath.'/tests'); ?>" class="btn btn-default btn-md"><i class="fa fa-question-circle" aria-hidden="true"></i> Help</a>
                    <a href="<?php echo base_url($currentPath.'/tests'); ?>" class="btn btn-danger btn-md"><i class="glyphicon glyphicon-collapse-up "></i> Quit</a></span>
                  </p>

                  <h3 class="widget-user-username">
                    <strong><?php echo  $test->test_name; ?></strong>
                  </h3>
                  Total Questions : <strong><?php echo $total; ?></strong>

                </div>
              </div>
            </div>

            
            <div class="box box-solid">
            

              <?php foreach ($allQuestions as $objQuestion) {

                    $type = $this->my_model->getARecord($this->tb_type, $objQuestion->PTEtypeid);
                    $subtype = $this->my_model->getARecord($this->tb_subtype, $objQuestion->PTEsubtypeid);

                    $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                    $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);


                    // check if member already attempt is question
                    $attempted = false;

                    $where = "testid = '".$test->id."' AND questionid = '".$objQuestion->id."' AND memberid = '".$user->id."' AND testdetail_id = '".$testdetail->id."' ";
                    $alreadyAttempt = $this->my_model->getWhereOrderRecords($this->tb_attempt, $where, 'id', 'ASC', true);
                    if( is_object($alreadyAttempt)) {
                      $attempted = true;
                    }

                ?>


                <div class="box-header with-border">
                <i class="fa fa-television"></i>
                <h3 class="box-title"><?php echo  $type->PTEtype?> : <?php echo $subtype->PTEsubtype?> </h3>
                </div>

                <div class="box-body mystyle">

                  <?php

                    if($attempted) {

                      $attempt = $this->my_model->getARecord($this->tb_attempt, $alreadyAttempt->id);
                      
                      //$subtype = $this->my_model->getARecord($this->tb_subtype, $attempt->subtypeid);
                      //$test = $this->my_model->checkARecord($this->tb_test, 'id', $attempt->testid);
                      //$type = $this->my_model->getARecord($this->tb_type, $subtype->PTEtypeid);
                      
                      $question = $this->my_model->checkARecord($this->tb_question, 'id', $attempt->questionid);
                    

                      include('testresponse.php');
                    
                    } else {

                  ?>

                    <div class="alert alert-warning"><?php echo $subtype->note; ?></div>

                    <?php if($subtype->id == '41') { // Read Aloud ?>
                      
                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              Member can read paragraph for 40 seconds
                              After 40 seconds, recording will start automatically for 40 seconds
                            */
                            echo nl2br($qExtra->paragraph);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>

                            <div class="alert alert-danger text-center" id="recording-message" style="display: none;">
                              <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">40</strong> seconds
                            </div>

                            <div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
                              <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page
                            </div>

                            <div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
                              
                              <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
                              <span id="recordHelp">Allow your microphone and reload page</span>
                                  Recording started .... <strong style="display: none;" id="countresult">40</strong><span id="time">00:00</span> seconds
                              
                            </div>

                            <div class="text-center" id="success-recording" style="display: none;">
                              <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
                            </div>

                            <div class="clearfix"></div>
                            <span id="level" style="display: none;"></span>
                            <div style="display: none;">
                              <div id="levelbase">
                                <canvas id="levelbar"></canvas>
                              </div>
                              <div id="levelbase2">
                                <div id="levelbar2"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '42') { // Repeat Sentence ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              Member can hear mp3 for 10 seconds
                              After 10 seconds, recording will start automatically for 10 seconds
                            */
                            $audiofile = base_url('uploads/pte/Speaking/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>

                            <div class="row">
                              <div class="col-md-12">
                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>
                                <audio class="my_audio" id="mp3player" style="display: none;" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                              </div>
                            </div>

                            <div class="row">
                              <div class="col-md-12">

                                <div class="alert alert-danger text-center" id="recording-message" style="display: none;">
                                  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">25</strong> seconds
                                </div>

                                <div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
                                  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page
                                </div>

                                <div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
                                  
                                  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
                                  <span id="recordHelp">Allow your microphone and reload page</span>
                                  Recording started .... <strong style="display: none;" id="countresult">10</strong><span id="time">00:00</span> seconds
                                  
                                </div>

                                <div class="text-center" id="success-recording" style="display: none;">
                                  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
                                </div>

                                <div class="clearfix"></div>
                                <span id="level"></span>
                                <div style="display: none;">
                                  <div id="levelbase">
                                    <canvas id="levelbar"></canvas>
                                  </div>
                                  <div id="levelbase2">
                                    <div id="levelbar2"></div>
                                  </div>
                                </div>

                              </div>
                            </div>

                    <?php } elseif($subtype->id == '43') { // Describe Image ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              Member can see photo for 25 seconds
                              After 25 seconds, recording will start automatically for 40 seconds
                            */
                            $imagefile = base_url('uploads/pte/Speaking/'.$qExtra->SDimage);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>

                            <div class="row">

                              <div class="col-md-6">
                                <img src="<?php echo $imagefile; ?>" class="img-responsive" alt="photo">
                              </div>

                              <div class="col-md-6">

                                <div class="alert alert-danger text-center" id="recording-message" style="display: none;">
                                  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">25</strong> seconds
                                </div>

                                <div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
                                  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page
                                </div>

                                <div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
                                  
                                  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
                                  <span id="recordHelp">Allow your microphone and reload page</span>
                                  Recording started .... <strong style="display: none;" id="countresult">40</strong><span id="time">00:00</span> seconds
                                  
                                </div>

                                <div class="text-center" id="success-recording" style="display: none;">
                                  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
                                </div>

                                <div class="clearfix"></div>
                                <span id="level"></span>
                                <div style="display: none;">
                                  <div id="levelbase">
                                    <canvas id="levelbar"></canvas>
                                  </div>
                                  <div id="levelbase2">
                                    <div id="levelbar2"></div>
                                  </div>
                                </div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '44') { // Re-tell lecture ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              Member can hear mp3 for whole mp3 length
                              After whole mp3, recording will start automatically for 15 seconds
                            */
                            $audiofile = base_url('uploads/pte/Speaking/'.$qExtra->mp3URL);
                            $imagefile = base_url('uploads/pte/Speaking/'.$qExtra->imageURL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>

                            <div class="row">

                              <div class="col-md-6">
                                <div class="text-center" id="myloading" style="display: none;">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>
                                <audio class="my_audio" id="mp3player" style="display: none;" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <img src="<?php echo $imagefile; ?>" class="img-responsive" alt="photo">
                              </div>

                              <div class="col-md-6">

                                <div class="alert alert-danger text-center" id="recording-message" style="display: none;">
                                  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">25</strong> seconds
                                </div>

                                <div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
                                  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page
                                </div>

                                <div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
                                  
                                  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
                                  <span id="recordHelp">Allow your microphone and reload page</span>
                                  Recording started .... <strong style="display: none;" id="countresult">40</strong><span id="time">00:00</span> seconds
                                  
                                </div>

                                <div class="text-center" id="success-recording" style="display: none;">
                                  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
                                </div>

                                <div class="clearfix"></div>
                                <span id="level"></span>
                                <div style="display: none;">
                                  <div id="levelbase">
                                    <canvas id="levelbar"></canvas>
                                  </div>
                                  <div id="levelbase2">
                                    <div id="levelbar2"></div>
                                  </div>
                                </div>


                              </div>
                            </div>

                    <?php } elseif($subtype->id == '45') { // Answer short question ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              Member can hear mp3 for whole mp3 length
                              After whole mp3, recording will start automatically for 15 seconds
                            */
                            $audiofile = base_url('uploads/pte/Speaking/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>

                            <div class="row">
                              <div class="col-md-12">
                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>
                                <audio class="my_audio" id="mp3player" style="display: none;" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                              </div>
                            </div>

                            <div class="row">
                              <div class="col-md-12">

                                <div class="alert alert-danger text-center" id="recording-message" style="display: none;">
                                  <i class="fa fa-spinner fa-spin"></i> Recording beginning in <strong id="count">25</strong> seconds
                                </div>

                                <div class="alert alert-danger text-center" id="audio-block" style="display: none;font-size: 20px;">
                                  <i class="fa fa-exclamation-circle"></i> Your browser does not support the audio. Allow your microphone and reload page
                                </div>

                                <div class="alert alert-successx text-center" id="player-block" style="display: none;background-color: #2c9f45;font-size: 20px;color: #ffffff;">
                                  
                                  <img src="../../uploads/recorder/images/Microphone.png" id="recordButton" class="recordOff">
                                  <span id="recordHelp">Allow your microphone and reload page</span>
                                  Recording started .... <strong style="display: none;" id="countresult">10</strong><span id="time">00:00</span> seconds
                                  
                                </div>

                                <div class="text-center" id="success-recording" style="display: none;">
                                  <i class="fa fa-spinner fa-spin"></i> Saving Your Response ...
                                </div>

                                <div class="clearfix"></div>
                                <span id="level"></span>
                                <div style="display: none;">
                                  <div id="levelbase">
                                    <canvas id="levelbar"></canvas>
                                  </div>
                                  <div id="levelbase2">
                                    <div id="levelbar2"></div>
                                  </div>
                                </div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '46') { // Summarize written text ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-12">
                                <?php echo nl2br($qExtra->essay); ?>
                                <hr />

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr />

                                <div class="text-center" id="responseblock" style="display: none;">
                                  <textarea class="form-control" rows="7" id="my-response" placeholder="Write your response here"></textarea>
                                  <br />
                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                  <br />
                                  Total word count : <strong id="display_count">0</strong> words.
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '47') { // Write Essay ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 20 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-12">
                                <?php echo nl2br($qExtra->essayTitle); ?>
                                <hr />

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr />

                                <div class="text-center" id="responseblock" style="display: none;">
                                  <textarea class="form-control" rows="7" id="my-response" placeholder="Write your response here"></textarea>
                                  <br />
                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                  <br />
                                  Total word count : <strong id="display_count">0</strong> words.
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>


                              </div>
                            </div>

                    <?php } elseif($subtype->id == '28') { // Summarize spoken text ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-12">
                              <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <hr />

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr />

                                <div class="text-center" id="responseblock" style="display: none;">
                                  <textarea class="form-control" rows="7" id="my-response" placeholder="Write your response here"></textarea>
                                  <br />
                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                  <br />
                                  Total word count : <strong id="display_count">0</strong> words.
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '29') { // Multiple-choice: Single ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-6">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <hr />
                              </div>

                              <div class="col-md-6">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>

                                <div id="contentblock" style="display: none;">
                                  <table class="table" style="font-size: 14px;">
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="1">
                                        <?php echo $qExtra->option1; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="2">
                                        <?php echo $qExtra->option2; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="3">
                                        <?php echo $qExtra->option3; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="4">
                                        <?php echo $qExtra->option4; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                      </td>
                                    </tr>
                                  </table>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>


                    <?php } elseif($subtype->id == '20') { ?>

                        <?php
                          //foreach ($allQuestions as $objQuestion) {

                            //$myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            //$qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL);
                          //}
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-6">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <hr />
                              </div>

                              <div class="col-md-6">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>

                                <div id="contentblock" style="display: none;">
                                  <table class="table" style="font-size: 14px;">
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="1">
                                        <?php echo $qExtra->option1; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="2">
                                        <?php echo $qExtra->option2; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="3">
                                        <?php echo $qExtra->option3; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="4">
                                        <?php echo $qExtra->option4; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                      </td>
                                    </tr>
                                  </table>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>


                    <?php } elseif($subtype->id == '19') { ?>

                        <?php
                          //foreach ($allQuestions as $objQuestion) {

                            //$myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            //$qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL);
                          //}
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-6">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <hr />
                              </div>

                              <div class="col-md-6">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>

                                <div id="contentblock" style="display: none;">
                                  <table class="table" style="font-size: 14px;">
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="1">
                                        <?php echo $qExtra->option1; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="2">
                                        <?php echo $qExtra->option2; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="3">
                                        <?php echo $qExtra->option3; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="4">
                                        <?php echo $qExtra->option4; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                      </td>
                                    </tr>
                                  </table>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>


                    <?php } elseif($subtype->id == '18') { ?>

                        <?php
                          //foreach ($allQuestions as $objQuestion) {

                            //$myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            //$qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL);
                          //}
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-6">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <hr />
                              </div>

                              <div class="col-md-6">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>

                                <div id="contentblock" style="display: none;">
                                  <table class="table" style="font-size: 14px;">
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="1">
                                        <?php echo $qExtra->option1; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="2">
                                        <?php echo $qExtra->option2; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="3">
                                        <?php echo $qExtra->option3; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="4">
                                        <?php echo $qExtra->option4; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                      </td>
                                    </tr>
                                  </table>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>


                    <?php } elseif($subtype->id == '17') { ?>

                        <?php
                          //foreach ($allQuestions as $objQuestion) {

                            //$myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            //$qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL);
                          //}
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>

                            <div class="row">
                              <div class="col-md-12">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                              </div>
                            </div>

                            <div class="row">
                              <div class="col-md-12">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr>

                                <div id="contentblock" style="display: none;padding: 10px;font-size: 18px;">

                                  <?php
                                    $mysearch = '<span class="ofield"></span>';
                                    $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                                    $finalText = '';
                                    $myctr = 1;
                                    $txts = explode($mysearch, trim($qExtra->paragraph));
                                    foreach ($txts as $text) {
                                      $blank = '';
                                      if($myctr <= $totalBlanks) {
                                        $blank = 'FILLBLANKLIST'.$myctr;
                                      }
                                      $finalText .= $text . $blank;
                                      $myctr++;
                                    }
                                    //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                                    $search = array();
                                    for ($i=1; $i <= $totalBlanks; $i++) { 
                                      $search[] = 'FILLBLANKLIST'.$i;
                                    }

                                    $replace = array();
                                    $correntwords = explode(',', $qExtra->words);
                                    $ctrlist = 1;

                                    $option1 = $qExtra->option1;
                                    $option2 = $qExtra->option2;
                                    $option3 = $qExtra->option3;
                                    $option4 = $qExtra->option4;

                                    foreach ($correntwords as $word) {

                                        $options = 'option'.$ctrlist;

                                        $opts = explode(',', $$options);
                                        $getOpts = '';
                                        foreach ($opts as $chooseOption) {
                                          $getOpts .= '<option value="'.$chooseOption.'">'.$chooseOption.'</option>';
                                        }

                                        $list = '<select name="my-response" required>';
                                        $list .= '<option value=""></option>';
                                        $list .= $getOpts;
                                        $list .= '</select>';

                                      $replace[] = $list;
                                      $ctrlist++;
                                    }
                                    //echo '<pre>'; print_r($search); echo '</pre>';
                                    //echo '<pre>'; print_r($replace); echo '</pre>';

                                    $finalParagraph = str_replace($search, $replace, $finalText);
                                    echo nl2br($finalParagraph);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">

                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>


                    <?php } elseif($subtype->id == '16') { ?>

                        <?php
                          //foreach ($allQuestions as $objQuestion) {

                            //$myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            //$qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL);
                          //}
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>

                            <div class="row">
                              <div class="col-md-12">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                              </div>
                            </div>

                            <div class="row">
                              <div class="col-md-12">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr>

                                <div id="contentblock" style="display: none;padding: 10px;font-size: 18px;">

                                  <?php
                                    $mysearch = '<span class="ofield"></span>';
                                    $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                                    $finalText = '';
                                    $myctr = 1;
                                    $txts = explode($mysearch, trim($qExtra->paragraph));
                                    foreach ($txts as $text) {
                                      $blank = '';
                                      if($myctr <= $totalBlanks) {
                                        $blank = 'FILLBLANKLIST'.$myctr;
                                      }
                                      $finalText .= $text . $blank;
                                      $myctr++;
                                    }
                                    //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                                    $search = array();
                                    for ($i=1; $i <= $totalBlanks; $i++) { 
                                      $search[] = 'FILLBLANKLIST'.$i;
                                    }

                                    $replace = array();
                                    $correntwords = explode(',', $qExtra->words);
                                    $ctrlist = 1;

                                    $option1 = $qExtra->option1;
                                    $option2 = $qExtra->option2;
                                    $option3 = $qExtra->option3;
                                    $option4 = $qExtra->option4;

                                    foreach ($correntwords as $word) {

                                        $options = 'option'.$ctrlist;

                                        $opts = explode(',', $$options);
                                        $getOpts = '';
                                        foreach ($opts as $chooseOption) {
                                          $getOpts .= '<option value="'.$chooseOption.'">'.$chooseOption.'</option>';
                                        }

                                        $list = '<select name="my-response" required>';
                                        $list .= '<option value=""></option>';
                                        $list .= $getOpts;
                                        $list .= '</select>';

                                      $replace[] = $list;
                                      $ctrlist++;
                                    }
                                    //echo '<pre>'; print_r($search); echo '</pre>';
                                    //echo '<pre>'; print_r($replace); echo '</pre>';

                                    $finalParagraph = str_replace($search, $replace, $finalText);
                                    echo nl2br($finalParagraph);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">

                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>


                    <?php } elseif($subtype->id == '15') { ?>

                        <?php
                          //foreach ($allQuestions as $objQuestion) {

                            //$myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            //$qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->mp3URL);
                          //}
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>

                            <div class="row">
                              <div class="col-md-12">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                              </div>
                            </div>

                            <div class="row">
                              <div class="col-md-12">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr>

                                <div id="contentblock" style="display: none;padding: 10px;font-size: 18px;">

                                  <?php
                                    $mysearch = '<span class="ofield"></span>';
                                    $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                                    $finalText = '';
                                    $myctr = 1;
                                    $txts = explode($mysearch, trim($qExtra->paragraph));
                                    foreach ($txts as $text) {
                                      $blank = '';
                                      if($myctr <= $totalBlanks) {
                                        $blank = 'FILLBLANKLIST'.$myctr;
                                      }
                                      $finalText .= $text . $blank;
                                      $myctr++;
                                    }
                                    //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                                    $search = array();
                                    for ($i=1; $i <= $totalBlanks; $i++) { 
                                      $search[] = 'FILLBLANKLIST'.$i;
                                    }

                                    $replace = array();
                                    $correntwords = explode(',', $qExtra->words);
                                    $ctrlist = 1;

                                    $option1 = $qExtra->option1;
                                    $option2 = $qExtra->option2;
                                    $option3 = $qExtra->option3;
                                    $option4 = $qExtra->option4;

                                    foreach ($correntwords as $word) {

                                        $options = 'option'.$ctrlist;

                                        $opts = explode(',', $$options);
                                        $getOpts = '';
                                        foreach ($opts as $chooseOption) {
                                          $getOpts .= '<option value="'.$chooseOption.'">'.$chooseOption.'</option>';
                                        }

                                        $list = '<select name="my-response" required>';
                                        $list .= '<option value=""></option>';
                                        $list .= $getOpts;
                                        $list .= '</select>';

                                      $replace[] = $list;
                                      $ctrlist++;
                                    }
                                    //echo '<pre>'; print_r($search); echo '</pre>';
                                    //echo '<pre>'; print_r($replace); echo '</pre>';

                                    $finalParagraph = str_replace($search, $replace, $finalText);
                                    echo nl2br($finalParagraph);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">

                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>


                    <?php } elseif($subtype->id == '30') { // Multiple-choice: Multiple ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-6">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                              </div>

                              <div class="col-md-6">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>

                                <div id="contentblock" style="display: none;">
                                  <?php /*
                                  <h3><?php echo $qExtra->optiontitle; ?></h3>
                                  */ ?>

                                  <table class="table" style="font-size: 16px;">
                                    <tr>
                                      <td>
                                        <input type="checkbox" name="my-response" value="1">
                                        <?php echo $qExtra->option1; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="checkbox" name="my-response" value="2">
                                        <?php echo $qExtra->option2; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="checkbox" name="my-response" value="3">
                                        <?php echo $qExtra->option3; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="checkbox" name="my-response" value="4">
                                        <?php echo $qExtra->option4; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                      </td>
                                    </tr>
                                  </table>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '31') { // Fill in the blanks ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            <div class="row">
                              <div class="col-md-12">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr>

                                <div id="contentblock" style="display: none;padding: 10px;font-size: 18px;">

                                  <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                  <hr />

                                  <?php
                                    
                                    $replace = '<input name="my-response">';

                                    $search = '<span class="stextfield"></span>';


                                    $finalParagraph = str_replace($search, $replace, $qExtra->transcription);
                                    echo nl2br($finalParagraph);
                                  
                                    $totalBlanks = substr_count($qExtra->transcription, $search);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">
                                  <br/>
                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '32') { // Highlight correct summary ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-6">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <hr />
                              </div>

                              <div class="col-md-6">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>

                                <div id="contentblock" style="display: none;">
                                  <table class="table" style="font-size: 14px;">
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="1">
                                        <?php echo $qExtra->option1; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="2">
                                        <?php echo $qExtra->option2; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="3">
                                        <?php echo $qExtra->option3; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="4">
                                        <?php echo $qExtra->option4; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                      </td>
                                    </tr>
                                  </table>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '33') { // Select missing word ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-6">
                                <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <hr />
                              </div>

                              <div class="col-md-6">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>

                                <div id="contentblock" style="display: none;">
                                  <table class="table" style="font-size: 14px;">
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="1">
                                        <?php echo $qExtra->option1; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="2">
                                        <?php echo $qExtra->option2; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="3">
                                        <?php echo $qExtra->option3; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="4">
                                        <?php echo $qExtra->option4; ?>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>
                                        <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                      </td>
                                    </tr>
                                  </table>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '34') { // Highlight incorrect words ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-12">
                              <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <hr />

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr />

                                <div class="text-center" id="responseblock" style="display: none;">
                                  <?php

                                    // span tag from transcription
                                    $filterTranscription = strip_tags($qExtra->transcription);

                                    // add class to choose
                                    $xx = explode(' ', $filterTranscription);

                                    $finalText = '';
                                    foreach ($xx as $key => $txt) {
                                      $finalText .= '<span class="chooseMe">'.$txt.'</span> ';
                                    }

                                    echo '<div id="mywordSelected">'.$finalText.'</div>';
                                  ?>
                                  <br />
                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                  <br />
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '35') { // Write from dictation ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $audiofile = base_url('uploads/pte/Listening/'.$qExtra->mp3URL);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-12">
                              <audio class="my_audio" src="<?php echo $audiofile;?>" preload="auto" controls>Your browser does not support the audio.</audio>
                                <hr />

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr />

                                <div class="text-center" id="responseblock" style="display: none;">
                                  <textarea class="form-control" rows="7" id="my-response" placeholder="Write your response here"></textarea>
                                  <br />
                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                  <br />
                                  Total word count : <strong id="display_count">0</strong> words.
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '36') { // Multiple Fill in the blanks ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            <div class="row">
                              <div class="col-md-12">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr>

                                <div id="contentblock" style="display: none;padding: 10px;font-size: 18px;">

                                  <?php
                                    $mysearch = '<span class="ofield"></span>';
                                    $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                                    $finalText = '';
                                    $myctr = 1;
                                    $txts = explode($mysearch, trim($qExtra->paragraph));
                                    foreach ($txts as $text) {
                                      $blank = '';
                                      if($myctr <= $totalBlanks) {
                                        $blank = 'FILLBLANKLIST'.$myctr;
                                      }
                                      $finalText .= $text . $blank;
                                      $myctr++;
                                    }
                                    //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                                    $search = array();
                                    for ($i=1; $i <= $totalBlanks; $i++) { 
                                      $search[] = 'FILLBLANKLIST'.$i;
                                    }

                                    $replace = array();
                                    $correntwords = explode(',', $qExtra->words);
                                    $ctrlist = 1;

                                    $option1 = $qExtra->option1;
                                    $option2 = $qExtra->option2;
                                    $option3 = $qExtra->option3;
                                    $option4 = $qExtra->option4;

                                    foreach ($correntwords as $word) {

                                        $options = 'option'.$ctrlist;

                                        $opts = explode(',', $$options);
                                        $getOpts = '';
                                        foreach ($opts as $chooseOption) {
                                          $getOpts .= '<option value="'.$chooseOption.'">'.$chooseOption.'</option>';
                                        }

                                        $list = '<select name="my-response" required>';
                                        $list .= '<option value=""></option>';
                                        $list .= $getOpts;
                                        $list .= '</select>';

                                      $replace[] = $list;
                                      $ctrlist++;
                                    }
                                    //echo '<pre>'; print_r($search); echo '</pre>';
                                    //echo '<pre>'; print_r($replace); echo '</pre>';

                                    $finalParagraph = str_replace($search, $replace, $finalText);
                                    echo nl2br($finalParagraph);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">

                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '37') { // Fill in the blanks ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            <div class="row">
                              <div class="col-md-12">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr>

                                <div id="contentblock" style="display: none;padding: 10px;font-size: 18px;">
                                  <?php
                                    
                                    $opts = explode(',', $qExtra->optionwords);
                                    $getOpts = '';
                                    foreach ($opts as $chooseOption) {
                                      $getOpts .= '<option value="'.$chooseOption.'">'.$chooseOption.'</option>';
                                    }
                                    $replace = '<select name="my-response" required>';
                                    $replace .= '<option value=""></option>';
                                    $replace .= $getOpts;
                                    $replace .= '</select>';

                                    $search = '<span class="stextfield"></span>';


                                    $finalParagraph = str_replace($search, $replace, $qExtra->paragraph);
                                    echo nl2br($finalParagraph);
                                  
                                    $totalBlanks = substr_count($qExtra->paragraph, $search);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">

                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '38') { // Re-order paragraphs ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                            $imagefile = base_url('uploads/dir/'.$type->PTEtype.'/'.$qExtra->diagram);
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            <div class="row">
                              <div class="col-md-12">
                                <img src="<?php echo $imagefile; ?>" class="img-responsive" alt="photo">
                              </div>
                            </div>

                            <div class="row">
                              <div class="col-md-12">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr>

                                <div id="contentblock" style="display: none;padding: 10px;font-size: 18px;">

                                  <?php
                                    $mysearch = '<span class="ofield"></span>';
                                    $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                                    $finalText = '';
                                    $myctr = 1;
                                    $txts = explode($mysearch, trim($qExtra->paragraph));
                                    foreach ($txts as $text) {
                                      $blank = '';
                                      if($myctr <= $totalBlanks) {
                                        $blank = 'FILLBLANKLIST'.$myctr;
                                      }
                                      $finalText .= $text . $blank;
                                      $myctr++;
                                    }
                                    //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                                    $search = array();
                                    for ($i=1; $i <= $totalBlanks; $i++) { 
                                      $search[] = 'FILLBLANKLIST'.$i;
                                    }

                                    $replace = array();
                                    $correntwords = explode(',', $qExtra->words);
                                    $ctrlist = 1;

                                    $option1 = $qExtra->option1;
                                    $option2 = $qExtra->option2;
                                    $option3 = $qExtra->option3;
                                    $option4 = $qExtra->option4;

                                    foreach ($correntwords as $word) {

                                        $options = 'option'.$ctrlist;

                                        $opts = explode(',', $$options);
                                        $getOpts = '';
                                        foreach ($opts as $chooseOption) {
                                          $getOpts .= '<option value="'.$chooseOption.'">'.$chooseOption.'</option>';
                                        }

                                        $list = '<select name="my-response" required>';
                                        $list .= '<option value=""></option>';
                                        $list .= $getOpts;
                                        $list .= '</select>';

                                      $replace[] = $list;
                                      $ctrlist++;
                                    }
                                    //echo '<pre>'; print_r($search); echo '</pre>';
                                    //echo '<pre>'; print_r($replace); echo '</pre>';

                                    $finalParagraph = str_replace($search, $replace, $finalText);
                                    echo nl2br($finalParagraph);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">

                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '39') { // Multiple-choice: Multiple ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                          ///// NEW }
                        ?>
                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            <div class="row">
                              <div class="col-md-12">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>
                                <hr>

                                <div id="contentblock" style="display: none;padding: 10px;font-size: 18px;">

                                  <?php
                                    $mysearch = '<span class="ofield"></span>';
                                    $totalBlanks = substr_count($qExtra->paragraph, $mysearch);

                                    $finalText = '';
                                    $myctr = 1;
                                    $txts = explode($mysearch, trim($qExtra->paragraph));
                                    foreach ($txts as $text) {
                                      $blank = '';
                                      if($myctr <= $totalBlanks) {
                                        $blank = 'FILLBLANKLIST'.$myctr;
                                      }
                                      $finalText .= $text . $blank;
                                      $myctr++;
                                    }
                                    //echo '<hr />';echo nl2br($finalText);echo '<hr />';

                                    $search = array();
                                    for ($i=1; $i <= $totalBlanks; $i++) { 
                                      $search[] = 'FILLBLANKLIST'.$i;
                                    }

                                    $replace = array();
                                    $correntwords = explode(',', $qExtra->words);
                                    $ctrlist = 1;

                                    $option1 = $qExtra->option1;
                                    $option2 = $qExtra->option2;
                                    $option3 = $qExtra->option3;
                                    $option4 = $qExtra->option4;

                                    foreach ($correntwords as $word) {

                                        $options = 'option'.$ctrlist;

                                        $opts = explode(',', $$options);
                                        $getOpts = '';
                                        foreach ($opts as $chooseOption) {
                                          $getOpts .= '<option value="'.$chooseOption.'">'.$chooseOption.'</option>';
                                        }

                                        $list = '<select name="my-response" required>';
                                        $list .= '<option value=""></option>';
                                        $list .= $getOpts;
                                        $list .= '</select>';

                                      $replace[] = $list;
                                      $ctrlist++;
                                    }
                                    //echo '<pre>'; print_r($search); echo '</pre>';
                                    //echo '<pre>'; print_r($replace); echo '</pre>';

                                    $finalParagraph = str_replace($search, $replace, $finalText);
                                    echo nl2br($finalParagraph);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">

                                  <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } elseif($subtype->id == '40') { // Multiple-choice: Single ?>

                        <?php
                          ///// NEW foreach ($allQuestions as $objQuestion) {

                            ///// NEW $myTable = $this->tb_prefix.$subtype->tbname.$this->tb_suffix;
                            ///// NEW $qExtra = $this->my_model->checkARecord($myTable, 'questionid', $objQuestion->id);
                            /*
                              After 10 minutes, user response automatically submitted/saved 
                              and [PENDING] redirect to next question if any.
                            */
                          ///// NEW }
                        ?>

                            <input type="hidden" name="questionid" id="questionid" value="<?php echo $objQuestion->id; ?>">
                            <hr>
                            
                            <div class="row">
                              <div class="col-md-6">
                                <?php echo nl2br($qExtra->paragraph); ?>
                              </div>


                              <div class="col-md-6">

                                <div class="text-center" id="myloading">
                                  <i class="fa fa-spinner fa-spin"></i> Please wait ...
                                </div>

                                <div class="text-center" id="timeblock" style="display: none;">
                                  <span id="counter" style="background-color: red;padding: 10px;color: #fff;">00:00</span> seconds
                                </div>

                                <div id="contentblock" style="display: none;">
                                  <h3><?php echo $qExtra->optiontitle; ?></h3>

                                  <table class="table" style="font-size: 16px;">

                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="1">
                                        <?php echo $qExtra->option1; ?>
                                      </td>
                                    </tr>

                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="2">
                                        <?php echo $qExtra->option2; ?>
                                      </td>
                                    </tr>

                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="3">
                                        <?php echo $qExtra->option3; ?>
                                      </td>
                                    </tr>

                                    <tr>
                                      <td>
                                        <input type="radio" name="my-response" value="4">
                                        <?php echo $qExtra->option4; ?>
                                      </td>
                                    </tr>

                                    <tr>
                                      <td>
                                        <button class="btn btn-primary btn-block" id="submit-answer">Submit</button>
                                      </td>
                                    </tr>

                                  </table>
                                </div>

                                <div class="text-center" id="success-json" style="display: none;"></div>
                              </div>
                            </div>

                    <?php } ?>

                  <?php } ?>

                </div>
              <?php } ?>


          </div>

        </div>


            <div class="text-center"><?php echo $pagination; ?></div>

            <?php /*
            <a id="" data-skin="skin-blue" class="btn btn-default btn-md" href="<?php echo base_url($currentPath.'/startTest'); ?>" target="_blank"><i class="glyphicon glyphicon-backward " aria-hidden="true"></i> Previous Question</a>

            <a id="" class="btn btn-danger btn-md" href="">  Next Question <i class="glyphicon glyphicon-forward"></i></a>
            */ ?>

          </div>
        </div>
      </div>
    </section>

  </div>
  <footer class="main-footer">
    <?php include_once('common/footer.php'); ?>
  </footer>
  <input type="hidden" name="token-name" id="token-name" value="<?php echo $this->security->get_csrf_token_name(); ?>">
  <input type="hidden" name="token-hash" id="token-hash" value="<?php echo $this->security->get_csrf_hash(); ?>">
  <input type="hidden" name="mid" id="mid" value="<?php echo $user->id; ?>">
  <input type="hidden" name="testid" id="testid" value="<?php echo $test->id; ?>">
  <input type="hidden" name="typeid" id="typeid" value="<?php echo $type->id; ?>">
  <input type="hidden" name="subtypeid" id="subtypeid" value="<?php echo $subtype->id; ?>">
  <input type="hidden" name="reporturl" id="reporturl" value="<?php echo $reporturl; ?>">
  <input type="hidden" id="recn" value="<?php echo uniqid().'-'.md5($user->id) ?>">
  <input type="hidden" id="testdetail_id" value="<?php echo $testdetail->id; ?>">

  <?php include_once('common/scripts.php'); ?>
  <?php
      // Read Aloud || Repeat Sentence || Describe Image || Re-tell lecture || Answer short question
      if(!$attempted && in_array($subtype->id, array('41','42','43','44','45'))) { ?>
        <script src="../../uploads/mic/js/justmicrec_lib.js"></script>
        <script type="text/javascript">
          $(document).ready(function () {

              // INITIALIZATION
              //$('#recn').val(new Date().getTime()); // unique id

              justMicRec.configure({
                hostPath : '../../uploads/mic/micrecajax.php?f=' + $('#recn').val(),
                workerPath: '../../uploads/mic/js/justmicrecworker.js',

                // Callback functions
                recordingActivity: function(analyserNode, seconds) { activity(analyserNode, seconds); },
                recordingError: function(e) { console.log('[ERR] ' + e) },
                //recordingStopped: recordingStopped,
                WAVsendingFinished: sendingFinished,
                uploadingProcess: function(current, total){
                        uploading(Math.round(current / total * 100)); }
              });

              function sendingFinished()
              {
                console.log('!! Recording has been sent to server successfully!');
              
                // DONE :- save attempt row
                var token_name = $("#token-name").val(); // token protection
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();
                var fname = $("#recn").val()+'.wav';

                var testdetail_id = $("#testdetail_id").val();

                var dataString ='mid='+mid+'&fname='+fname+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;

                var weburl = '<?php echo site_url(); ?>';
                 $.ajax({
                  type: "POST",
                  url: weburl + "member/uploadattempt/",
                  data: dataString,
                  cache:false,
                  success: function(data) {
                    console.log(data);
                    if( data.result == "success") {
                      console.log('done ...');
                    }
                    $("#success-recording").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');
                  },
                  error : function(data) {
                    console.log(data);
                  }
                 });

                // change unique id and reconfigure path to new wav file
                //$('#recn').val(new Date().getTime());
                justMicRec.configure({
                  hostPath : '../../uploads/mic/micrecajax.php?f=' + $('#recn').val()
                });
              }

              var canvas = document.getElementById('levelbar'),
                  canvasWidth = canvas.width,
                  canvasHeight = canvas.height,
                  analyserContext = canvas.getContext('2d');


              // analyserNode - node to recording data, time - seconds
              function activity(analyserNode, time)
              {
                // maxTime - global var
                // var time = maxTime - time;
                if (time < 0) time = 0;
                var min = Math.floor(time / 60),
                    sec = Math.floor(time % 60);

                $('#time').text((min < 10 ? "0" : "") + min + ":" + (sec < 10 ? "0" : "") + sec);
                
                // $('#level').text(level);

                updateAnalysers(analyserNode);
                updateAnalysers2(analyserNode); // second variant
              }

              function uploading(percent)
              {
                $('#levelbar2').width(percent + '%');
              }

              function updateAnalysers(analyserNode) {
                var SPACING = 3,
                    BAR_WIDTH = 1,
                    numBars = Math.round(canvasWidth / SPACING),
                    freqByteData = new Uint8Array(analyserNode.frequencyBinCount);

                analyserNode.getByteFrequencyData(freqByteData); 

                analyserContext.clearRect(0, 0, canvasWidth, canvasHeight);
                analyserContext.fillStyle = '#F6D565';
                analyserContext.lineCap = 'round';
                var multiplier = analyserNode.frequencyBinCount / numBars;

                  // Draw rectangle for each frequency bin.
                  for (var i = 0; i < numBars; ++i) {
                  var magnitude = 0;
                  var offset = Math.floor( i * multiplier );
                  // gotta sum/average the block, or we miss narrow-bandwidth spikes
                  for (var j = 0; j < multiplier; j++)
                     magnitude += freqByteData[offset + j];
                  magnitude = magnitude / multiplier;
                  var magnitude2 = freqByteData[i * multiplier];
                  analyserContext.fillStyle = "hsl( " + Math.round((i*360)/numBars) + ", 100%, 50%)";
                  analyserContext.fillRect(i * SPACING, canvasHeight, BAR_WIDTH, -magnitude);
                  }
              }

              function updateAnalysers2(analyserNode) {
                // OLED 
                var array = new Uint8Array(analyserNode.frequencyBinCount);
                analyserNode.getByteFrequencyData(array);
                var values = 0;

                var length = array.length;
                for (var i = 0; i < length; i++) {
                  values += array[i];
                }

                var average = values / length;
                $('#levelbar2').width(Math.min(parseInt(average * 2), 100) + '%');
              } 
          });
        </script>
        <?php
      }
  ?>


  <script type="text/javascript">
    $(document).ready(function () {

      <?php if(!$attempted) { ?>

          <?php if($subtype->id == '41') { // Read Aloud ?>

            // Run code after 2 seconds, before this code is checking for audio support
            setTimeout(function() {

                  // Check if browser support audio
                  if($('#recordButton').hasClass('recordOn')) {

                    $("#recording-message").show(); // Show recording alert
                    mycounter('count', 40); // Handle counter
                    $("#recording-message").delay(40000).fadeOut(); // Hide message after 40s

                    // Show the player after 41s
                    // Start recording after 41s, for 40 seconds
                    $("#player-block").delay(41000).fadeIn();
                    setTimeout(function() {
                      
                      var maxTime = 40;
                      mycounter('countresult', maxTime); // Start Time
                      //startRecording();

                      console.log('*log: recording started (' + maxTime + ')');
                      justMicRec.start(maxTime);

                      setTimeout(function() {
                        // stop recording
                        // hide player block
                        // show success recording block
                        //stopRecording();
                        console.log('log: recording stopped');
                        $('#level').text('');
                        justMicRec.sendWAV();

                        $("#player-block").hide();
                        $("#success-recording").show();

                      }, 41000);

                    }, 41000);

                  } else {

                    // Show message to user , that your browser not support audio
                    $("#audio-block").delay(1000).fadeIn();
                  }

            }, 2000);
          <?php } ?>


          <?php if($subtype->id == '42') { // Repeat Sentence ?>

            // Run code after 5 seconds,
            // Before this code is checking for audio support and user will read a message
            setTimeout(function() {

              // Check if browser support audio
              if($('#recordButton').hasClass('recordOn')) {

                $('#myloading').hide(); // hide loading block
                startAudio();

              } else {

                // Show message to user , that your browser not support audio
                $("#audio-block").delay(1000).fadeIn();
              }

            }, 5000);

            function startAudio() {

              $('#mp3player').show(); 
              
              $(".my_audio").trigger('play'); // already loaded, just play audio
              console.log('start audio ...');

              $('.my_audio').on('ended', function() {

                  //console.log('Audio is completed');
                  $('#mp3player').hide(); // hide player block , once audio file is completed

                  $("#player-block").show();

                  var maxTime = 11; // always add 1 second extra, to store write length of audio
                  mycounter('countresult', maxTime); // Start Time
                  //startRecording();

                  console.log('log: recording started (' + maxTime + ')');
                  justMicRec.start(maxTime);

                  setTimeout(function() {
                    // stop recording
                    // hide player block
                    // show success recording block
                    //stopRecording();
                    console.log('log: recording stopped');
                    $('#level').text('');
                    justMicRec.sendWAV();

                    $("#player-block").hide();
                    $("#success-recording").show();

                  }, 12000); // always add 1 second in maxTime
              });
            }
          <?php } ?>


          <?php if($subtype->id == '43') { // Describe Image ?>

            // Run code after 2 seconds, before this code is checking for audio support
            setTimeout(function() {

                  // Check if browser support audio
                  if($('#recordButton').hasClass('recordOn')) {

                    $("#recording-message").show(); // Show recording alert
                    mycounter('count', 25); // Handle counter
                    $("#recording-message").delay(25000).fadeOut(); // Hide message after 25s

                    // Show the player after 26s
                    // Start recording after 26s, for 40 seconds
                    $("#player-block").delay(26000).fadeIn();
                    setTimeout(function() {

                      var maxTime = 40;
                      mycounter('countresult', maxTime); // Start Time
                      //startRecording();

                      console.log('*log: recording started (' + maxTime + ')');
                      justMicRec.start(maxTime);

                      setTimeout(function() {
                        // stop recording
                        // hide player block
                        // show success recording block
                        //stopRecording();
                        console.log('log: recording stopped');
                        $('#level').text('');
                        justMicRec.sendWAV();

                        $("#player-block").hide();
                        $("#success-recording").show();

                      }, 41000);

                    }, 26000);

                  } else {

                    // Show message to user , that your browser not support audio
                    $("#audio-block").delay(1000).fadeIn();
                  }

            }, 2000);
          <?php } ?>


          <?php if($subtype->id == '44') { // Re-tell lecture ?>

            // Run code after 2 seconds,
            // Before this code is checking for audio support
            setTimeout(function() {

              // Check if browser support audio
              if($('#recordButton').hasClass('recordOn')) {
                
                $('#myloading').show();

                // Run code after 10 seconds,
                // Before this code user will read a message
                setTimeout(function() {
                  $('#myloading').hide(); // hide loading block
                  startAudio();
                }, 10000);


              } else {

                // Show message to user , that your browser not support audio
                $("#audio-block").delay(1000).fadeIn();
              }

            }, 2000);

            function startAudio() {

              $('#mp3player').show(); 
              
              $(".my_audio").trigger('play'); // already loaded, just play audio
              console.log('start audio ...');

              $('.my_audio').on('ended', function() {

                  //console.log('Audio is completed');
                  $('#mp3player').hide(); // hide player block , once audio file is completed

                  $("#player-block").show();

                  var maxTime = 41; // always add 1 second extra, to store write length of audio
                  mycounter('countresult', maxTime); // Start Time
                  //startRecording();

                  console.log('log: recording started (' + maxTime + ')');
                  justMicRec.start(maxTime);

                  setTimeout(function() {
                    // stop recording
                    // hide player block
                    // show success recording block
                    //stopRecording();
                    console.log('log: recording stopped');
                    $('#level').text('');
                    justMicRec.sendWAV();

                    $("#player-block").hide();
                    $("#success-recording").show();

                  }, 42000); // always add 1 second in maxTime
              });
            }
          <?php } ?>


          <?php if($subtype->id == '45') { // Answer short question ?>

            // Run code after 5 seconds,
            // Before this code is checking for audio support and user will read a message
            setTimeout(function() {

              // Check if browser support audio
              if($('#recordButton').hasClass('recordOn')) {
                
                $('#myloading').hide(); // hide loading block
                startAudio();

              } else {

                // Show message to user , that your browser not support audio
                $("#audio-block").delay(1000).fadeIn();
              }

            }, 5000);

            function startAudio() {

              $('#mp3player').show(); 
              
              $(".my_audio").trigger('play'); // already loaded, just play audio
              console.log('start audio ...');

              $('.my_audio').on('ended', function() {

                  //console.log('Audio is completed');
                  $('#mp3player').hide(); // hide player block , once audio file is completed

                  $("#player-block").show();

                  var maxTime = 16; // always add 1 second extra, to store write length of audio
                  mycounter('countresult', maxTime); // Start Time
                  //startRecording();

                  console.log('log: recording started (' + maxTime + ')');
                  justMicRec.start(maxTime);

                  setTimeout(function() {
                    // stop recording
                    // hide player block
                    // show success recording block
                    //stopRecording();
                    console.log('log: recording stopped');
                    $('#level').text('');
                    justMicRec.sendWAV();

                    $("#player-block").hide();
                    $("#success-recording").show();

                  }, 17000); // always add 1 second in maxTime
              });
            }
          <?php } ?>


          <?php if($subtype->id == '46') { // Summarize written text ?>

            // Run code after 10 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#responseblock").delay(1000).fadeIn();
              mycounter('counter', 1200); // Start Time , 1200 seconds = 20 minutes

              $('#submit-answer').prop('disabled', true);

              // submit, only if user enter 150 words
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                var myresponse = $("#my-response").val();

                var testdetail_id = $("#testdetail_id").val();

                var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;
                
                var weburl = '<?php echo site_url(); ?>';

                 $.ajax({
                  type: "POST",
                  url: weburl + "member/uploadjson/",
                  /*data: {
                    audiosrc: audiosrc,
                    mid: mid,
                    testid: testid,
                    questionid: questionid,
                    subtypeid: subtypeid
                  },
                  dataType:"json",*/
                  data: dataString,
                  cache:false,
                  success: function(data) {
                    console.log(data);
                    if( data.result == "success") {
                      console.log('done ...');
                    }

                    $('#myloading').hide();
                    $('#timeblock').hide();
                    $('#responseblock').hide();

                    console.log('Your Response is saved.');
                    $('#success-json').show();
                    $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');


                  },
                  error : function(data) {
                    console.log(data);
                    $('#submit-answer').prop('disabled', false);
                    $(this).html('Submit');
                  }
                 });



              });
            }, 10000);

            var wordCounts = {};
            $("#my-response").keyup(function() {
                var matches = this.value.match(/\b/g);
                wordCounts[this.id] = matches ? matches.length / 2 : 0;
                var finalCount = 0;
                $.each(wordCounts, function(k, v) {
                    finalCount += v;
                });
                var totalWord = parseInt(finalCount);
                if( totalWord > 149) {
                  $('#submit-answer').prop('disabled', false);
                } else {
                  $('#submit-answer').prop('disabled', true);
                }
                $('#display_count').html(finalCount);
            }).keyup();
          <?php } ?>


          <?php if($subtype->id == '47') { // Write Essay ?>

            // Run code after 10 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#responseblock").delay(1000).fadeIn();
              mycounter('counter', 1200); // Start Time , 1200 seconds = 20 minutes

              $('#submit-answer').prop('disabled', true);

              // submit, only if user enter 50 words
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                var myresponse = $("#my-response").val();

                var testdetail_id = $("#testdetail_id").val();

                var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;
                
                var weburl = '<?php echo site_url(); ?>';

                $.ajax({
                  type: "POST",
                  url: weburl + "member/uploadjson/",
                  /*data: {
                    audiosrc: audiosrc,
                    mid: mid,
                    testid: testid,
                    questionid: questionid,
                    subtypeid: subtypeid
                  },
                  dataType:"json",*/
                  data: dataString,
                  cache:false,
                  success: function(data) {
                    console.log(data);
                    if( data.result == "success") {
                      console.log('done ...');
                    }

                    $('#myloading').hide();
                    $('#timeblock').hide();
                    $('#responseblock').hide();

                    console.log('Your Response is saved.');
                    $('#success-json').show();
                    $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');


                  },
                  error : function(data) {
                    console.log(data);
                    $('#submit-answer').prop('disabled', false);
                    $(this).html('Submit');
                  }
                 });



              });
            }, 10000);

            var wordCounts = {};
            $("#my-response").keyup(function() {
                var matches = this.value.match(/\b/g);
                wordCounts[this.id] = matches ? matches.length / 2 : 0;
                var finalCount = 0;
                $.each(wordCounts, function(k, v) {
                    finalCount += v;
                });
                var totalWord = parseInt(finalCount);
                if( totalWord > 49) {
                  $('#submit-answer').prop('disabled', false);
                } else {
                  $('#submit-answer').prop('disabled', true);
                }

                $('#display_count').html(finalCount);
            }).keyup();
          <?php } ?>


          <?php if($subtype->id == '28') { // Summarize spoken text ?>

            // Run code after 10 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#responseblock").delay(1000).fadeIn();
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes

              $(".my_audio").trigger('play'); // already loaded, just play audio

              $('#submit-answer').prop('disabled', true);

              // submit, only if user enter 50 words
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                var myresponse = $("#my-response").val();
                var testdetail_id = $("#testdetail_id").val();

                var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;
                
                var weburl = '<?php echo site_url(); ?>';

                 $.ajax({
                  type: "POST",
                  url: weburl + "member/uploadjson/",
                  /*data: {
                    audiosrc: audiosrc,
                    mid: mid,
                    testid: testid,
                    questionid: questionid,
                    subtypeid: subtypeid
                  },
                  dataType:"json",*/
                  data: dataString,
                  cache:false,
                  success: function(data) {
                    console.log(data);
                    if( data.result == "success") {
                      console.log('done ...');
                    }

                    $('#myloading').hide();
                    $('#timeblock').hide();
                    $('#responseblock').hide();

                    console.log('Your Response is saved.');
                    $('#success-json').show();
                    $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');


                  },
                  error : function(data) {
                    console.log(data);
                    $('#submit-answer').prop('disabled', false);
                    $(this).html('Submit');
                  }
                 });



              });
            }, 10000);

            var wordCounts = {};
            $("#my-response").keyup(function() {
                var matches = this.value.match(/\b/g);
                wordCounts[this.id] = matches ? matches.length / 2 : 0;
                var finalCount = 0;
                $.each(wordCounts, function(k, v) {
                    finalCount += v;
                });
                var totalWord = parseInt(finalCount);
                if( totalWord > 50) {
                  $('#submit-answer').prop('disabled', false);
                } else {
                  $('#submit-answer').prop('disabled', true);
                }
                $('#display_count').html(finalCount);
            }).keyup();
          <?php } ?>


          <?php if($subtype->id == '29') { // Multiple-choice: Single ?>

            // Run code after 10 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              $(".my_audio").trigger('play'); // already loaded, just play audio

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                var myresponse = $("input[name='my-response']:checked").val();
                var testdetail_id = $("#testdetail_id").val();

                // console.log(myresponse);

                if(myresponse) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;

                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 10000);
          <?php } ?>


          <?php if($subtype->id == '20') { ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              $(".my_audio").trigger('play'); // already loaded, just play audio

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();
                var myresponse = $("input[name='my-response']:checked").val();

                // console.log(myresponse);

                if(myresponse) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '19') { ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              $(".my_audio").trigger('play'); // already loaded, just play audio

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();
                var myresponse = $("input[name='my-response']:checked").val();

                // console.log(myresponse);

                if(myresponse) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '18') { ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              $(".my_audio").trigger('play'); // already loaded, just play audio

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();
                var myresponse = $("input[name='my-response']:checked").val();

                // console.log(myresponse);

                if(myresponse) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '17') { ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {

              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes (60 x 10)

              $(".my_audio").trigger('play'); // already loaded, just play audio
              
              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 600000); // 600 seconds (600 x 1000)
              

              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                //var myresponse = $("input[name='my-response']:checked").val();
                var counterSelected = 0;
                var totalBlanks = $('#totalBlanks').val();

                var responseArr = [];
                $.each($("select[name='my-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
                var myresponse = responseArr.join(",");
                console.log(myresponse);

                if(myresponse && counterSelected == totalBlanks) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '16') { ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {

              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes (60 x 10)

              $(".my_audio").trigger('play'); // already loaded, just play audio
              
              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 600000); // 600 seconds (600 x 1000)
              

              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                //var myresponse = $("input[name='my-response']:checked").val();
                var counterSelected = 0;
                var totalBlanks = $('#totalBlanks').val();

                var responseArr = [];
                $.each($("select[name='my-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
                var myresponse = responseArr.join(",");
                console.log(myresponse);

                if(myresponse && counterSelected == totalBlanks) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '15') { ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {

              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes (60 x 10)

              $(".my_audio").trigger('play'); // already loaded, just play audio
              
              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 600000); // 600 seconds (600 x 1000)
              

              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                //var myresponse = $("input[name='my-response']:checked").val();
                var counterSelected = 0;
                var totalBlanks = $('#totalBlanks').val();

                var responseArr = [];
                $.each($("select[name='my-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
                var myresponse = responseArr.join(",");
                console.log(myresponse);

                if(myresponse && counterSelected == totalBlanks) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>







          <?php if($subtype->id == '30') { // Multiple-choice: Multiple ?>

            // Run code after 10 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              $(".my_audio").trigger('play'); // already loaded, just play audio

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response
                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();
                var testdetail_id = $("#testdetail_id").val();

                //var myresponse = $("input[name='my-response']:checked").val();

                var responseArr = [];
                $.each($("input[name='my-response']:checked"), function(){            
                  responseArr.push($(this).val());
                });
                var myresponse = responseArr.join(",");


                console.log(myresponse);

                if(myresponse) {

                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 10000);
          <?php } ?>


          <?php if($subtype->id == '31') { // Fill in the blanks ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              $(".my_audio").trigger('play'); // already loaded, just play audio

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();
                var testdetail_id = $("#testdetail_id").val();

                //var myresponse = $("input[name='my-response']:checked").val();
                var counterSelected = 0;
                var totalBlanks = $('#totalBlanks').val();

                var responseArr = [];
                $.each($("input[name='my-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
                var myresponse = responseArr.join(",");
                //console.log(myresponse);

                if(myresponse && counterSelected == totalBlanks) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '32') { // Highlight correct summary ?>

            // Run code after 10 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              $(".my_audio").trigger('play'); // already loaded, just play audio

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                var myresponse = $("input[name='my-response']:checked").val();
                var testdetail_id = $("#testdetail_id").val();

                // console.log(myresponse);

                if(myresponse) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 10000);
          <?php } ?>


          <?php if($subtype->id == '33') { // Select missing word ?>

            // Run code after 10 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              $(".my_audio").trigger('play'); // already loaded, just play audio

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                var myresponse = $("input[name='my-response']:checked").val();
                var testdetail_id = $("#testdetail_id").val();

                // console.log(myresponse);

                if(myresponse) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  <?php echo site_url(); ?>

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 10000);
          <?php } ?>


          <?php if($subtype->id == '34') { // Highlight incorrect words ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#responseblock").delay(1000).fadeIn();
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes

              $(".my_audio").trigger('play'); // already loaded, just play audio

              $('#submit-answer').prop('disabled', true);

              var responseArr = [];
              $('.chooseMe').click(function() {
                $('#submit-answer').prop('disabled', false);
                var txt = $(this).html();
                var statustxt = $(this).attr('data-status');

                if(statustxt == 'true') {
                  console.log('already selected.');
                } else {
                  $(this).attr('data-status','true');
                  $(this).css('background-color','green');
                  $(this).css('color','white');
                  $(this).css('padding','2px');
                  $(this).addClass( "chooseMe mySelected" );
                  //console.log(txt);
                  responseArr.push(txt);              
                }
              });

              // submit
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();
                var testdetail_id = $("#testdetail_id").val();

                //var myresponse = $("#my-response").val();
                
                //var myresponse = responseArr.join(",");

                var myresponse = $('#mywordSelected').html();

                var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;
                
                var weburl = '<?php echo site_url(); ?>';

                 $.ajax({
                  type: "POST",
                  url: weburl + "member/uploadjson/",
                  /*data: {
                    audiosrc: audiosrc,
                    mid: mid,
                    testid: testid,
                    questionid: questionid,
                    subtypeid: subtypeid
                  },
                  dataType:"json",*/
                  data: dataString,
                  cache:false,
                  success: function(data) {
                    //console.log(data);
                    if( data.result == "success") {
                      console.log('done ...');
                    }

                    $('#myloading').hide();
                    $('#timeblock').hide();
                    $('#responseblock').hide();

                    console.log('Your Response is saved.');
                    $('#success-json').show();
                    $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');


                  },
                  error : function(data) {
                    console.log(data);
                    $('#submit-answer').prop('disabled', false);
                    $(this).html('Submit');
                  }
                 });



              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '35') { // Summarize spoken text ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#responseblock").delay(1000).fadeIn();
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes

              $(".my_audio").trigger('play'); // already loaded, just play audio

              $('#submit-answer').prop('disabled', true);

              // submit, only if user enter 3 words
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                var myresponse = $("#my-response").val();
                var testdetail_id = $("#testdetail_id").val();

                var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&testdetail_id='+testdetail_id+'&akaal_token='+token_hash;
                
                var weburl = '<?php echo site_url(); ?>';

                 $.ajax({
                  type: "POST",
                  url: weburl + "member/uploadjson/",
                  /*data: {
                    audiosrc: audiosrc,
                    mid: mid,
                    testid: testid,
                    questionid: questionid,
                    subtypeid: subtypeid
                  },
                  dataType:"json",*/
                  data: dataString,
                  cache:false,
                  success: function(data) {
                    console.log(data);
                    if( data.result == "success") {
                      console.log('done ...');
                    }

                    $('#myloading').hide();
                    $('#timeblock').hide();
                    $('#responseblock').hide();

                    console.log('Your Response is saved.');
                    $('#success-json').show();
                    $("#success-json").html('Your Response is saved. <a href="'+reporturl+'">View Report</a>');


                  },
                  error : function(data) {
                    console.log(data);
                    $('#submit-answer').prop('disabled', false);
                    $(this).html('Submit');
                  }
                 });



              });
            }, 5000);

            var wordCounts = {};
            $("#my-response").keyup(function() {
                var matches = this.value.match(/\b/g);
                wordCounts[this.id] = matches ? matches.length / 2 : 0;
                var finalCount = 0;
                $.each(wordCounts, function(k, v) {
                    finalCount += v;
                });
                var totalWord = parseInt(finalCount);
                if( totalWord > 3) {
                  $('#submit-answer').prop('disabled', false);
                } else {
                  $('#submit-answer').prop('disabled', true);
                }
                $('#display_count').html(finalCount);
            }).keyup();
          <?php } ?>




          <?php if($subtype->id == '36') { // Multiple Fill in the blanks ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();

              
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes (60 x 10)

              
              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 600000); // 600 seconds (600 x 1000)
              


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                //var myresponse = $("input[name='my-response']:checked").val();
                var counterSelected = 0;
                var totalBlanks = $('#totalBlanks').val();

                var responseArr = [];
                $.each($("select[name='my-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
                var myresponse = responseArr.join(",");
                console.log(myresponse);

                if(myresponse && counterSelected == totalBlanks) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '37') { // Fill in the blanks ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes (60 x 10)

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 600000); // 600 seconds (600 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                //var myresponse = $("input[name='my-response']:checked").val();
                var counterSelected = 0;
                var totalBlanks = $('#totalBlanks').val();

                var responseArr = [];
                $.each($("select[name='my-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
                var myresponse = responseArr.join(",");
                console.log(myresponse);

                if(myresponse && counterSelected == totalBlanks) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '38') { ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();

              
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes (60 x 10)

              
              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 600000); // 600000 seconds (600 x 1000)
              


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                //var myresponse = $("input[name='my-response']:checked").val();
                var counterSelected = 0;
                var totalBlanks = $('#totalBlanks').val();

                var responseArr = [];
                $.each($("select[name='my-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
                var myresponse = responseArr.join(",");
                console.log(myresponse);

                if(myresponse && counterSelected == totalBlanks) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '39') { ?>

            // Run code after 5 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();

              
              mycounter('counter', 600); // Start Time , 600 seconds = 10 minutes (60 x 10)

              
              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 600000); // 600000 seconds (600 x 1000)
              


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                //var myresponse = $("input[name='my-response']:checked").val();
                var counterSelected = 0;
                var totalBlanks = $('#totalBlanks').val();

                var responseArr = [];
                $.each($("select[name='my-response']"), function(){
                  if($(this).val()){
                    responseArr.push($(this).val());
                    counterSelected++;
                  }
                });
                var myresponse = responseArr.join(",");
                console.log(myresponse);

                if(myresponse && counterSelected == totalBlanks) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 5000);
          <?php } ?>


          <?php if($subtype->id == '40') { // Multiple-choice: Single ?>

            // Run code after 10 seconds,
            // Before this code user will read a message
            setTimeout(function() {
              
              $('#myloading').hide();
              $("#timeblock").delay(1000).fadeIn();
              $("#contentblock").delay(1000).fadeIn();
              mycounter('counter', 120); // Start Time , 120 seconds = 2 minutes (60 x 2)

              setTimeout(function() {
                $('#timeblock').hide();
                $('#submit-answer').hide();
                $('#submit-answer').prop('disabled', true);
                alert('Time is over, Please reload page to submit your response.');
                //window.location.reload(true);
              }, 120000); // 120 seconds (120 x 1000)


              // submit,
              $('#submit-answer').click(function() {
                console.log('submitted');

                $('#submit-answer').prop('disabled', true);
                $(this).html('Please wait ...');

                // upload user response

                // token protection
                var token_name = $("#token-name").val();
                var token_hash = $("#token-hash").val();
                var mid = $("#mid").val();
                var testid = $("#testid").val();
                var questionid = $("#questionid").val();
                var subtypeid = $("#subtypeid").val();
                var reporturl = $("#reporturl").val();

                var myresponse = $("input[name='my-response']:checked").val();


                console.log(myresponse);

                if(myresponse) {
                  var dataString ='myresponse='+myresponse+'&mid='+mid+'&testid='+testid+'&questionid='+questionid+'&subtypeid='+subtypeid+'&akaal_token='+token_hash;
                  
                  var weburl = '<?php echo site_url(); ?>';

                  $.ajax({
                    type: "POST",
                    url: weburl + "member/uploadjson/",
                    data: dataString,
                    cache:false,
                    success: function(data) {
                      console.log(data);
                      if( data.result == "success") {
                        console.log('done ...');
                      }

                      $('#myloading').hide();
                      $('#timeblock').hide();
                      $('#contentblock').hide();

                      console.log('Your Response is saved.');
                      $('#success-json').show();
                      $("#success-json").html('Your Response is saved. <a target="_blank" href="'+reporturl+'">View Report</a>');

                    },
                    error : function(data) {
                      console.log(data);
                      $('#submit-answer').prop('disabled', false);
                      $(this).html('Submit');
                    }
                  });
                } else {
                  $('#submit-answer').prop('disabled', false);
                  $(this).html('Submit');
                }

              });
            }, 10000);
          <?php } ?>




      <?php } ?>


      <?php if(!$attempted && in_array($subtype->id, array('41','42','43','44','45'))) { ?>
        /*
        * Method to check audio support
        *
        */
        var audio_data;
        window.onload = function init() {
          try  {
            // Webkit shim
            window.AudioContext = window.AudioContext || window.webkitAudioContext;
            navigator.getUserMedia = ( navigator.getUserMedia ||
                             navigator.webkitGetUserMedia ||
                             navigator.mozGetUserMedia ||
                             navigator.msGetUserMedia);
            window.URL = window.URL || window.webkitURL;
            
            audio_data = new AudioContext;
            console.log('Audio context set up.');
            console.log('navigator.getUserMedia ' + (navigator.getUserMedia ? 'available.' : 'not present!'));
          
          } catch (e) {
            //alert('No web audio support in this browser!');
          }
          
          navigator.getUserMedia({audio: true}, initUserMedia, function(e) {
            console.log('No live audio input: ' + e);
            //alert('Your browser does not support the audio.');
          });
        };

        function initUserMedia(stream) {
          var input = audio_data.createMediaStreamSource(stream);
          //console.log('Media stream created.' );
          //console.log("input sample rate " +input.context.sampleRate);

          input.connect(audio_data.destination);
          console.log('Input connected to audio context destination.');

          $("#recordButton").removeClass("recordOff").addClass("recordOn");
          $("#recordHelp").fadeOut("slow");
          console.log('Recorder initialised.');
        }
      <?php } ?>


      /*
      * Method to handle counter
      *
      * elementId {string} - id of counter element
      * seconds {integer} - maximum seconds of counter
      */
      function mycounter(elementId, seconds) {

        var counter = seconds;
        setInterval(function() {
          counter--;
          if (counter >= 0) {
            span = document.getElementById(elementId);
            span.innerHTML = counter;
          } else {
            document.getElementById(elementId).style.display = "none";
          }
          // Display 'counter' wherever you want to display it.
          if (counter === 0) {
              clearInterval(counter);
          }
        }, 1000);
      }
    });
  </script>
</body>
</html>
