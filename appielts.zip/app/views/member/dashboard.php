<!DOCTYPE html>
<html>
<head>
    <title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>
<style>
    img, .school-banner {
    max-width: 100%;
    height: 90px;
}
</style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

 
    <?php include_once('common/nav.php'); ?>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">


    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard 
        <small>
    Welcome ! We are super excited to have you onboard.</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
           <h3 style="margin-left: 15px;"><b>Competitive English Section</b></h3>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="info-box">
		  <?php if(!empty($school_banner)){?>
			<a rel="nofollow" href="<?php echo $school_banner_link; ?>"><img class="school-banner" src="<?php echo base_url(); ?>uploads/reseller_banner/<?php echo $school_banner; ?>" width="100%" height="150"></a>
		  <?php }else{ ?>
			<a rel="nofollow" href="<?php echo $first_banner_link->meta_value; ?>" target="_blank"><img src="<?php echo base_url(); ?>uploads/admin_banner/<?php echo $first_banner->meta_value; ?>" width="100%" height="150"></a>
		  <?php } ?>
		  
          <!-- <img src="#" width="250" height="90"> -->
            <!-- <span class="info-box-icon bg-aqua"><i class="fa fa-object-group"></i></span> -->

            <!-- <div class="info-box-content">
              <span class="info-box-text">Total Attempted <br>Tests</span>
              <span class="info-box-number">5<small></small></span>
            </div> -->
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
			
			  <a href="<?php echo base_url($currentPath.'/vocabulary'); ?>">
			  <div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-file-text-o"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Vocabulary <br>Tests </span>
				 <!--  <span class="info-box-number">Total tests # <small></small></span> -->
				</div>
				<!-- /.info-box-content -->
			  </div>
			  </a>
			</div>
		    <!--<div class="col-md-3 col-sm-6 col-xs-12">
			  <div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-life-ring"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Support</span>
				</div>
			  </div>
			</div>-->
			<div class="col-md-3 col-sm-6 col-xs-12">
			  <a href="<?php echo base_url($currentPath.'/spottingErrors'); ?>">
			  <div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-exclamation"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Spotting Error <br>Tests </span>
				 <!--  <span class="info-box-number">Total Tests #<small></small></span> -->
				</div>
				<!-- /.info-box-content -->
			  </div>
			  </a>
			</div>
			<!--<div class="col-md-3 col-sm-6 col-xs-12">
			
			  <div class="info-box">
				<span class="info-box-icon bg-red"><i class="fa fa-cog"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Setting</span>
				</div>
			  </div>
			</div>-->
      </div>
	  
	  <div class="row">
		 
			<!--<div class="col-md-3 col-sm-6 col-xs-12">
			
			  <a href="<?php echo base_url($currentPath.'/vocabulary'); ?>">
			  <div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-file-text-o"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Vocabulary Tests </span>-->
				 <!--  <span class="info-box-number">Total tests # <small></small></span> -->
				<!--</div>-->
				<!-- /.info-box-content -->
			  <!--</div>
			  </a>
			</div>-->
			<!--<div class="col-md-3 col-sm-6 col-xs-12">
			  <div class="info-box">
				<span class="info-box-icon bg-red"><i class="fa fa-exclamation"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Spotting Error <br>Tests </span>-->
				 <!--  <span class="info-box-number">Total Tests #<small></small></span> -->
				<!--</div>-->
				<!-- /.info-box-content -->
			  <!--</div>
			</div>-->
			<div class="col-md-3 col-sm-6 col-xs-12">
			<a href="<?php echo base_url($currentPath.'/dictation'); ?>">
			  <div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-level-up"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Dictation Level <br>Tests </span>
				  <!-- <span class="info-box-number">Total tests #<small></small></span> -->
				</div>
				<!-- /.info-box-content -->
			  </div>
			</a>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12">
			    	<a href="<?php echo base_url($currentPath.'/comprehensionTest'); ?>">
			  <div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-file-text-o"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Comprehension <br> Passage </span>
				  <!-- <span class="info-box-number">Total Tests #<small></small></span> -->
				</div>
				<!-- /.info-box-content -->
			  </div>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12">
			<a href="<?php echo base_url($currentPath.'/reArrangeTestdetails'); ?>">
			  <div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-retweet"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Re Arrange Tests </span>
				 <!--  <span class="info-box-number">Total tests # <small></small></span> -->
				</div>
				<!-- /.info-box-content -->
			  </div>
			</a>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12">
			<a href="<?php echo base_url($currentPath.'/fillblanks'); ?>">
			  <div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-bars"></i></span>

				<div class="info-box-content">
				  <span class="info-box-text">Fill in the <br> blanks Test</span>
				 <!--  <span class="info-box-number">Total tests # <small></small></span> -->
				</div>
				<!-- /.info-box-content -->
			  </div>
			</a>
			</div>
			
			<!--<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="info-box">
					<img src="<?php echo base_url(); ?>uploads/admin_banner/<?php echo $second_banner->meta_value; ?>" width="450" height="150"> -->
					<!-- /.info-box-content -->
				<!--</div>-->
			<!-- /.info-box -->
			<!--</div>-->
        </div>
      
      <div class="row">
      <h3 style="margin-left: 15px;"><b>IELTS Test Parts</b></h3>
        <div class="col-md-3 col-sm-6 col-xs-12">
        
          <div class="info-box">
			<a href="<?php echo base_url($currentPath."/sampleQuestion/1"); ?>">
            <span class="info-box-icon bg-aqua"><i class="fa fa-headphones"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Listening</span>
            </div>
			</a>
            <!-- /.info-box-content -->
         </div>
        </div>
       <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
			<a href="<?php echo base_url($currentPath."/sampleQuestion/2"); ?>">
            <span class="info-box-icon bg-aqua"><i class="fa fa-book"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">ACADEMIC READING</span>
            </div>
            <!-- /.info-box-content -->
			</a>
          </div>
        </div>
         <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
			<a href="<?php echo base_url($currentPath."/sampleQuestion/3"); ?>">
            <span class="info-box-icon bg-aqua"><i class="fa fa-book"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">GENERAL READING</span>
            </div>
            <!-- /.info-box-content -->
			</a>
          </div>
        </div>
          <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
			<a href="<?php echo base_url($currentPath."/sampleQuestion/4"); ?>">
            <span class="info-box-icon bg-aqua"><i class="fa fa-pencil-square-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">ACADEMIC WRITING</span>
            </div>
            <!-- /.info-box-content -->
			</a>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
		    <a href="<?php echo base_url($currentPath."/sampleQuestion/5"); ?>">
            <span class="info-box-icon bg-aqua"><i class="fa fa-pencil-square-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">GENERAL WRITING</span>
            </div>
            <!-- /.info-box-content -->
			</a>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
			<a href="<?php echo base_url($currentPath."/sampleQuestion/6"); ?>">
            <span class="info-box-icon bg-aqua"><i class="fa fa-volume-up"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">SPEAKING</span>
               </div>
           <!-- /.info-box-content -->
			</a>
          </div>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="info-box">
		  <?php if(!empty($school_banner)){?>
			<a rel="nofollow" href="<?php echo $school_banner_link; ?>" target="_blank"><img class="school-banner" src="<?php echo base_url(); ?>uploads/reseller_banner/<?php echo $school_banner; ?>" width="100%" height="150"></a>
		  <?php }else{ ?>
			<a rel="nofollow" href="<?php echo $second_banner_link->meta_value; ?>" target="_blank"><img src="<?php echo base_url(); ?>uploads/admin_banner/<?php echo $second_banner->meta_value; ?>" width="100%" height="150"></a>
		  <?php } ?>
      </div>

<!--<div class="row">
        <div class="col-md-12">
          

          
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Recent Taken Tests</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                    <tr>
                      <th>Test</th>
                      <th>Taken Date</th>
                      <th>Status</th>
                      <th >Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><a>OR9842</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt Again</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>OR1848</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt Again</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>OR7429</a></td>
                      <td>26-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt Again</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>OR7429</a></td>
                      <td>20-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt Again</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>Score Guide</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt Again</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>PTE Overview, Score Guide</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt Again</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>OR9842</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-success">Processing</span></td>
                      
                      <td><span class="label label-success">Attempt Again</span></td>
                      
                    </tr>
                  </tbody>
                </table>
              </div>
              
            </div>
            
            <div class="box-footer clearfix">
              <a href="javascript:void(0)" class="btn btn-sm btn-info btn-flat pull-left">Buy Coins</a>
              <a href="javascript:void(0)" class="btn btn-sm btn-default btn-flat pull-right">View All Taken Tests</a>
            </div>
            
          </div>
          
        </div>
      </div>-->

      <!--<div class="row">
      <h3 style="margin-left: 15px;">Celpip Section Tests</h3>
        <div class="col-md-3 col-sm-6 col-xs-12">
        
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-headphones"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Listening Section</span>
              <span class="info-box-number">Total tests # <small></small></span>
            </div>
            
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-book"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Reading Section</span>
              <span class="info-box-number">Total Tests #<small></small></span>
            </div>
           
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-volume-up"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Speaking Sections</span>
              <span class="info-box-number">Total tests #<small></small></span>
            </div>
           
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-pencil-square-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Writing Section</span>
              <span class="info-box-number">Total Tests #<small></small></span>
            </div>
            
          </div>
        </div>
      </div>-->

      <!--<div class="row">
      <h3 style="margin-left: 15px;">Complete Celpip Tests</h3>
        <div class="col-md-3 col-sm-6 col-xs-12">
        
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-check-square-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Attempted <br>Tests #</span>
             <span class="info-box-number">Total tests # <small></small></span>
            </div>
            
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-check-square-o"></i></span>

            <div class="info-box-content">
             <span class="info-box-text">Total Completed <br>Tests #</span>
             <span class="info-box-number">Total Tests #<small></small></span>
            </div>
            
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-check-square-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Order Coins</span>
               <span class="info-box-number">Total tests #<small></small></span> 
            </div>
            
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-check-square-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Discount Coupons</span>
              <span class="info-box-number">Total Tests #<small></small></span> 
            </div>
            
          </div>
        </div>
      </div>-->
<!--<hr>-->
      <!--<div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-object-group"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Attempted <br>Tests</span>
              <span class="info-box-number">5<small></small></span>
            </div>
            
          </div>
         
        </div>
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-file-text-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Completed<br> Test</span>
              <span class="info-box-number">54</span>
            </div>
            
          </div>
          
        </div>
       



        
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-purple"><i class="fa fa-language"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Allowed Practice<br> Tests</span>
              <span class="info-box-number">760</span>
            </div>
            
          </div>
          
        </div>
        
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-light-blue"><i class="fa fa-gift"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Special Discount<br> Offer</span>
              <span class="info-box-number"><span class="label label-danger">$50 off</span></span>
            </div>
            
          </div>
          
        </div>
        
      </div>-->
      <!-- /.row -->


   

  
     

      <?php /*<div class="row">
        <div class="col-md-12">
          

          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Recent Taken Tests</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                    <tr>
                      <th>Test</th>
                      <th>Taken Date</th>
                      <th>Status</th>
                      <th >Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><a>OR9842</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>OR1848</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>OR7429</a></td>
                      <td>26-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>OR7429</a></td>
                      <td>20-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>Score Guide</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>PTE Overview, Score Guide</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-danger">Evaluated</span></td>
                      
                      <td><span class="label label-success">Attempt</span></td>
                      
                    </tr>
                    <tr>
                      <td><a>OR9842</a></td>
                      <td>22-08-2018</td>
                      <td><span class="label label-success">Processing</span></td>
                      
                      <td><span class="label label-success">Attempt</span></td>
                      
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <a href="javascript:void(0)" class="btn btn-sm btn-info btn-flat pull-left">Buy New Test</a>
              <a href="javascript:void(0)" class="btn btn-sm btn-default btn-flat pull-right">View All Taken Tests</a>
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
      </div>*/ ?>


    </section>
  </div>

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

   <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>



</div>
<!-- ./wrapper -->

  <?php include_once('common/scripts.php'); ?>
</body>
</html>
