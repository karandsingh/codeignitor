<div id="v-instructions" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="box box-solid">
          <div class="box-body">
            <h3 class="text-center"><u>Instructions - Vocabulary Test</u></h3>
      			<?php if($this->session->flashdata('global_msg')){ ?>
      				 <div class="alert alert-success">
      				  <button class="close" type="button" data-dismiss="alert">
      					<span aria-hidden="true">&times;</span>
      				  </button>
      				  <?=$this->session->flashdata('global_msg')?>
      				</div>
      			<?php } ?>
			    <div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
            <div class="alert alert-warning alert-dismissible" >
              <i class="glyphicon glyphicon-warning-sign"></i>
              Please Read all instructions carefully before you begin . 
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <ul>
              <li>Every instruction pertaining to set of questions must be read carefully and answer as expected.</li>
              <li>Vocabulary Test contains only MCQs.</li>
              <li>Each question of Vocabulary Test is of 60 seconds duration, so target your answers under the given time.</li>
              <li>You can see questions one by one.</li>
            </ul>
          </div>
        </div>
        <div class="text-center">
          <button type="button" class="btn btn-primary" id="v-test-submit" data-testid="<?php echo $test->id; ?>" data-memberid="<?php echo $user->id; ?>">Start Test Now</button>
        </div>
      </div>
    </div>
  </div>
</div>




<!-- Quit Modal -->
<div id="v-quit-popup" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="box box-solid">
          <div class="box-body">
            <h3 class="text-center"><u>Instructions</u></h3>
			    <div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
           
            <p>Even if you don't complete the section, your coins will be deducted, are you sure you want to exit?</p>
          </div>
        </div>
        <div class="text-center">
          <a href="<?php echo $site_url; ?>/vtestdetails/<?php echo $test->id; ?>/<?php echo md5($test->id); ?>"><button type="button" class="btn btn-primary">Yes, I want to exit</button></a>
          <button type="button" class="btn btn-primary" data-dismiss="modal">No, I will continue</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Quit Modal -->

<!-- Spotting Error Modal -->
<div id="spottingError-quit-popup" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="box box-solid">
          <div class="box-body">
            <h3 class="text-center"><u>Instructions</u></h3>
			    <div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
           
            <p>Even if you don't complete the section, your coins will be deducted, are you sure you want to exit?</p>
          </div>
        </div>
        <div class="text-center">
          <a href="<?php echo $site_url; ?>/spottingErrors"><button type="button" class="btn btn-primary">Yes, I want to exit</button></a>
          <button type="button" class="btn btn-primary" data-dismiss="modal">No, I will continue</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Spotting Error Modal -->


<!-- Dictation Test Modal -->
<div id="dictation-quit-popup" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="box box-solid">
          <div class="box-body">
            <h3 class="text-center"><u>Instructions</u></h3>
			    <div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
           
            <p>Even if you don't complete the section, your coins will be deducted, are you sure you want to exit?</p>
          </div>
        </div>
        <div class="text-center">
          <a href="<?php echo $site_url; ?>/dictationTestdetails/<?php echo $test->id; ?>/<?php echo md5($test->id); ?>"><button type="button" class="btn btn-primary">Yes, I want to exit</button></a>
          <button type="button" class="btn btn-primary" data-dismiss="modal">No, I will continue</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Dictation Test Modal -->


<!-- comprehension Test Modal -->
<div id="comprehension-quit-popup" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="box box-solid">
          <div class="box-body">
            <h3 class="text-center"><u>Instructions</u></h3>
			    <div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
           
            <p>Even if you don't complete the section, your coins will be deducted, are you sure you want to exit?</p>
          </div>
        </div>
        <div class="text-center">
          <a href="<?php echo $site_url; ?>/comprehensionTest"><button type="button" class="btn btn-primary">Yes, I want to exit</button></a>
          <button type="button" class="btn btn-primary" data-dismiss="modal">No, I will continue</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- comprehension Test Modal -->

<!-- Re-Arrange Test Modal -->
<div id="rearrange-quit-popup" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="box box-solid">
          <div class="box-body">
            <h3 class="text-center"><u>Instructions</u></h3>
			    <div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
           
            <p>Even if you don't complete the section, your coins will be deducted, are you sure you want to exit?</p>
          </div>
        </div>
        <div class="text-center">
          <a href="<?php echo $site_url; ?>/reArrangeTestdetails"><button type="button" class="btn btn-primary">Yes, I want to exit</button></a>
          <button type="button" class="btn btn-primary" data-dismiss="modal">No, I will continue</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Re-Arrange Test Modal -->

<!-- Fill In Blank Test Modal -->
<div id="fillInBlank-quit-popup" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <div class="box box-solid">
          <div class="box-body">
            <h3 class="text-center"><u>Instructions</u></h3>
			    <div class="get_test_msg" style="text-align:center;color:#ff0000"></div>
           
            <p>Even if you don't complete the section, your coins will be deducted, are you sure you want to exit?</p>
          </div>
        </div>
        <div class="text-center">
          <a href="<?php echo $site_url; ?>/fillblanks"><button type="button" class="btn btn-primary">Yes, I want to exit</button></a>
          <button type="button" class="btn btn-primary" data-dismiss="modal">No, I will continue</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Fill In Blank Test Modal -->