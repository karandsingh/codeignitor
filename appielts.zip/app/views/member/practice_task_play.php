<!doctype html>
<html lang="en">
<head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <title><?php echo $window_title; ?></title>

  <?php include_once('common/speakinghead.php'); ?>

  <style>

a {

  color: #337ab7;

}

p {

  margin-top: 1rem;

}

a:hover {

  color:#23527c;

}

a:visited {

  color: #8d75a3;

}



body {

	line-height: 1.5;

	font-family: sans-serif;

	word-wrap: break-word;

	overflow-wrap: break-word;

	color:black;

	margin:2em;

}



h1 {

	text-decoration: underline red;

	text-decoration-thickness: 3px;

	text-underline-offset: 6px;

	font-size: 220%;

	font-weight: bold;

}



h2 {

	font-weight: bold;

	color: #005A9C;

	font-size: 140%;

	text-transform: uppercase;

}



red {

	color: red;

}



#controls {

  display: flex;

  margin-top: 2rem;

  max-width: 28em;

} 



button {

  flex-grow: 1;

  height: 3.5rem;

  min-width: 2rem;

  border: none;

  border-radius: 0.15rem;

  background: #ed341d;

  margin-left: 2px;

  box-shadow: inset 0 -0.15rem 0 rgba(0, 0, 0, 0.2);

  cursor: pointer;

  display: flex;

  justify-content: center;

  align-items: center;

  color:#ffffff;

  font-weight: bold;

  font-size: 1.5rem;

}



button:hover, button:focus {

  outline: none;

  background: #c72d1c;

}



button::-moz-focus-inner {

  border: 0;

}



button:active {

  box-shadow: inset 0 1px 0 rgba(0, 0, 0, 0.2);

  line-height: 3rem;

}



button:disabled {

  pointer-events: none;

  background: lightgray;

}

button:first-child {

  margin-left: 0;

}



audio {

  display: block;

  width: 100%;

  margin-top: 0.2rem;

}



li {

  list-style: none;

  margin-bottom: 1rem;

}



#formats {

  margin-top: 0.5rem;

  font-size: 80%;

}



#recordingsList{

	max-width: 28em;

}

</style>





  <style type="text/css">
   .drag_block {
    margin-bottom:15px;
}
 label > input[type=radio] {
    visibility:hidden;
}

 .checking {
	display: inline-block;
	padding: 0px;
	height:20px;
	width:20px;
	background: none;margin-top:-20px;
}

td > label {
	display: block;
	width: 20px;
	margin-top: -10px;
}

  input:checked +.checking {  
	background: url(http://cdn1.iconfinder.com/data/icons/onebit/PNG/onebit_34.png);
	background-repeat: no-repeat;
	background-position:center center;
	background-size:15px 15px;
}
.droppable-element.ui-droppable {
    min-height: 25px;
    border: 2px solid grey;
    margin-left:20px;
    margin-right:20px;
    min-width:200px;max-width:max-content;
    background-color: #fdfdfd;
    padding:2px;
    display:inline-block;
}
.drag-container{
    padding:5px;margin:10px;width: max-content;}
th{text-align:center;padding:5px;}
    @media only screen and (max-width: 600px) {
  .scrollbar1 {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 65%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
  }
}
@media only screen and (max-width: 600px) {
  .scrollbar {
    margin-left: 0px;
    float: left;
    height: 500px;
    width: 60%;
    background: #F5F5F5;
    overflow-y: scroll;
    margin-bottom: 25px;
}
}
@media only screen and (max-width: 600px) {
.page-title-wrapper {
  margin-bottom: 30px !important;
  border-top: 1px solid #fff;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  -ms-border-radius: 3px;
  -o-border-radius: 3px;
  border-radius: 3px;
  margin-top: 100px !important;
  margin-left: 10px !important;
  margin-right: 10px !important;
}
}
.radio-gap {
    margin-top: 35px;
}
@media only screen and (max-width: 600px) {
.image_size {
        width: 100% !important;
        margin-top: 15px;
        margin-bottom: 15px;
    }}
  </style>
</head>
<!---<body class="hold-transition skin-blue sidebar-mini" oncontextmenu="return false" onselectstart="return false" ondragstart="return false">-->
<body class="hold-transition skin-blue sidebar-mini">
      <div class="page-wrapper">
    <div id="page-content">
		<header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip</h1>
              <a href="<?php echo base_url('member/dashboard'); ?>"><!--font size="20px"><strong>CELPIP</strong></font--><img src="/theme/deafult/images/ielts24x7.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            
          </div>
        </div>
      </header>

	  <div class="page-title-wrapper fixed-width">
        <div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1><?php 
				if($testdetail->test_id==14){
					echo 'Listening Part 4: Labelling on a map Details ';
				}elseif($testdetail->test_id==16){
					echo 'Listening Part 6: Fill in the gaps: short answers:';
				}elseif($testdetail->test_id==13){
					echo 'Listening Part 3: Matching:';
				}elseif($testdetail->test_id==11){
					echo 'Listening Part 1 : Multiple choice with one answer';
				}elseif($testdetail->test_id==12){
					echo 'Listening Part 2: Multiple choice question with more than one answer';
				}elseif($testdetail->test_id==15){
					echo 'Listening Part 5: Fill in the Blank';
				}elseif($testdetail->test_id==47){
					echo 'Writing Task 1: Writing an Email Details';
				}elseif($testdetail->test_id==46){
					echo 'Writing Task 2: Responding to Survey Questions';
				}elseif($testdetail->test_id==59){
					echo 'Speaking: Practice Task';
				}elseif($testdetail->test_id==58){
					echo 'Speaking Task 1: Giving Advice ';
				}elseif($testdetail->test_id==62){
					echo 'Speaking Task 1: Introduction & Interview';
				}elseif($testdetail->test_id==63){
					echo 'Speaking Task 2: Individual Long Turn (Cue-Card)';
				}elseif($testdetail->test_id==64){
					echo 'Speaking Task 3: Discussion';
				}elseif($testdetail->test_id==56){
					echo 'Speaking Task 3: Describing a Scene';
				}elseif($testdetail->test_id==55){
					echo 'Speaking Task 4: Making Predictions';
				}elseif($testdetail->test_id==54){
					echo 'Speaking Task 5: Comparing and Persuading';
				}elseif($testdetail->test_id==51){
					echo 'General Writing Part 1';
				}elseif($testdetail->test_id==52){
					echo 'General Writing Part 2';
				}elseif($testdetail->test_id==42){
					echo 'Academic Writing Part 2';
				}elseif($testdetail->test_id==41){
					echo 'Academic Writing Part 1';
				}elseif($testdetail->test_id==21){
					echo 'Academic Reading Part 1 : Multiple choice with one answer';
				}elseif($testdetail->test_id==22){
					echo 'Academic Reading Part 2: Multiple choice question with more than one answer';
				}elseif($testdetail->test_id==23){
					echo 'Reading Part 3: Identifying Information (True/False/Not Given)';
				}elseif($testdetail->test_id==24){
					echo 'Reading Part 4: Note Completion';
				}elseif($testdetail->test_id==25){
					echo 'Reading Part 5: Matching Headings';
				}elseif($testdetail->test_id==26){
					echo 'Reading Part 6: Summary Completion';
				}elseif($testdetail->test_id==27){
					echo 'Reading Part 7: Summary Completion (selecting from a list of words or phrases)';
				}elseif($testdetail->test_id==28){
					echo 'Reading Part 8: Flow-chart Completion';
				}elseif($testdetail->test_id==29){
					echo 'Reading Part 9: Sentence Completion';
				}elseif($testdetail->test_id==30){
					echo 'Reading Part 10: Matching Sentence Endings Details';
				}elseif($testdetail->test_id==31){
					echo 'Academic Reading Part 1: Matching Information';
				}elseif($testdetail->test_id==32){
					echo 'Academic Reading Part 2: True/False/Not Given';
				}elseif($testdetail->test_id==33){
					echo 'Academic Reading Part 3: Note Completion';
				}elseif($testdetail->test_id==34){
					echo 'Academic Reading Part 4: Summary Completion';
				}elseif($testdetail->test_id==35){
					echo 'Academic Reading Part 5: Matching Features';
				}elseif($testdetail->test_id==36){
					echo 'Academic Reading Part 6: Multiple Choice';
				}elseif($testdetail->test_id==37){
					echo 'Academic Reading Part 7: Summary Completion';
				}
				else{
					echo '';
				} ?>
			</h1>
            
          </div>
          <div class="otw-five otw-columns">
		    
          </div>
        </div>
       
      </div>
	  
      <!--header id="top">
        <div class="otw-row otw-collapse">
          <div>
            <div id="otw-site-title">
              <h1>Celpip Practice Test</h1>
              <a href="<?php //echo base_url(); ?>"><img src="images/logo-celpip.png" title="celpip" alt="" style="width:200px;" /></a>
            </div>
            
          </div>
          <div class="menu-wrapper">
            
          </div>
        </div>
      </header-->

      
        <?php /*<div class="otw-row page-title">
          <div class="otw-nineteen otw-columns">
            <h1><?php 
				if($testdetail->test_id==20){
					echo 'Part 1: Listening to Problem Solving';
				}elseif($testdetail->test_id==29){
					echo 'Listening Practice Task Questions:';
				}elseif($testdetail->test_id==19){
					echo 'Part 2: Listening to Daily Life Conversation:';
				}elseif($testdetail->test_id==18){
					echo 'Part 3: Listening for Information:';
				}elseif($testdetail->test_id==17){
					echo 'Part 4: Listening to a News Item';
				}else{
					echo '';
				} ?>
			</h1>
          </div>
          <div class="otw-five otw-columns">
            <form name="submit_ptest" enctype="multipart/form-data" id="submit_ptest" action="<?php echo base_url('member/PracticeTaskSubmit')?>" method="get" class="searchform">
                <!--button type="button" class="btn btn-danger"><i class="fa fa-hand-o-right"></i>Submit</button-->
				
				<?php if($testdetail->test_id==29){ ?>
                <input type="submit" title="Next" name="submit" value="Submit">
				<?php } ?>
				
				<?php if($testdetail->test_id==20){ ?>
					<button type="button" class="btn ls1_next_btn" data-screenid="2">Next</button>
				<?php } ?>
				
				<?php if($testdetail->test_id==19){ ?>
					<button type="button" class="btn ls2_next_btn" data-screenid="2">Next</button>
				<?php } ?>
				
				<?php if($testdetail->test_id==18){ ?>
					<button type="button" class="btn ls3_next_btn" data-screenid="2">Next</button>
				<?php } ?>
				
				<?php if($testdetail->test_id==17){ ?>
					<button type="button" class="btn ls4_next_btn" data-screenid="2">Next</button>
				<?php } ?>
            
          </div>
        </div>*/ ?>

      </div>
      
		
		<?php if($testdetail->test_id==14){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns">
				  <h1> Listen to the following audio and label the point on the map. You will hear the audio only once. </h1>
				 
				  <p align="center">
				    <audio controls autoplay style="display:none;height:0px;">
						<source src="<?php echo base_url('uploads/part1_LOM/').$test->l1_conversation_1_audio; ?>" type="audio/mpeg">
				    </audio>
				    				<div class="otw-twelve otw-columns">

				      <img src="<?php echo base_url('uploads/part1_LOM/').$test->q1_image; ?>"></p>
			
				</div>
		
							 <div class="otw-twelve otw-columns">
					

									<div class="otw-twentyfour otw-columns">

				<table style="border:1px solid grey;margin:auto">
					    <tr>
					        <th></th>
					        <th>A</th>
					        <th>B</th>
					        <th>C</th>
					        <th>D</th>
					        <th>E</th>
					        <th>F</th>
					        <th>G</th>
					        <th>H</th>
					    </tr>
					    <tr>
					        <td><p>1. <?php echo $test->q1_question; ?> </p></td>
					     <td><label>
					         <input type="radio" name="q1-response" value="A"></input><img class="checking" />
					         </label></td>
						 <td>
						     <label><input  type="radio" name="q1-response" value="B"></input><img class="checking" />
						     </label></td>
						 <td><label><input type="radio" name="q1-response" value="C"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q1-response" value="D"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q1-response" value="E"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q1-response" value="F"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q1-response" value="G"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q1-response" value="H"></input><img class="checking" /></label></td>
						 
					   </tr>

					
					<tr>
					        <td><p>2. <?php echo $test->q2_question; ?></td>
					     <td><label><input type="radio" name="q2-response" value="A"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q2-response" value="B"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q2-response" value="C"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q2-response" value="D"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q2-response" value="E"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q2-response" value="F"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q2-response" value="G"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q2-response" value="H"></input><img class="checking" /></label></td>
						 
					   </tr>
					   <tr>
					        <td><p>3. <?php echo $test->q3_question; ?></td>
					     <td><label><input type="radio" name="q3-response" value="A"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q3-response" value="B"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q3-response" value="C"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q3-response" value="D"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q3-response" value="E"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q3-response" value="F"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q3-response" value="G"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q3-response" value="H"></input><img class="checking" /></label></td>
						 
					   </tr>
					   </table>
					</p>
				</div>
				</div>
				</div>
			</div>
			
			<?php } ?>
		
		<?php if($testdetail->test_id==39){ 
			//echo "<pre>";print_r($test);
		?>
		
			<div class="otw-row ls-part2 ls-part2-screen-1">
				<div class="otw-twentyfour otw-columns">
				 
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				    <div class="border-sec">
				  <!--<div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				   <p align="center">
				    <h1><?php echo $test->passage; ?></h1>
				    </p>
				   </div>
				   <!-- <div style="border-right: 1px solid #c5c5c5;height: 600px"></div> -->
				</div>
					<div class="otw-row ls-part4 ls-part4-screen-2" style="display:none">
				<div class="otw-twentyfour otw-columns">
					<h2>Choose the best way to complete each statement from the drop-down menu (<i class="fa fa-caret-down" aria-hidden="true"></i>)</h2>
					
					<p>1. <?php echo $test->q1_question; ?>
					   <select type="drop-down" style="width: 150px;" class="searchform q1-sel-opt" name="q1-response">
					   <option value=""></option>
						 <option value="q1_option1"><?php echo $test->q1_option1; ?></option>
						 <option value="q1_option2"><?php echo $test->q1_option2; ?></option>
						 <option value="q1_option3"><?php echo $test->q1_option3; ?></option>
						 <option value="q1_option4"><?php echo $test->q1_option4; ?></option>
					   </select>
					</p>
					
					<p>2. <?php echo $test->q2_question; ?>
					   <select type="drop-down" style="width: 150px;" class="searchform q2-sel-opt" name="q2-response">
					   <option value=""></option>
						 <option value="q2_option1"><?php echo $test->q2_option1; ?></option>
						 <option value="q2_option2"><?php echo $test->q2_option2; ?></option>
						 <option value="q2_option3"><?php echo $test->q2_option3; ?></option>
						 <option value="q2_option4"><?php echo $test->q2_option4; ?></option>
					   </select>
					</p>
					
					<p>3. <?php echo $test->q3_question; ?>
					   <select type="drop-down" style="width: 150px;" class="searchform q3-sel-opt" name="q3-response">
					    <option value=""></option>
						<option value="q3_option1"><?php echo $test->q3_option1; ?></option>
						<option value="q3_option2"><?php echo $test->q3_option2; ?></option>
						<option value="q3_option3"><?php echo $test->q3_option3; ?></option>
						<option value="q3_option4"><?php echo $test->q3_option4; ?></option>
					   </select>
					</p>
					
					
				</div>
			</div>
		
		<?php } ?>
		<?php if($testdetail->test_id==13){ ?>
			<div style="padding-left:20px;padding-right:20px;width:90%;margin:auto">
			     <h2>Listen to the audio carefully and select the correct answer for the following questions. You will only hear the audio once.</h2>
			      <p align="center">
				    <audio controls autoplay>
						<source src="<?php echo base_url('uploads/part1_MH/').$test->l1_conversation_1_audio; ?>" type="audio/mpeg" >
				    </audio></p>
				
			    <div class="row">
			        <div class="col-sm-6">
		<div class="drag_block">
		    <?php echo $test->heading1; ?>

<div class="droppable-element" id="q1_answer">

</div>
</div>
<div class="drag_block">
<?php echo $test->heading2; ?>
<div class="droppable-element" id="q2_answer" >
</div>
</div>
<div class="drag_block">
<?php echo $test->heading3; ?>

<div class="droppable-element" id="q3_answer">
</div>
</div>
<div class="drag_block">
<?php echo $test->heading4; ?>
<div class="droppable-element" id="q4_answer">

</div>
</div>
<div class="drag_block">
<?php echo $test->heading5; ?>
<div class="droppable-element" id="q5_answer">
</div>
    </div>
</div>
			        <div class="cols-sm-6"><div id="answers">
	<div id = "dragitem1-container" class="drag-container">
      <div id="dragitem1" class="qitem2 di1"><?php echo $test->h1_answer; ?></div>
    </div>
    
    <div id = "dragitem2-container" class="drag-container">
      <div id="dragitem2" class="qitem2 di1"><?php echo $test->h2_answer; ?></div>
    </div>
    
    <div id = "dragitem3-container" class="drag-container">
       <div id="dragitem3" class="qitem2 di1"><?php echo $test->h3_answer; ?></div>
    </div>
    <div id = "dragitem4-container" class="drag-container">
       <div id="dragitem4" class="qitem2 di1"><?php echo $test->h4_answer; ?></div>
    </div>
    <div id = "dragitem5-container" class="drag-container">
       <div id="dragitem5" class="qitem2 di1"><?php echo $test->h5_answer; ?></div>
    </div>
    <div id = "dragitem6-container" class="drag-container">
       <div id="dragitem6" class="qitem2 di1"><?php echo $test->option1; ?></div>
    </div>
    <div id = "dragitem7-container" class="drag-container">
       <div id="dragitem7" class="qitem2 di1"><?php echo $test->option2; ?></div>
    </div>
    <div id = "dragitem8-container" class="drag-container">
       <div id="dragitem8" class="qitem2 di1"><?php echo $test->option3; ?></div>
    </div>
    </div>
</div>

			        
</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==11){ 
			//echo "<pre>";print_r($test);
		?>
	
			<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns" style="padding-right:30px;">
				 <h2>Listen to the audio carefully and select the correct answer for the following questions. You will only hear the audio once.</h2>
				 <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				  <p align="center">
				   <audio controls autoplay style="display:none;">
						<source src="<?php echo base_url('uploads/part1_MCOA/').$test->l1_conversation_1_audio; ?>" type="audio/mpeg" >
				    </audio></p>
				  
				</div>
					<div class="col-sm-6" >

					<p>1. <?php echo $test->q1_question; ?>
					<br>
					<ul style="list-style:none">
						<li> 
						<input type="radio" name="q1-response" value="q1_option1" style="margin-right:20px;"><?php echo $test->q1_option1; ?></input>
						</li>
						<li>
						     <input type="radio" name="q1-response" value="q1_option2" style="margin-right:20px;"><?php echo $test->q1_option2; ?></input>
						 </li>
						 <li>
						 <input type="radio" name="q1-response" value="q1_option3" style="margin-right:20px;"><?php echo $test->q1_option3; ?></option>
						 </li>
					</ul>
						 
					   </select>
					   <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					</div>
						<div class="col-sm-6" >
					<p>2. <?php echo $test->q2_question; ?>
					<br>
					<ul style="list-style:none;text-align:justify">
					   <li>
						 <input type="radio" name="q2-response" value="q2_option1" style="margin-right:20px;"><?php echo $test->q2_option1; ?></input></li>
						<li> <input type="radio" name="q2-response" value="q2_option2" style="margin-right:20px;"><?php echo $test->q2_option2; ?></input></li>
						<li><input type="radio" name="q2-response" value="q2_option3" style="margin-right:20px;"><?php echo $test->q2_option3; ?></input></li>
						</ul>
						 
					   </select>
					   <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					</div>
						<div class="col-sm-6">
					<p>3. <?php echo $test->q3_question; ?>
					<br>
					<ul style="list-style:none;text-align:justify">
					    <li>
						<input type="radio" name="q3-response" value="q3_option1" style="margin-right:20px;"><?php echo $test->q3_option1; ?></input></li>
						<li>
						<input type="radio" name="q3-response" value="q3_option2" style="margin-right:20px;"><?php echo $test->q3_option2; ?></input></li>
						<li>
						<input type="radio" name="q3-response" value="q3_option3" style="margin-right:20px;"><?php echo $test->q3_option3; ?></input></li>
					   </select>
					  <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span></ul>
					</p>
					
					
				</div>
			</div>
		 
		<?php } ?>
		
		
		<?php if($testdetail->test_id==12){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns" style="padding-right:30px;">
				 <h2>Listen to the audio carefully and select the correct answer for the following questions. You will only hear the audio once.</h2>
				 <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				  <p align="center">
				     <audio controls autoplay style="display:none;">
						<source src="<?php echo base_url('uploads/part1_MCMTOA/').$test->l1_conversation_1_audio; ?>" type="audio/mpeg" >
				    </audio></p>
				  
				</div>
					<div class="col-sm-6" >

					<p>1. <?php echo $test->q1_question; ?>
					<br>
						<input type="checkbox" name="q1response" value="<?php echo $test->q1_option1; ?>" onclick="return myfun()" style="margin-right:20px;"><?php echo $test->q1_option1; ?>
						<br>
						     <input type="checkbox" name="q1response" value="<?php echo $test->q1_option2; ?>" onclick="return myfun()" style="margin-right:20px;"><?php echo $test->q1_option2; ?>
						    <br> 
						 <input type="checkbox" name="q1response" value="<?php echo $test->q1_option3; ?>" onclick="return myfun()" style="margin-right:20px;"><?php echo $test->q1_option3; ?>
						 <br>
						<input type="checkbox" name="q1response" value="<?php echo $test->q1_option4; ?>" onclick="return myfun()" style="margin-right:20px;"><?php echo $test->q1_option4; ?>
					<br>
					
						     <input type="checkbox" onclick="return myfun()" name="q1response" value="<?php echo $test->q1_option5; ?>" style="margin-right:20px;"><?php echo $test->q1_option5; ?>
						<br>     
						 <input type="checkbox" onclick="return myfun()" name="q1response" value="<?php echo $test->q1_option6; ?>" style="margin-right:20px;"><?php echo $test->q1_option6; ?>
						<br>
						<input type="checkbox" onclick="return myfun()" name="q1response" value="<?php echo $test->q1_option7; ?>" style="margin-right:20px;"><?php echo $test->q1_option7; ?>
						<br>
						     <input type="checkbox" onclick="return myfun()" name="q1response" value="<?php echo $test->q1_option8; ?>" style="margin-right:20px;"><?php echo $test->q1_option8; ?>
						<br>
					
					<span style="color:red;" id="invalid"></span>
						<span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					</div>
				
			</div>
		 
		<?php } ?>
		
			<?php if($testdetail->test_id==16){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns" style="padding-right:30px;">
				 <h2>Listen to the audio carefully and select the correct answer for the following questions. You will only hear the audio once.</h2>
				 <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				  <p align="center">
				    <audio controls autoplay style="display:none;">
						<source src="<?php echo base_url('uploads/part1_FGOWA/').$test->l1_conversation_1_audio; ?>" type="audio/mpeg" >
				    </audio></p>
				  
				</div>
					<div class="col-sm-6" >

					<p>1. <?php echo $test->q1_question; ?>
				
					</p>
					
				<textarea type="text" id="q1-response" name="q1-response" placeholder="Place some text here" required="" style="font-size:18px;font-weight:normal;color:#1d1d1d;"></textarea>
				
				<textarea type="text" id="q2-response" name="q2-response" placeholder="Place some text here" required="" style="font-size:18px;font-weight:normal;color:#1d1d1d;"></textarea>
				
				<textarea type="text" id="q3-response" name="q3-response" placeholder="Place some text here" required="" style="font-size:18px;font-weight:normal;color:#1d1d1d;"></textarea>

					</div>
				
			</div>
		 
		<?php } ?>
		
		<?php if($testdetail->test_id==36){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns" style="padding-right:30px;">
			
				 <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				  <p align="center">
				   </p>
				  <?php echo $test->passage; ?>
				</div>
					<div class="col-sm-6" >

					<p>1. <?php echo $test->q1_question; ?>
					<br>
						<input type="checkbox" name="q1response" value="<?php echo $test->q1_option1; ?>" onclick="return myfun4()" style="margin-right:20px;"><?php echo $test->q1_option1; ?>
						<br>
						     <input type="checkbox" name="q1response" value="<?php echo $test->q1_option2; ?>" onclick="return myfun4()" style="margin-right:20px;"><?php echo $test->q1_option2; ?>
						    <br> 
						 <input type="checkbox" name="q1response" value="<?php echo $test->q1_option3; ?>" onclick="return myfun4()" style="margin-right:20px;"><?php echo $test->q1_option3; ?>
						 <br>
						<input type="checkbox" name="q1response" value="<?php echo $test->q1_option4; ?>" onclick="return myfun4()" style="margin-right:20px;"><?php echo $test->q1_option4; ?>
					<br>
					
						     <input type="checkbox" onclick="return myfun4()" name="q1response" value="<?php echo $test->q1_option5; ?>" style="margin-right:20px;"><?php echo $test->q1_option5; ?>
						<br>
						     
					
					<span style="color:red;" id="invalid"></span>
						<span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					</div>
				
			</div>
		 
		<?php } ?>
		<?php if($testdetail->test_id==37){ 
			//echo "<pre>";print_r($test);
		?>
		
			<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twelve otw-columns">
				<div id="wrapper" style="height:600px; overflow-y:scroll;width:auto">
							<h2>Read the following message. </h2>
							<h3><?php echo $test->q1_title; ?></h3>

							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-twelve otw-columns">
			    <div class="answer-side" style="height:600px; overflow-y:scroll;line-height:2">
			        <h3 align="center"><?php echo $test->q1_title; ?></h3>

			        <?  $replace = '<input  name="q1-response">';
                                  

                                    //$search = '<span class="stextfield"></span>';
                                    $search = $this->BLANKAREA;
                                    $finalParagraph = str_replace($search, $replace, $test->q1_question);
                                    ?>
                              
                                     <? echo $finalParagraph ?>
                                       
                                    <?
                                    $totalBlanks = substr_count($test->q1_question, $search);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">
                                  <br/>
                                
						</div>
						</div>
		</div>
        <?php } ?>
		<?php if($testdetail->test_id==15){ 
			//echo "<pre>";print_r($test);
		?>
		
		<div class="otw-row">
			<div class="otw-twentyfour otw-columns">
<p align="center">
     <h2>Listen to the audio carefully and select the correct answer for the following questions. You will only hear the audio once.</h2>
				    <audio controls autoplay style="display:none;">
						<source src="<?php echo base_url('uploads/part1_FIG/').$test->l1_conversation_1_audio; ?>" type="audio/mpeg" >
				    </audio></p>			  <div class="otw-sc-hr"></div>
			</div>
		</div>
		
		<div class="otw-row">
			<div class="otw-twentyfour otw-columns">
			   <div id="contentblock" style="padding: 10px;font-size: 18px;">

                             
                                  <hr />

                                  <?php
                                    
                                    $replace = '<input  name="q1-response">';
                                    $replace2 = '<input  name="q2-response">';
                                    $replace3 = '<input  name="q3-response">';

                                    //$search = '<span class="stextfield"></span>';
                                    $search = $this->BLANKAREA;
                                    $finalParagraph = str_replace($search, $replace, $test->q1_question);
                                    ?>
                                    <div class="row" style="width:90%;margin:auto">
                                        <div class="col-sm-3">
                                            <? echo $test->q1_heading ?>
                                        </div>
                                        <div class="col-sm-6">
                                        <? echo nl2br($finalParagraph);?>
                                    </div>
                                    </div>
                                    <br><br>
                                    <?
                                     $finalParagraph2 = str_replace($search, $replace2, $test->q2_question);?>
                                    <div class="row" style="width:90%;margin:auto">
                                        <div class="col-sm-3">
                                            <? echo $test->q2_heading ?>
                                        </div>
                                        <div class="col-sm-6">
                                        <? echo nl2br($finalParagraph2);?>
                                    </div>
                                    </div>
                                    <br><br>
                                    <?
                                     $finalParagraph3 = str_replace($search, $replace3, $test->q3_question);?>
                                    
                                    <div class="row" style="width:90%;margin:auto">
                                        <div class="col-sm-3">
                                            <? echo $test->q1_heading ?>
                                        </div>
                                        <div class="col-sm-6">
                                        <? echo nl2br($finalParagraph3);?>
                                    </div>
                                    </div>
                                    <br><br>
                                    <?
                                    $totalBlanks = substr_count($test->q1_question, $search);
                                    $totalBlanks2 = substr_count($test->q2_question, $search);
                                    $totalBlanks3 = substr_count($test->q3_question, $search);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">
                                  <input type="hidden" id="totalBlanks2" value="<?php echo $totalBlanks2;?>">
                                  <input type="hidden" id="totalBlanks3" value="<?php echo $totalBlanks3;?>">
                                  <br/>
                                
                                </div>

                                
                              </div>
		</div>
		
        <?php } ?>
		
		<?php if($testdetail->test_id==47){ 
			//echo "<pre>";print_r($test);
		?>	
		<div class="otw-row" style="margin-bottom: -80px;">
				<div class="otw-ten otw-columns">

					<div style="border: 1px solid #00c0ef; border-radius: 10px;width: 440px;height: 500px;padding:10px;">
						<h2>Read the following information. </h2>
						  <p><?php echo $test->question_title; ?>
						   </p>
						   </div>

						  <div class="otw-sc-hr"></div>
				</div>
						 <div class="otw-thirteen otw-columns">
						 <div id="wrapper">
				<div class="scrollbar1" id="style-default">
				  <div class="force-overflow" style="border: 1px solid #00c0ef; border-radius: 10px;padding:10px;">
						<form>
							<table>
								<div>
									<p><?php echo $test->email_title; ?>
								</div>
								<div>
									<p>
										<textarea type="text" id="wt_q1_response" name="q1_response" placeholder="Place some text here" required="" style="height: 250px;font-size:18px;font-weight:normal;color:#1d1d1d;"></textarea>
										<span id="display_count">0</span> words
									</p>
									<p>
								</div>
							</table>
						</form>

					</div>
				</div>
			</div>
			<div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		
		<?php if($testdetail->test_id==41){ 
			//echo "<pre>";print_r($test);
		?>	
		<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns">
				  
				  <p align="center">
				   		<div class="otw-twelve otw-columns">
				    				    <p>1. <?php echo $test->q1_question; ?> </p>
				     <img src="<?php echo base_url('uploads/part4_SAWPA/').$test->q1_image; ?>"></p>
			
				</div>
		
							 <div class="otw-twelve otw-columns">
					

									<div class="otw-twentyfour otw-columns">
									    <textarea type="text" id="wt_q1_response" name="q1_response" placeholder="Place some text here" required="" style="height: 600pxfont-size:18px;font-weight:normal;color:#1d1d1d;"></textarea>
										<span id="display_count">0</span> words

				</div>
			</div>
			</div></div>
		<?php } ?>
		
			<?php if($testdetail->test_id==42){ 
			//echo "<pre>";print_r($test);
		?>	
		<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns">
				 
				  <p align="center">
				 	<div class="otw-twelve otw-columns">
				    		 <p>1. <?php echo $test->passage; ?> </p>
				    		 <p>1. <?php echo $test->q1_question; ?> </p>
				    
			
				</div>
		
							 <div class="otw-twelve otw-columns">
					

									<div class="otw-twentyfour otw-columns">
									    <textarea type="text" id="wt_q1_response" name="q1_response" placeholder="Place some text here" required="" style="height: 600pxfont-size:18px;font-weight:normal;color:#1d1d1d;"></textarea>
										<span id="display_count">0</span> words

				</div>
			</div>
			</div></div>
		<?php } ?>
		
			<?php if($testdetail->test_id==51){ 
			//echo "<pre>";print_r($test);
		?>	
		<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns">
				 
				  <p align="center">
				 	<div class="otw-twelve otw-columns">
			<b>	    		 <p>1. <?php echo $test->passage; ?> </p>
				    		 <p>1. <?php echo $test->q1_question; ?> </p>
				</b>    		 <p>1. <?php echo $test->instruction; ?> </p>

				    
			
				</div>
		
							 <div class="otw-twelve otw-columns">
					

									<div class="otw-twentyfour otw-columns">
									    <textarea type="text" id="gw_q1_response" name="q1_response" placeholder="Place some text here" required="" style="height: 600pxfont-size:18px;font-weight:normal;color:#1d1d1d;"></textarea>
										<span id="display_count">0</span> words

				</div>
			</div>
			</div></div>
		<?php } ?>
			<?php if($testdetail->test_id==52){ 
			//echo "<pre>";print_r($test);
		?>	
		<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns">
			 
				  <p align="center">
				 	<div class="otw-twelve otw-columns">
				    		 <p>1. <?php echo $test->passage; ?> </p>
				    		 <p>1. <?php echo $test->q1_question; ?> </p>
				    
			
				</div>
		
							 <div class="otw-twelve otw-columns">
					

									<div class="otw-twentyfour otw-columns">
									    <textarea type="text" id="gw_q2_response" name="q1_response" placeholder="Place some text here" required="" style="height: 600pxfont-size:18px;font-weight:normal;color:#1d1d1d;"></textarea>
										<span id="display_count">0</span> words

				</div>
			</div>
			</div></div>
		<?php } ?>
	
	
			
	<?php if($testdetail->test_id==62){ 
			//echo "<pre>";print_r($test);
		?>
			<div class="otw-row ls-part1 ls-part1-screen-1">
				<div class="otw-twentyfour otw-columns">
				  <p><div><font style="font-size: 30px;"> Q1.</font>
				  &nbsp; <?php echo $test->q1_question; ?></div></p>
				 
	</div>
			</div>
			
				    <p><div><font style="font-size: 30px;"> Q2.</font>
				  &nbsp; <?php echo $test->q2_question; ?></div></p>

				<div class="otw-ten otw-columns">
			 <p><div><font style="font-size: 30px;"> Q3.</font>
				  &nbsp; <?php echo $test->q3_question; ?></div></p>

				</div>
				     <p><div><font style="font-size: 30px;"> Q4.</font>
				  &nbsp; <?php echo $test->q4_question; ?></div></p>
			
 <p><div><font style="font-size: 30px;"> Q5.</font>
				  &nbsp; <?php echo $test->q5_question; ?></div></p>
			
				<!-- Recording Audio -->
				<div style="width:90%;margin:auto">
				<div id="controls">

				<button id="recordButtonOld">Record</button>
				<button id="stopButtonOld" disabled>Stop</button>

				</div>
				<div id="timer_div" style="color:#000"></div>	
				<div id="x"></div>	

				<div id="timer_audiodiv" style="color:#000"></div>	
								<div id="audioname" style="color:#000"></div>	


	
				<div id="formats">Format: start recording to see sample rate</div>

				<p><strong>Recordings:</strong></p>

				<ol id="recordingsList"></ol>
				<a href="javascript:void(0);" style="display:none" class="upload"></a>
	<div id="ptext">	</div>
	<p style="color:green" id="submit"></p>
	</div>
		<?php } ?>
		
			<?php if($testdetail->test_id==63){ 
			//echo "<pre>";print_r($test);
		?>
				<div class="otw-twentyfour otw-columns">
				  <p><div><font style="font-size: 30px;"> Q1.</font>
				  &nbsp; <?php echo $test->q1_question; ?></div></p>
				 
			</div>
			
				    <p><div><font style="font-size: 30px;"> Q2.</font>
				  &nbsp; <?php echo $test->q2_question; ?></div></p>

			
				<!-- Recording Audio -->
		<div style="width:90%;margin:auto">
				<div id="controls">

				<button id="recordButtonOld">Record</button>
				<button id="stopButtonOld" disabled>Stop</button>

				</div>
				<div id="timer_div" style="color:#000"></div>	
				<div id="x"></div>	

				<div id="timer_audiodiv" style="color:#000"></div>	
								<div id="audioname" style="color:#000"></div>	


	
				<div id="formats">Format: start recording to see sample rate</div>

				<p><strong>Recordings:</strong></p>

				<ol id="recordingsList"></ol>
				<a href="javascript:void(0);" style="display:none" class="upload"></a>
	<div id="ptext">	</div>
	<p style="color:green" id="submit"></p>		</div>
		<?php } ?>
		
	<?php if($testdetail->test_id==64){ 
			//echo "<pre>";print_r($test);
		?>
				<div class="otw-twentyfour otw-columns">
				  <p><div><font style="font-size: 30px;"> Q1.</font>
				  &nbsp; <?php echo $test->q1_question; ?></div></p>
				 
	</div>
			
				    <p><div><font style="font-size: 30px;"> Q2.</font>
				  &nbsp; <?php echo $test->q2_question; ?></div></p>

			
			
			 <p><div><font style="font-size: 30px;"> Q3.</font>
				  &nbsp; <?php echo $test->q3_question; ?></div></p>

			
				<!-- Recording Audio -->
				<div style="width:90%;margin:auto">
				<div id="controls">

				<button id="recordButtonOld">Record</button>
				<button id="stopButtonOld" disabled>Stop</button>

				</div>
				<div id="timer_div" style="color:#000"></div>	
				<div id="x"></div>	

				<div id="timer_audiodiv" style="color:#000"></div>	
								<div id="audioname" style="color:#000"></div>	


	
				<div id="formats">Format: start recording to see sample rate</div>

				<p><strong>Recordings:</strong></p>

				<ol id="recordingsList"></ol>
				<a href="javascript:void(0);" style="display:none" class="upload"></a>
	<div id="ptext">	</div>
	<p style="color:green" id="submit"></p></div>
		<?php } ?>
		

		
	
		
		<?php if($testdetail->test_id==23){ //echo "<pre>";print_r($test);?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-ten otw-columns">
				<div id="wrapper">
							<h2>Read the following message. </h2>
							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-thirteen otw-columns">

							<form>
								<table>
							    	<p><?php echo $test->q1_question; ?></p>

											<select type="drop-down" style="width: 150px;display:block" class="searchform q1-sel-opt" name="q1-response">
											    
												<option value=""></option>
												<option value="true">True</option>
												<option value="false">False</option>
												<option value="not given">Not Given</option>
											
												</select>	<span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
													<p><?php echo $test->q2_question; ?></p>

											<select type="drop-down" style="width: 150px;display:block" class="searchform q2-sel-opt" name="q2-response">
												<option value=""></option>
												<option value="true">True</option>
												<option value="false">False</option>
												<option value="not given">Not Given</option>
												</select>
												<span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
													<p><?php echo $test->q3_question; ?></p>

											<select type="drop-down" style="width: 150px;display:block" class="searchform q3-sel-opt" name="q3-response">
												<option value=""></option>
												<option value="true">True</option>
												<option value="false">False</option>
												<option value="not given">Not Given</option>
											</select>
											<span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span></form>
											</table>

						</div>
		</div>
		
		<?php } ?>
		
		
			<?php if($testdetail->test_id==24){ //echo "<pre>";print_r($test);?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twelve otw-columns">
				<div id="wrapper" style="height:600px; overflow-y:scroll;width:auto">
							<h2>Read the following message. </h2>
							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-twelve otw-columns">
			    <div class="answer-side" style="height:600px; overflow-y:scroll;line-height:2">
<h3> <? echo $test->q1_title ?></h3>
						<ul>
						    
                                  <?php
                                    
                                    $replace = '<input  name="q1-response">';
                                    $replace2 = '<input  name="q2-response">';
                                    $replace3 = '<input  name="q3-response">';
                                    $replace4 = '<input  name="q4-response">';
                                    $replace5 = '<input  name="q5-response">';
                                    $replace6 = '<input  name="q6-response">';

                                    //$search = '<span class="stextfield"></span>';
                                    $search = $this->BLANKAREA;
                                    $finalParagraph = str_replace($search, $replace, $test->q1_question);
                                    ?> 
                                    <li>
                                        <? echo nl2br($finalParagraph);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph2 = str_replace($search, $replace2, $test->q2_question);?>
                                     
                                    <li>
                                          
                                        <? echo nl2br($finalParagraph2);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph3 = str_replace($search, $replace3, $test->q3_question);?>
                                    
                                   
                                    <li>
                                        <? echo nl2br($finalParagraph3);?>
                                    </li>
                                    <br>
                                    
                                    <? $finalParagraph4 = str_replace($search, $replace4, $test->q4_question);
                                    ?> <li>
                                        <? echo nl2br($finalParagraph4);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph5 = str_replace($search, $replace5, $test->q5_question);?>
                                    <li>
                                          
                                        <? echo nl2br($finalParagraph5);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph6 = str_replace($search, $replace6, $test->q6_question);?>
                                    
                                   
                                        <li>
                                        <? echo nl2br($finalParagraph6);?>
                                    </li>
                                    <br>
						</ul>
</div>
						</div>
		</div>
		
		<?php } ?>
		
			<?php if($testdetail->test_id==25){ ?>
			<div  style="padding-left:20px;padding-right:20px;width:90%;margin:auto">
			    <div class="row">
			        <div class="col-sm-6">
			       <h2><?php echo $test->passage_heading1; ?></h2> 
			       <div class="droppable-element" id="q1_answer"></div>
			           <p><?php echo $test->passage1; ?></p> 
			           
			           
			           <h3><?php echo $test->passage_heading2; ?></h3>
			           <p><?php echo $test->passage2; ?></p> 
			           <div class="droppable-element" id="q2_answer" ></div>
			           
			           
			           <p><?php echo $test->passage3; ?></p>
			           <div class="droppable-element" id="q3_answer"></div>
			           
			           <p><?php echo $test->passage4; ?></p>
			           <div class="droppable-element" id="q4_answer"></div>
			           
			           <p><?php echo $test->passage5; ?></p></div>
			        <div class="cols-sm-6"><div id="answers">
	<div id = "dragitem1-container" class="drag-container">
      <div id="dragitem1" class="qitem2 di1"><?php echo $test->p1_answer; ?></div>
    </div>
    
    <div id = "dragitem2-container" class="drag-container">
      <div id="dragitem2" class="qitem2 di1"><?php echo $test->p2_answer; ?></div>
    </div>
    
    <div id = "dragitem3-container" class="drag-container">
       <div id="dragitem3" class="qitem2 di1"><?php echo $test->p3_answer; ?></div>
    </div>
    <div id = "dragitem4-container" class="drag-container">
       <div id="dragitem4" class="qitem2 di1"><?php echo $test->p4_answer; ?></div>
    </div>

    <div id = "dragitem6-container" class="drag-container">
       <div id="dragitem6" class="qitem2 di1"><?php echo $test->heading1; ?></div>
    </div>
    <div id = "dragitem7-container" class="drag-container">
       <div id="dragitem7" class="qitem2 di1"><?php echo $test->heading1; ?></div>
    </div>
    <div id = "dragitem8-container" class="drag-container">
       <div id="dragitem8" class="qitem2 di1"><?php echo $test->heading1; ?></div>
    </div>
    </div>
</div>

			        
</div>
		<?php } ?>
		
		
		
		
		<?php if($testdetail->test_id==26){ 
			//echo "<pre>";print_r($test);
		?>
		
			<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twelve otw-columns">
				<div id="wrapper" style="height:600px; overflow-y:scroll;width:auto">
							<h2>Read the following message. </h2>
							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-twelve otw-columns">
			    <div class="answer-side" style="height:600px; overflow-y:scroll;line-height:2">
			        <?  $replace = '<input  name="q1-response">';
                                  

                                    //$search = '<span class="stextfield"></span>';
                                    $search = $this->BLANKAREA;
                                    $finalParagraph = str_replace($search, $replace, $test->q1_question);
                                    ?>
                              
                                     <? echo $finalParagraph ?>
                                       
                                    <?
                                    $totalBlanks = substr_count($test->q1_question, $search);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">
                                  <br/>
                                
						</div>
						</div>
		</div>
        <?php } ?>
        
        		<?php if($testdetail->test_id==27){ 
			//echo "<pre>";print_r($test);
		?>
		
			<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twelve otw-columns">
				<div id="wrapper" style="height:600px; overflow-y:scroll;width:auto">
							<h2>Read the following message. </h2>
							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-twelve otw-columns">
			    <div class="answer-side" style="height:600px; overflow-y:scroll;line-height:2">
			        <? $replace = '<div class="droppable-element" id="q1_answer1"></div>';
			        $replace2 = ' <div class="droppable-element" id="q1_answer2"></div>';
			         $replace3 = ' <div class="droppable-element" id="q1_answer3"></div>';
			         $replace4 = ' <div class="droppable-element" id="q2_answer"></div>';
                                  

                                    //$search = '<span class="stextfield"></span>';
                                    
                                    
                                    $search = $this->BLANKAREA;
                                    $search1 = $this->BLANKAREA1;
                                    
                                    $search2 = $this->BLANKAREA2;
                                    
                                    $search3 = $this->BLANKAREA3;
                                    
                                    $finalParagraph = str_replace($search1, $replace, $test->q1_question);
                                    ?>
                                    
                                    
                                    <? $finalParagraph2= str_replace($search2, $replace2,$finalParagraph);
                                    ?>
                                    <? $finalParagraph3= str_replace($search3, $replace3,$finalParagraph2);
                                    
                                    $finalParagraph4 = str_replace($search, $replace4, $test->q2_question);
                                    ?>
                                    
                                    
                              
                                     <? echo $finalParagraph3 ?>
                                     <br>
                                       <? echo $finalParagraph4 ?>  
                                       
                                    <?
                                    $totalBlanks = substr_count($test->q1_question, $search);
                                    $totalBlanks2 = substr_count($test->q2_question, $search);
                                  ?>
                                  
                                  <br/>
                               <div class="cols-sm-6"><div id="answers">
	<div id = "dragitem1-container" class="drag-container">
      <div id="dragitem1" class="qitem2 di1"><?php echo $test->q1_answer; ?></div>
    </div>
    
    <div id = "dragitem2-container" class="drag-container">
      <div id="dragitem2" class="qitem2 di1"><?php echo $test->q2_answer; ?></div>
    </div>
    
    <div id = "dragitem3-container" class="drag-container">
       <div id="dragitem3" class="qitem2 di1"><?php echo $test->q3_answer; ?></div>
    </div>
    <div id = "dragitem4-container" class="drag-container">
       <div id="dragitem4" class="qitem2 di1"><?php echo $test->q4_answer; ?></div>
    </div>

    <div id = "dragitem5-container" class="drag-container">
       <div id="dragitem5" class="qitem2 di1"><?php echo $test->option1; ?></div>
    </div>
    <div id = "dragitem6-container" class="drag-container">
       <div id="dragitem6" class="qitem2 di1"><?php echo $test->option2; ?></div>
    </div>
    <div id = "dragitem7-container" class="drag-container">
       <div id="dragitem7" class="qitem2 di1"><?php echo $test->option3; ?></div>
    </div>
    </div>
</div>  
						</div>
						</div>
		</div>
        <?php } ?>
        
        
        			<?php if($testdetail->test_id==28){ //echo "<pre>";print_r($test);?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twelve otw-columns">
				<div id="wrapper" style="height:600px; overflow-y:scroll;width:auto">
							<h2>Read the following message. </h2>
							<h3><?php echo $test->q1_title; ?></h3>

							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-twelve otw-columns">
			    <div class="answer-side" style="height:600px; overflow-y:scroll;line-height:2">
			        <h3> <? echo $test->q2_title ?></h3>
						<ul style="list-style:none">
						    
                                  <?php
                                    
                                    $replace = '<input  name="q1-response"  type="text" style="width:max-content;display:inline-block;border: 1px solid #d7d7d7;">';
                                    $replace2 = '<input  name="q2-response" style="width:max-content;display:inline-block;border: 1px solid #d7d7d7;" type="text">';
                                    $replace3 = '<input  name="q3-response" style="width:max-content;display:inline-block;border: 1px solid #d7d7d7;" type="text">';
                                   
                                    //$search = '<span class="stextfield"></span>';
                                    $search = $this->BLANKAREA; 
                                    $finalParagraph = str_replace($search, $replace, $test->q1_question);
                                    ?> 
                                    <div>
                                        <div class="row" style="width:90%;margin:auto">
                                        <div class="col-sm-12"><div style="text-align:center;padding:20px;margin: 30px;;border:1px solid black;width:100%">
                                            <p><?php echo $test->l1_line; ?></p>
                                        </div></div>
                                        <br>
                                        <div class="col-sm-12" ><div style="text-align:center;padding:20px;margin: 30px;border:1px solid black">
                                        <? echo nl2br($finalParagraph);?>
                                        </div></div>
                                    <br>
                                      <div class="col-sm-12" ><div style="text-align:center;padding:20px;margin: 30px;border:1px solid black;width:100%">
                                            <?php echo $test->l2_line; ?>
                                        </div></div><br>
                                    <?
                                     $finalParagraph2 = str_replace($search, $replace2, $test->q2_question);?>
                                     
                                    <div class="row" style="width:100%;margin:auto">
                                        <div class="col-sm-6">
                                          <div  style="text-align:center;padding:20px;border:1px solid black">
                                        <? echo nl2br($finalParagraph2);?>
                                        </div>
                                    </div>
                                    <?
                                     $finalParagraph3 = str_replace($search, $replace3, $test->q3_question);?>
                                    
                                      <div class="col-sm-6">
                                          <div style="text-align:center;padding:20px;border:1px solid black">
                                          
                                        <? echo nl2br($finalParagraph3);?>
                                        </div>
                                    </div>
                                    </div>
                                    </div>
                                    
                                   
						</ul>
</div>
						</div>
		</div>
		
		<?php } ?>
		
			<?php if($testdetail->test_id==29){ //echo "<pre>";print_r($test);?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twelve otw-columns">
				<div id="wrapper" style="height:600px; overflow-y:scroll;width:auto">
							<h2>Read the following message. </h2>
							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-twelve otw-columns">
			    <div class="answer-side" style="height:600px; overflow-y:scroll;line-height:2">
			        <h3> <? echo $test->q1_title ?></h3>
						<ul style="list-style:none">
						    
                                  <?php
                                    
                                    $replace = '<input  name="q1-response">';
                                    $replace2 = '<input  name="q2-response">';
                                    $replace3 = '<input  name="q3-response">';
                                    $replace4 = '<input  name="q4-response">';
                                    $replace5 = '<input  name="q5-response">';
                                    //$search = '<span class="stextfield"></span>';
                                    $search = $this->BLANKAREA;
                                    $finalParagraph = str_replace($search, $replace, $test->q1_question);
                                    ?> 
                                    <li>
                                        <? echo nl2br($finalParagraph);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph2 = str_replace($search, $replace2, $test->q2_question);?>
                                     
                                    <li>
                                          
                                        <? echo nl2br($finalParagraph2);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph3 = str_replace($search, $replace3, $test->q3_question);?>
                                    
                                    <li>
                                        <? echo nl2br($finalParagraph3);?>
                                    </li>
                                    <br><? $finalParagraph4 = str_replace($search, $replace4, $test->q4_question);
                                    ?> <li>
                                        <? echo nl2br($finalParagraph4);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph5 = str_replace($search, $replace5, $test->q5_question);?>
                                    <li>
                                          
                                        <? echo nl2br($finalParagraph5);?>
                                    </li>
                                    <br>
                                   
						</ul>
</div>
						</div>
		</div>
		
		<?php } ?>
		
		
					<?php if($testdetail->test_id==30){ 
			//echo "<pre>";print_r($test);
		?>
		
			<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twelve otw-columns">
				<div id="wrapper" style="height:600px; overflow-y:scroll;width:auto">
							<h2>Read the following message. </h2>
								<h2><?php echo $test->passage_heading; ?></h2>

							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-twelve otw-columns">
			    <div class="answer-side" style="height:600px; overflow-y:scroll;line-height:2">
			        <?  $replace = ' <div class="droppable-element" id="q1_answer"></div>';
			        $replace2 = ' <div class="droppable-element" id="q2_answer"></div>';
			    
			        $replace3 = ' <div class="droppable-element" id="q3_answer"></div>';
                                  

                                    //$search = '<span class="stextfield"></span>';
                                    $search = $this->BLANKAREA;
                                    $finalParagraph = str_replace($search, $replace, $test->passage1);
                                    ?>
                                    <? $finalParagraph2= str_replace($search, $replace2, $test->passage2);
                                    ?>
                                    
                                      <? $finalParagraph3= str_replace($search, $replace3, $test->passage3);
                                    ?>
                              
                                    <div class="drag_block">
<? echo $finalParagraph ?></div>
                
                                <div class="drag_block">
  <? echo $finalParagraph2 ?>  </div>
                            <div class="drag_block">
           <? echo $finalParagraph3 ?>  </div>
                                          

                                  <br/>
                               <div class="cols-sm-6"><div id="answers">
	<div id = "dragitem1-container" class="drag-container">
      <div id="dragitem1" class="qitem2 di1"><?php echo $test->p1_answer; ?></div>
    </div>
    
    <div id = "dragitem2-container" class="drag-container">
      <div id="dragitem2" class="qitem2 di1"><?php echo $test->p2_answer; ?></div>
    </div>
    
    <div id = "dragitem3-container" class="drag-container">
       <div id="dragitem3" class="qitem2 di1"><?php echo $test->p3_answer; ?></div>
    </div>
    

    <div id = "dragitem5-container" class="drag-container">
       <div id="dragitem5" class="qitem2 di1"><?php echo $test->heading1; ?></div>
    </div>
    <div id = "dragitem6-container" class="drag-container">
       <div id="dragitem6" class="qitem2 di1"><?php echo $test->heading2; ?></div>
    </div>
    <div id = "dragitem7-container" class="drag-container">
       <div id="dragitem7" class="qitem2 di1"><?php echo $test->heading3; ?></div>
    </div>
    </div>
</div>  
						</div>
						</div>
		</div>
        <?php } ?>
        
        
		
		
		
			<?php if($testdetail->test_id==32){ //echo "<pre>";print_r($test);?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-ten otw-columns">
				<div id="wrapper">
							<h2>Read the following message. </h2>
							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-thirteen otw-columns">

							<form>
								<table>
							    	<p><?php echo $test->q1_question; ?></p>

											<select type="drop-down" style="width: 150px;display:block" class="searchform q1-sel-opt" name="q1-response">
											    
												<option value=""></option>
												<option value="true">True</option>
												<option value="false">False</option>
												<option value="not given">Not Given</option>
											
												</select>	<span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
													<p><?php echo $test->q2_question; ?></p>

											<select type="drop-down" style="width: 150px;display:block" class="searchform q2-sel-opt" name="q2-response">
												<option value=""></option>
												<option value="true">True</option>
												<option value="false">False</option>
												<option value="not given">Not Given</option>
												</select>
												<span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
													<p><?php echo $test->q3_question; ?></p>

											<select type="drop-down" style="width: 150px;display:block" class="searchform q3-sel-opt" name="q3-response">
												<option value=""></option>
												<option value="true">True</option>
												<option value="false">False</option>
												<option value="not given">Not Given</option>
											</select>
											<span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
											
											
											
											
												<p><?php echo $test->q4_question; ?></p>

											<select type="drop-down" style="width: 150px;display:block" class="searchform q4-sel-opt" name="q4-response">
											    
												<option value=""></option>
												<option value="true">True</option>
												<option value="false">False</option>
												<option value="not given">Not Given</option>
											
												</select>	<span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
													<p><?php echo $test->q5_question; ?></p>

											<select type="drop-down" style="width: 150px;display:block" class="searchform q5-sel-opt" name="q5-response">
												<option value=""></option>
												<option value="true">True</option>
												<option value="false">False</option>
												<option value="not given">Not Given</option>
												</select>
												<span class="q5-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
													<p><?php echo $test->q6_question; ?></p>

											<select type="drop-down" style="width: 150px;display:block" class="searchform q6-sel-opt" name="q6-response">
												<option value=""></option>
												<option value="true">True</option>
												<option value="false">False</option>
												<option value="not given">Not Given</option>
											</select>
											<span class="q6-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
											</table>
											
											</form>

						</div>
		</div>
		
		<?php } ?>
		
			<?php if($testdetail->test_id==33){ //echo "<pre>";print_r($test);?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twelve otw-columns">
				<div id="wrapper" style="height:600px; overflow-y:scroll;width:auto">
							<h2>Read the following passage. </h2>
							 <h3> <? echo $test->q1_title ?></h3>

							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-twelve otw-columns">
			    <div class="answer-side" style="height:600px; overflow-y:scroll;line-height:2">
						<ul style="list-style:none">
						    
                                  <?php
                                    
                                    $replace = '<input  name="q1-response">';
                                    $replace2 = '<input  name="q2-response">';
                                    $replace3 = '<input  name="q3-response">';
                                    $replace4 = '<input  name="q4-response">';
                                    $replace5 = '<input  name="q5-response">';
                                    //$search = '<span class="stextfield"></span>';
                                    $search = $this->BLANKAREA;
                                    $finalParagraph = str_replace($search, $replace, $test->q1_question);
                                    ?> 
                                    <li>
                                        <? echo nl2br($finalParagraph);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph2 = str_replace($search, $replace2, $test->q2_question);?>
                                     
                                    <li>
                                          
                                        <? echo nl2br($finalParagraph2);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph3 = str_replace($search, $replace3, $test->q3_question);?>
                                    
                                    <li>
                                        <? echo nl2br($finalParagraph3);?>
                                    </li>
                                    <br><? $finalParagraph4 = str_replace($search, $replace4, $test->q4_question);
                                    ?> <li>
                                        <? echo nl2br($finalParagraph4);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph5 = str_replace($search, $replace5, $test->q5_question);?>
                                    <li>
                                          
                                        <? echo nl2br($finalParagraph5);?>
                                    </li>
                                    <br>
                                   
						</ul>
</div>
						</div>
						</div>
		<?php } ?>
		
		
		
			<?php if($testdetail->test_id==34){ //echo "<pre>";print_r($test);?>
		<div class="otw-row" style="margin-bottom: -80px;">
			<div class="otw-twelve otw-columns">
				<div id="wrapper" style="height:600px; overflow-y:scroll;width:auto">
							<h2>Read the following passage. </h2>
							 <h3> <? echo $test->q1_title ?></h3>

							<p><?php echo $test->passage; ?></p>
						

						</div>
					</div>
			<div class="otw-twelve otw-columns">
			    <div class="answer-side" style="height:600px; overflow-y:scroll;line-height:2">
						<ul style="list-style:none">
						    
                                  <?php
                                    
                                    $replace = '<input  name="q1-response">';
                                    $replace2 = '<input  name="q2-response">';
                                    $replace3 = '<input  name="q3-response">';
                                    $replace4 = '<input  name="q4-response">';
                                    //$search = '<span class="stextfield"></span>';
                                    $search = $this->BLANKAREA;
                                    $finalParagraph = str_replace($search, $replace, $test->q1_question);
                                    ?> 
                                    <li>
                                        <? echo nl2br($finalParagraph);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph2 = str_replace($search, $replace2, $test->q2_question);?>
                                     
                                    <li>
                                          
                                        <? echo nl2br($finalParagraph2);?>
                                    </li>
                                    <br>
                                    <?
                                     $finalParagraph3 = str_replace($search, $replace3, $test->q3_question);?>
                                    
                                    <li>
                                        <? echo nl2br($finalParagraph3);?>
                                    </li>
                                    <br><? $finalParagraph4 = str_replace($search, $replace4, $test->q4_question);
                                    ?> <li>
                                        <? echo nl2br($finalParagraph4);?>
                                    </li>
                                    <br>
                                   
                                    <?
                                    $totalBlanks = substr_count($test->q1_question, $search);
                                    $totalBlanks2 = substr_count($test->q3_question, $search);
                                  ?>
                                  <input type="hidden" id="totalBlanks" value="<?php echo $totalBlanks;?>">
                                 
                                  <input type="hidden" id="totalBlanks2" value="<?php echo $totalBlanks2;?>">
						</ul>
</div>
						</div>
		</div>
		
		<?php } ?>
		
		
			<?php if($testdetail->test_id==35){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="row" style="width:90%;margin:auto">
				<div class="otw-twentyfour otw-columns">
				<div class="row">
				    <div class="col-sm-6"><h2>
				        <?php echo $test->heading; ?>
				    </h2><p><?php echo $test->passage; ?></p></div>
				    <div class="col-sm-6">	<table style="border:1px solid grey;margin:auto">
					    <tr>
					        <th></th>
					        <th>A</th>
					        <th>B</th>
					        <th>C</th>
					    </tr>
					    <tr>
					        <td><p>1. <?php echo $test->q1_question; ?> </p></td>
					     <td><label><input type="radio" name="q1-response" value="<?php echo $test->q_option1; ?>"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q1-response" value="<?php echo $test->q_option2; ?>"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q1-response" value="<?php echo $test->q_option3; ?>"></input><img class="checking" /></label></td>
						
						 
					   </tr>

					
					<tr>
					        <td><p>2. <?php echo $test->q2_question; ?></td>
					     <td><label><input type="radio" name="q2-response" value="<?php echo $test->q_option1; ?>"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q2-response" value="<?php echo $test->q_option2; ?>"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q2-response" value="<?php echo $test->q_option3; ?>"></input><img class="checking" /></label></td>
					   </tr>
					   <tr>
					        <td><p>3. <?php echo $test->q3_question; ?></td>
					     <td><label><input type="radio" name="q3-response" value="<?php echo $test->q_option1; ?>"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q3-response" value="<?php echo $test->q_option2 ;?>"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q3-response" value="<?php echo $test->q_option3; ?>"></input><img class="checking" /></label></td>
					   </tr>
					   	<tr>
					        <td><p>2. <?php echo $test->q4_question; ?></td>
					     <td><label><input type="radio" name="q4-response" value="<?php echo $test->q_option<1; ?>"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q4-response" value="<?php echo $test->q_option2; ?>"></input><img class="checking" /></label></td>
						 <td><label><input type="radio" name="q4-response" value="<?php echo $test->q_option3; ?>"></input><img class="checking" /></label></td>
					   </tr>
					   </table>
					   <div class="col-sm-6">
					   <table style="border:1px solid grey;margin:auto;margin-top:30px;">
					    <tr>
					      <th colspan="3"> <?php echo $test->optionheading;?></th>
					       
					    </tr>
					    <tr>
					        <td>A</td>
					        <td> <?php echo $test->q_option1; ?></td>
					     
						
						 
					   </tr>
					    <tr>
					        <td>B</td>
					        <td> <?php echo $test->q_option2; ?></td>
					     
						
						 
					   </tr>
					    <tr>
					        <td>C</td>
					        <td> <?php echo $test->q_option3; ?></td>
					     
						
						 
					   </tr>
					   </table>
					   </div>
					   </div>
				</div> 
				  <p align="center">
				   </p>
			
				</div>
		
			
					</p>
			
				</div>
			</div>
			
			<?php } ?>
		
		<?php if($testdetail->test_id==21){ 
			//echo "<pre>";print_r($test);
		?>
			<div class="row" style="width:90%;margin:auto">
				<div class="otw-twelve otw-columns">
				 <h2>Read the paragraph and answer the following questions carefully</h2>
				 <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				 	<p><?php echo $test->passage; ?></p>
				  
				</div>
					<div class="otw-twelve otw-columns" >
					<div class="otw-twentyfour otw-columns" >

					<p>1. <?php echo $test->q1_question; ?>
					<br>
					<ul style="list-style:none;text-align:justify">
						<li> 
						<input type="radio" name="q1-response" value="q1_option1" style="margin-right:20px;"><?php echo $test->q1_option1; ?></input>
						</li>
						<li>
						     <input type="radio" name="q1-response" value="q1_option2" style="margin-right:20px;"><?php echo $test->q1_option2; ?></input>
						 </li>
						 <li>
						 <input type="radio" name="q1-response" value="q1_option3" style="margin-right:20px;"><?php echo $test->q1_option3; ?></option>
						 </li>
						 <li>
						 <input type="radio" name="q1-response" value="q1_option4" style="margin-right:20px;"><?php echo $test->q1_option4; ?></option>
						 </li>
					</ul>
						 
					   </select>
					   <span class="q1-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					</div>
						<div class="otw-twentyfour otw-columns" >
					<p>2. <?php echo $test->q2_question; ?>
					<br>
					<ul style="list-style:none;text-align:justify">
					   <li>
						 <input type="radio" name="q2-response" value="q2_option1" style="margin-right:20px;"><?php echo $test->q2_option1; ?></input></li>
						<li> <input type="radio" name="q2-response" value="q2_option2" style="margin-right:20px;"><?php echo $test->q2_option2; ?></input></li>
						<li><input type="radio" name="q2-response" value="q2_option3" style="margin-right:20px;"><?php echo $test->q2_option3; ?></input></li>
						<li><input type="radio" name="q2-response" value="q2_option4" style="margin-right:20px;"><?php echo $test->q2_option4; ?></input></li>
						</ul>
						
						 
					   </select>
					   <span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</p>
					</div>
						<div class="otw-twentyfour otw-columns">
					<p>3. <?php echo $test->q3_question; ?>
					<br>
					<ul style="list-style:none;text-align:justify">
					    <li>
						<input type="radio" name="q3-response" value="q3_option1" style="margin-right:20px;"><?php echo $test->q3_option1; ?></input></li>
						<li>
						<input type="radio" name="q3-response" value="q3_option2" style="margin-right:20px;"><?php echo $test->q3_option2; ?></input></li>
						<li>
						<input type="radio" name="q3-response" value="q3_option3" style="margin-right:20px;"><?php echo $test->q3_option3; ?></input></li>
						<li>
						<input type="radio" name="q3-response" value="q3_option4" style="margin-right:20px;"><?php echo $test->q3_option4; ?></input></li>
					   </select>
					  <span class="q3-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span></ul>
					</p>
					
					
				</div>
						<div class="otw-twentyfour otw-columns">
					<p>4. <?php echo $test->q4_question; ?>
					<br>
					<ul style="list-style:none;text-align:justify">
					    <li>
						<input type="radio" name="q4-response" value="q4_option1" style="margin-right:20px;"><?php echo $test->q4_option1; ?></input></li>
						<li>
						<input type="radio" name="q4-response" value="q3_option2" style="margin-right:20px;"><?php echo $test->q4_option2; ?></input></li>
						<li>
						<input type="radio" name="q4-response" value="q4_option3" style="margin-right:20px;"><?php echo $test->q4_option3; ?></input></li>
						<li>
						<input type="radio" name="q4-response" value="q4_option4" style="margin-right:20px;"><?php echo $test->q4_option4; ?></input></li>
					   </select>
					  <span class="q4-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span></ul>
					</p>
					
					</div>
				</div>
			</div>
		 
		<?php } ?>
		
		<?php if($testdetail->test_id==22){ 
			//echo "<pre>";print_r($test);
		?>
		<div class="otw-row" style="margin-bottom: -80px;">
		   		<div class="otw-twentyfour otw-columns" style="padding-right:30px;">
		   		   
				 <div class="otw-twelve otw-column">
				 <!-- <div style="background-color: #eee;border-radius: 10px;"><p align="center">Click "NEXT" to continue.</p></div>-->
				  <p align="center">
				      <?php echo $test->passage;?>
				    </p>
				 </div> 
				<div class="otw-twelve otw-column">
					<div class="col-sm-6" >

					<p>1. <?php echo $test->q1_question; ?>
					<br>
						<input type="checkbox" name="q1_response" value="<?php echo $test->q1_option1; ?>" onclick="return myfnc()" style="margin-right:20px;"><?php echo $test->q1_option1; ?>
						<br>
						     <input type="checkbox" name="q1_response" value="<?php echo $test->q1_option2; ?>" onclick="return myfnc()" style="margin-right:20px;"><?php echo $test->q1_option2; ?>
						    <br> 
						 
						<input type="checkbox" name="q1_response" value="<?php echo $test->q1_option3; ?>" onclick="return myfnc()" style="margin-right:20px;"><?php echo $test->q1_option3; ?>
					<br>
					
						     <input type="checkbox" onclick="return myfnc()" name="q1_response" value="<?php echo $test->q1_option4; ?>" style="margin-right:20px;"><?php echo $test->q1_option4; ?>
						<br>     
						 <input type="checkbox" onclick="return myfnc()" name="q1_response" value="<?php echo $test->q1_option5; ?>" style="margin-right:20px;"><?php echo $test->q1_option5; ?>
						<br>
						<input type="checkbox" onclick="return myfnc()" name="q1_response" value="<?php echo $test->q1_option6; ?>" style="margin-right:20px;"><?php echo $test->q1_option6; ?>
						<br>
						     <input type="checkbox" onclick="return myfnc()" name="q1_response" value="<?php echo $test->q1_option7; ?>" style="margin-right:20px;"><?php echo $test->q1_option7; ?>
						<br>
							<p>2. <?php echo $test->q2_question; ?>
					<br>
						<input type="checkbox" name="q2_response" value="<?php echo $test->q2_option1; ?>" onclick="return fnc()" style="margin-right:20px;"><?php echo $test->q2_option1; ?>
						<br>
						     <input type="checkbox" name="q2_response" value="<?php echo $test->q2_option2; ?>" onclick="return fnc()" style="margin-right:20px;"><?php echo $test->q2_option2; ?>
						    <br> 
						 
						<input type="checkbox" name="q2_response" value="<?php echo $test->q2_option3; ?>" onclick="return fnc()" style="margin-right:20px;"><?php echo $test->q2_option3; ?>
					<br>
					
						     <input type="checkbox" onclick="return fnc()" name="q2_response" value="<?php echo $test->q2_option4; ?>" style="margin-right:20px;"><?php echo $test->q2_option4; ?>
						<br>     
						 <input type="checkbox" onclick="return fnc()" name="q2_response" value="<?php echo $test->q2_option5; ?>" style="margin-right:20px;"><?php echo $test->q2_option5; ?>
						<br>
						<input type="checkbox" onclick="return fnc()" name="q2_response" value="<?php echo $test->q2_option6; ?>" style="margin-right:20px;"><?php echo $test->q2_option6; ?>
						<br>
						     <input type="checkbox" onclick="return fnc()" name="q2_response" value="<?php echo $test->q2_option7; ?>" style="margin-right:20px;"><?php echo $test->q2_option7; ?>
						<br>
					<span style="color:red;" id="invalid"></span>
						<span class="q2-sel-opt-text" style="border-bottom:1px solid #ccc;color:#008000"></span>
					</div>
				</div>
				<div class="otw-sc-hr"></div>
			</div>
		</div>
		<?php } ?>
		
		
		<input type="hidden" name="token" value="<?php echo $this->uri->segment(3); ?>"/>
       <div class="page-title-wrapper fixed-width">
        <div class="otw-row page-title">
            <div class="otw-ten otw-columns"></div>		
        <div class="otw-four otw-columns">
			<?php if($testdetail->test_id==50){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls8_next_btn" data-screenid="2"><div class="submit" align="center">Next</div></a>
			<?php }  else if($testdetail->test_id==13){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls3_submit_btn" data-screenid="2"><div class="submit" align="center">Submit</div></a>
			
			<?php } else if($testdetail->test_id==11){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls1_submit_btn" data-screenid="2"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==12){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls2_submit_btn" data-screenid="2"><div class="submit" align="center">Submit</div></a>
			<?php }	else if($testdetail->test_id==14){ ?>
			    <a href="javascript:void(0);" style="color:#fff" class="ls4_submit_btn" data-screenid="2"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==16){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls6_submit_btn" data-screenid="2"><div class="submit" align="center">Submit</div></a>	
			<?php } else if($testdetail->test_id==15){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="ls5_submit_btn" ><div class="submit" align="center">Submit</div></a>	
			<?php } else if($testdetail->test_id==31){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="gr1_submit_btn"><div class="submit" align="center">Submit</div></a>	
			<?php } else if($testdetail->test_id==32){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="gr2_submit_btn"><div class="submit" align="center">Submit</div></a>	
			<?php } else if($testdetail->test_id==33){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="gr3_submit_btn"><div class="submit" align="center">Submit</div></a>	
			<?php } else if($testdetail->test_id==34){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="gr4_submit_btn"><div class="submit" align="center">Submit</div></a>	
			<?php } else if($testdetail->test_id==35){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="gr5_submit_btn"><div class="submit" align="center">Submit</div></a>	
			<?php } else if($testdetail->test_id==21){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd1_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==22){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd2_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==23){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd3_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==24){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd4_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==25){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd5_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==26){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd6_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==27){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd7_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==28){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd8_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==29){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd9_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==30){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="rd10_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==36){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="gr6_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==37){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="gr7_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==41){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="wt1_submit_btn"><div class="submit" align="center">Submit</div></a>
				<?php } else if($testdetail->test_id==42){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="wt2_submit_btn"><div class="submit" align="center">Submit</div></a>
		
			<?php } else if($testdetail->test_id==59){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="sp_practice_submit"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==62){ ?>
			<a href="javascript:void(0);" style="color:#fff" class="sp2_next_btn upload" id="stopButtonOld" data-screenid="2"><div class="submit" align="center">Next</div></a>
			<?php } else if($testdetail->test_id==63){ ?>
			<a href="javascript:void(0);" style="color:#fff" class="sp3_next_btn upload" id="stopButtonOld" data-screenid="2"><div class="submit" align="center">Next</div></a>
			<?php } else if($testdetail->test_id==64){ ?>
			<a href="javascript:void(0);" style="color:#fff" class="sp4_next_btn upload" id="stopButtonOld" data-screenid="2"><div class="submit" align="center">Next</div></a>
			<?php } else if($testdetail->test_id==52){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="gw2_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php } else if($testdetail->test_id==51){ ?>
				<a href="javascript:void(0);" style="color:#fff" class="gw1_submit_btn"><div class="submit" align="center">Submit</div></a>
			<?php }else{ ?> 
				<!--a href="#"><div align="center">submit</div></a-->
			<?php } ?>
		</div>
        <div class="otw-ten otw-columns"></div>
          <!--<div class="otw-nineteen otw-columns">-->
           
                <!--input type="submit" title="Answer Key" name="submit" value="Answer Key"-->
            
          <!--</div>-->
         <!-- <div class="otw-five otw-columns">-->
            <!--<form action="#" method="get" role="search" class="searchform">
                <input type="submit" title="Back" name="submit" value="Back">
            </form>-->
          <!--</div>-->
        </div>
        
      </div>
    </div>
      </div>

    </div>

     <footer id="page-footer">
      
      <div class="otw-row copyright">
        <div class="otw-twelve otw-columns">
          
        </div>
        <div class="otw-twelve otw-columns text-right">
          <a href="#"><!--img src="images/logo-celpip-footer.png" title="celpip" alt=""/--></a>
           &copy; 2020 All rights reserved.
        </div>
      </div>
    </footer>
  </div>
<script type="text/javascript">
	function show() { document.getElementById('area').style.display = 'block'; }
	function hide() { document.getElementById('area').style.display = 'none'; }
</script>
  <?php include_once('common/scripts.php'); ?>
  
 

<?php if($testdetail->test_id==62){ ?>
<script type="text/javascript">
var timeLeft = 40;
var elem = document.getElementById('timer_div');
var timerId = setInterval(countdown, 1000);
function countdown() {
	if(timeLeft == 0) {
	$("#recordButtonOld").trigger("click");

  } else {
	elem.innerHTML = timeLeft + ' seconds remaining';
	timeLeft--;
  }
}
</script>
<?php } ?>
<?php if($testdetail->test_id==63){ ?>
<script type="text/javascript">
var timeLeft = 6;
var elem = document.getElementById('timer_div');
var timerId = setInterval(countdown, 1000);
function countdown() {
	if(timeLeft == 0) {
	$("#recordButtonOld").trigger("click");

  } else {
	elem.innerHTML = timeLeft + ' seconds remaining';
	timeLeft--;
  }
}
</script>
<?php } ?>

<?php if($testdetail->test_id==64){ ?>
<script type="text/javascript">
var timeLeft = 40;
var elem = document.getElementById('timer_div');
var timerId = setInterval(countdown, 1000);
function countdown() {
	if(timeLeft == 0) {
	$("#recordButtonOld").trigger("click");

  } else {
	elem.innerHTML = timeLeft + ' seconds remaining';
	timeLeft--;
  }
}
</script>
<?php } ?>


<?php if($testdetail->test_id==62 || $testdetail->test_id==63 || $testdetail->test_id==64 ){
 ?>


<script src="https://cdn.rawgit.com/mattdiamond/Recorderjs/08e7abd9/dist/recorder.js"></script>




<script>

//webkitURL is deprecated but nevertheless

URL = window.URL || window.webkitURL;



var gumStream; 						//stream from getUserMedia()

var rec; 							//Recorder.js object

var input; 							//MediaStreamAudioSourceNode we'll be recording



// shim for AudioContext when it's not avb. 

var AudioContext = window.AudioContext || window.webkitAudioContext;

var audioContext //audio context to help us record



var recordButton = document.getElementById("recordButtonOld");

var stopButton = document.getElementById("stopButtonOld");




//add events to those 2 buttons

recordButton.addEventListener("click", startRecording);

stopButton.addEventListener("click", stopRecording);





function startRecording() {

	console.log("recordButton clicked");



	/*

		Simple constraints object, for more advanced audio features see

		https://addpipe.com/blog/audio-constraints-getusermedia/

	*/

    

    var constraints = { audio: true, video:false }



 	/*

    	Disable the record button until we get a success or fail from getUserMedia() 

	*/



	recordButton.disabled = true;

	stopButton.disabled = false;

var img = document.createElement("img");
 
img.src = "https://cdn.pixabay.com/photo/2017/01/10/03/54/icon-1968243_960_720.png";
img.style = "width:100px;margin:auto;";
var src = document.getElementById("x");
 
src.appendChild(img);
	document.getElementById("timer_div").style.display = "none";



	navigator.mediaDevices.getUserMedia(constraints).then(function(stream) {

		console.log("getUserMedia() success, stream created, initializing Recorder.js ...");



		/*

			create an audio context after getUserMedia is called

			sampleRate might change after getUserMedia is called, like it does on macOS when recording through AirPods

			the sampleRate defaults to the one set in your OS for your playback device



		*/

		audioContext = new AudioContext();



		//update the format 

		document.getElementById("formats").innerHTML="Format: 1 channel pcm @ "+audioContext.sampleRate/1000+"kHz"

<?php if($testdetail->test_id==62){ ?>
var time = 15;
var timeelem = document.getElementById('timer_audiodiv');
var timeId = setInterval(timecountdown, 1000);
function timecountdown() {
	if(time == 0) {
	$(stopButton).trigger("click");

  } else {
	timeelem.innerHTML = time + ' seconds remaining';
	time--;
  }
}
<?php } else if($testdetail->test_id==63){ ?>
var time = 40;
var timeelem = document.getElementById('timer_audiodiv');
var timeId = setInterval(timecountdown, 1000);
function timecountdown() {
	if(time == 0) {
	$(stopButton).trigger("click");

  } else {
	timeelem.innerHTML = time + ' seconds remaining';
	time--;
  }
}
<?php } else if($testdetail->test_id==64){ ?>
var time = 40;
var timeelem = document.getElementById('timer_audiodiv');
var timeId = setInterval(timecountdown, 1000);
function timecountdown() {
	if(time == 0) {
	$(stopButton).trigger("click");

  } else {
	timeelem.innerHTML = time + ' seconds remaining';
	time--;
  }
}
<?php } ?>


		/*  assign to gumStream for later use  */

		gumStream = stream;

		

		/* use the stream */

		input = audioContext.createMediaStreamSource(stream);



		/* 

			Create the Recorder object and configure to record mono sound (1 channel)

			Recording 2 channels  will double the file size

		*/

		rec = new Recorder(input,{numChannels:1})



		//start the recording process

		rec.record()



		console.log("Recording started");



	}).catch(function(err) {

	  	//enable the record button if getUserMedia() fails

    	recordButton.disabled = false;

    	stopButton.disabled = true;


	});

}






function stopRecording() {

	console.log("stopButton clicked");



	//disable the stop button, enable the record too allow for new recordings

	stopButton.disabled = true;

	recordButton.disabled = true;


	document.getElementById("x").style.display = "none"; 
	document.getElementById("timer_audiodiv").style.display = "none"; 

var utime = 1;
var utimerId = setInterval(ucountdown, 1000);
function ucountdown() {
  if (utime == 0) {
	clearTimeout(utimerId);
	$('.upload').trigger("click");
  } else {
	utime--;
  } 
    
}
var psubmit = document.createElement("p");
psubmit.style="font-size:18px; color:green";

 psubmit.innerHTML = 'Submitting Audio. Please wait before clicking "Next". We will notify when its done. ';
 
var pdiv = document.getElementById("ptext");	

pdiv.appendChild(psubmit);

$("#tooglebutton").css("display", "block");		      
	
	//tell the recorder to stop the recording

	rec.stop();



	//stop microphone access

	gumStream.getAudioTracks()[0].stop();



	//create the wav blob and pass it on to createDownloadLink

	rec.exportWAV(createDownloadLink);


}



function createDownloadLink(blob) {



	var url = URL.createObjectURL(blob);

	var au = document.createElement('audio');

	var li = document.createElement('li');

	var link = document.createElement('a');


	//name of .wav file to use during upload and download (without extendion)

	var filename = Math.random().toString(36).slice(2);

 var audi = document.createElement("input");
 
audi.type = "hidden";
audi.value = filename+ ".wav";
audi.name = "audiofile"; 
var audiodiv = document.getElementById("audioname");
 
audiodiv.appendChild(audi);

	//add controls to the <audio> element

	au.controls = true;

	au.src = url;



	//save to disk link

	link.href = url;

	link.download = filename+".wav"; //download forces the browser to donwload the file using the  filename

	link.innerHTML = "Download";



	//add the new audio element to li

	li.appendChild(au);

	

	//add the filename to the li

	li.appendChild(document.createTextNode(filename+".wav "))



	//add the save to disk link to li

	li.appendChild(link);

	

	//upload link



	$('.upload').click(function(){

		  var xhr=new XMLHttpRequest();

		  xhr.onload=function(e) {

		      if(this.readyState === 4) {

		          console.log("Server returned: ",e.target.responseText);

		      }

		  };
		 xhr.addEventListener("load", transferComplete);

		  var fd=new FormData();

		  fd.append("audio_data",blob, filename);

		  xhr.open("POST","https://app.ptezone.com/member/upload",true);

		  xhr.send(fd);
		  function transferComplete(evt) {
		      console.log("The transfer is complete.");
		      
		      $( ".audiosubmitlink" ).removeClass( "disabled-link" );
		      document.getElementById("ptext").style.display = "none"; 
document.getElementById("submit").innerHTML = 'Audio Submission Successful. Click "Next". ';
     	  }
	})

	li.appendChild(document.createTextNode (" "))//add a space in between

	li.appendChild(upload)//add the upload link to li



	//add the li element to the ol

	recordingsList.appendChild(li);

}







</script>

<?php } ?>

<script type="text/javascript">
$(document).ready(function() {
	$("#wt_q2_response").on('keydown', function(e) {
        var words = $.trim(this.value).length ? this.value.match(/\S+/g).length : 0;
		$('#display_count').text(words);
    });
    
   
	$("#gw_q2_response").on('keydown', function(e) {
        var words = $.trim(this.value).length ? this.value.match(/\S+/g).length : 0;
		$('#display_count').text(words);
    });
    $("#gw_q1_response").on('keydown', function(e) {
        var words = $.trim(this.value).length ? this.value.match(/\S+/g).length : 0;
		$('#display_count').text(words);
    });
    $("#wt_q1_response").on('keydown', function(e) {
        var words = $.trim(this.value).length ? this.value.match(/\S+/g).length : 0;
		$('#display_count').text(words);
        /* if (words <= 200) {
            $('#display_count').text(words);
            //$('#word_left').text(200-words)
        }else{
            if (e.which !== 8) e.preventDefault();
        } */
    });
}); 
</script>
<script type="text/javascript">
// how many minutes
var mins = 5;

// how many seconds (don't change this)
var secs = mins * 60;
function countdown() {
	setTimeout('Decrement()',1000);
}
function Decrement() {
	if (document.getElementById(Timer)) {
		minutes = document.getElementById("minutes");
		seconds = document.getElementById("seconds");
		// if less than a minute remaining
		if (seconds < 59) {
			seconds.value = secs;
		} else {
			minutes.value = getminutes();
			seconds.value = getseconds();
		}
		secs--;
		if(secs >0)
{
setTimeout('Decrement()',1000);


} else {
		document.forms[0].submit.click();
		//HERE IS YOUR TEXT WHEN THE TIME EXPIRES
		alert('The time expired');
		}

	}
}
function getminutes() {
	// minutes is seconds divided by 60, rounded down
	mins = Math.floor(secs / 60);
	return mins;
}
function getseconds() {
	// take mins remaining (as seconds) away from total seconds remaining
	return secs-Math.round(mins *60);
}

</script>        
	 <script type="text/javascript">  
						 function myfun(){
						     var a = document.getElementsByName("q1response");
						     var newvar = 0;
						     var count;
						     for(count=0; count<a.length; count++){
						     if(a[count].checked==true){
						         newvar = newvar + 1;
						     }
						     }
						     if(newvar>=4)
						     {document.getElementById("invalid").innerHTML=
						         "**Please select only 3 options"
						         return false;
						     }
						     
						     }
						     function myfun4(){
						     var a = document.getElementsByName("q1response");
						     var newvar = 0;
						     var count;
						     for(count=0; count<a.length; count++){
						     if(a[count].checked==true){
						         newvar = newvar + 1;
						     }
						     }
						     if(newvar>=3)
						     {document.getElementById("invalid").innerHTML=
						         "**Please select only 2 options"
						         return false;
						     }
						     
						     }
						 </script>
						 	 <script type="text/javascript">  
						 function myfnc(){
						     var a = document.getElementsByName("q1_response");
						     var newvar = 0;
						     var count;
						     for(count=0; count<a.length; count++){
						     if(a[count].checked==true){
						         newvar = newvar + 1;
						     }
						     }
						     if(newvar>=3)
						     {document.getElementById("invalid").innerHTML=
						         "**Please select only 2 options"
						         return false;
						     }
 						 }
						 </script>
						 <script>
						 function fnc(){
						     var a = document.getElementsByName("q2_response");
						     var newvar = 0;
						     var count;
						     for(count=0; count<a.length; count++){
						     if(a[count].checked==true){
						         newvar = newvar + 1;
						     }
						     }
						     if(newvar>=3)
						     {document.getElementById("invalid").innerHTML=
						         "**Please select only 2 options"
						         return false;
						     }
 						 }
						 </script>
						
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
                       
                                  
                                  <script>
$(document).ready(function() {

  function makedraggable() {
     $(".qitem2").draggable({
     		"revert": "invalid"
     		
     });
  }
  
  makedraggable();
     
     $(".droppable-element").droppable({
        "accept": ".qitem2",
        "drop": function(event, ui) {
            debugger;
            if ($(this).find(".qitem2").length) {
                
                var $presentChild = $(this).find(".qitem2"),
                    currChildId = $presentChild.attr("id"),
                    $currChildContainer = $("#" + currChildId + "-container");                  
               $currChildContainer.append($presentChild);
               $presentChild.removeAttr("style");
               makedraggable();
                           
            }
            
            $(ui.draggable).clone().appendTo(this).removeAttr("style");
            $(ui.draggable).remove();
        }
     })
$.ui.draggable.prototype.destroy = function (ul, item) { };
})





var shuffleKeys = function() {
    $("#answers > .drag-container").sort(function(a, b) {
        return Math.random() - 0.5;
    }).prependTo($("#answers"));
};

shuffleKeys();

</script>

</body>
</html>