<!DOCTYPE html>
<html>
<head>
    <title><?php echo $meta['title']; ?></title>

    <base href="<?php echo base_url("/theme/default"); ?>/">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- jvectormap -->
    <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
     folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <script src="https://www.google.com/recaptcha/api.js"></script>
    <style type="text/css">
     .login-page, .register-page {
        background: #152733;
      }

      .login-logo a, .register-logo a {
        color: #fff;
      }

      .login-box-body, .register-box-body {
        border: 1px solid #666;
        background: #152733;
        padding: 20px;
        color: #fff;
        border-radius: 6px;
        padding-bottom: 20px;
      }
    </style>>

</head>
<body class="hold-transition login-page">
<div class="login-box">
  
  <!-- /.login-logo -->
  <div class="col-xs-12 login-box-body">

    <div class="login-logo">
    <a>
      <?php if($pagetitle == 'Student Login') { ?>
        <b>Student</b> Login
      <?php } ?>

      <?php if($pagetitle == 'Super Admin Login') { ?>
        <b>SuperAdmin</b> Login
      <?php } ?>

      <?php if($pagetitle == 'Teacher Login') { ?>
        <b>Teacher</b> Login
      <?php } ?>
	  
	  <?php if($pagetitle == 'Reseller Login') { ?>
        <b>Reseller</b> Login
      <?php } ?>

	  <?php if($pagetitle == 'Tycoon Login') { ?>
        <b>Tycoon</b> Login
      <?php } ?>
	  
	  <?php if($pagetitle == 'Business Login') { ?>
        <b>Business</b> Login
      <?php } ?>

    </a>
  </div>

    <p class="login-box-msg">Sign in to start your session</p>

     <?php echo validation_errors(); ?>
     <?php echo form_open($formAction) ?>

      <div class="form-group has-feedback">
        <input type="text" name="username" class="form-control" placeholder="Username"  value="<?php echo set_value('username'); ?>" required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Password" name="password" class="form-control"  required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      		<div class="form-group">
                            <div class="g-recaptcha" data-sitekey="<?php echo $this->recaptcha_sitekey; ?>"></div>
                            
                            <!-- <input class="form-control d-none" data-recaptcha="true" required data-error="Please complete the Captcha">
                            <div class="help-block with-errors"></div> -->
                        </div>
      <div class="row">
        
        <div class="col-xs-12">
          <button type="submit" class="btn btn-info btn-block btn-flat">Sign In</button>
        </div>

                       

                <?php if($pagetitle == 'Student Login') { ?>
                  <p class="login-box-msg">or</p>
                  <p class="login-box-msg">if you are not registered yet</p>

                  <div class="col-xs-12">
                    <a href="<?php echo base_url('/registration'); ?>" class="btn btn-danger btn-block btn-flat" target="_blank"><i class="fa fa-user"></i> Register a new membership</a>
                  </div>
                <?php } ?>      

      </div>
    </form>

  </div>
  <!-- /.login-box-body -->
</div>




<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    
  });
</script>



</body>
</html>
