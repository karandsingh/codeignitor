<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-purple sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?></li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-6">
         
          <div class="box">
            <div class="box-header">
            </div>




      


            <!-- /.box-header -->
            <div class="box-body">


                                   <?php if($this->session->flashdata('global_msg')){ ?>
										 <div class="alert alert-success">
										  <button class="close" type="button" data-dismiss="alert">
											<span aria-hidden="true">&times;</span>
										  </button>
										  <?=$this->session->flashdata('global_msg')?>
										</div>
									<?php } ?>

                                    <?php echo validation_errors(); ?>
                                    
                                    <?php

                                    //Form syntex echo form_open('form/data_submitted'); 
                                    echo form_open_multipart('superadmin/editvlevel/'.$this->uri->rsegment(3).'', array('id' => mb_strtolower($this->uri->rsegment(3)), 'class' => 'clearfix' )); ?>


                                  
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Category Name</label>
                                                <input type="text" class="form-control" placeholder="abc" name="level_name" required value="<?php echo set_value('level_name',$level->name); ?>">
                                            </div>
											<div class="form-group">
                                                <label>Coin Cost</label>
                                                <input type="text" class="form-control" placeholder="1" name="coin_cost" required value="<?php echo set_value('coin_cost',$level->coin_cost); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    

                                   

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Edit </button>
                                    <div class="clearfix"></div>
                                </form>
                            
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

 
  <?php include_once('common/scripts.php'); ?>
</body>
</html>
