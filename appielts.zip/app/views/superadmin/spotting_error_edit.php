<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?><small><?php echo $pagetitle; ?> details</small></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?> Manager </li>
      </ol>
    </section>

    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <div class="box">
                  <div class="box-header">
                    <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
                      <h4><i class="fa fa-info"></i> Note:</h4>
                      Edit Spotting Error Passage</strong>
                      <a href="<?php echo base_url('superadmin/spotting_ErrorTests'); ?>">   <span class="pull-right badge bg-red">Click here to Go Back</span></a>
                    </div>
                  </div>
				  
				  <?php if($this->session->flashdata('global_msg')){ ?>
					 <div class="alert alert-success">
					  <button class="close" type="button" data-dismiss="alert">
						<span aria-hidden="true">&times;</span>
					  </button>
					  <?=$this->session->flashdata('global_msg')?>
					</div>
				   <?php } ?>

                  <div class="box-body">

                    <?php
                      if($errors) {
                        foreach ($errors as $error) {
                          echo '<div class="alert alert-danger">'.$error.'</div>';
                        }
                      }
                    ?>
					
                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('superadmin/spotting_ErrorEdit/'.$this->uri->segment(3), array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>

                       <hr />
					   
					    <div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Passage</label>
									<textarea class="form-control" rows="10" name="passage" placeholder="Place some text here" required=""><?php echo set_value('passage',$test->passage); ?></textarea>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>1st Question Option 1</label>
								<input type="text" class="form-control" placeholder="text" name="q1_option1" required value="<?php echo set_value('q1_option1',$test->q1_option1); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>1st Question Option 2</label>
								<input type="text" class="form-control" placeholder="text" name="q1_option2" required value="<?php echo set_value('q1_option2',$test->q1_option2); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>1st Question Option 3</label>
								<input type="text" class="form-control" placeholder="text" name="q1_option3" required value="<?php echo set_value('q1_option3',$test->q1_option3); ?>">
								</div>
							</div>

						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>1st Question Option 4</label>
								<input type="text" class="form-control" placeholder="text" name="q1_option4" required value="<?php echo set_value('q1_option4',$test->q1_option4); ?>">
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 1st Question Correct Answer</label>
								<select class="form-control" name="q1_answere" required>
								<option value="">Select</option>
								<option <?php if($test->q1_answere==1){ echo 'selected'; }?> value="1">Option 1</option>
								<option <?php if($test->q1_answere==2){ echo 'selected'; }?> value="2">Option 2</option>
								<option <?php if($test->q1_answere==3){ echo 'selected'; }?> value="3">Option 3</option>
								<option <?php if($test->q1_answere==4){ echo 'selected'; }?> value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>2nd Question Option 1</label>
								<input type="text" class="form-control" placeholder="text" name="q2_option1" required value="<?php echo set_value('q2_option1',$test->q2_option1); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>2nd Question Option 2</label>
								<input type="text" class="form-control" placeholder="text" name="q2_option2" required value="<?php echo set_value('q2_option2',$test->q2_option2); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>2nd Question Option 3</label>
								<input type="text" class="form-control" placeholder="text" name="q2_option3" required value="<?php echo set_value('q2_option3',$test->q2_option3); ?>">
								</div>
							</div>

						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>2nd Question Option 4</label>
								<input type="text" class="form-control" placeholder="text" name="q2_option4" required value="<?php echo set_value('q2_option4',$test->q2_option4); ?>">
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 2nd Question Correct Answer</label>
								<select class="form-control" name="q2_answere" required>
								<option value="">Select</option>
								<option <?php if($test->q2_answere==1){ echo 'selected'; }?> value="1">Option 1</option>
								<option <?php if($test->q2_answere==2){ echo 'selected'; }?> value="2">Option 2</option>
								<option <?php if($test->q2_answere==3){ echo 'selected'; }?> value="3">Option 3</option>
								<option <?php if($test->q2_answere==4){ echo 'selected'; }?> value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>3rd Question Option 1</label>
								<input type="text" class="form-control" placeholder="text" name="q3_option1" required value="<?php echo set_value('q3_option1',$test->q3_option1); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>3rd Question Option 2</label>
								<input type="text" class="form-control" placeholder="text" name="q3_option2" required value="<?php echo set_value('q3_option2',$test->q3_option2); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>3rd Question Option 3</label>
								<input type="text" class="form-control" placeholder="text" name="q3_option3" required value="<?php echo set_value('q3_option3',$test->q3_option3); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>3rd Question Option 4</label>
								<input type="text" class="form-control" placeholder="text" name="q3_option4" required value="<?php echo set_value('q3_option4',$test->q3_option4); ?>">
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 3rd Question Correct Answer</label>
								<select class="form-control" name="q3_answere" required>
								<option value="">Select</option>
								<option <?php if($test->q3_answere==1){ echo 'selected'; }?> value="1">Option 1</option>
								<option <?php if($test->q3_answere==2){ echo 'selected'; }?> value="2">Option 2</option>
								<option <?php if($test->q3_answere==3){ echo 'selected'; }?> value="3">Option 3</option>
								<option <?php if($test->q3_answere==4){ echo 'selected'; }?> value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>4th Question Option 1</label>
								<input type="text" class="form-control" placeholder="text" name="q4_option1" required value="<?php echo set_value('q4_option1',$test->q4_option1); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>4th Question Option 2</label>
								<input type="text" class="form-control" placeholder="text" name="q4_option2" required value="<?php echo set_value('q4_option2',$test->q4_option2); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>4th Question Option 3</label>
								<input type="text" class="form-control" placeholder="text" name="q4_option3" required value="<?php echo set_value('q4_option3',$test->q4_option3); ?>">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								<label>4th Question Option 4</label>
								<input type="text" class="form-control" placeholder="text" name="q4_option4" required value="<?php echo set_value('q4_option4',$test->q4_option4); ?>">
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 4th Question Correct Answer</label>
								<select class="form-control" name="q4_answere" required>
								<option value="">Select</option>
								<option <?php if($test->q4_answere==1){ echo 'selected'; }?> value="1">Option 1</option>
								<option <?php if($test->q4_answere==2){ echo 'selected'; }?> value="2">Option 2</option>
								<option <?php if($test->q4_answere==3){ echo 'selected'; }?> value="3">Option 3</option>
								<option <?php if($test->q4_answere==4){ echo 'selected'; }?> value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						
						<button type="submit" class="btn btn-info btn-fill pull-right">Edit</button>
                         <div class="clearfix"></div> 
                      </form>

                  </div>

              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>