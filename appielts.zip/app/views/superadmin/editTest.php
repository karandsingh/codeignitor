<!doctype html>
<html lang="en">
<head>
<title><?php echo $window_title; ?></title>
<?php include_once('common/head.php'); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
  <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Test
        <small>Test details</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add New Test</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
            </div>




      


            <!-- /.box-header -->
            <div class="box-body">


                                   <?php if($success) { ?>
                                  <div class="alert alert-danger">
                                    Test Information successfully Updated.</br></br>
                                        
                                        <?php header( "refresh:1;url=" ); ?>

                                  </div>
                                  <?php } else { ?>

                                    <?php echo validation_errors(); ?>
                                    
                                    <?php 

                                    //Form syntex echo form_open('form/data_submitted'); 

                                     echo form_open($this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3), array('id' => $this->uri->segment(2),'role'=>'form')) ?>



                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Test type</label>
                                                <select class="form-control" name="testType" required>
                                                  <option value=""></option>

                <option <?php if($test->testType=='General Test'){echo "selected";}?>>General Test</option>
                <option <?php if($test->testType=='General LS Test'){echo "selected";}?>>General LS Test</option>




                                                </select>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Test name</label>
                                                <input type="text" class="form-control" name="test_name" required value="<?=$test->test_name?>"

                                                <?php if($test->id == '7') {?>readonly="readonly"<?php } ?>
                                                >
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Time</label>
                                                <input type="text" class="form-control" placeholder="e.g. 2 hours 54 minutes" name="total_time" required value="<?=$test->total_time?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Price</label>
                                                <input type="text" class="form-control" name="price" required value="<?=$test->price?>">
                                            </div>
                                        </div>
                                    </div>

                                   

                                    <button type="submit" class="btn btn-info btn-fill">Save</button>
                                    <div class="clearfix"></div>
                                </form>
                            
                              <?php } ?>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

 
  <?php include_once('common/scripts.php'); ?>
</body>
</html>
