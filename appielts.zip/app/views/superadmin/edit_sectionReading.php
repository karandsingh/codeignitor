<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Section Wise Reading Test
        <small>Test details</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Reading Test</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            </div>
            <!-- /.box-header -->
            <div class="box-body">
				<?php //echo "<pre>";print_r($test);die;
				echo validation_errors(); ?>
				<?php
					echo form_open_multipart('superadmin/editSectionReading/'.$test->id, array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Test name</label>
								<input type="text" class="form-control" name="test_name" required value="<?php echo set_value('test_name',$test->test_name); ?>">
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Practice Task</label>
								<select class="form-control" name="practice_code" required>
								<?php 
								foreach ($practice as $key => $practice_test) { ?>
								  <option value="<?=$practice_test->test_code?>" <?php if($test->practice_code==$practice_test->test_code){ echo 'selected'; }?>><?=$practice_test->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 1: Reading Correspondence</label>
								<select class="form-control" name="part1_code" required>
								<?php foreach ($rdpart1 as $key => $part1) { ?>
								  <option value="<?=$part1->test_code?>" <?php if($test->part1_code==$part1->test_code){ echo 'selected'; }?>><?=$part1->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
				   
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 2: Reading to Apply a Diagram</label>
								<select class="form-control" name="part2_code" required>
								<?php foreach ($rdpart2 as $key => $part2) { ?>
								  <option value="<?=$part2->test_code?>" <?php if($test->part2_code==$part2->test_code){ echo 'selected'; }?>><?=$part2->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 3: Reading for Information</label>
								<select class="form-control" name="part3_code" required>
								<?php foreach ($rdpart3 as $key => $part3) { ?>
								  <option value="<?=$part3->test_code?>" <?php if($test->part3_code==$part3->test_code){ echo 'selected'; }?>><?=$part3->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 4: Reading for Viewpoints</label>
								<select class="form-control" name="part4_code" required>
								<?php foreach ($rdpart4 as $key => $part4) { ?>
								  <option value="<?=$part4->test_code?>" <?php if($test->part4_code==$part4->test_code){ echo 'selected'; }?>><?=$part4->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
					
					<button type="submit" class="btn btn-info btn-fill">Edit</button>
					<div class="clearfix"></div>
				</form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>