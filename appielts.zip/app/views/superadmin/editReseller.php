<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Reseller
        <small>Reseller details</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Reseller</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
            </div>




      


            <!-- /.box-header -->
            <div class="box-body">


                            
                                   <?php if($success) { ?>
                                  <div class="alert alert-success">
                                    Reseller Information successfully Updated.</br></br>
                                        
                                        <?php header( "refresh:1;url=" ); ?>

                                  </div>
                                  <?php } else { ?>

                                    <?php echo validation_errors(); ?>
                                    
                                    <?php 

                                    //Form syntex echo form_open('form/data_submitted'); 

                                     echo form_open($this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3), array('id' => $this->uri->segment(2),'role'=>'form')) ?>


                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label> Name</label>
                                                <input type="text" class="form-control"  placeholder="singh" name="name" required value="<?=$reseller->name?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Username</label>
                                                <input type="text" class="form-control" placeholder="Username" name="username" required value="<?=$reseller->username?>" >
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address</label>
                                                <input type="email" class="form-control" placeholder="Email" name="email" required value="<?=$reseller->email?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Password</label>
                                                <input type="text" class="form-control" placeholder="Password" name="password" required value="<?=$reseller->notMD5password?>">
                                            </div>
                                        </div>
										<div class="col-md-3">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address</label>
                                                <input type="email" class="form-control" placeholder="Email" name="email" required value="<?=$reseller->email?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Reference Number</label>
                                                <input type="text" class="form-control" placeholder="" name="reference_no" required value="<?=$reseller->reference_no?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" class="form-control" placeholder="Home Address"  name="street_address" required value="<?=$reseller->street_address?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>City</label>
                                                <input type="text" class="form-control" placeholder="Mohali" name="city_region" required value="<?=$reseller->city_region?>">
                                            </div>
                                        </div>

                                      <?php
                                      $whare="id !='0' "; 
                                      $countries = $this->my_model->getWhereRecords('system_countries_code',$whare);
                                      ?>
                                      

                                    
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <select class="form-control" name="country_id" >


                                                <?php 
                                                if($countries!=NULL)
                                                {
                                                foreach ($countries as $key => $country) { ?>

                                                <?php if($reseller->country_id==$country->id){ ?>

                                                  <option value="<?=$country->id?>" selected><?=$country->name?></option>

                                                 <?php }else{ ?>

                                                  <option value="<?=$country->id?>"><?=$country->name?></option>
                                                 
                                                <?php }}}?>

                                              </select>

                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Postal Code</label>
                                                <input type="number" class="form-control" placeholder="ZIP Code" name="postal_code" required value="<?=$reseller->postal_code?>">
                                            </div>
                                        </div>
                                    </div>

                                   

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Save</button>
                                    <div class="clearfix"></div>
                                </form>
                            
                              <?php } ?>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>

 
  <?php include_once('common/scripts.php'); ?>
</body>
</html>
