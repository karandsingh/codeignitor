<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?><small><?php echo $pagetitle; ?> details</small></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?> Manager </li>
      </ol>
    </section>


    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <div class="box">
                  <div class="box-header">
                    <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
                      <h4><i class="fa fa-info"></i> Note:</h4>
                      Add Coins</strong>
                      <a href="<?php echo base_url('superadmin/blog'); ?>">   <span class="pull-right badge bg-red">Click here to Go Back</span></a>
                    </div>
                  </div>
				  
				  <?php if($this->session->flashdata('global_msg')){ ?>
					 <div class="alert alert-success">
					  <button class="close" type="button" data-dismiss="alert">
						<span aria-hidden="true">&times;</span>
					  </button>
					  <?=$this->session->flashdata('global_msg')?>
					</div>
				   <?php } ?>

                  <div class="box-body">
                    <table class="table table-bordered">
                      <tr>
                        <td>Coins</td>
                      </tr>
                    </table>

                    <?php
                      if($errors) {
                        foreach ($errors as $error) {
                          echo '<div class="alert alert-danger">'.$error.'</div>';
                        }
                      }
                    ?>

                    <?php if($success) { ?>
                      <div class="alert alert-success">
                        <?php header( "refresh:2;url=" ); ?>
                        New Data have been added successfully.</br></br>
                        Have a great day!
                      </div>
                    <?php } else { ?>

                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('superadmin/addcoins/', array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>

                          <hr />
						  
						
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Cost for coins (just add number)</label>
									<input type="cost" class="form-control" placeholder="10" name="cost" value="" required>
								</div>
							</div>
						</div>
					
						
							
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Total coins</label>
									<input type="text" class="form-control" placeholder="10000" name="coins" value="" required>
								</div>
							</div>
						</div>
					
					
						
						
						
					
					
						  
						  
						 <button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
                         <div class="clearfix"></div> 

                          <?php
                            //$PTEsubid=$this->uri->segment(3);
                            //Load Template As per PTE test subtype: question/subid.php
                            //include_once("question/$PTEsubid.php");
                          ?>
                      </form>
                    <?php } ?>

                  </div>


              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>