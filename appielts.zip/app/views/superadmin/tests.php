<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Test Manager 
        <small>Manage CELPIP Tests</small>
      </h1>
      <ol class="breadcrumb">
        <li><a><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">CELPIP Tests</h3>
            </div>




          <?php if (@$_GET['trash']) { ?>
                      <div class="alert alert-success">
                      <button class="close" type="button" data-dismiss="alert">
                      <span aria-hidden="true">&times;</span>
                      </button>
                      user information deleted.
                      </div>
                      <?php } ?>

            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr No</th>
                    <th>Test Name</th>
                    <th>Total Question</th>
                    <th>Type</th>
                    <th>Total Time</th>
                    <th>Created Date</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                <?php
                  if (!empty($tests)) {
                    $myCounter = 0;
                    foreach ($tests as $key => $test) {
                      $myCounter++;

                      $where = "testid = '".$test->id."' ";
                      $allQuestions = $this->my_model->getWhereOrderRecords($this->tb_question, $where, 'id', 'asc');

                      ?>
                        <tr>
                          <td><span class="online"><?php echo $myCounter; ?></span></td>
                          <td><span class="online"><?=$test->test_name?></span></td>
                          <td><span class="online"><?php echo count($allQuestions); ?></span></td>
                          <td><span class="online"><?=$test->testType?></span></td>
                          <td><span class="online"><?=$test->total_time?></span></td>
                          <td><span class="online"><?=date("d-m-Y",$test->time)?></span></td>
                          <td><span class="label label-success"><?=$test->status?></span></td>
                          <td>
                          
                            <a href="<?php echo base_url($currentPath.'/editTest/'.$test->id); ?>" class="btn btn-xs btn-primary" title="Edit" data-toggle="tooltip"><i class="fa fa-edit"></i></a>

                            <?php if($test->id != '7') { // sample test?>
                            <?php $_onClick = "onclick=\"return confirm('Are you sure you want to delete ".$test->test_name." ? This action will delete all data owned by this Client.')\"";?>
                            <a href="<?php echo base_url($currentPath.'/deleteTest/'.$test->id); ?>" class="btn btn-xs btn-danger" title="Delete" <?php echo $_onClick; ?> data-toggle="tooltip" data-placement="left"><i class="fa fa-trash-o"></i> </a>
                            <?php } ?>

                          </td>
                        </tr>

                <?php }} ?>
     


                          </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
</body>
</html>
