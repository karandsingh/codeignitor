<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Section Wise Listening Test
        <small>Test details</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Listening Test</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            </div>
            <!-- /.box-header -->
            <div class="box-body">
				<?php echo validation_errors(); ?>
				<?php
					echo form_open_multipart('superadmin/editSectionListening/'.$test->id, array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Test name</label>
								<input type="text" class="form-control" name="test_name" required value="<?php echo set_value('test_name',$test->test_name); ?>">
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Practice Task</label>
								<select class="form-control" name="practice_code" required>
								<?php 
								foreach ($practice as $key => $practice_test) { ?>
								  <option value="<?=$practice_test->test_code?>" <?php if($test->practice_code==$practice_test->test_code){ echo 'selected'; }?>><?=$practice_test->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 1: Listening to Problem Solving</label>
								<select class="form-control" name="part1_code" required>
								<?php foreach ($lspart1 as $key => $part1) { ?>
								  <option value="<?=$part1->test_code?>" <?php if($test->part1_code==$part1->test_code){ echo 'selected'; }?>><?=$part1->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
				   
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 2: Listening to Daily Life Conversation</label>
								<select class="form-control" name="part2_code" required>
								<?php foreach ($lspart2 as $key => $part2) { ?>
								  <option value="<?=$part2->test_code?>" <?php if($test->part2_code==$part2->test_code){ echo 'selected'; }?>><?=$part2->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 3: Listening For Information</label>
								<select class="form-control" name="part3_code" required>
								<?php foreach ($lspart3 as $key => $part3) { ?>
								  <option value="<?=$part3->test_code?>" <?php if($test->part3_code==$part3->test_code){ echo 'selected'; }?>><?=$part3->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 4: Listening to a News Item</label>
								<select class="form-control" name="part4_code" required>
								<?php foreach ($lspart4 as $key => $part4) { ?>
								  <option value="<?=$part4->test_code?>" <?php if($test->part4_code==$part4->test_code){ echo 'selected'; }?>><?=$part4->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 5: Listening to a Discussion</label>
								<select class="form-control" name="part5_code" required>
								<?php foreach ($lspart5 as $key => $part5) { ?>
								  <option value="<?=$part5->test_code?>" <?php if($test->part5_code==$part5->test_code){ echo 'selected'; }?>><?=$part5->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Part 6: Listening to View Points</label>
								<select class="form-control" name="part6_code" required>
								<?php foreach ($lspart6 as $key => $part6) { ?>
								  <option value="<?=$part6->test_code?>" <?php if($test->part6_code==$part6->test_code){ echo 'selected'; }?>><?=$part6->test_code?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
					<button type="submit" class="btn btn-info btn-fill">Edit</button>
					<div class="clearfix"></div>
				</form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>