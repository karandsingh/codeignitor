<div class="row">
  <div class="col-md-4">
      <div class="form-group">
          <label>Select Test</label>
          <select class="form-control" name="testid" >
            <?php if($tests) { foreach ($tests as $key => $test) { ?>
              <option value="<?=$test->id?>"><?=$test->test_name?></option>
            <?php }} ?>
          </select>
      </div>
  </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Question Title</label>
            <input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question'); ?>" required>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
          <label for="mp3URL">Question Audio </label>   
          <input id="mp3URL" name="mp3URL" type="file" accept=".mp3,audio/*"  required>
          <p class="help-block">Please attach MP3 format </p>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Option 1</label>
        <input type="text" class="form-control" placeholder="text" name="option1" required value="<?php echo set_value('option1'); ?>">
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Option 2</label>
        <input type="text" class="form-control" placeholder="text" name="option2" required value="<?php echo set_value('option2'); ?>">
        </div>
    </div>

</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Option 3</label>
        <input type="text" class="form-control" placeholder="text" name="option3" required value="<?php echo set_value('option3'); ?>">
        </div>
    </div>

</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Option 4</label>
        <input type="text" class="form-control" placeholder="text" name="option4" required value="<?php echo set_value('option4'); ?>">
        </div>
    </div>

</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group has-success">
        <label >Please Select Correct Answers</label>
        <select class="form-control" multiple="multiple" name="answer[]" required>
        <option value="1">Option 1</option>
        <option value="2">Option 2</option>
        <option value="3">Option 3</option>
        <option value="4">Option 4</option>
        </select>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
<div class="clearfix"></div>