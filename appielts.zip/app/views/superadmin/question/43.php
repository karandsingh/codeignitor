<div class="row">
  <div class="col-md-4">
      <div class="form-group">
          <label>Select Test</label>
          <select class="form-control" name="testid" >
            <?php if($tests) { foreach ($tests as $key => $test) { ?>
              <option value="<?=$test->id?>"><?=$test->test_name?></option>
            <?php }} ?>
          </select>
      </div>
  </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Question Title</label>
            <input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question'); ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
          <label for="exampleInputFile">Attach Image</label>
          <input id="exampleInputFile" name="SDimage" type="file" accept="image/*"  required>
          <p class="help-block">Please attach JPG JPEG or GIF format </p>
        </div>
    </div>
</div>


<button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
<div class="clearfix"></div>