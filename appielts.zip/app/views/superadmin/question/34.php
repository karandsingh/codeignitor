<div class="row">
  <div class="col-md-4">
      <div class="form-group">
          <label>Select Test</label>
          <select class="form-control" name="testid" >
            <?php if($tests) { foreach ($tests as $key => $test) { ?>
              <option value="<?=$test->id?>"><?=$test->test_name?></option>
            <?php }} ?>
          </select>
      </div>
  </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Question Title</label>
            <input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question'); ?>" required>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
          <label for="mp3URL">Question Audio </label>   
          <input id="mp3URL" name="mp3URL" type="file" accept=".mp3,audio/*"  required>
          <p class="help-block">Please attach MP3 format </p>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Transcription Of The Audio</label>

        <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;">

              <h4><i class="fa fa-exclamation-triangle"></i> Importent Note: </h4><b> Please add Span class to highlight incorrect words . Read below example to add incorrect words in Transcription Of The Audio</b></br>Example:<p>
              Researcher Marc Seifer, <mark>&lt;span class="icorrectw"&gt;word1&lt;/span&gt;</mark> astrophysicist <mark>&lt;span class="icorrectw"&gt;word2&lt;/span&gt;</mark> Travis Taylor and journalist Jason Stapleton study the life and work of an offbeat scientist, Nikolas Tesla journalist Jason Stapleton study the life and work of an offbeat . journalist Jason Stapleton study the life and work of an offbeat scientist . journalist Jason <mark>&lt;span class="icorrectw"&gt;word3&lt;/span&gt;</mark>Stapleton study the life and work of an offbeat scientist</p>
              
            </div> </br>

         <textarea class="form-control" rows="10" name="transcription" placeholder="Place some text here" required><?php echo set_value('question'); ?></textarea>
        </div>
    </div>
</div>

<div class="row hidden">
    <div class="col-md-12">
        <div class="form-group">
            <label>Correct Words (Fill in the blanks)</label><br>
              <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>
                 Note : Please separate all words with commas (eg.word1,word2,word3 etc)</div>
            <input type="text" class="form-control" placeholder="word1,word2,word3,word4,word5" name="words" value="word1,word2,word3,word4,word5" required>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
<div class="clearfix"></div>