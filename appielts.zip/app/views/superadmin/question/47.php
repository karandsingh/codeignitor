<div class="row">
  <div class="col-md-4">
      <div class="form-group">
          <label>Select Test</label>
          <select class="form-control" name="testid" >
            <?php if($tests) { foreach ($tests as $key => $test) { ?>
              <option value="<?=$test->id?>"><?=$test->test_name?></option>
            <?php }} ?>
          </select>
      </div>
  </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Question Title</label>
            <input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question'); ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Email Title</label>
            <textarea class="form-control" rows="5" name="essayTitle" placeholder="Place some text here" required><?php echo set_value('essayTitle'); ?></textarea>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
<div class="clearfix"></div>