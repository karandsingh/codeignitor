<div class="row">
  <div class="col-md-4">
      <div class="form-group">
          <label>Select Test</label>
          <select class="form-control" name="testid" >
            <?php if($tests) { foreach ($tests as $key => $test) { ?>
              <option value="<?=$test->id?>"><?=$test->test_name?></option>
            <?php }} ?>
          </select>
      </div>
  </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>
              Question Title 
              <span style="color: red;">*</span>
              (<small class="text-muted" style="font-weight: normal;">Only For Backend Purpose</small>)
            </label> 
            
            <input type="text" class="form-control" 
              name="question"
              value="<?php echo set_value('question'); ?>"
              required>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>
              Detail
              <span style="color: red;">*</span>
              (<small class="text-muted" style="font-weight: normal;">This is actual question detail which will display to students when they attempt question</small>)
            </label> 

            <textarea class="form-control" rows="8"
              id="detail" 
              name="detail" 
              required><?php echo set_value('detail'); ?></textarea>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
          <label>Choose Photo</label>
          <span style="color: red;">*</span>
          (<small class="text-muted" style="font-weight: normal;">This will display under question</small>)
          <input id="photo" name="photo" type="file" accept="image/*"  required>
          <p class="help-block">Please attach JPG JPEG or GIF format </p>
        </div>
    </div>
</div>


<button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
<div class="clearfix"></div>