<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Question Title</label>
            <input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question', $objQuestion->question); ?>" required>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-3">
        <div class="form-group">
          <label for="mp3URL">Attach Mp3</label>
          <input id="mp3URL" name="mp3URL" type="file" accept=".mp3,audio/*" >
          <p class="help-block">Please attach MP3 format </p>
        </div>
    </div>
    <div class="col-md-6">
        <a href="<?php echo base_url('uploads/dir/'.$type->PTEtype.'/'.$objExtra->mp3URL); ?>" target="_blank" class="btn btn-success">Download Previous File</a>
    </div>
</div>






<button type="submit" class="btn btn-info btn-fill pull-rightx">Update</button>
<div class="clearfix"></div>