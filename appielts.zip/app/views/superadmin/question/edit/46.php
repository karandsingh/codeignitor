
<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Question Title</label>
            <input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question', $objQuestion->question); ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Survey</label> ( Add paragraph )
            <textarea class="form-control" rows="10" name="essay" placeholder="Place some text here" required><?php echo set_value('essay', $objExtra->essay); ?></textarea>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-info btn-fill pull-rightx">Update</button>
<div class="clearfix"></div>