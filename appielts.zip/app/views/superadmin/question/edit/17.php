
<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Question Title</label>
            <input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question', $objQuestion->question); ?>" required>
        </div>
    </div>
</div>

    
<div class="row">
    <div class="col-md-3">
        <div class="form-group">
          <label for="mp3URL">Question Audio</label>
          <input id="mp3URL" name="mp3URL" type="file" accept=".mp3,audio/*">
          <p class="help-block">Please attach MP3 format </p>
        </div>
    </div>
    <div class="col-md-6">
        <a href="<?php echo base_url('uploads/dir/'.$type->PTEtype.'/'.$objExtra->mp3URL); ?>" target="_blank" class="btn btn-success">Download Previous File</a>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Paragraph</label>

        <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;">

              <h4><i class="fa fa-exclamation-triangle"></i> Important Note: </h4><b> Please add Span class to add option field in Paragraph . Read below example to add option fields in Paragraph</b></br>Example:<p>
              Researcher Marc Seifer, <mark>&lt;span class="ofield"&gt;&lt;/span&gt;</mark> astrophysicist <mark>&lt;span class="ofield"&gt;&lt;/span&gt;</mark> Travis Taylor and journalist Sometimes need to allow multiple files upload to the web application. This can easily add by separately creating file element for selection. Jason Stapleton study the life and work of an offbeat scientist, Nikolas Tesla journalist Jason Stapleton study the life and work of an offbeat . journalist Jason Stapleton study the life and work of an offbeat scientist . journalist Jason <mark>&lt;span class="ofield"&gt;&lt;/span&gt;</mark>Stapleton study the life and work of an offbeat scientist.Sometimes need to allow multiple files upload to the web application. This can easily add by separately creating <mark>&lt;span class="ofield"&gt;&lt;/span&gt;</mark>    file element for selection.</p>
              
            </div> </br>

         <textarea class="form-control" rows="10" name="paragraph" placeholder="Place some text here" required><?php echo $objExtra->paragraph; ?></textarea>
        </div>
    </div>
</div>

<div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>
   Note : Please separate all words with commas (eg.word1,word2,word3 etc)</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label> Option 1 words</label><br>
            <input type="text" class="form-control" placeholder="word1,word2,word3,word4,word5" name="option1" value="<?php echo $objExtra->option1; ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label> Option 2 words</label><br>
            <input type="text" class="form-control" placeholder="word1,word2,word3,word4,word5" name="option2" value="<?php echo $objExtra->option2; ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label> Option 3 words</label><br>
            <input type="text" class="form-control" placeholder="word1,word2,word3,word4,word5" name="option3" value="<?php echo $objExtra->option3; ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label> Option 4 words</label><br>
            <input type="text" class="form-control" placeholder="word1,word2,word3,word4,word5" name="option4" value="<?php echo $objExtra->option4; ?>" required>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Please Enter Correct words in right order</label><br>
              <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>
                 Note : Please separate all words with commas (eg.word1,word2,word3 etc)</div>
            <input type="text" class="form-control" placeholder="word1,word2,word3,word4" name="words" value="<?php echo $objExtra->words; ?>" required>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-info btn-fill pull-rightx">Update</button>
<div class="clearfix"></div>