
<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Question Title</label>
            <input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question', $objQuestion->question); ?>" required>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-3">
        <div class="form-group">
          <label for="mp3URL">Attach Mp3 (Repeat Sentence)</label>
          <input id="mp3URL" name="mp3URL" type="file" accept=".mp3,audio/*">
          <p class="help-block">Please attach MP3 format </p>
        </div>
    </div>
    <div class="col-md-6">
        <a href="<?php echo base_url('uploads/dir/'.$type->PTEtype.'/'.$objExtra->mp3URL); ?>" target="_blank" class="btn btn-success">Download Previous File</a>
    </div>
</div>



        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                <label>Option 1</label>
                <input type="text" class="form-control" placeholder="text" name="option1" required value="<?php echo $objExtra->option1; ?>">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                <label>Option 2</label>
                <input type="text" class="form-control" placeholder="text" name="option2" required value="<?php echo $objExtra->option2; ?>">
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                <label>Option 3</label>
                <input type="text" class="form-control" placeholder="text" name="option3" required value="<?php echo $objExtra->option3; ?>">
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                <label>Option 4</label>
                <input type="text" class="form-control" placeholder="text" name="option4" required value="<?php echo $objExtra->option4; ?>">
                </div>
            </div>

        </div>



        <div class="row">
            <div class="col-md-12">
                <div class="form-group has-success">
                <label >Please Select Correct Answer</label>
                <select class="form-control" name="answer" >
                <option value="1" <?php if($objExtra->answer=='1'){echo "selected";}?>>Option 1</option>
                <option value="2" <?php if($objExtra->answer=='2'){echo "selected";}?>>Option 2</option>
                <option value="3" <?php if($objExtra->answer=='3'){echo "selected";}?>>Option 3</option>
                <option value="4" <?php if($objExtra->answer=='4'){echo "selected";}?>>Option 4</option>
                </select>
                </div>
            </div>
        </div>


<button type="submit" class="btn btn-info btn-fill pull-rightx">Update</button>
<div class="clearfix"></div>