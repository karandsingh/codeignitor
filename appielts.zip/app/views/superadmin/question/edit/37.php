
<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Question Title</label>
            <input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question', $objQuestion->question); ?>" required>
        </div>
    </div>
</div>

    



<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Paragraph</label>

        <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;">

              <h4><i class="fa fa-exclamation-triangle"></i> Importent Note: </h4><b> Please add Span class to add text field in Paragraph . Read below example to add text fields in Paragraph</b></br>Example:<p>
              Researcher Marc Seifer, <mark>&lt;span class="stextfield"&gt;&lt;/span&gt;</mark> astrophysicist <mark>&lt;span class="stextfield"&gt;&lt;/span&gt;</mark> Travis Taylor and journalist Jason Stapleton study the life and work of an offbeat scientist, Nikolas Tesla journalist Jason Stapleton study the life and work of an offbeat . journalist Jason Stapleton study the life and work of an offbeat scientist . journalist Jason <mark>&lt;span class="stextfield"&gt;&lt;/span&gt;</mark>Stapleton study the life and work of an offbeat scientist</p>
              
            </div> </br>

         <textarea class="form-control" rows="10" name="paragraph" placeholder="Place some text here" required><?php echo $objExtra->paragraph; ?></textarea>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Word Options(Fill in the blanks)</label><br>
              <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>
                 Note : Please separate all words with commas (eg.word1,word2,word3 etc)</div>
            <input type="text" class="form-control" placeholder="word1,word2,word3,word4,word5,word6,word7" name="optionwords" value="<?php echo $objExtra->optionwords; ?>" required>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Please Enter Correct Words (Fill in the blanks) in right order</label><br>
              <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>
                 Note : Please separate all words with commas (eg.word1,word2,word3 etc)</div>
            <input type="text" class="form-control" placeholder="word1,word2,word3" name="words" value="<?php echo $objExtra->words; ?>" required>
        </div>
    </div>
</div>
<button type="submit" class="btn btn-info btn-fill pull-rightx">Update</button>
<div class="clearfix"></div>