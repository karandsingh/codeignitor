<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?><small><?php echo $pagetitle; ?> details</small></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?> Manager </li>
      </ol>
    </section>

      <?php
        /*
        Load Template As per PTE test subtype: question/subid.php  

        PTE Types SPEAKING (Id:1)  READING(ID:2) LISTENING (ID:3) WRITING (ID:4)

        PTE SubID   PTE TestSubType               Type
        ---------   ----------------              ------

          28        Summarize spoken text          3
          29        Multiple-choice: Single        3
          30        Multiple-choice: Multiple      3
          31        Fill in the blanks             3
          32        Highlight correct summary      3
          33        Select missing word            3
          34        Highlight incorrect words      3
          35        Write from dictation           3

          36        Multiple Fill in the blanks    2
          37        Fill in the blanks             2
          38        Re-order paragraphs            2
          39        Multiple-Choice: Multiple      2
          40        Multiple-choice: Single        2

          41        Read Aloud                     1
          42        Repeat Sentence                1
          43        Describe Image                 1
          44        Re-tell lecture                1
          45        Answer short question          1

          46        Summarize written text         4
          47        Write Essey                    4

        */ 
      ?>

    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <div class="box">
                  <div class="box-header">
                    <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
                      <h4><i class="fa fa-info"></i> Note:</h4>
                      Edit Question Under category Part 4 : Note Completion</strong>
                      <a href="<?php echo base_url('superadmin/part24list'); ?>">   <span class="pull-right badge bg-red">Click here to Go Back</span></a>
                    </div>
                  </div>
				  <?php ///echo "<pre>";print_r($l2data);die; ?>
				  <?php if($this->session->flashdata('global_msg')){ ?>
					 <div class="alert alert-success">
					  <button class="close" type="button" data-dismiss="alert">
						<span aria-hidden="true">&times;</span>
					  </button>
					  <?=$this->session->flashdata('global_msg')?>
					</div>
				   <?php } ?>

                  <div class="box-body">
                    <table class="table table-bordered">
                      <tr>
                        <td>Type</td>
                        <td><strong>Academic Reading</strong></td>
                      </tr>
                      <tr>
                        <td>Sub Type</td>
                        <td><strong>Part 4: Note Completion</strong></td>
                      </tr>
					  <tr>
                        <td>Test Code</td>
                        <td><strong><?=$l2data->test_code;?></strong></td>
                      </tr>
					  
                    </table>

                    <?php
                      if($errors) {
                        foreach ($errors as $error) {
                          echo '<div class="alert alert-danger">'.$error.'</div>';
                        }
                      }
                    ?>

                    <?php if($success) { ?>
                      <div class="alert alert-success">
                        <?php header( "refresh:2;url=" ); ?>
                        New Data have been added successfully.</br></br>
                        Have a great day!
                      </div>
                    <?php } else { ?>

                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('superadmin/edit_part2_4/'.$this->uri->rsegment(3), array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>

                          <hr />
			<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Passage</label>

             <textarea class="form-control" rows="10" name="passage" placeholder="Place some text here" required><?php echo $l2data->passage; ?></textarea>
        </div>
    </div>
</div>
			  <div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Title</label><br>
             
            <input type="text" class="form-control" placeholder="Answer" name="q1_title" value="<?php echo $l2data->q1_title; ?>" required>
        </div>
    </div>
</div>
				
<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Question 1</label>

       <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;">

            <h4><i class="fa fa-exclamation-triangle"></i> Importent Note: </h4><b> Please add Span class to create blank text filed in summary . Read below example to add Text fields in Transcription Of The Audio</b></br>
             
            Example:<p>
            Researcher Marc Seifer, <mark><?php echo $this->BLANKAREA; ?></mark> astrophysicist <mark><?php echo $this->BLANKAREA; ?></mark></p>
            
          </div> </br>

         <textarea class="form-control" rows="10" name="q1_question" placeholder="Place some text here" required><?php echo $l2data->q1_question; ?></textarea>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Answer</label><br>
             
            <input type="text" class="form-control" placeholder="Answer" name="q1_answer" value="<?php echo $l2data->q1_answer; ?>" required>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Question 2</label>

       <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;">

            <h4><i class="fa fa-exclamation-triangle"></i> Importent Note: </h4><b> Please add Span class to create blank text filed in summary . Read below example to add Text fields in Transcription Of The Audio</b></br>
             
            Example:<p>
            Researcher Marc Seifer, <mark><?php echo $this->BLANKAREA; ?></mark> astrophysicist <mark><?php echo $this->BLANKAREA; ?></mark></p>
            
          </div> </br>

         <textarea class="form-control" rows="10" name="q2_question" placeholder="Place some text here" required><?php echo $l2data->q2_question; ?></textarea>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Answer</label><br>
             
            <input type="text" class="form-control" placeholder="Answer" name="q2_answer" value="<?php echo $l2data->q2_answer; ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Question 3</label>

       <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;">

            <h4><i class="fa fa-exclamation-triangle"></i> Importent Note: </h4><b> Please add Span class to create blank text filed in summary . Read below example to add Text fields in Transcription Of The Audio</b></br>
             
            Example:<p>
            Researcher Marc Seifer, <mark><?php echo $this->BLANKAREA; ?></mark> astrophysicist <mark><?php echo $this->BLANKAREA; ?></mark></p>
            
          </div> </br>

         <textarea class="form-control" rows="10" name="q3_question" placeholder="Place some text here" required><?php echo $l2data->q3_question; ?></textarea>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Answer</label><br>
             
            <input type="text" class="form-control" placeholder="Answer" name="q3_answer" value="<?php echo $l2data->q3_answer; ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Question 4</label>

       <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;">

            <h4><i class="fa fa-exclamation-triangle"></i> Importent Note: </h4><b> Please add Span class to create blank text filed in summary . Read below example to add Text fields in Transcription Of The Audio</b></br>
             
            Example:<p>
            Researcher Marc Seifer, <mark><?php echo $this->BLANKAREA; ?></mark> astrophysicist <mark><?php echo $this->BLANKAREA; ?></mark></p>
            
          </div> </br>

         <textarea class="form-control" rows="10" name="q4_question" placeholder="Place some text here" required><?php echo $l2data->q4_question; ?></textarea>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Answer</label><br>
             
            <input type="text" class="form-control" placeholder="Answer" name="q4_answer" value="<?php echo $l2data->q4_answer; ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Question 5</label>

       <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;">

            <h4><i class="fa fa-exclamation-triangle"></i> Importent Note: </h4><b> Please add Span class to create blank text filed in summary . Read below example to add Text fields in Transcription Of The Audio</b></br>
             
            Example:<p>
            Researcher Marc Seifer, <mark><?php echo $this->BLANKAREA; ?></mark> astrophysicist <mark><?php echo $this->BLANKAREA; ?></mark></p>
            
          </div> </br>

         <textarea class="form-control" rows="10" name="q5_question" placeholder="Place some text here" required><?php echo $l2data->q5_question; ?></textarea>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Answer</label><br>
             
            <input type="text" class="form-control" placeholder="Answer" name="q5_answer" value="<?php echo $l2data->q5_answer; ?>" required>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
        <label>Question 6</label>

       <div class="alert alert-danger-light   alert-dismissible" style="margin-bottom: 0!important;">

            <h4><i class="fa fa-exclamation-triangle"></i> Importent Note: </h4><b> Please add Span class to create blank text filed in summary . Read below example to add Text fields in Transcription Of The Audio</b></br>
             
            Example:<p>
            Researcher Marc Seifer, <mark><?php echo $this->BLANKAREA; ?></mark> astrophysicist <mark><?php echo $this->BLANKAREA; ?></mark></p>
            
          </div> </br>

         <textarea class="form-control" rows="10" name="q6_question" placeholder="Place some text here" required><?php echo $l2data->q6_question; ?></textarea>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label>Answer</label><br>
             
            <input type="text" class="form-control" placeholder="Answer" name="q6_answer" value="<?php echo $l2data->q6_answer; ?>" required>
        </div>
    </div>
</div>
						  
						 <button type="submit" class="btn btn-info btn-fill pull-right">Edit</button>
                         <div class="clearfix"></div> 

                          <?php
                            //$PTEsubid=$this->uri->segment(3);
                            //Load Template As per PTE test subtype: question/subid.php
                            //include_once("question/$PTEsubid.php");
                          ?>
                      </form>
                    <?php } ?>

                  </div>


              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>