<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        STUDENT MANAGER
        <small>Manage Students</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
            <div class="box-header">
              <a href="<?=base_url()?>superadmin/memberNew" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
            </div>

                      <?php if (@$_GET['trash']) { ?>
                      <div class="alert alert-success">
                      <button class="close" type="button" data-dismiss="alert">
                      <span aria-hidden="true">&times;</span>
                      </button>
                      Member information deleted.
                      </div>
                      <?php } ?>
                      
                      <?php if($this->session->flashdata('global_msg')){ ?>
                         <div class="alert alert-success">
                          <button class="close" type="button" data-dismiss="alert">
                            <span aria-hidden="true">&times;</span>
                          </button>
                          <?=$this->session->flashdata('global_msg')?>
                        </div>
                     <?php } ?>

      


            <!-- /.box-header -->
            <div class="box-body">
                <div class="table-responsive">
                    <table id="memberList" class="table table-bordered table-striped" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Reference No</th>
                                <th>Name</th>
                                <th>Coins</th>
                                <th>Email</th>
                                <th>Country</th>
                                <th>City</th>
                                <th>Ip address</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>
  
  <div id="student_addCoinModal" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Add Coins</h4>
          </div>
          <div class="modal-body">
            <div class="form-group">
                <label>Number of Coins</label>
                <input type="text" class="form-control add_coin_no" placeholder="10" name="coins" required />
            </div>
            <div class="form-group">
                <label>Add Description</label>
                <input type="text" class="form-control add_coin_desc" placeholder="description" name="description" required="">
            </div>
            <input type="hidden" class="student_id" name="student_id" value=""/>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-info student_add_coins_btn">Save</button>
          </div>
        </div>

      </div>
   </div>

 
  <?php include_once('common/scripts.php'); ?>
  
  
</body>
</html>
