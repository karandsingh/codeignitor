<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?><small><?php echo $pagetitle; ?> details</small></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?> Manager </li>
      </ol>
    </section>

    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <div class="box">
                  <div class="box-header">
                    <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
                      <h4><i class="fa fa-info"></i> Note:</h4>
                      Add Question Under category Part 2: Listening to Problem Solving</strong>
                      <a href="<?php echo base_url('superadmin/lspart2Listing'); ?>">   <span class="pull-right badge bg-red">Click here to Go Back</span></a>
                    </div>
                  </div>
				  
				  <?php if($this->session->flashdata('global_msg')){ ?>
					 <div class="alert alert-success">
					  <button class="close" type="button" data-dismiss="alert">
						<span aria-hidden="true">&times;</span>
					  </button>
					  <?=$this->session->flashdata('global_msg')?>
					</div>
				   <?php } ?>

                  <div class="box-body">
                    <table class="table table-bordered">
                      <tr>
                        <td>Type</td>
                        <td><strong>Listening</strong></td>
                      </tr>
                      <tr>
                        <td>Sub Type</td>
                        <td><strong>Part 2: Listening to Problem Solving</strong></td>
                      </tr>
					  <tr>
                        <td>Test Code</td>
                        <td><strong><?php echo $test_code; ?></strong></td>
                      </tr>
                    </table>

                    <?php
                      if($errors) {
                        foreach ($errors as $error) {
                          echo '<div class="alert alert-danger">'.$error.'</div>';
                        }
                      }
                    ?>

                    <?php if($success) { ?>
                      <div class="alert alert-success">
                        <?php header( "refresh:2;url=" ); ?>
                        New Data have been added successfully.</br></br>
                        Have a great day!
                      </div>
                    <?php } else { ?>

                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('superadmin/lspart2/', array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>

                          <hr />
						  
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">Ist Conversation Audio </label>   
								  <input id="mp3URL" name="conversation_1_audio" type="file" accept=".mp3,audio/*"  required>
								  <p class="help-block">Please attach MP3 format </p>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">1st Question Audio</label>   
								  <input id="mp3URL" name="q1_audio" type="file" accept=".mp3,audio/*" required>
								  <p class="help-block">Please attach MP3 format </p>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>1st Question option1</label>
									<input type="text" class="form-control" placeholder="question" name="q1_option1" value="<?php echo set_value('q1_option1'); ?>" required>
								</div>
							</div>
						</div>
						
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>1st Question option2</label>
									<input type="text" class="form-control" placeholder="question" name="q1_option2" value="<?php echo set_value('q1_option2'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>1st Question option3</label>
									<input type="text" class="form-control" placeholder="question" name="q1_option3" value="<?php echo set_value('q1_option3'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>1st Question option4</label>
									<input type="text" class="form-control" placeholder="question" name="q1_option4" value="<?php echo set_value('q1_option4'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select Correct answer</label>
								<select class="form-control" name="q1_answer" required>
								<option value="">Select</option>
								<option value="1">Option 1</option>
								<option value="2">Option 2</option>
								<option value="3">Option 3</option>
								<option value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">2nd Question Audio</label>   
								  <input id="mp3URL" name="q2_audio" type="file" accept=".mp3,audio/*"  required>
								  <p class="help-block">Please attach MP3 format </p>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>2nd Question option1</label>
									<input type="text" class="form-control" placeholder="question" name="q2_option1" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>2nd Question option2</label>
									<input type="text" class="form-control" placeholder="question" name="q2_option2" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>2nd Question option3</label>
									<input type="text" class="form-control" placeholder="question" name="q2_option3" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>2nd Question option4</label>
									<input type="text" class="form-control" placeholder="question" name="q2_option4" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 2nd Question Correct answer</label>
								<select class="form-control" name="q2_answer" required>
								<option value="">Select</option>
								<option value="1">Option 1</option>
								<option value="2">Option 2</option>
								<option value="3">Option 3</option>
								<option value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">3rd Question Audio</label>   
								  <input id="mp3URL" name="q3_audio" type="file" accept=".mp3,audio/*"  required>
								  <p class="help-block">Please attach MP3 format </p>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>3rd Question option1</label>
									<input type="text" class="form-control" placeholder="question" name="q3_option1" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>3rd Question option2</label>
									<input type="text" class="form-control" placeholder="question" name="q3_option2" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>3rd Question option3</label>
									<input type="text" class="form-control" placeholder="question" name="q3_option3" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>3rd Question option4</label>
									<input type="text" class="form-control" placeholder="question" name="q3_option4" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 3rd Question Correct answer</label>
								<select class="form-control" name="q3_answer" required>
								<option value="">Select</option>
								<option value="1">Option 1</option>
								<option value="2">Option 2</option>
								<option value="3">Option 3</option>
								<option value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">4th Question Audio</label>   
								  <input id="mp3URL" name="q4_audio" type="file" accept=".mp3,audio/*"  required>
								  <p class="help-block">Please attach MP3 format </p>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>4th Question option1</label>
									<input type="text" class="form-control" placeholder="question" name="q4_option1" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>4th Question option2</label>
									<input type="text" class="form-control" placeholder="question" name="q4_option2" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>4th Question option3</label>
									<input type="text" class="form-control" placeholder="question" name="q4_option3" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>4th Question option4</label>
									<input type="text" class="form-control" placeholder="question" name="q4_option4" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 4th Question Correct answer</label>
								<select class="form-control" name="q4_answer" required>
								<option value="">Select</option>
								<option value="1">Option 1</option>
								<option value="2">Option 2</option>
								<option value="3">Option 3</option>
								<option value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">5th Question Audio</label>   
								  <input id="mp3URL" name="q5_audio" type="file" accept=".mp3,audio/*"  required>
								  <p class="help-block">Please attach MP3 format </p>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>5th Question option1</label>
									<input type="text" class="form-control" placeholder="question" name="q5_option1" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>5th Question option2</label>
									<input type="text" class="form-control" placeholder="question" name="q5_option2" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>5th Question option3</label>
									<input type="text" class="form-control" placeholder="question" name="q5_option3" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>5th Question option4</label>
									<input type="text" class="form-control" placeholder="question" name="q5_option4" value="<?php echo set_value('question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 5th Question Correct answer</label>
								<select class="form-control" name="q5_answer" required>
								<option value="">Select</option>
								<option value="1">Option 1</option>
								<option value="2">Option 2</option>
								<option value="3">Option 3</option>
								<option value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						  
						  
						 <button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
                         <div class="clearfix"></div> 

                          <?php
                            //$PTEsubid=$this->uri->segment(3);
                            //Load Template As per PTE test subtype: question/subid.php
                            //include_once("question/$PTEsubid.php");
                          ?>
                      </form>
                    <?php } ?>

                  </div>


              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>