<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> 
      </h1>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
           
            <div class="box-body">





                <?php echo validation_errors(); ?>
                <?php if ($success) { ?>
                  <div class="alert alert-success">
                    <button class="close" type="button" data-dismiss="alert">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    Question has been updated successfully.
                  </div>
                <?php } ?>

                <?php if($_GET['new'] == "1") { ?>
                <div class="alert alert-success">
                  Question has been added successfully. You just need to update question information according your requirements.
                </div>
                <?php } ?>


                <?php #} else { ?>
                  <div class="row">
                    <div class="col-md-12">
                      <!-- form start -->
                      <?php echo form_open_multipart($this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3), array('id' => $this->uri->segment(2),'role'=>'form'));
					  
					  //echo form_open($this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3), array('id' => $this->uri->segment(2),'role'=>'form')) ?>

                        <div class="box-body">

                          <div class="form-group row">
                              <label for="title" class="col-sm-12 control-label">Question <span class="text-danger">*</span></label>
                              <div class="col-md-12">
                                  <textarea class="form-control editor" name="title" id="title" rows="5" ><?php echo $objQuestion->title; ?></textarea>
                                  <div class="text-muted"></div>
                              </div>
                          </div>
						  
						  
						  <div class="form-group">
						    <?php if(!empty($objQuestion->question_image)){ ?>
								<img src="<?php echo base_url(); ?>/uploads/question_images/<?php echo $objQuestion->question_image;?>" width="100px" height="100px" />
							<?php } ?>
						  
						    <label for="exampleInputFile">Question Image </label>
						    <input type="file" name="question_img" accept="image/x-png,image/gif,image/jpeg" />
						 </div>

                          <p>Options</p>


                          <?php if($_GET['newoption'] == "1") { ?>
                          <div class="alert alert-success">Option has been added successfully.</div>
                          <?php } ?>
                          <?php if($_GET['deleteoption'] == "1") { ?>
                          <div class="alert alert-success">Option has been deleted successfully.</div>
                          <?php } ?>


                          <?php
                              $serialNo = 0;
                              foreach ($options as $getOptionq) {
                              $serialNo++;
                          ?>
                          <div class="form-group row">
                              <label for="opt<?php echo $getOptionq->id; ?>" class="col-sm-1 control-label">
                                  <?php echo $serialNo; ?> <span class="text-danger">*</span>
                              </label>

                              <div class="col-md-8">
                                  <input 
                                      type="text" 
                                      class="form-control" 
                                      name="quiz_opt_title[<?php echo $getOptionq->id; ?>]" 
                                      id="opt<?php echo $getOptionq->id; ?>"
                                      value="<?php echo $getOptionq->title; ?>" required>
                                  <div class="text-muted"></div>
                              </div>

                              <div class="col-md-3">
                                  <!-- 
                                  Delete only if not correct and not in first two.
                                  -->
                                  <?php if($serialNo > 2 && !$getOptionq->is_correct) { ?>
                                  <a href="javascript:void(0)"
                                      data-toggle="tooltip"
                                      data-original-title="Delete"
                                      data-link="<?php echo base_url($currentPath.'/vdeletequestionoption/'.$getOptionq->id); ?>"
                                      data-msg="this Question Option"
                                      class="confirm-goto-page pull-right btn btn-danger">
                                      <i class="fa fa-close text-danger"></i>
                                  </a>
                                  <?php } ?>

                                  <div class="radio">
                                      <input 
                                          <?php if($getOptionq->is_correct == '1'){ $chk = 'checked="checked"';}else{$chk=' ';}echo $chk; ?>

                                          type="radio"
                                          value="<?php echo $getOptionq->id; ?>" name="quizquestion_iscorrect" 
                                          id="rght<?php echo $getOptionq->id; ?>" class="radio-col-light-green"
                                          required>
                                      
                                      <label for="rght<?php echo $getOptionq->id; ?>" data-toggle="tooltip" data-placement="top" data-original-title="Set as Right Answer">Set as Right Answer</label>
                                  </div>
                              </div>

                          </div>
                          <?php } ?>


                          <div class="form-group row">
                              <div class="col-md-1">&nbsp;</div>
                              <div class="col-md-10">
                                  <a href="javascript:void(0)"
                                  data-link="<?php echo base_url($currentPath.'/vaddquestionoption/'.$objQuestion->id); ?>"
                                  class="btn btn-info goto-page"
                                  data-toggle="tooltip" 
                                  data-placement="right" 
                                  data-original-title="Add New Option">
                                  <i class="fa fa-plus"></i> Add New Option</a>

                                  <b>Note</b> : Before add new option, please save question if you have made any changes.
                              </div>
                          </div>

                        </div>
                        <div class="box-footer">
                          <hr />
                          <button type="submit" class="btn btn-success">Save Changes</button>
                        </div>
                      <?php echo form_close() ?>
                    </div>
                  </div>
       
                <?php #} ?>










            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
</body>
</html>
