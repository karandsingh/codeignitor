<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?><small><?php echo $pagetitle; ?> details</small></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?> Manager </li>
      </ol>
    </section>

    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <div class="box">
                  <div class="box-header">
                    <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
                      <h4><i class="fa fa-info"></i> Note:</h4>
                      Edit Question Under category Practice Task</strong>
                      <a href="<?php echo base_url('superadmin/lsPracticeList'); ?>">   <span class="pull-right badge bg-red">Click here to Go Back</span></a>
                    </div>
                  </div>
				  
				  <?php if($this->session->flashdata('global_msg')){ ?>
					 <div class="alert alert-success">
					  <button class="close" type="button" data-dismiss="alert">
						<span aria-hidden="true">&times;</span>
					  </button>
					  <?=$this->session->flashdata('global_msg')?>
					</div>
				   <?php } ?>

                  <div class="box-body">
                    <table class="table table-bordered">
                      <tr>
                        <td>Type</td>
                        <td><strong>Listening</strong></td>
                      </tr>
                      <tr>
                        <td>Sub Type</td>
                        <td><strong>Practice Task</strong></td>
                      </tr>
					  <tr>
                        <td>Test Code</td>
                        <td><strong><?=$test->test_code;?></strong></td>
                      </tr>
                    </table>

                    <?php
                      if($errors) {
                        foreach ($errors as $error) {
                          echo '<div class="alert alert-danger">'.$error.'</div>';
                        }
                      }
                    ?>
					
                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('superadmin/lsPractice_edit/'.$this->uri->segment(3), array('id' => $this->uri->segment(2), 'class' => 'clearfix' )); ?>

                          <hr />
						  
						
						 
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Question Title</label>
									<input type="text" class="form-control" placeholder="question" name="question" value="<?php echo set_value('question',$test->question); ?>" required>
								</div>
							</div>
						</div>


						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <?php if(!empty($test->mp3URL)) {?>
							      <audio controls>
										  <source src="<?php echo base_url(); ?>uploads/listening_practiceTask/<?=$test->mp3URL?>" type="audio/mpeg">
										  Your browser does not support the audio tag.
								      </audio>
                                   <?php } ?>
								  <label for="mp3URL">Question Audio </label>   
								  <input id="mp3URL" name="mp3URL" type="file" accept=".mp3,audio/*">
								  <p class="help-block">Please attach MP3 format </p>
								</div>
							</div>
						</div>


								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
										<label>Option 1</label>
										<input type="text" class="form-control" placeholder="text" name="option1" required value="<?php echo set_value('option1',$test->option1); ?>">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
										<label>Option 2</label>
										<input type="text" class="form-control" placeholder="text" name="option2" required value="<?php echo set_value('option2',$test->option2); ?>">
										</div>
									</div>

								</div>

								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
										<label>Option 3</label>
										<input type="text" class="form-control" placeholder="text" name="option3" required value="<?php echo set_value('option3',$test->option3); ?>">
										</div>
									</div>

								</div>

								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
										<label>Option 4</label>
										<input type="text" class="form-control" placeholder="text" name="option4" required value="<?php echo set_value('option4',$test->option4); ?>">
										</div>
									</div>

								</div>

								<div class="row">
									<div class="col-md-12">
										<div class="form-group has-success">
										<label >Please Select Correct Answer</label>
										<select class="form-control" name="answer" required>
										<option value="">Select</option>
										<option <?php if($test->answer==1){ echo 'selected'; }?> value="1">Option 1</option>
										<option <?php if($test->answer==2){ echo 'selected'; }?> value="2">Option 2</option>
										<option <?php if($test->answer==3){ echo 'selected'; }?> value="3">Option 3</option>
										<option value="4" <?php if($test->answer==4){ echo 'selected'; }?>>Option 4</option>
										</select>
										</div>
									</div>
								</div>


						<button type="submit" class="btn btn-info btn-fill pull-right">Edit</button>
                         <div class="clearfix"></div> 

                          <?php
                            //$PTEsubid=$this->uri->segment(3);
                            //Load Template As per PTE test subtype: question/subid.php
                            //include_once("question/$PTEsubid.php");
                          ?>
                      </form>

                  </div>


              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>