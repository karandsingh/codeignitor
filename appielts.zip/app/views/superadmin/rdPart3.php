<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <?php include_once('common/nav.php'); ?>
  </header>

  <aside class="main-sidebar">
    <?php include_once('common/sidebar.php'); ?>
  </aside>

  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php echo $pagetitle; ?><small><?php echo $pagetitle; ?> details</small></h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $pagetitle; ?> Manager </li>
      </ol>
    </section>

    <section class="content">
        <div class="row">
          <div class="col-xs-12">
              <div class="box">
                  <div class="box-header">
                    <div class="alert alert-info alert-dismissible" style="margin-bottom: 0!important;">
                      <h4><i class="fa fa-info"></i> Note:</h4>
                      Add Question Under category Part 3: Reading for Information</strong>
                      <a href="<?php echo base_url('superadmin/rdPart3List'); ?>">   <span class="pull-right badge bg-red">Click here to Go Back</span></a>
                    </div>
                  </div>
				  
				  <?php if($this->session->flashdata('global_msg')){ ?>
					 <div class="alert alert-success">
					  <button class="close" type="button" data-dismiss="alert">
						<span aria-hidden="true">&times;</span>
					  </button>
					  <?=$this->session->flashdata('global_msg')?>
					</div>
				   <?php } ?>

                  <div class="box-body">
                    <table class="table table-bordered">
                      <tr>
                        <td>Type</td>
                        <td><strong>Reading</strong></td>
                      </tr>
                      <tr>
                        <td>Sub Type</td>
                        <td><strong>Part 3: Reading for Information</strong></td>
                      </tr>
					  <tr>
                        <td>Test Code</td>
                        <td><strong><?php echo $test_code;?></strong></td>
                      </tr>
                    </table>

                    <?php
                      if($errors) {
                        foreach ($errors as $error) {
                          echo '<div class="alert alert-danger">'.$error.'</div>';
                        }
                      }
                    ?>
					
                      <?php echo validation_errors(); ?>
                      <?php echo form_open_multipart('superadmin/rdPart3/', array('id' => $this->uri->rsegment(2), 'class' => 'clearfix' )); ?>

                       <hr />
					   <div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">1st Passages </label>
									<textarea class="form-control" rows="10" name="passages_1" placeholder="Place some text here" required=""></textarea>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">2nd Passages </label>
									<textarea class="form-control" rows="10" name="passages_2" placeholder="Place some text here" required=""></textarea>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">3rd Passages </label>
									<textarea class="form-control" rows="10" name="passages_3" placeholder="Place some text here" required=""></textarea>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
								  <label for="mp3URL">4th Passages </label>
									<textarea class="form-control" rows="10" name="passages_4" placeholder="Place some text here" required=""></textarea>
								</div>
							</div>
						</div>
				
				 
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>1st Question</label>
									<input type="text" class="form-control" placeholder="question" name="q1_question" value="<?php echo set_value('q1_question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 1st Question Correct Answer</label>
								<select class="form-control" name="q1_answere" required>
								<option value="">Select</option>
								<option value="a">A</option>
								<option value="b">B</option>
								<option value="c">C</option>
								<option value="d">D</option>
								<option value="e">E</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>2nd Question</label>
									<input type="text" class="form-control" placeholder="question" name="q2_question" value="<?php echo set_value('q2_question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 2nd Question Correct Answer</label>
								<select class="form-control" name="q2_answere" required>
								<option value="">Select</option>
								<option value="a">A</option>
								<option value="b">B</option>
								<option value="c">C</option>
								<option value="d">D</option>
								<option value="e">E</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>3rd Question</label>
									<input type="text" class="form-control" placeholder="question" name="q3_question" value="<?php echo set_value('q3_question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 3rd Question Correct Answer</label>
								<select class="form-control" name="q3_answere" required>
								<option value="">Select</option>
								<option value="a">A</option>
								<option value="b">B</option>
								<option value="c">C</option>
								<option value="d">D</option>
								<option value="e">E</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>4th Question</label>
									<input type="text" class="form-control" placeholder="question" name="q4_question" value="<?php echo set_value('q4_question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 4th Question Correct Answer</label>
								<select class="form-control" name="q4_answere" required>
								<option value="">Select</option>
								<option value="a">A</option>
								<option value="b">B</option>
								<option value="c">C</option>
								<option value="d">D</option>
								<option value="e">E</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>5th Question</label>
									<input type="text" class="form-control" placeholder="question" name="q5_question" value="<?php echo set_value('q5_question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 5th Question Correct Answer</label>
								<select class="form-control" name="q5_answere" required>
								<option value="">Select</option>
								<option value="a">A</option>
								<option value="b">B</option>
								<option value="c">C</option>
								<option value="d">D</option>
								<option value="e">E</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>6th Question</label>
									<input type="text" class="form-control" placeholder="question" name="q6_question" value="<?php echo set_value('q6_question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 6th Question Correct Answer</label>
								<select class="form-control" name="q6_answere" required>
								<option value="">Select</option>
								<option value="a">A</option>
								<option value="b">B</option>
								<option value="c">C</option>
								<option value="d">D</option>
								<option value="e">E</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>7th Question</label>
									<input type="text" class="form-control" placeholder="question" name="q7_question" value="<?php echo set_value('q7_question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 7th Question Correct Answer</label>
								<select class="form-control" name="q7_answere" required>
								<option value="">Select</option>
								<option value="a">A</option>
								<option value="b">B</option>
								<option value="c">C</option>
								<option value="d">D</option>
								<option value="e">E</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>8th Question</label>
									<input type="text" class="form-control" placeholder="question" name="q8_question" value="<?php echo set_value('q8_question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 8th Question Correct Answer</label>
								<select class="form-control" name="q8_answere" required>
								<option value="">Select</option>
								<option value="a">A</option>
								<option value="b">B</option>
								<option value="c">C</option>
								<option value="d">D</option>
								<option value="e">E</option>
								</select>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>9th Question</label>
									<input type="text" class="form-control" placeholder="question" name="q9_question" value="<?php echo set_value('q9_question'); ?>" required>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select 9th Question Correct Answer</label>
								<select class="form-control" name="q9_answere" required>
								<option value="">Select</option>
								<option value="a">A</option>
								<option value="b">B</option>
								<option value="c">C</option>
								<option value="d">D</option>
								<option value="e">E</option>
								</select>
								</div>
							</div>
						</div>


						<button type="submit" class="btn btn-info btn-fill pull-right">Add New</button>
                         <div class="clearfix"></div> 
                      </form>

                  </div>

              </div>
          </div>
        </div>
    </section>
  </div>
  <footer class="main-footer">
  <?php include_once('common/footer.php'); ?>
  </footer>
  <?php include_once('common/scripts.php'); ?>
</body>
</html>