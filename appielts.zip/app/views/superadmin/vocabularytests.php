<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> 
      </h1>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
              <div class="box-header">
                <a href="<?=base_url()?>superadmin/vaddlevel" class="btn btn-primary btn-sm"> <i class="pe-7s-plus"></i> Add New </a>
            </div>
            <div class="box-body">

              <div class="card">
			  <?php if($this->session->flashdata('global_msg')){ ?>
					 <div class="alert alert-success">
					  <button class="close" type="button" data-dismiss="alert">
						<span aria-hidden="true">&times;</span>
					  </button>
					  <?=$this->session->flashdata('global_msg')?>
					</div>
				<?php } ?>
                <table class="table table-hover table-bordered table-stripedx" id="example1">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Level</th>
                      <th>Coin Cost</th>
                      <th>Total Questions</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $serialno = 0; 
                      foreach ($levels as $objLevel) {
                      $viewLink = base_url($currentPath.'/vquestions/'.$objLevel->id);
                      $serialno++;
                    ?>
                    <tr>
                      <td><?php echo $serialno;?></td>
                      <td><?php echo $objLevel->name;?></td>
                      <td><?php echo $objLevel->coin_cost;?></td>
                      <td><?php echo $objLevel->total_questions;?></td>
                      <td><a href="<?php echo $viewLink; ?>" class="btn btn-primary btn-sm">View Questions</a>
					  <a href="<?php echo base_url(); ?>superadmin/editvlevel/<?php echo $objLevel->id; ?>" class="btn btn-xs btn-primary" title="" data-toggle="tooltip" data-original-title="Edit"><i class="fa fa-edit"></i></a>
					  </td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
</body>
</html>
