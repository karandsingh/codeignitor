<!doctype html>
<html lang="en">
<head>
  
<title><?php echo $window_title; ?></title>
    <?php include_once('common/head.php'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    
    <?php include_once('common/nav.php'); ?>

  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    
    <?php include_once('common/sidebar.php'); ?>

    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $pagetitle; ?> 
      </h1>
    </section>

    <!-- Main content -->
  <section class="content">
      <div class="row">
        <div class="col-xs-12">
         
          <div class="box">
           
            <div class="box-body">
                <?php echo validation_errors(); ?>
                  <div class="row">
                    <div class="col-md-12">
                      <!-- form start -->
                      <?php echo form_open_multipart($this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4), array('id' => $this->uri->segment(2),'role'=>'form'));
					  
					  //echo form_open($this->uri->segment(1).'/'.$this->uri->segment(2).'/'.$this->uri->segment(3), array('id' => $this->uri->segment(2),'role'=>'form')) ?>

                        <div class="box-body">
						    <div class="form-group row">
                              <label for="title" class="col-sm-12 control-label">Question <span class="text-danger">*</span></label>
                                <div class="col-md-12">
									<textarea class="form-control" rows="5" name="title" placeholder="Place some text here" required=""><?php echo set_value('title',$objQuestion->question); ?></textarea>
                                    <div class="text-muted"></div>
                                </div>
                            </div>
						<div class="form-group">
							<?php if(!empty($objQuestion->question)){?>
							<audio controls>
								<source src="<?php echo base_url('uploads/dictation_files/').$objQuestion->question_audio; ?>" type="audio/mpeg">
						    </audio>
							<?php } ?>
						    <label for="exampleInputFile">Question Audio </label>
						    <input type="file" name="question_audio" accept=".mp3,audio/*" />
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>1st Option <?php $objOptions[0]->dictation_option; ?></label>
									<textarea class="form-control" rows="5" name="option[<?php echo $objOptions[0]->id; ?>]" placeholder="Place option here" required=""><?php echo set_value('1st_option',$objOptions[0]->dictation_option); ?></textarea>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>2nd Option</label>
									<textarea class="form-control" rows="5" name="option[<?php echo $objOptions[1]->id; ?>]" placeholder="Place option here" required=""><?php echo set_value('2nd_option',$objOptions[1]->dictation_option); ?></textarea>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>3rd Option</label>
									<textarea class="form-control" rows="5" name="option[<?php echo $objOptions[2]->id; ?>]" placeholder="Place option here" required=""><?php echo set_value('3rd_option',$objOptions[2]->dictation_option); ?></textarea>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>4th Option</label>
									<textarea class="form-control" rows="5" name="option[<?php echo $objOptions[3]->id; ?>]" placeholder="Place option here" required=""><?php echo set_value('4th_option',$objOptions[3]->dictation_option); ?></textarea>
								</div>
							</div>
						</div>
						  
						<div class="row">
							<div class="col-md-12">
								<div class="form-group has-success">
								<label >Please Select Correct answer</label>
								<select class="form-control" name="answere" required>
								<option value="">Select</option>
								<option <?php if($objQuestion->right_option==1){ echo 'selected'; }?> value="1">Option 1</option>
								<option <?php if($objQuestion->right_option==2){ echo 'selected'; }?> value="2">Option 2</option>
								<option <?php if($objQuestion->right_option==3){ echo 'selected'; }?> value="3">Option 3</option>
								<option <?php if($objQuestion->right_option==4){ echo 'selected'; }?> value="4">Option 4</option>
								</select>
								</div>
							</div>
						</div>
						  
						  
                        </div>
                        <div class="box-footer">
                          <button type="submit" class="btn btn-success">Edit Question</button>
                        </div>
                      <?php echo form_close() ?>
                    </div>
                  </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   
  <?php include_once('common/footer.php'); ?>

  </footer>



  <?php include_once('common/scripts.php'); ?>
</body>
</html>
