<!DOCTYPE html>
<html>
<head>
    <title><?php echo $meta['title']; ?></title>

    <base href="<?php echo base_url("/theme/default"); ?>/">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- jvectormap -->
    <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
     folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    
    <style type="text/css">
     .login-page, .register-page {
        background: #152733;
      }

      .login-logo a, .register-logo a {
        color: #fff;
      }

      .login-box-body, .register-box-body {
        border: 1px solid #666;
        background: #152733;
        padding: 20px;
        color: #fff;
        border-radius: 6px;
        padding-bottom: 20px;
      }
    </style>

</head>
<body class="hold-transition register-page">
<div class="register-page">


    <div class="container-fluid">


        <div class="row">
            <div class="col-xs-8 col-xs-offset-2 text-center" style="color: #fff;">
                <h3><?php echo $this->app_name; ?></h3>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-8 col-xs-offset-2 register-box-body">

                <div class="card">
                    <div class="header">
                        <h4 class="title">Register a new membership</h4>
                    </div>
                    <div class="content">

                        <?php if($success) { ?>
                        <div class="alert alert-success">
                            You have successfully register. Please check your inbox for account details.
                        </div>
                        <?php } ?>

                        <?php echo validation_errors(); ?>
                        <?php echo form_open_multipart('registration', array('id' => mb_strtolower($this->uri->rsegment(2)), 'class' => 'formclass' )); ?>

                            <?php /* <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Full name</label>
                                        <input type="text" name="name" class="form-control" placeholder="Contain only alpha-numeric characters or spaces." value="<?php echo set_value('name'); ?>" required>
                                    </div>
                                </div>
                            </div>
							
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Mobile</label>
                                        <input type="text" name="mobile" class="form-control" placeholder="e.g. +91 9800098000, +91 9800098000" value="<?php echo set_value('mobile'); ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Address</label>
                                        <input type="text" name="street_address" class="form-control" placeholder="Street name and number" value="<?php echo set_value('street_address'); ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>City or Region</label>
                                        <input type="text" name="city_region" class="form-control" value="<?php echo set_value('city_region'); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Country</label>
                                        <select name="country_id" class="form-control" required>
                                            <option value=""></option>
                                            <?php
                                                foreach ($countries as $getCountry) {
                                                    echo '<option value="'.$getCountry->id.'">'.$getCountry->name.'</option>';
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Postal Code</label>
                                        <input type="number" name="postal_code" class="form-control" placeholder="ZIP Code" value="<?php echo set_value('postal_code'); ?>">
                                    </div>
                                </div>
                            </div> 
							
							<p>I've read and understand the  <a href="<?php echo base_url('/'); ?>" target="_blank" style="display: inline-block;">Terms of service</a>. <a href="<?php echo base_url('/'); ?>" target="_blank" style="display: inline-block;">I already have a membership.</a></p>
							
							*/?>
							
							<div class="row">
							    <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Username</label>
                                        <input type="text" name="username" class="form-control" placeholder="Alpha-numeric characters. Use for login." value="<?php echo set_value('username'); ?>" required>
                                    </div>
                                </div>
							</div>
							
							<div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Email address</label>
                                        <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo set_value('email'); ?>" required>
                                    </div>
                                </div>
                            </div>
							
							<div class="row">
								<div class="col-md-12">
                                    <div class="form-group">
                                        <label>Coupon code</label>
                                        <input type="text" name="reference_no" class="form-control" placeholder="Alpha-numeric characters." value="<?php echo set_value('reference_no'); ?>" required>
                                    </div>
                                </div>
							</div>
							
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="g-recaptcha" data-sitekey="<?php echo $this->recaptcha_sitekey; ?>"></div>
                                </div>
                            </div>

                            <p><a href="<?php echo base_url('/'); ?>" target="_blank" style="display: inline-block;">I already have a membership.</a></p>

                            <button type="submit" class="btn btn-info btn-fill">Submit</button>
                            <div class="clearfix"></div>
                        </form>

                    </div>
                </div>
         
            </div>
        </div>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>


    </div>



</div>




<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>


<script src='https://www.google.com/recaptcha/api.js'></script>

<!-- page script -->
<script>
  $(function () {
    
  });
</script>
</body>
</html>