<!DOCTYPE html>
<html lang="en-US">
  <head>

    <base href="<?php echo $custom_url; ?>/">



     <!-- Basic -->
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favcon -->
          <link rel="shortcut icon" type="image/png" href="wp-content/themes/edutech/images/favicon.png">
        <title><?php echo $meta['title']; ?></title>
<link rel='dns-prefetch' href='//maps.google.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="theaustralianacademy &raquo; Feed" href="feed/" />
<link rel="alternate" type="application/rss+xml" title="theaustralianacademy &raquo; Comments Feed" href="comments/feed/" />
<link rel="alternate" type="text/calendar" title="theaustralianacademy &raquo; iCal Feed" href="events/?ical=1" />
    <script type="text/javascript">
      window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/theaustralianacademy.com\/NEW\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.8"}};
      !function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
    </script>
    <style type="text/css">
img.wp-smiley,
img.emoji {
  display: inline !important;
  border: none !important;
  box-shadow: none !important;
  height: 1em !important;
  width: 1em !important;
  margin: 0 .07em !important;
  vertical-align: -0.1em !important;
  background: none !important;
  padding: 0 !important;
}
</style>
<link rel='stylesheet' id='tribe-events-full-calendar-style-css'  href='wp-content/plugins/the-events-calendar/src/resources/css/tribe-events-full.min.css?ver=4.6.21' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-events-custom-jquery-styles-css'  href='wp-content/plugins/the-events-calendar/vendor/jquery/smoothness/jquery-ui-1.8.23.custom.css?ver=4.6.21' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-events-bootstrap-datepicker-css-css'  href='wp-content/plugins/the-events-calendar/vendor/bootstrap-datepicker/css/bootstrap-datepicker.standalone.min.css?ver=4.6.21' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-events-calendar-style-css'  href='wp-content/plugins/the-events-calendar/src/resources/css/tribe-events-theme.min.css?ver=4.6.21' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-accessibility-css-css'  href='wp-content/plugins/the-events-calendar/common/src/resources/css/accessibility.min.css?ver=4.7.18' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-events-calendar-full-mobile-style-css'  href='wp-content/plugins/the-events-calendar/src/resources/css/tribe-events-full-mobile.min.css?ver=4.6.21' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='tribe-events-calendar-mobile-style-css'  href='wp-content/plugins/the-events-calendar/src/resources/css/tribe-events-theme-mobile.min.css?ver=4.6.21' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='contact-form-7-css'  href='wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0.3' type='text/css' media='all' />


<link rel='stylesheet' id='bootstrap-css'  href='wp-content/themes/edutech/vendor/bootstrap/bootstrap.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-select-css'  href='wp-content/themes/edutech/vendor/bootstrap-select/dist/css/bootstrap-select.css?ver=4.9.8' type='text/css' media='all' />

<link rel='stylesheet' id='font-awesome-css'  href='wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=5.0.1' type='text/css' media='all' />


<link rel='stylesheet' id='animate-css'  href='wp-content/themes/edutech/vendor/WOW-master/css/libs/animate.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='edutech_main-style-css'  href='wp-content/themes/edutech/style.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='edutech_responsive-css'  href='wp-content/themes/edutech/css/responsive.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='edutech_custom-style-css'  href='wp-content/themes/edutech/css/custom.css?ver=4.9.8' type='text/css' media='all' />

<link rel='stylesheet' id='edutech-theme-slug-fonts-css'  href='https://fonts.googleapis.com/css?family=Lato%3A700%7COpen+Sans%3A400%2C600%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />

<link rel='stylesheet' id='js_composer_front-css'  href='wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=5.0.1' type='text/css' media='all' />

<script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>



<script type='text/javascript'>
/* <![CDATA[ */
var tribe_js_config = {"permalink_settings":"\/index.php\/%year%\/%monthnum%\/%day%\/%postname%\/","events_post_type":"tribe_events","events_base":"http:\/\/theaustralianacademy.com\/NEW\/index.php\/events\/"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/the-events-calendar/src/resources/js/tribe-events.min.js?ver=4.6.21'></script>
<script type='text/javascript' src='wp-content/plugins/the-events-calendar/src/resources/js/tribe-events-bar.min.js?ver=4.6.21'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.3.1.5'></script>
<script type='text/javascript' src='wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.3.1.5'></script>
<script type='text/javascript' src='http://maps.google.com/maps/api/js?key&#038;ver=4.9.8'></script>
<script type='text/javascript' src='wp-content/themes/edutech/vendor/gmap.js?ver=4.9.8'></script>


<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>


</head>
  <body class="page-template page-template-tpl-visual_composer page-template-tpl-visual_composer-php page page-id-10 tribe-no-js wpb-js-composer js-comp-ver-5.0.1 vc_responsive">
    
    <div class="main-page-wrapper">


        <!-- Header _________________________________ -->
        <header class="inner-header">

            <?php /*
            <div class="top-header">
                <div class="container">
                    <div class="left-side float-left">

                        <ul>
                                                      <li><span class="icon round-border"><i class="ficon flaticon-signs"></i></span> <a href="" class="tran3s">45/12 Best Avenue Street, UK 2450, US</a></li>
                                                                      <li><span class="icon round-border"><i class="ficon flaticon-multimedia"></i></span> <a href="mailto:lakhvir0788@gmail.com" class="tran3s">lakhvir0788@gmail.com</a></li>
                                                                                    <li><span class="icon round-border"><i class="ficon flaticon-technology"></i></span> <a href="Tel: +49 123 456 789" class="tran3s"> +49 123 456 789</a></li>
                                                                                </ul> 
                    </div> <!-- /.left-side -->
                                        <div class="right-side float-right">
                                                <ul>
                                                      <li><a href="http://facebook.com" class="tran3s round-border icon"><i class="fa fa-facebook"></i></a></li>
                                                        <li><a href="http://twitter.com" class="tran3s round-border icon"><i class="fa fa-twitter"></i></a></li>
                                                        <li><a href="http://googleplus.com" class="tran3s round-border icon"><i class="fa fa-google-plus"></i></a></li>
                                                        <li><a href="http://linkedin.com" class="tran3s round-border icon"><i class="fa fa-linkedin"></i></a></li>
                                                    </ul>
                                            </div> <!-- /.right-side -->
                                    </div>
            </div> <!-- /.top-header -->
            */ ?>
            <div class="top-header">
                <div class="container">
                    &nbsp;
                </div>
            </div>


            <div class="container">
                <div class="main-menu-wrapper clear-fix" style="background-color: #0facce;">
                    <div class="container">
                        <div class="logo float-left">
                          <a href="<?php echo base_url('/'); ?>"  ><h2 style="color:#fff;">The Australian Academy</h2></a>
                        </div>
 
                        <!-- Menu -->
                        <nav class="navbar float-right">
                           <!-- Brand and toggle get grouped for better mobile display -->
                           <div class="navbar-header">
                             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="false">
                               <span class="sr-only">Toggle navigation</span>
                               <span class="icon-bar"></span>
                               <span class="icon-bar"></span>
                               <span class="icon-bar"></span>
                             </button>
                           </div>
                           <!-- Collect the nav links, forms, and other content for toggling -->
                           <div class="collapse navbar-collapse" id="navbar-collapse-1">
                             <ul class="nav navbar-nav">


<li id="menu-item-249" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-249"><a title="Home" href="<?php echo base_url('/'); ?>" class="hvr-underline-from-left1" data-scroll data-options="easing: easeOutQuart">Home</a></li>

<li id="menu-item-288" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-10 current_page_item menu-item-288 active"><a title="" href="http://theaustralianacademy.com/about-us/" class="hvr-underline-from-left1" data-scroll data-options="easing: easeOutQuart">About Us</a></li>







<li id="menu-item-304" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-304 dropdown dropdown-holder"><a title="Test format" href="<?php echo base_url('/'); ?>" data-toggle="dropdown1" class="hvr-underline-from-left1" aria-expanded="false" data-scroll data-options="easing: easeOutQuart">Sections</a>
          <ul role="menu" class="sub-menu">

            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/'); ?>">Speaking Section</a></li>
            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/'); ?>">Writing Section</a></li>
            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/'); ?>">Reading Section</a></li>
            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/'); ?>">Listening Section</a></li>
          </ul>
</li>





<li id="menu-item-304" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-304 dropdown dropdown-holder"><a title="" href="<?php echo base_url('/'); ?>" data-toggle="dropdown1" class="hvr-underline-from-left1" aria-expanded="false" data-scroll data-options="easing: easeOutQuart">Contact Us</a>
          <ul role="menu" class="sub-menu">

            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/'); ?>">Candidate Queries</a></li>
            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/'); ?>">Partner Queries</a></li>
            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/'); ?>">Affiliate Queries</a></li>
            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/'); ?>">FAQs</a></li>
            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/'); ?>">Common Questions</a></li>
          </ul>
</li>








<li id="menu-item-304" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-304 dropdown dropdown-holder"><a title="" href="<?php echo base_url('/'); ?>" data-toggle="dropdown1" class="hvr-underline-from-left1" aria-expanded="false" data-scroll data-options="easing: easeOutQuart">Login</a>
          <ul role="menu" class="sub-menu">

            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/member'); ?>">Student Login</a></li>
            <li id="menu-item-322" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-322"><a href="<?php echo base_url('/registration'); ?>">Student Registration</a></li>

          </ul>
</li>
















                             </ul>
                           </div><!-- /.navbar-collapse -->
                        </nav>
                    </div>
                </div> <!-- /.main-menu-wrapper -->
            </div>
        </header><!-- Inner Page Main Banner __________________ -->
<div class="inner-page-banner" >
    <div class="opacity">
        <div class="container">
            <h2>Register a new membership</h2>
        </div> <!-- /.container -->
    </div> <!-- /.opacity -->
</div> <!-- /.inner-page-banner -->

<!-- Page Breadcrum __________________________ -->
<div class="page-breadcrum">
    <div class="container">
        <ul class=""><li><a>Home</a></li><li style="color: #0facce;">Registration</li></ul>    </div> <!-- /.container -->
</div>
 


            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="card ">

                            <?php if($success) { ?>
                            <div class="alert alert-success">
                                You have successfully register. Please check your inbox for account details.
                            </div>
                            <?php } else { ?> 

                                    <?php echo validation_errors(); ?>
                                    <?php echo form_open_multipart('registration', array('id' => mb_strtolower($this->uri->rsegment(2)), 'class' => 'formclassx' )); ?>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Full name</label>
                                                    <input type="text" name="name" class="form-control" placeholder="Contain only alpha-numeric characters or spaces." required value="<?php echo set_value('name'); ?>">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Email address</label>
                                                    <input type="email" name="email" class="form-control" placeholder="Email" required value="<?php echo set_value('email'); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Username</label>
                                                    <input type="text" name="username" class="form-control" placeholder="Alpha-numeric characters. Use for login." required value="<?php echo set_value('username'); ?>">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Mobile</label>
                                                    <input type="text" name="mobile" class="form-control" placeholder="e.g. +91 9800098000, +91 9800098000" required value="<?php echo set_value('mobile'); ?>">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Address</label>
                                                    <input type="text" name="street_address" class="form-control" placeholder="Street name and number" required value="<?php echo set_value('street_address'); ?>">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>City or Region</label>
                                                    <input type="text" name="city_region" class="form-control" placeholder="" required value="<?php echo set_value('city_region'); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Country</label>
                                                    <select name="country_id" class="form-control" required>
                                                        <option value=""></option>
                                                        <?php
                                                            foreach ($countries as $getCountry) {
                                                                echo '<option value="'.$getCountry->id.'">'.$getCountry->name.'</option>';
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label>Postal Code</label>
                                                    <input type="number" name="postal_code" class="form-control" placeholder="ZIP Code" required value="<?php echo set_value('postal_code'); ?>">
                                                </div>
                                            </div>
                                        </div>



                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="g-recaptcha" data-sitekey="<?php echo $this->recaptcha_sitekey; ?>"></div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-12">
                                                <p>I've read and understand the 

                                                    <strong>
                                                        <a href="<?php echo base_url('/'); ?>" target="_blank">Terms of service</a>
                                                    </strong>.
                                                    <br>

                                                    <strong>
                                                        <a href="<?php echo base_url('/member'); ?>" target="_blank">I already have a membership.</a>
                                                    </strong>
                                                </p>
                                                <div class="clearfix">&nbsp;</div>

                                                <div class="single-input float-leftc input-three">
                                                    <button type="submit" style="width: 120px;color: #fff;padding-top: 4px;padding-bottom: 4px;background-color: #0facce;" class="tran3s p-color-bg themehover">Submit</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                            <?php } ?>

                        </div>
                    </div>
                </div>
            </div>



            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                    </div>
                </div>
            </div>


<div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">   
   


</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">


</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">   
   

</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">



</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">


</div></div></div></div>
  
        
    <footer>
   <div class="bottom-footer">
            <p>Copyright 2018 &copy; <a href="http://theaustralianacademy.com/" class="tran3s" target="_blank" style="color: #0facce;">Theaustralianacademy.com</a></p>
        </div>
    </footer>

    <!-- Scroll Top Button -->
    <button class="scroll-top tran3s p-color-bg">
        <i class="fa fa-angle-up" aria-hidden="true"></i>
    </button>
    
    <!-- pre loader  -->
    </div>    
   
<script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='wp-content/themes/edutech/vendor/bootstrap/bootstrap.min.js?ver=4.9.8'></script>
<script type='text/javascript' src='wp-content/themes/edutech/vendor/bootstrap-select/dist/js/bootstrap-select.js?ver=4.9.8'></script>


<script type='text/javascript' src='wp-content/themes/edutech/js/theme.js?ver=4.9.8'></script>


</body>
</html>