<div class="top-bar top-bar-v4">
    <div class="col-full">
        <ul id="menu-top-bar-left" class="nav">
            <li class="menu-item animate-dropdown">
                <a href="<?php echo base_url('/about'); ?>">About</a>
            </li>
            <li class="menu-item animate-dropdown">
                <a href="<?php echo base_url('/rules'); ?>">Listing Rules</a>
            </li>
            <li class="menu-item animate-dropdown">
                <a href="<?php echo base_url('/terms'); ?>">Terms &amp; Conditions</a>
            </li>
            <li class="menu-item animate-dropdown">
                <a href="<?php echo base_url('/privacy'); ?>">Privacy Policy</a>
            </li>

            <li class="menu-item animate-dropdown">
                <a href="<?php echo base_url('/registration'); ?>"><i class="tm tm-login-register"></i>Register</a>
            </li>

            <li class="menu-item animate-dropdown">
                <a href="<?php echo base_url('/member/login'); ?>"><i class="tm tm-login-register"></i>Member Login</a>
            </li>

        </ul>
        <!-- .nav -->


    </div>
</div>

<header id="masthead" class="site-header header-v4" style="background-image: none; ">
    <?php include_once('navigation-desktop.php'); ?>
    <?php include_once('navigation-handheld.php'); ?>
</header>