<div class="col-full desktop-only">
    <div class="techmarket-sticky-wrap">
        <div class="row">
            <div class="site-branding">
                <a href="<?php echo base_url('/'); ?>" class="custom-logo-link" rel="home">
                    <img src="<?php echo base_url('/theme/manage/assets/img/logo.png'); ?>" border="0" alt="Logo">
                </a>
            </div>

            <div id="departments-menu" class="dropdown departments-menu">
                <button class="btn dropdown-toggle btn-block" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="tm tm-departments-thin"></i>
                    <span>All Departments</span>
                </button>
                <ul id="menu-departments-menu" class="dropdown-menu yamm departments-menu-dropdown">
                    <li class="highlight menu-item animate-dropdown">
                        <a href="<?php echo base_url('/'); ?>">For Swap</a>
                    </li>
                    <li class="highlight menu-item animate-dropdown">
                        <a href="<?php echo base_url('/'); ?>">For Sale</a>
                    </li>
                    <li class="highlight menu-item animate-dropdown">
                        <a href="<?php echo base_url('/'); ?>">Wanted</a>
                    </li>
                    <li class="yamm-tfw menu-item menu-item-has-children animate-dropdown dropdown-submenu">
                        <a title="Computers &amp; Laptops" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" href="##">Computers &#038; Laptops <span class="caret"></span></a>
                        <ul role="menu" class=" dropdown-menu">
                            <li class="menu-item menu-item-object-static_block animate-dropdown">
                                <div class="yamm-content">
                                    <div class="bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right">
                                        <div class="kc-col-container">
                                            <div class="kc_single_image">
                                                <img src="assets/images/megamenu.jpg" class="" alt="" />
                                            </div>
                                            <!-- .kc_single_image -->
                                        </div>
                                        <!-- .kc-col-container -->
                                    </div>
                                    <!-- .bg-yamm-content -->
                                    <div class="row yamm-content-row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Computers &amp; Accessories</li>
                                                        <li><a href="#shop.html">All Computers &amp; Accessories</a></li>
                                                        <li><a href="#shop.html">Laptops, Desktops &amp; Monitors</a></li>
                                                        <li><a href="#shop.html">Pen Drives, Hard Drives &amp; Memory Cards</a></li>
                                                        <li><a href="#shop.html">Printers &amp; Ink</a></li>
                                                        <li><a href="#shop.html">Networking &amp; Internet Devices</a></li>
                                                        <li><a href="#shop.html">Computer Accessories</a></li>
                                                        <li><a href="#shop.html">Software</a></li>
                                                        <li class="nav-divider"></li>
                                                        <li>
                                                            <a href="##">
                                                                <span class="nav-text">All Electronics</span>
                                                                <span class="nav-subtext">Discover more products</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Office &amp; Stationery</li>
                                                        <li><a href="#shop.html">All Office &amp; Stationery</a></li>
                                                        <li><a href="#shop.html">Pens &amp; Writing</a></li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                    </div>
                                    <!-- .kc_row -->
                                </div>
                                <!-- .yamm-content -->
                            </li>
                        </ul>
                    </li>
                    <li class="yamm-tfw menu-item menu-item-has-children animate-dropdown dropdown-submenu">
                        <a title="Cameras &amp; Photo" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" href="##">Cameras &#038; Photo <span class="caret"></span></a>
                        <ul role="menu" class=" dropdown-menu">
                            <li class="menu-item menu-item-object-static_block animate-dropdown">
                                <div class="yamm-content">
                                    <div class="bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right">
                                        <div class="kc-col-container">
                                            <div class="kc_single_image">
                                                <img src="assets/images/megamenu-1.jpg" class="" alt="" />
                                            </div>
                                            <!-- .kc_single_image -->
                                        </div>
                                        <!-- .kc-col-container -->
                                    </div>
                                    <!-- .bg-yamm-content -->
                                    <div class="row yamm-content-row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Cameras & Photography</li>
                                                        <li><a href="#shop.html">All Cameras & Photography</a></li>
                                                        <li><a href="#shop.html">Point & Shoot Cameras</a></li>
                                                        <li><a href="#shop.html">Lenses</a></li>
                                                        <li><a href="#shop.html">Camera Accessories</a></li>
                                                        <li><a href="#shop.html">Security & Surveillance</a></li>
                                                        <li><a href="#shop.html">Binoculars & Telescopes</a></li>
                                                        <li><a href="#shop.html">Camcorders</a></li>
                                                        <li class="nav-divider"></li>
                                                        <li>
                                                            <a href="##">
                                                                <span class="nav-text">All Electronics</span>
                                                                <span class="nav-subtext">Discover more products</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Audio & Video</li>
                                                        <li><a href="#shop.html">All Audio & Video</a></li>
                                                        <li><a href="#shop.html">Headphones & Speakers</a></li>
                                                        <li><a href="#shop.html">Home Entertainment Systems</a></li>
                                                        <li><a href="#shop.html">MP3 & Media Players</a></li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                    </div>
                                    <!-- .kc_row -->
                                </div>
                                <!-- .yamm-content -->
                            </li>
                        </ul>
                    </li>
                    <li class="yamm-tfw menu-item menu-item-has-children animate-dropdown dropdown-submenu">
                        <a title="Smart Phones &amp; Tablets" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" href="##">Smart Phones &#038; Tablets <span class="caret"></span></a>
                        <ul role="menu" class=" dropdown-menu">
                            <li class="menu-item menu-item-object-static_block animate-dropdown">
                                <div class="yamm-content">
                                    <div class="bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right">
                                        <div class="kc-col-container">
                                            <div class="kc_single_image">
                                                <img src="assets/images/megamenu.jpg" class="" alt="" />
                                            </div>
                                            <!-- .kc_single_image -->
                                        </div>
                                        <!-- .kc-col-container -->
                                    </div>
                                    <!-- .bg-yamm-content -->
                                    <div class="row yamm-content-row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Computers &amp; Accessories</li>
                                                        <li><a href="#shop.html">All Computers &amp; Accessories</a></li>
                                                        <li><a href="#shop.html">Laptops, Desktops &amp; Monitors</a></li>
                                                        <li><a href="#shop.html">Pen Drives, Hard Drives &amp; Memory Cards</a></li>
                                                        <li><a href="#shop.html">Printers &amp; Ink</a></li>
                                                        <li><a href="#shop.html">Networking &amp; Internet Devices</a></li>
                                                        <li><a href="#shop.html">Computer Accessories</a></li>
                                                        <li><a href="#shop.html">Software</a></li>
                                                        <li class="nav-divider"></li>
                                                        <li>
                                                            <a href="##">
                                                                <span class="nav-text">All Electronics</span>
                                                                <span class="nav-subtext">Discover more products</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Office &amp; Stationery</li>
                                                        <li><a href="#shop.html">All Office &amp; Stationery</a></li>
                                                        <li><a href="#shop.html">Pens &amp; Writing</a></li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                    </div>
                                    <!-- .kc_row -->
                                </div>
                                <!-- .yamm-content -->
                            </li>
                        </ul>
                    </li>
                    <li class="yamm-tfw menu-item menu-item-has-children animate-dropdown dropdown-submenu">
                        <a title="Video Games &amp; Consoles" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" href="##">Video Games &#038; Consoles <span class="caret"></span></a>
                        <ul role="menu" class=" dropdown-menu">
                            <li class="menu-item menu-item-object-static_block animate-dropdown">
                                <div class="yamm-content">
                                    <div class="bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right">
                                        <div class="kc-col-container">
                                            <div class="kc_single_image">
                                                <img src="assets/images/megamenu-1.jpg" class="" alt="" />
                                            </div>
                                            <!-- .kc_single_image -->
                                        </div>
                                        <!-- .kc-col-container -->
                                    </div>
                                    <!-- .bg-yamm-content -->
                                    <div class="row yamm-content-row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Cameras & Photography</li>
                                                        <li><a href="#shop.html">All Cameras & Photography</a></li>
                                                        <li><a href="#shop.html">Point & Shoot Cameras</a></li>
                                                        <li><a href="#shop.html">Lenses</a></li>
                                                        <li><a href="#shop.html">Camera Accessories</a></li>
                                                        <li><a href="#shop.html">Security & Surveillance</a></li>
                                                        <li><a href="#shop.html">Binoculars & Telescopes</a></li>
                                                        <li><a href="#shop.html">Camcorders</a></li>
                                                        <li class="nav-divider"></li>
                                                        <li>
                                                            <a href="##">
                                                                <span class="nav-text">All Electronics</span>
                                                                <span class="nav-subtext">Discover more products</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Audio & Video</li>
                                                        <li><a href="#shop.html">All Audio & Video</a></li>
                                                        <li><a href="#shop.html">Headphones & Speakers</a></li>
                                                        <li><a href="#shop.html">Home Entertainment Systems</a></li>
                                                        <li><a href="#shop.html">MP3 & Media Players</a></li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                    </div>
                                    <!-- .kc_row -->
                                </div>
                                <!-- .yamm-content -->
                            </li>
                        </ul>
                    </li>
                    <li class="yamm-tfw menu-item menu-item-has-children animate-dropdown dropdown-submenu">
                        <a title="TV &amp; Audio" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" href="##">TV &#038; Audio <span class="caret"></span></a>
                        <ul role="menu" class=" dropdown-menu">
                            <li class="menu-item menu-item-object-static_block animate-dropdown">
                                <div class="yamm-content">
                                    <div class="bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right">
                                        <div class="kc-col-container">
                                            <div class="kc_single_image">
                                                <img src="assets/images/megamenu.jpg" class="" alt="" />
                                            </div>
                                            <!-- .kc_single_image -->
                                        </div>
                                        <!-- .kc-col-container -->
                                    </div>
                                    <!-- .bg-yamm-content -->
                                    <div class="row yamm-content-row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Computers &amp; Accessories</li>
                                                        <li><a href="#shop.html">All Computers &amp; Accessories</a></li>
                                                        <li><a href="#shop.html">Laptops, Desktops &amp; Monitors</a></li>
                                                        <li><a href="#shop.html">Pen Drives, Hard Drives &amp; Memory Cards</a></li>
                                                        <li><a href="#shop.html">Printers &amp; Ink</a></li>
                                                        <li><a href="#shop.html">Networking &amp; Internet Devices</a></li>
                                                        <li><a href="#shop.html">Computer Accessories</a></li>
                                                        <li><a href="#shop.html">Software</a></li>
                                                        <li class="nav-divider"></li>
                                                        <li>
                                                            <a href="##">
                                                                <span class="nav-text">All Electronics</span>
                                                                <span class="nav-subtext">Discover more products</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Office &amp; Stationery</li>
                                                        <li><a href="#shop.html">All Office &amp; Stationery</a></li>
                                                        <li><a href="#shop.html">Pens &amp; Writing</a></li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                    </div>
                                    <!-- .kc_row -->
                                </div>
                                <!-- .yamm-content -->
                            </li>
                        </ul>
                    </li>
                    <li class="yamm-tfw menu-item menu-item-has-children animate-dropdown dropdown-submenu">
                        <a title="Car Electronic &amp; GPS" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" href="##">Car Electronic &#038; GPS <span class="caret"></span></a>
                        <ul role="menu" class=" dropdown-menu">
                            <li class="menu-item menu-item-object-static_block animate-dropdown">
                                <div class="yamm-content">
                                    <div class="bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right">
                                        <div class="kc-col-container">
                                            <div class="kc_single_image">
                                                <img src="assets/images/megamenu-1.jpg" class="" alt="" />
                                            </div>
                                            <!-- .kc_single_image -->
                                        </div>
                                        <!-- .kc-col-container -->
                                    </div>
                                    <!-- .bg-yamm-content -->
                                    <div class="row yamm-content-row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Cameras & Photography</li>
                                                        <li><a href="#shop.html">All Cameras & Photography</a></li>
                                                        <li><a href="#shop.html">Point & Shoot Cameras</a></li>
                                                        <li><a href="#shop.html">Lenses</a></li>
                                                        <li><a href="#shop.html">Camera Accessories</a></li>
                                                        <li><a href="#shop.html">Security & Surveillance</a></li>
                                                        <li><a href="#shop.html">Binoculars & Telescopes</a></li>
                                                        <li><a href="#shop.html">Camcorders</a></li>
                                                        <li class="nav-divider"></li>
                                                        <li>
                                                            <a href="##">
                                                                <span class="nav-text">All Electronics</span>
                                                                <span class="nav-subtext">Discover more products</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Audio & Video</li>
                                                        <li><a href="#shop.html">All Audio & Video</a></li>
                                                        <li><a href="#shop.html">Headphones & Speakers</a></li>
                                                        <li><a href="#shop.html">Home Entertainment Systems</a></li>
                                                        <li><a href="#shop.html">MP3 & Media Players</a></li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                    </div>
                                    <!-- .kc_row -->
                                </div>
                                <!-- .yamm-content -->
                            </li>
                        </ul>
                    </li>
                    <li class="yamm-tfw menu-item menu-item-has-children animate-dropdown dropdown-submenu">
                        <a title="Accesories" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true" href="##">Accesories <span class="caret"></span></a>
                        <ul role="menu" class=" dropdown-menu">
                            <li class="menu-item menu-item-object-static_block animate-dropdown">
                                <div class="yamm-content">
                                    <div class="bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right">
                                        <div class="kc-col-container">
                                            <div class="kc_single_image">
                                                <img src="assets/images/megamenu.jpg" class="" alt="" />
                                            </div>
                                            <!-- .kc_single_image -->
                                        </div>
                                        <!-- .kc-col-container -->
                                    </div>
                                    <!-- .bg-yamm-content -->
                                    <div class="row yamm-content-row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Computers &amp; Accessories</li>
                                                        <li><a href="#shop.html">All Computers &amp; Accessories</a></li>
                                                        <li><a href="#shop.html">Laptops, Desktops &amp; Monitors</a></li>
                                                        <li><a href="#shop.html">Pen Drives, Hard Drives &amp; Memory Cards</a></li>
                                                        <li><a href="#shop.html">Printers &amp; Ink</a></li>
                                                        <li><a href="#shop.html">Networking &amp; Internet Devices</a></li>
                                                        <li><a href="#shop.html">Computer Accessories</a></li>
                                                        <li><a href="#shop.html">Software</a></li>
                                                        <li class="nav-divider"></li>
                                                        <li>
                                                            <a href="##">
                                                                <span class="nav-text">All Electronics</span>
                                                                <span class="nav-subtext">Discover more products</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                        <div class="col-md-6 col-sm-12">
                                            <div class="kc-col-container">
                                                <div class="kc_text_block">
                                                    <ul>
                                                        <li class="nav-title">Office &amp; Stationery</li>
                                                        <li><a href="#shop.html">All Office &amp; Stationery</a></li>
                                                        <li><a href="#shop.html">Pens &amp; Writing</a></li>
                                                    </ul>
                                                </div>
                                                <!-- .kc_text_block -->
                                            </div>
                                            <!-- .kc-col-container -->
                                        </div>
                                        <!-- .kc_column -->
                                    </div>
                                    <!-- .kc_row -->
                                </div>
                                <!-- .yamm-content -->
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item menu-item-type-custom animate-dropdown">
                        <a title="Gadgets" href="#landing-page-v1.html">Gadgets</a>
                    </li>
                    <li class="menu-item menu-item-type-custom animate-dropdown">
                        <a title="Virtual Reality" href="#landing-page-v2.html">Virtual Reality</a>
                    </li>
                </ul>
            </div>
            <!-- .departments-menu -->












            <form class="navbar-search" method="get" action="">
                <label class="sr-only screen-reader-text" for="search">Search for:</label>
                <div class="input-group">
                    <input type="text" id="search" class="form-control search-field product-search-field" dir="ltr" value="" name="s" placeholder="Search for products" />
                    <div class="input-group-addon search-categories popover-header">
                        <select name='product_cat' id='product_cat' class='postform resizeselect'>
                            <option value='0' selected='selected'>All Categories</option>
                            <option class="level-0" value="television">Televisions</option>
                            <option class="level-0" value="home-theater-audio">Home Theater &amp; Audio</option>
                            <option class="level-0" value="headphones">Headphones</option>
                            <option class="level-0" value="digital-cameras">Digital Cameras</option>
                            <option class="level-0" value="cells-tablets">Cells &amp; Tablets</option>
                            <option class="level-0" value="smartwatches">Smartwatches</option>
                            <option class="level-0" value="games-consoles">Games &amp; Consoles</option>
                            <option class="level-0" value="printer">Printer</option>
                            <option class="level-0" value="tv-video">TV &amp; Video</option>
                            <option class="level-0" value="home-entertainment">Home Entertainment</option>
                            <option class="level-0" value="tvs">TVs</option>
                            <option class="level-0" value="speakers">Speakers</option>
                            <option class="level-0" value="computers-laptops">Computers &amp; Laptops</option>
                            <option class="level-0" value="laptops">Laptops</option>
                            <option class="level-0" value="ultrabooks">Ultrabooks</option>
                            <option class="level-0" value="notebooks">Notebooks</option>
                            <option class="level-0" value="desktop-pcs">Desktop PCs</option>
                            <option class="level-0" value="mac-computers">Mac Computers</option>
                            <option class="level-0" value="all-in-one-pc">All in One PC</option>
                            <option class="level-0" value="audio-music">Audio &amp; Music</option>
                            <option class="level-0" value="pc-components">PC Components</option>
                        </select>
                    </div>
                    <!-- .input-group-addon -->
                    <div class="input-group-btn input-group-append">
                        <input type="hidden" id="search-param" name="post_type" value="product" />
                        <button type="submit" class="btn btn-primary">
                            <i class="fa fa-search"></i>
                            <span class="search-btn">Search</span>
                        </button>
                    </div>
                    <!-- .input-group-btn -->
                </div>
                <!-- .input-group -->
            </form>
            <!-- .navbar-search -->







            <!-- .header-wishlist -->
            <ul id="site-header-cart" class="site-header-cart menu">
                <li class="animate-dropdown dropdown ">
                    <a class="cart-contents" href="<?php echo base_url('/'); ?>" data-toggle="dropdown" title="View your wishlist">
                        <i class="tm tm-favorites"></i>
                        <span class="count">2</span>
                        <span class="amount">
                            <span class="price-label"></span>Wishlist</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-mini-cart">
                        <li>
                            <div class="widget woocommerce widget_shopping_cart">
                                <div class="widget_shopping_cart_content">
                                    <ul class="woocommerce-mini-cart cart_list product_list_widget ">
                                        <li class="woocommerce-mini-cart-item mini_cart_item">
                                            <a class="remove" aria-label="Remove this item" data-product_id="65" data-product_sku="">×</a>
                                            <a>
                                                <img src="assets/images/products/mini-cart1.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="">XONE Wireless Controller&nbsp;
                                            </a>
                                            <span class="quantity">1 ×
                                                <span class="woocommerce-Price-amount amount">
                                                    <span class="woocommerce-Price-currencySymbol">$</span>64.99</span>
                                            </span>
                                        </li>
                                        <li class="woocommerce-mini-cart-item mini_cart_item">
                                            <a class="remove" aria-label="Remove this item" data-product_id="27" data-product_sku="">×</a>
                                            <a>
                                                <img src="assets/images/products/mini-cart2.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="">Gear Virtual Reality 3D with Bluetooth Glasses&nbsp;
                                            </a>
                                            <span class="quantity">1 ×
                                                <span class="woocommerce-Price-amount amount">
                                                    <span class="woocommerce-Price-currencySymbol">$</span>72.00</span>
                                            </span>
                                        </li>
                                    </ul>
                                   

                                    <p class="woocommerce-mini-cart__buttons buttons">
                                        <a href="<?php echo base_url('/'); ?>" class="button wc-forward">View Wishlist</a>
                                        <a href="<?php echo base_url('/'); ?>" class="button checkout wc-forward">Profile</a>
                                    </p>
                                </div>
                                <!-- .widget_shopping_cart_content -->
                            </div>
                            <!-- .widget_shopping_cart -->
                        </li>
                    </ul>
                    <!-- .dropdown-menu-mini-cart -->
                </li>
            </ul>
            <!-- .site-header-cart -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.row -->
</div>