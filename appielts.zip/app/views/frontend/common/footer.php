<footer class="footer">
    <div class="container-fluid">
        <?php /*
        <nav class="pull-left">
            <ul>
                <li><a href="#">Link</a></li>
                <li><a href="#">Link</a></li>
                <li><a href="#">Link</a></li>
            </ul>
        </nav>
        */ ?>
        <p class="copyright text-center">
            &copy; <?php echo date('Y'); ?> <a href="<?php echo base_url('/'); ?>"><?php echo $this->app_name; ?></a>. All rights reserved
        </p>
    </div>
</footer>