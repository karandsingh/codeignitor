<!doctype html>
<html lang="en">
<head>
    <title><?php echo $meta['title']; ?></title>
    <?php include_once('common/head.php'); ?>
</head>
<body>

<div class="wrapper">
    <?php //include_once('common/sidebar.php'); ?>

    <div class="main-panelx">



        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h3><?php echo $this->app_name; ?></h3>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Sign in to start your session</h4>
                            </div>
                            <div class="content">
                                <form>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Username</label>
                                                <input type="text" class="form-control" placeholder="Username" value="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address</label>
                                                <input type="email" class="form-control" placeholder="Email">
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill">Login</button>
                                    <div class="clearfix"></div>
                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>


        <?php include_once('common/footer.php'); ?>
    </div>
</div>


</body>

    <?php include_once('common/scripts.php'); ?>
</html>