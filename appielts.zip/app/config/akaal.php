<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* Custom settings for Site
*
*/

# number of questions should be visible 
$config['number_of_visible_questions'] = 35;


# number of teachers should check student tests 
$config['number_of_teachers_for_checking'] = 2;

$config['app_name'] = 'app.ielts24x7.com';
//$config['app_name'] = 'CELPIPSTORE.COM';
$config['app_email'] = 'admin@ielts24x7.com';
//$config['app_email'] = 'admin@celpipstore.com';

$config['app_contactemail'] = 'contact@ielts24x7.com';

$config['app_datetimeformat'] = 'M j, Y h:i A';
$config['app_dateformat'] = 'M j, Y';

$config['tb_prefix'] = 'system_';
$config['tb_suffix'] = '_code';

/* End of file akaal.php */
/* Location: ./application/config/akaal.php */