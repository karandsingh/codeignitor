<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* Customizing the Pagination
* 
* For more information: https://ellislab.com/codeIgniter/user-guide/libraries/pagination.html 
*/

//The following is a list of all the preferences you can pass to the initialization function to tailor the display.

$config['uri_segment'] = 2;
//The pagination function automatically determines which segment of your URI contains the page number. If you need something different you can specify it.

$config['num_links'] = 2;
//The number of "digit" links you would like before and after the selected page number. For example, the number 2 will place two digits on either side, as in the example links at the very top of this page.

$config['use_page_numbers'] = TRUE;
//By default, the URI segment will use the starting index for the items you are paginating. If you prefer to show the the actual page number, set this to TRUE.

$config['page_query_string'] = FALSE;
//By default, the pagination library assume you are using URI Segments, and constructs your links something like


// Adding Enclosing Markup

//If you would like to surround the entire pagination with some markup you can do it with these two prefs:

$config['full_tag_open'] = '<ul class="pagination pagination-lg">'; // Additional sizes = .pagination  .pagination-lg  .pagination-sm

//The opening tag placed on the left side of the entire result.

$config['full_tag_close'] = '</ul>';
//The closing tag placed on the right side of the entire result.








//Customizing the First Link

$config['first_link'] = FALSE;
//The text you would like shown in the "first" link on the left. If you do not want this link rendered, you can set its value to FALSE.

$config['first_tag_open'] = '<li>';
//The opening tag for the "first" link.

$config['first_tag_close'] = '</li>';
//The closing tag for the "first" link.





//Customizing the Last Link

$config['last_link'] = FALSE;
//The text you would like shown in the "last" link on the right. If you do not want this link rendered, you can set its value to FALSE.

$config['last_tag_open'] = '<li>';
//The opening tag for the "last" link.

$config['last_tag_close'] = '</li>';
//The closing tag for the "last" link.






//Customizing the "Next" Link

$config['next_link'] = '&raquo;';
//The text you would like shown in the "next" page link. If you do not want this link rendered, you can set its value to FALSE.

$config['next_tag_open'] = '<li>';
//The opening tag for the "next" link.

$config['next_tag_close'] = '</li>';
//The closing tag for the "next" link.






//Customizing the "Previous" Link

$config['prev_link'] = '&laquo;';
//The text you would like shown in the "previous" page link. If you do not want this link rendered, you can set its value to FALSE.

$config['prev_tag_open'] = '<li class="page-item">';
//The opening tag for the "previous" link.

$config['prev_tag_close'] = '</li>';
//The closing tag for the "previous" link.



//Customizing the "Current Page" Link

$config['cur_tag_open'] = '<li><span class="page-numbers current">';
//The opening tag for the "current" link.

$config['cur_tag_close'] = '</span></li>';
//The closing tag for the "current" link.



//Customizing the "Digit" Link

$config['num_tag_open'] = '<li>';
//The opening tag for the "digit" link.

$config['num_tag_close'] = '</li>';
//The closing tag for the "digit" link.




//Hiding the Pages

//If you wanted to not list the specific pages (for example, you only want "next" and "previous" links), you can suppress their rendering by adding:
$config['display_pages'] = TRUE;


//Adding a class to every anchor
$config['anchor_class'] = TRUE;

//If you want to add a class attribute to every link rendered by the pagination class, you can set the config "anchor_class" equal to the classname you want.


/* End of file pagination.php */
/* Location: ./application/config/pagination.php */