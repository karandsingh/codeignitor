<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );
/*
* Common Controller for every specific controller
*/
class AKAAL_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();

        /** Load custom configurations **/
        $this->config->load('akaal');

        /*
        * Set default timezone
        */
        date_default_timezone_set('Asia/Kolkata'); 

        /*
        * Global variables (use in controller, model and view files)
        */
        $this->logged = false;
        $this->success = false;
        $this->data['success'] = false;

        $this->logo_mini = '<b>I</b>';
        //$this->logo_large = '<b>CELPIP</b>.Biz';
        $this->logo_large = '<b>IELTS24X7</b>.com';

        $this->app_name = $this->config->item('app_name');
        $this->app_email = $this->config->item('app_email');
        $this->app_contactemail = $this->config->item('app_email');

        $this->app_datetimeformat = $this->config->item('app_datetimeformat');
        $this->app_dateformat = $this->config->item('app_dateformat');

        $this->recaptcha_sitekey = '6LcF0uAZAAAAABYtku_EYPQew6pjwpOBuXUsDT0x';
        $this->recaptcha_privatekey = '6LcF0uAZAAAAAIElDtBX1EirVcDkTOPuCuOqIINU';

        $this->unauthorized_message = 'You are not authorized to access this page.';
        $this->internalerror_message = 'Internal error, report to webmaster.';
        $this->ajaxerror_message = 'You are not authorized to make this request.';

        $this->filemaxsize = '20480000'; // 20MB = 20480000

        /* 
        * DB Table(s)
        */
        $tb_prefix = $this->tb_prefix = $this->config->item('tb_prefix');
        $tb_suffix = $this->tb_suffix = $this->config->item('tb_suffix');

        $this->tb_prefix = $tb_prefix;
        $this->tb_suffix = $tb_suffix;

        $this->tb_role = $tb_prefix.'role'.$tb_suffix;
        $this->tb_superadmin = $tb_prefix.'superadmin'.$tb_suffix;

        $this->tb_member = $tb_prefix.'member'.$tb_suffix;
        $this->tb_member_extras = $tb_prefix.'member_extras'.$tb_suffix;

        $this->tb_categories = $tb_prefix.'categories'.$tb_suffix;
        $this->tb_countries = $tb_prefix.'countries'.$tb_suffix;

        $this->tb_teacher = $tb_prefix.'teacher'.$tb_suffix;
        $this->tb_teacher_extras = $tb_prefix.'teacher_extras'.$tb_suffix;

        $this->tb_test = $tb_prefix.'tests'.$tb_suffix;
        $this->tb_question = $tb_prefix.'question'.$tb_suffix;
        $this->tb_type = $tb_prefix.'PTEtype'.$tb_suffix;
        $this->tb_subtype = $tb_prefix.'PTEsubtype'.$tb_suffix;

        $this->tb_attempt = $tb_prefix.'attempt'.$tb_suffix;
        $this->tb_testdetails = $tb_prefix.'testdetails'.$tb_suffix;

        $this->tb_support = $tb_prefix.'support'.$tb_suffix;
        $this->tb_ticket = $tb_prefix.'ticket'.$tb_suffix;
		
        $this->tb_reseller = $tb_prefix.'reseller'.$tb_suffix;

        $this->question_screen = array('15','16','17','18','19','20','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','51','52','53','54','55','56','57','58','59');
        $this->BLANKAREA = 'TEXTFIELD';
        $this->BLANKAREA1 = 'TEXTFIELDA';
        $this->BLANKAREA2 = 'TEXTFIELDB';
        $this->BLANKAREA3 = 'TEXTFIELDC';


        // Vocabulary Tests
        $this->tb_vlevel = $tb_prefix.'vlevel'.$tb_suffix;
        $this->tb_vquestion = $tb_prefix.'vquestion'.$tb_suffix;
        $this->tb_voption = $tb_prefix.'voption'.$tb_suffix;
        $this->tb_vtestdetails = $tb_prefix.'vtestdetails'.$tb_suffix;
        $this->tb_vattempt = $tb_prefix.'vattempt'.$tb_suffix;

        /** Load default helper and model **/
        $this->load->helper('my');
        $this->load->model('my_model');




    }

    /*
    * Verify recaptcha
    */
    public function verifyRecaptcha($response) {

        $url = 'https://www.google.com/recaptcha/api/siteverify';
        $data = array(
            'secret' => $this->recaptcha_privatekey,
            'response' => $response
        );
        $options = array(
            'http' => array (
                'method' => 'POST',
                'content' => http_build_query($data)
            )
        );
        $context  = stream_context_create($options);
        $verify = file_get_contents($url, false, $context);
        $captcha = json_decode($verify);

        if($captcha->success == false) {
            return false;
        } else {
            return true;
        }
    }


}