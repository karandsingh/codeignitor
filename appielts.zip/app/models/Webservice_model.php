<?php
if( !defined( 'BASEPATH' ) ) exit( 'No direct script access allowed' );

class Webservice_model extends CI_Model {

	function getUser($table, $username, $password) {
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where('username', $username);
		$this->db->where('password', MD5($password));
		$this->db->where('confirm', 'yes');
		$this->db->limit(1);

		$query = $this->db->get();

		if($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

	function changePassword($newPassword, $uId, $tablename)
	{

		$this->db->select('id');
		$this->db->where('id', $uId);
		$this->db->where('password', MD5($this->input->post('old')));

		$query = $this->db->get( $tablename );

		if($query->num_rows() > 0)
		{
			$data = array(
				'password' => md5($newPassword),
				'notMD5password' =>  $newPassword,
			);

			if($this->updateTable( $tablename, $data, $uId ))
			{
				return true;
			}
			return false;
		}
		else
		{
			// current password is not correct
			return false;
		}
	}

	function getByRole($table, $role_id)
	{
		$this->db->where('role_id', $role_id);
		$this->db->where('confirm', 'yes');
		$this->db->order_by('name', 'asc');
		$query = $this->db->get($table);
		return  $query->result();
	}

	function updateTable($table, $data, $id)
	{
		if(is_string($table) && is_array($data) && is_numeric($id))
		{
			$this->db->where('id', $id);
			$this->db->update($table, $data);
			return true;
		}
		// something went wrong, password not changed
		return false;
	}

	// Without pagination
	function getAllRecords($table) {
		$this->db->order_by('id', 'desc');
		$query = $this->db->get($table);
		return $query->result();
	}

	function getTestimonials($table) {
		$this->db->limit(3);
		$this->db->order_by('rand()');
		$query = $this->db->get($table);
		return  $query->result();
	}

	// with pagination
	/*function getAllRecords($table, $perPage, $offSet=0)
	{
		$this->db->order_by('id', 'asc');
		$query = $this->db->get($table, $perPage, $offSet);
		return $query->result();
	}*/

	function totalCount($table)
	{
		return $this->db->count_all($table);
	}

	function insertDataIntoTable($table, $data)
	{
		if(is_string($table) && is_array($data))
		{
			$this->db->insert($table, $data);
			return true;
		}
		// something went wrong, data not inserted into given table
		return false;
	}

	function getARecord($table, $id)
	{
		if(is_string($table) && is_numeric($id))
		{
			$this->db->where('id', $id);
			$this->db->limit(1);
			$query = $this->db->get($table);

			if($query->num_rows() > 0)
			{
				return $query->row();
			}
			return false; // matching not found
		}
		// invalid input/s
		return false;
	}

	function deleteARecord($table, $id)
	{
		if(is_string($table) && is_numeric($id))
		{
			$this->db->where('id', $id);
			$this->db->limit(1);

			if($this->db->delete($table))
			{
				return true;
			}
			return false; // matching not found
		}
		// invalid input/s
		return false;
	}

	function deleteWhereRecord($table,$column, $id)
	{
		if(is_string($table) && is_numeric($id))
		{
			$this->db->where($column, $id);
			$this->db->limit(1);

			if($this->db->delete($table))
			{
				return true;
			}
			return false; // matching not found
		}
		// invalid input/s
		return false;
	}


function deleteWhereColumnRecord($table,$column, $id)
  {
    if(is_string($table) && is_numeric($id))
    {
      $this->db->where($column, $id);


      if($this->db->delete($table))
      {
        return true;
      }
      return false; // matching not found
    }
    // invalid input/s
    return false;
  }



	/**********************************************
	* $column {string} field name
	* $value {string|integer} we need unique value
	***********************************************/
	function checkARecord($table, $column, $value)
	{
		if(is_string($table) && is_string($column) && is_string($value) )
		{
			$this->db->where($column, $value);
			$this->db->limit(1);
			$query = $this->db->get($table);

			if($query->num_rows() > 0)
			{
				return $query->row();
			}

			return false; // record not found, it is not in database
		}

		return false; // invalid inputs
	}

	function getSpecifyRecords($table, $column, $column_value)
	{
		$this->db->where($column, $column_value);
		$this->db->order_by('id', 'asc');
		$query = $this->db->get($table);
		return $query->result();
	}

  function getWhereRecords($table, $where, $limit = false)
  {
    $this->db->where($where);
    $this->db->order_by('id', 'desc');
    $query = $this->db->get($table);

    if($limit) {
    	return $query->row();
    } else {
    	return $query->result();
    }
  }

  function getWhereInRecords($table, $colname, $colArr)
  {
    $this->db->where_in($colName, $colArr);
    $this->db->order_by('id', 'asc');
    $query = $this->db->get($table);
    return $query->result();
  }

  function getReport($table, $where, $orderColumn = 'id', $sort = 'desc', $limit = false)
  {
    $this->db->where($where);
    $this->db->order_by($orderColumn, $sort);
    $query = $this->db->get($table);

    if($limit) {
      return $query->row();
    } else {
      return $query->result();
    }
  }

	// same as getWhereRecords function
	function getJobs($table, $where)
	{
		$this->db->where($where);
		$query = $this->db->get($table);
		return $query->result();
	}

  	// same as getWhereRecords function
  	function getWhereOrderRecords($table, $where, $orderColumn = 'id', $sort = 'desc', $limit = false)
  	{
		$this->db->where($where);
		$this->db->order_by($orderColumn, $sort);
		$query = $this->db->get($table);

		if($limit) {
			return $query->row();
		} else {
			return $query->result();
		}
  	}

  	// Get data from single table
  	// With pagination
  	/*
		Usage of getQuestionsByFilter method in controller.
		--------------------------------------------------
        # Get latest listing

            // Set preferences for pagination
            $perPage = 12;
            $offset = getOffset($page, $perPage); // Set offset value
            $mylink = base_url($this->data['objType']->urlkey.'/'.$this->data['objCat']->urlkey.'/'.$this->data['objSubcat']->urlkey);

            $total = $this->my_model->getQuestionsByFilter($perPage, $offset, true, $this->tb_listing );
            $config['base_url'] = $mylink.'/p/';
            $config['uri_segment'] = 5;
            $config['num_links'] = 2;
            $config['total_rows'] = $total;
            $config['per_page'] = $perPage;
            $config['first_url'] = $mylink;

            $config['full_tag_open'] = '<ul class="page-numbers">';
            $config['next_link'] = '»';
            $config['prev_link'] = '«';
            $config['attributes'] = array('class' => 'page-numbers');

            $this->pagination->initialize($config);
            // end pagination

        $this->data['list_wanted'] = $this->my_model->getQuestionsByFilter($perPage, $offset, false, $this->tb_listing );
        $this->data['total'] = $total;
        $this->data['pagination'] = $this->pagination->create_links();
	*/
	function getQuestionsByFilter($perPage, $offSet=0, $totalrows, $tablename) {

		if(count($this->conditions)) {
			$this->db->where($this->conditions);
		}

		if($this->sortby && $this->orderby) {
			$this->db->order_by($this->sortby, $this->orderby);
		}

		if($totalrows) {

			$query = $this->db->get($tablename);
			return $query->num_rows(); // Get total count

		} else {
			$query = $this->db->get($tablename, $perPage, $offSet); // Get Array
		}

		/*echo '<hr>';
		echo $this->db->last_query();
		echo '<hr>';*/

		if($query->num_rows() > 0) {
			return $query->result();
		} else {
			return false;
		}
	}

  	// Get joined data from multiple table
  	// Without pagination
  	/*
		Usage of getJoinedRecords method in controller.
		--------------------------------------------------
        
        $fromTable = $this->tb_question;
        $join = array(
            array(
                'table' => $this->tb_test,
                'join_table_id' => $this->tb_test.'.id',
                'from_table_id' => $fromTable.'.testid',
                'join_type' => 'left'
            )
        );

        $select_columns = $fromTable.".*, ".$this->tb_test.".test_name";
        $conditions = array($fromTable.'.testid' => $this->data['test']->id, $fromTable.'.PTEsubtypeid' => $this->data['subtype']->id);

        $myData = $this->my_model->getJoinedRecords(
            $fromTable,
            $conditions,
            $select_columns,
            '',
            '',
            '',
            '',
            $join
        );

        if (!empty($myData)) {
            echo '<pre>';
            print_r($myData);
            echo '</pre>';
        }
  	*/
   function getJoinedRecords($tablename, $condition_array = array(), $data = '*', $sortby = '', $orderby = '', $limit = '', $offset = '', $join_str = array())
   {
		$this->db->select($data);
    	
    	// If Join_str array is not empty then implement the join query
		if (!empty($join_str)) {
		  	foreach ($join_str as $join) {
		      if ($join['join_type'] == '') {
		      	$this->db->join($join['table'], $join['join_table_id'] . '=' . $join['from_table_id']);
		      } else {
		         $this->db->join($join['table'], $join['join_table_id'] . '=' . $join['from_table_id'], $join['join_type']);
		      }
		  	}
		}

    	// Condition array pass to where condition
    	$this->db->where($condition_array);

    	// Setting Limit for Paging
		if ($limit != '' && $offset == 0) {
			$this->db->limit($limit);
		} else if ($limit != '' && $offset != 0) {
			$this->db->limit($limit, $offset);
		}
    
    	// Order by query
    	if ($sortby != '' && $orderby != '') {
      	$this->db->order_by($sortby, $orderby);
    	}

    	$query = $this->db->get($tablename);
    
    	// If limit is empty then returns total count
    	if ($limit == '') {
      	$query->num_rows();
    	}
    	
    	// If limit is not empty then return result array
    	return $query->result_array();
	}
	
	
  function getWhereOneRecords($table, $where)
  {
    $this->db->where($where);
    $query = $this->db->get($table);
    return $query->row();
   
  }
  
  
  function getWhereLastRecords($table, $where)
  {
    $this->db->limit(1);
	$this->db->where($where);
	$this->db->order_by('id','desc');
    $query = $this->db->get($table);
    return $query->row();
  }
  
   function getWhereOrderLimitRecords($table, $where, $orderColumn = 'id', $sort = 'desc', $limit = false,$start = false)
  	{
		$this->db->where($where);
		$this->db->order_by($orderColumn, $sort);
		$this->db->limit($limit, $start);
		$query = $this->db->get($table);
		return $query->result();
  	}
	
	
	/* var $table = 'employee';
    var $column_order = array(null, 'employee_name','employee_salary','employee_age'); //set column field database for datatable orderable
    var $column_search = array('employee_name','employee_salary','employee_age'); //set column field database for datatable searchable 
    var $order = array('id' => 'asc');  */// default order
	
	public function get_query()
    {
        $table = 'system_member_code';
		$column_order = array(null, 'id','email','username','coins'); //set column field database for datatable orderable
		$column_search = array('id','email','username','coins'); //set column field database for datatable searchable 
		$order = array('id' => 'asc'); 
		
		$this->db->from('system_member_code');
        $i = 0;
        foreach ($column_search as $emp) // loop column 
        {
			if(isset($_POST['search']['value']) && !empty($_POST['search']['value'])){
			$_POST['search']['value'] = $_POST['search']['value'];
		} else
			$_POST['search']['value'] = '';
		if($_POST['search']['value']) // if datatable send POST for search
		{
			if($i===0) // first loop
			{
				$this->db->group_start();
				$this->db->like(($emp), $_POST['search']['value']);
			}
			else
			{
				$this->db->or_like(($emp), $_POST['search']['value']);
			}

			if(count($column_search) - 1 == $i) //last loop
				$this->db->group_end(); //close bracket
		}
		$i++;
		}
		
		if(isset($_POST['order'])) // here order processing
		{
		$this->db->order_by($column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($order))
		{
		$order = $order;
		$this->db->order_by(key($order), $order[key($order)]);
		}
    }
	
	function get_employees()
    {
        $this->get_query();
		if(isset($_POST['length']) && $_POST['length'] < 1) {
			$_POST['length']= '10';
		} else
		$_POST['length']= $_POST['length'];
		
		if(isset($_POST['start']) && $_POST['start'] > 1) {
			$_POST['start']= $_POST['start'];
		}
        $this->db->limit($_POST['length'], $_POST['start']);
		$this->db->order_by('id', 'desc');
		//print_r($_POST);die;
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered()
    {
        $this->get_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from('system_member_code');
        return $this->db->count_all_results();
    }

}